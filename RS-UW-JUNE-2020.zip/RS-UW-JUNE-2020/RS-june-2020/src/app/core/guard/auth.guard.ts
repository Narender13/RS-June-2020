import { MessageService } from './../message/service/message.service';
import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { AuthService } from 'src/app/core/guard/services/auth.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
import { Observable } from 'rxjs';
import { map } from "rxjs/operators";
import { AppLoadService } from 'src/app/app-load.service';
@Injectable({
  providedIn: 'root'
})
export class AuthGuard {

  constructor(private router: Router,
    private userAutherizationService: UserAutherizationService,
    private authService: AppLoadService, private messageService: MessageService) { }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    return this.authService.checkUserExitAndIsActive().pipe(map((result) => {
      console.log(!result, 'auth-guard-result');
      if (!result) {
        this.router.navigate(['/accessdenied']);
        return false;
      } else {
        this.messageService.sendMessage({ 'isAuthorized': true, 'auth': true });
        return true;
      }
    }));

  }

}
