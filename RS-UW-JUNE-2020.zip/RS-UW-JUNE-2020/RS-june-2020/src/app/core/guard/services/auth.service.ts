import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { Response } from "@angular/http";
// import { Observable } from 'rxjs';
// import 'rxjs/add/operator/map';
import { Router } from '@angular/router';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { map, catchError } from 'rxjs/operators';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';

@Injectable()
export class AuthService {

  //readonly rootUrl = 'http://localhost:4200/assets/json/credentials.json';
  allowedroles: any = [];
  returndata: any;
  errormsg: string;
  constructor(private http: HttpClient, private router: Router, private adalSvc: MsAdalAngular6Service) { }

  login(userName: string, password: string) {

    let data: string = "username=" + userName + "&password=" + password + "&grant_type=password";
    let reqHeader: HttpHeaders = new HttpHeaders({ 'Content-Type': 'application/x-www-urlencoded', 'No-Auth': 'True' });
    return this.http.post(RSAENDPOINTConstants.LOGIN_INTERNAL, data, { headers: reqHeader }).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('login error')));
  }
  goHome() {
    this.router.navigateByUrl('/finance');
  }
  setAuthToken(data: any) {
    sessionStorage.setItem(RSAConstants.token, data.access_token);
  }
  getAuthToken(): string {
    return sessionStorage.getItem(RSAConstants.token);
    // return sessionStorage.getItem("userToken");

  }
  setRefreshToken(data: any) {
    sessionStorage.setItem(RSAConstants.token, data.refresh_token);
  }
  getRefreshToken(): string {
    return sessionStorage.getItem(RSAConstants.token);
  }
  clearAuthToken() {
    sessionStorage.removeItem(RSAConstants.token);
  }
  logout() {
    if (window.sessionStorage) {
      sessionStorage.removeItem(RSAConstants.token);
      sessionStorage.removeItem('userProfileObject');
      this.adalSvc.logout();
      sessionStorage.clear();
    }
    this.router.navigateByUrl('/login');
  }

  sendToken(token: string) {
    sessionStorage.setItem(RSAConstants.token, token);
  }
  getToken() {
    return sessionStorage.getItem(RSAConstants.token);
  }
  isLoggednIn() {
    //  console.log(sessionStorage.getItem('LoggedInUser'));
    if (sessionStorage.getItem(RSAConstants.token) !== null) {
      return true;
    } else {
      // console.log("false");
      return false;
    }
  }
  setUserInfo(userinfo: object) {
    sessionStorage.setItem('userProfileObject', JSON.stringify(userinfo));
    if (sessionStorage.getItem('userProfileObject')) {
      var userProfile = JSON.parse(sessionStorage.getItem('userProfileObject'));
      console.log("user profile info" + JSON.stringify(userProfile));
      //this.username=userProfile.userName;
      console.log("user name" + userProfile.userName);
      sessionStorage.setItem('userId', userProfile.userName);
      let username = userProfile.userName.split('.');
      var result = username[1].split('@');
      sessionStorage.setItem('userName', username[0] + ' ' + result[0]);
    }
  }

  getUserID() {
    return sessionStorage.getItem('userId');
  }
  getUserName() {
    return sessionStorage.getItem('userName');
  }


}
