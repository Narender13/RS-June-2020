import { environment } from 'src/environments/environment';

export const RSAUNDERWRITINGENDPOINTConstants = {
  USERLIMITS: `${environment.APP_BASE_HREF}udw/api/Lookup/Get?uwLookups=74`,
  UNDERWRTINGPOLICYHEADER: 'assets/json/coulmnHeaderPolicyNumberSearch.json',
  UNDERWRTINGCATDATA: 'assets/json/cat.json',
  UNDERWRTINGLOBDATA: `${environment.APP_BASE_HREF}udw/api/Lookup/Get?uwLookups=43`,
  UNDERWRTINGSEARCHROUTING: 'assets/json/search-route-underwriting.json',
  PRODUCTLOBDROPDOWN: 'assets/json/product-lob-dropdown.json',
  TRANSCATIONROUTINGDATA: 'assets/json/transcation-routing.json',
  TRANSCATIONGACCWCPTLROUTINGDATA: 'assets/json/transcaion-gacc-wctpl-risk.json',
  REAMINDERJSON: 'assets/json/reaminder.json',
  PROPERTYRATING: 'assets/json/rating.json',
  UNDERWRITINGPOLICYACCESS: 'assets/json/policytype.json',
  CEW: 'assets/json/cew.json',
  UNDERWRITINGSIDEMENU: 'assets/json/udw_sidemenu.json',
  MANAGAERISKDROPDOWN: 'assets/json/manage-risk-dropdown.json',
  MANAGAERISKDROPDOWNPROPERTY: 'assets/json/manage-risk-property.json',
  MANAGERISKGACCWCTPL: 'assets/json/manage-risk-gacc-wctpl.json',
  RISKSUMMARYDATA: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/Get?`,
  RISKSUMMARYDATACAREAR: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/GetEbldRiskSummary?`,
  GETREMINDER: `${environment.APP_BASE_HREF}udw/api/Reminder/Get?`,
  CREATEREMINDER: `${environment.APP_BASE_HREF}udw/api/Reminder/Post`,
  UPDATEREMINDER: `${environment.APP_BASE_HREF}udw/api/Reminder/Put`,
  GETDOSRISKSUMMARYDETAILS: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/GetDOSRiskSummary?`,
  GETDOSRISKDETAILS: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/GetDOSRiskDetails?`,
  RISKSUMMARYDATAEEI: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/GetEEIRiskSummary?`,
  // REMARKS
  GETREMARKS: `${environment.APP_BASE_HREF}udw/api/Remarks/Get?`,
  CREATEREMARKS: `${environment.APP_BASE_HREF}udw/api/Remarks/Post`,
  DELETEREMARKS: `${environment.APP_BASE_HREF}udw/api/Remarks/Delete?`,
  // POLICYTEXT
  GETPOLICYTEXT: `${environment.APP_BASE_HREF}udw/api/PolicyText/Get?`,
  CREATEPOLICYTEXT: `${environment.APP_BASE_HREF}udw/api/PolicyText/Post`,
  // RENEWAL
  SAVERENEWAL: `${environment.APP_BASE_HREF}udw/api/Renewal/Post`,
  // COPY POLICY
  SAVECOPYPOLICY: `${environment.APP_BASE_HREF}udw/api/CopyPolicy/Post`,
  // Underwriting policy Search and Policy History
  GETPOLICYLISTUW: `${environment.APP_BASE_HREF}udw/api/PolicySearch/Get?`,
  GETPOLICYHISTORYRESULT: `${environment.APP_BASE_HREF}udw/api/PolicyHistory/Get?`,
  GETPOLICYHISTORYRESULTCLAIM: `${environment.APP_BASE_HREF}udw/api/PolicyClaims/Get?`,
  GETPOLICYHISTORYRESULTCOLLECTION: `${environment.APP_BASE_HREF}udw/api/PolicyCollections/Get?`,
  GETPOLICYHISTORYRESULTDECLARATION: `${environment.APP_BASE_HREF}udw/api/PolicyDeclarations/Get?`,
  GETPOLICYHISTORYRESULTDECLARATIONPAGE: `${environment.APP_BASE_HREF}udw/api/PolicyDeclarations/GetHistory?`,
  EXPORTPOLICYHISTROY: `${environment.APP_BASE_HREF}udw/api/PolicyHistory/GET?`,
  CREATERECEIPT: `${environment.APP_BASE_HREF}udw/api/PolicyCollections/Post`,
  GETPOLICYHISTORYRESULTSERVER: `${environment.APP_BASE_HREF}udw/api/PolicyHistory/POST?`,
  UNDERWRITINGSAVEDOSENGINEERINGINFO: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/PostEngineeringDOSRisk`,
  GETUWSHEET: `${environment.APP_BASE_HREF}udw/api/Schedule/GET?`,
  GETRENEWAL: `${environment.APP_BASE_HREF}udw/api/Renewal/GET?`,
  // UnderWriting masters
  UNDERWRITINGADMINMASTERS: 'assets/json/underwriting-masters.json',
  GETUDWMASTERS: `${environment.APP_BASE_HREF}adm/api/UnderwritingMasters/Get?entityType=`,
  GETUDWMASTERSAPI: `${environment.APP_BASE_HREF}adm/api/UnderwritingMasters/Get?`,
  POSTUDWMASTERS: `${environment.APP_BASE_HREF}adm/api/UnderwritingMasters/`,
  DELETEUDWMASTERS: `${environment.APP_BASE_HREF}adm/api/UnderwritingMasters/Delete?entityType=`,
  GETCOUNTRYLIST: `${environment.APP_BASE_HREF}adm/api/UnderwritingMasters/Get?entityType=`,
  // POSTCOUNTRYREGION: `${environment.APP_BASE_HREF}adm/api/UnderwritingMasters/`,

  // underwrting reports
  // Reports dropdown
  GENERATERENEWALNOTICEDIRECTREPORT: `${environment.APP_BASE_HREF}udw/api/DailyReports/POST?`,
  // GENERATERENEWALNOTICEDIRECTREPORT : `http://localhost:61025/api/DailyReports/POST?`,

  REPORTSLIST: 'assets/json/underwritingReports.json',
  POLICYTEXT: 'assets/json/policytext.json',
  GETREPORTSDROPDOWNS: `${environment.APP_BASE_HREF}udw/api/Lookup/Get?`,
  GETCOUNTRY: `${environment.APP_BASE_HREF}udw/api/Lookup/Get?uwLookups=80`,
  // Reports URLs
  REPORTSDUBAI: `https://blrrsqldbd01/ReportServer/Pages/ReportViewer.aspx?/Jupiter/Underwriting/Dubai/`,
  REPORTSABUDHABI: `https://blrrsqldbd01/ReportServer/Pages/ReportViewer.aspx?/Jupiter/Underwriting/AbuDhabi/`,
  REPORTSSHARJAH: `https://blrrsqldbd01/ReportServer/Pages/ReportViewer.aspx?/Jupiter/Underwriting/Sharjah/`,
  REPORTSOMAN: `https://blrrsqldbd01/ReportServer/Pages/ReportViewer.aspx?/Jupiter/Underwriting/OMAN/`,
  REPORTSKSA: `https://blrrsqldbd01/ReportServer/Pages/ReportViewer.aspx?/Jupiter/Underwriting/KSA/`,
  REPORTSBAHRAIN: `https://blrrsqldbd01/ReportServer/Pages/ReportViewer.aspx?/Jupiter/Underwriting/BAHRAIN/`,

  // Daily reports
  DUBAIDAILYREPORTS: `https://blrrsqldbd01/ReportServer/Pages/ReportViewer.aspx?/Jupiter/Underwriting/Dubai/Daily Report`,
  ABUDHABIDAILYREPORTS: `https://blrrsqldbd01/ReportServer/Pages/ReportViewer.aspx?/Jupiter/Underwriting/AbuDhabi/Daily Report`,
  SHARJAHDAILYREPORTS: `https://blrrsqldbd01/ReportServer/Pages/ReportViewer.aspx?/Jupiter/Underwriting/Sharjah/Daily Report`,
  GETRENEWALPROCESS: `${environment.APP_BASE_HREF}udw/api/QuoteGeneration/get?`,
  BATCHPROCESSING: `${environment.APP_BASE_HREF}udw/api/QuoteGeneration/POST?`,
  GENERATEQUOTE: `${environment.APP_BASE_HREF}udw/api/QuoteGeneration/POST`,
  // Enquiry report
  ENQUIRYREPORT: `${environment.APP_BASE_HREF}udw/api/ReportEnquiry/Get?`,
  // underwriting Lookups
  UNDERWRITINGTRNSACTIONLOOKUP: `${environment.APP_BASE_HREF}udw/api/Lookup/Get?`,
  UNDERWRITINGENGINEERINGRISK: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/Get?`,
  UNDERWRITINGTRNSACTIONLOOKUPINSURED: `${environment.APP_BASE_HREF}udw/api/Insured/Get?`,
  UNDERWRITINGADDINSURED: `${environment.APP_BASE_HREF}udw/api/Insured/Post`,
  UNDERWRITINGREMARKSPOST: `${environment.APP_BASE_HREF}udw/api/Remarks/Post`,
  UNDERWRITINGGETINSURED: `${environment.APP_BASE_HREF}udw/api/Insured/Get?`,
  UNDERWRITINGSAVEPOLICYINFO: `${environment.APP_BASE_HREF}udw/api/PolicyInfo/Post`,
  UNDERWRITINGSAVERISKINFO: `${environment.APP_BASE_HREF}udw/api/PropertyRisk/Post`,
  UNDERWRITINGSAVECPEENGGRISKINFO: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/Post`,
  UNDERWRITINGSAVEENGGCAREARRISKINFO: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/PostEbldRisk`,
  UNDERWRITINGSAVEENGGEEIRISKINFO: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/PostElectronicEqRisk`,
  UNDERWRITINGGETPOLICYINFO: `${environment.APP_BASE_HREF}udw/api/PolicyInfo/Get?`,
  UNDERWRITINGOUTPUTSPOST: `${environment.APP_BASE_HREF}udw/api/Schedule/Post`,
  UNDERWRITINGOUTPUTSPOSTINS: `${environment.APP_BASE_HREF}udw/api/Schedule/Post?`,
  UNDERWRITINGGETPOLICYLEVELFLOATINGBI: `${environment.APP_BASE_HREF}udw/api/FloaterBI/GET?`,
  UNDERWRITINGGETPOLICYLEVELFLOATINGMBLOP: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/GetBIDetails?`,
  CRMPOLICYINFO: `${environment.APP_BASE_HREF}udw/api/CrmPolicy/Get?`,
  QUOPOLICYINFO: `${environment.APP_BASE_HREF}udw/api/Renewal/Get?`,
  SENDTOCRMPOST: `${environment.APP_BASE_HREF}udw/api/CrmPolicy/Post`,
  UNDERWRITINGGETCRM: `${environment.APP_BASE_HREF}udw/api/CrmPolicy/Get?`,
  // transcation api
  CEWPOST: `${environment.APP_BASE_HREF}udw/api/ConditionsExclusionsWarranty/POST`,
  GETCEW: `${environment.APP_BASE_HREF}udw/api/ConditionsExclusionsWarranty/GET?`,
  DELETECEW: `${environment.APP_BASE_HREF}udw/api/ConditionsExclusionsWarranty/DELETE?`,
  GETRATINGGRIDDATA: `${environment.APP_BASE_HREF}udw/api/Lookup/GetRatingTabConent?`,
  GETRATINGDETAILS: `${environment.APP_BASE_HREF}udw/api/Rating/POSTRating?`,
  GETENGINEERINGRATINGDETAILS: `${environment.APP_BASE_HREF}udw/api/Rating/POSTEngineeringRating?`,
  SAVERATING: `${environment.APP_BASE_HREF}udw/api/Rating/POST`,
  GETPREMIUMFUNCTIONRATING: `${environment.APP_BASE_HREF}udw/api/Lookup/Get?uwLookups=64`,
  GETSITYPE: `${environment.APP_BASE_HREF}udw/api/Lookup/Get?uwLookups=54`,
  PRINTOUTPUTS: `${environment.APP_BASE_HREF}udw/api/Schedule/Post?periodCheck=`,
  SAVEPOLICYTAXATION: `${environment.APP_BASE_HREF}udw/api/PolicyHistory/POST`,
  GETMOTORRISKSUMMARY: `${environment.APP_BASE_HREF}udw/api/MotorRisk/Get?`,
  // RISKSUMMARYDATACAREAR: 'assets/json/underWriting_car_ear_risk.json',
  GETRISKSUMMARY: `${environment.APP_BASE_HREF}udw/api/PropertyRisk/Get?`,
  GETRISKBYID: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/GetRiskDetails?`,
  DELETERISK: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/Delete?`,
  GETTERRITORY: `${environment.APP_BASE_HREF}udw/api/Lookup/Get?uwLookups=62`,
  EXPORTRISK: `${environment.APP_BASE_HREF}udw/api/ExportPropertyRisk/GET?`,
  // Open Cover
  SAVEOPENCOVER: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/PostEngOpenCover`,
  GETOPENCOVER: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/Get?`,
  DELETEOPENCOVER: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/DeleteOpenCover?`,

  GETRISKSUMMARYMARINIHULL: `${environment.APP_BASE_HREF}udw/api/MarineHull/GetMarineHullRiskSummary?`,

  // Floater BI
  SAVEFLOATERBI: `${environment.APP_BASE_HREF}udw/api/FloaterBI/POST`,
  SAVEFLOATERBIENG: `${environment.APP_BASE_HREF}udw/api/FloaterBI/POSTEngBI`,
  GETFLOATERBI: `${environment.APP_BASE_HREF}udw/api/FloaterBI/GET?`,

  // POLICY EXCESS
  GETPOLICYEXCESS: `${environment.APP_BASE_HREF}udw/api/PolicyExcess/GET?`,
  SAVEPOLICYEXCESS: `${environment.APP_BASE_HREF}udw/api/PolicyExcess/POST`,

  // marine hull api
  MARINIHULLRISKLOOKUP: `${environment.APP_BASE_HREF}udw/api/Lookup/Get?`,
  MARINIHULLGETRISKDETAIL: `${environment.APP_BASE_HREF}udw/api/MarineHull/Get?`,
  SAVEMARINHULLDETAIL: `${environment.APP_BASE_HREF}udw/api/MarineHull/Post?`,
  DELETEMARINHULLRISK: `${environment.APP_BASE_HREF}udw/api/MarineHull/Delete?`,

  // GETFLOATERBI: `${environment.APP_BASE_HREF}udw/api/FloaterBI/GET?`,
  // My Tasks
  GETTASKAPPROVAL: `${environment.APP_BASE_HREF}udw/api/TaskApproval/GET?`,
  SAVETASKAPPROVAL: `${environment.APP_BASE_HREF}udw/api/TaskApproval/POST`,

  // POLICY PRICING
  PRICINGDROPDOWNS: `${environment.APP_BASE_HREF}udw/api/Lookup/Get?`,
  GETPOLICYPRICING: `${environment.APP_BASE_HREF}udw/api/PolicyPricing/GET?`,
  SAVEPOLICYPRICING: `${environment.APP_BASE_HREF}udw/api/PolicyPricing/POST`,
  // Task Reminders
  GETTASKREMINDERS: `${environment.APP_BASE_HREF}udw/api/TaskReminder/Get`,
  // Delete Properrty Risk
  DELETEPROPERTYRISK: `${environment.APP_BASE_HREF}udw/api/PropertyRisk/Post?`,

  // Floater BI Engginerring
  SAVEFLOATERENGGBI: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/POSTEngBI`,
  // Endorsement Text
  ENDORSEMENTTEXT: `${environment.APP_BASE_HREF}udw/api/EndorsementText/Get?`,
  ENDORSEMENTSAVE: `${environment.APP_BASE_HREF}udw/api/EndorsementText/Post`,
  // Cancel Policy
  CANCELPOLICY: `${environment.APP_BASE_HREF}udw/api/Cancellation/Post`,

  // AttachMBDPolicyNoToDOS
  SaveAttachMBDPolicNoToDOS: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/PostAttachMBDPolicyNoToDOS`,
  GETAttachMBDPolicyNoToDOS: `${environment.APP_BASE_HREF}udw/api/EngineeringRisk/GetAttachedMBDPolicyNoToDOS?`,

  // Motor
  UNDERWRITINGMOTORLOOKUP: `${environment.APP_BASE_HREF}udw/api/Lookup/Get?`,
  UNDERWRITINGMOTORRISKPOST: `http://localhost:61025/api/MotorRisk/Post`,

  //wctpl
  WCTPLWCELLOOKUP: `${environment.APP_BASE_HREF}udw/api/Lookup/Get?`,
  GETWCELNAMEDPERSON: `${environment.APP_BASE_HREF}udw/api/WorkmenEmployer/GetWCELNamedPerson?`,
  GETWCELUNNAMEDPERSON: `${environment.APP_BASE_HREF}udw/api/WorkmenEmployer/GetWCELUnNamedPerson?`


};
