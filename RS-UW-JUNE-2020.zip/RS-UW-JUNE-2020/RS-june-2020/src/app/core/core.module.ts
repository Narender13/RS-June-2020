import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { Page404Component } from './page404/page404.component';
import { Page401Component } from './page401/page401.component';
import { httpInterceptorProviders } from 'src/app/core/interceptor';
import { TechnicalErrorComponent } from 'src/app/core/technicalError/technicalerror.component';
import { MessageService } from 'src/app/core/message/service/message.service';
import { AuthService } from 'src/app/core/guard/services/auth.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
import { AuthInterceptor } from 'src/app/core/interceptor/auth-interceptor';

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CommonModule,
    HttpModule,
    HttpClientModule,    
  ],
  declarations: [
    Page404Component,
    Page401Component,
    TechnicalErrorComponent
  ],
  providers: [
    httpInterceptorProviders,
    MessageService,
    AuthService,  
    UserAutherizationService  
  ],
  exports: [
    Page404Component,
    Page401Component
  ]

})
export class CoreModule { }
