﻿import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { Injectable, Injector } from "@angular/core";

@Injectable({
    providedIn: 'root'
})
export class HeaderInterceptor {

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const httpReq = req.clone({
            headers: new HttpHeaders({
                'Content-Type': 'application/json; charset=utf-8',
                'Access-Control-Allow-Headers': 'Content-Type,Origin,content-type',
                'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Origin': '*',
                'locCode': sessionStorage.getItem('locationcode')
            })
        });
        console.log(sessionStorage.getItem('locationcode'));
        if (req.url.includes('assets/json/')) {
            return next.handle(req);
        } else {
            return next.handle(httpReq);
        }
    }
}