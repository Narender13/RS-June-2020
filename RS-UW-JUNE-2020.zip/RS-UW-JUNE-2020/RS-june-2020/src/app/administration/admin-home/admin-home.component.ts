import { Component, OnInit, ViewChild, Output, EventEmitter, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { AdminMastersService } from './../services/admin-masters.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
import { TabsetComponent, TabDirective } from 'ngx-bootstrap/tabs';
import { Router } from '@angular/router';
import { UwMastersService } from '../underwriting-masters/services/uw-masters.service';
import { Subscription } from 'rxjs';
import { AdminMasters } from './../services/admin-entity';
import { UWSubmenu } from './../underwriting-masters/entity/uw-masters';
@Component({
  selector: 'rsa-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.scss']
})
export class AdminHomeComponent implements OnInit, OnDestroy {
  @ViewChild('master') master: TabDirective;
  // @Output() UWMasters = new EventEmitter();
  adminMasters: AdminMasters[] = [];
  uwList: UWSubmenu[] = [];
  username: string;
  welcomeInfo: any = { 'welcomeMsg': 'HELLO!', 'msg1': 'what do you want to analyse', 'msg2': 'today?' };
  private selectedIndex = 0;
  private subscription: Subscription = new Subscription();
  constructor(private _service: AdminMastersService, private umservice: UwMastersService,
    private allowAccess: UserAutherizationService, private router: Router) { }

  ngOnInit() {
    this.getAdminUrlsList();
    this.getUWMastersList();
    this.username = sessionStorage.getItem('userName');
  }
  getAdminUrlsList() {
    this.subscription.add(this._service.getAdminUrlsList().subscribe((adminMastersdata) => {
      this.adminMasters = adminMastersdata;
    }));
  }

  getUWMastersList() {
    this.subscription.add(this.umservice.getUnderWritingMastersList().subscribe((uwMastersData) => {
      this.uwList = uwMastersData.submenu;
      this.processUWList();
    }));
  }
  viewMasters(evt) {

  }
  commonMasters(name: string) {
    this.router.navigate(['/admin']);
  }
  displayMenuItem(functionid) {
    return this.allowAccess.isAllowed(functionid);
  }
  displayUWMenuItem(functionid){
    let isAllowed:boolean = this.allowAccess.isAllowed(functionid);
    return isAllowed;
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  processUWList(){
    var thisScope = this;
    this.uwList.forEach(function (element) {
      if (element.data !=null) {
          for (var functionID = element.data.minRange; functionID <= element.data.maxRange; functionID++){
            let isAllowed:boolean = thisScope.allowAccess.isAllowed(functionID);
            if(isAllowed===true){              
              element.isDisabled = false;
              break;
            }
          }
      }
    });
  }

}
