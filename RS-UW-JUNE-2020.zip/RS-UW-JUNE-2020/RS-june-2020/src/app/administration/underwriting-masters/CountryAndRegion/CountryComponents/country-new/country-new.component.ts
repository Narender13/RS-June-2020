import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {CountryDetails} from 'src/app/administration/underwriting-masters/CountryAndRegion/CountryComponents/model/CountryDetails';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { UwMastersService } from 'src/app/administration/underwriting-masters/services/uw-masters.service';


@Component({
  selector: 'rsa-country-new',
  templateUrl: './country-new.component.html',
  styleUrls: ['./country-new.component.scss']
})
export class CountryNewComponent implements OnInit {

  countryEditForm: FormGroup;
  chartDetails: CountryDetails;
  updatedDetails: CountryDetails;
  //saveDetailsObject: CountryDetails[];
  uwMaster: string = "Country";
  @Input() isEdit: boolean;
  @Input() EditData: CountryDetails;

  @Output() cancelClick = new EventEmitter();
  constructor(private formBuilder: FormBuilder, private alertService: AlertService, private _uwMasterService: UwMastersService) { }

  ngOnInit() {
    this.chartDetails = new CountryDetails();

    this.createCountryForm();
    if (this.isEdit) {
      this.chartDetails = this.EditData;

      this.fillEditData();
  }
  }
  createCountryForm(): void {
    this.countryEditForm = this.formBuilder.group({
      Code: [null],
      EnglishDescription: [null],
      ArabicDescription: [null],
      EnglishShortDescription: [null],
      NationalityEngDescription: [null],
      NationalityArabicDescription: [null],
      Zone: [null],
      DialCode: [null]
    });
  }
  get Code() { return this.countryEditForm.controls['Code']; }
  get EnglishDescription() { return this.countryEditForm.controls['EnglishDescription']; }
  get ArabicDescription() { return this.countryEditForm.controls['ArabicDescription']; }
  get EnglishShortDescription() { return this.countryEditForm.controls['EnglishShortDescription']; }
  get NationalityEngDescription() { return this.countryEditForm.controls['NationalityEngDescription']; }
  get NationalityArabicDescription() { return this.countryEditForm.controls['NationalityArabicDescription']; }
  get Zone() { return this.countryEditForm.controls['Zone']; }
  get DialCode() { return this.countryEditForm.controls['DialCode']; }

  formControlAddValidator() {
    this.Code.setValidators([Validators.required]);
    this.Code.updateValueAndValidity();
    this.EnglishDescription.setValidators([Validators.required]);
    this.EnglishDescription.updateValueAndValidity();
    this.ArabicDescription.setValidators([Validators.required]);
    this.ArabicDescription.updateValueAndValidity();
    this.EnglishShortDescription.setValidators([Validators.required]);
    this.EnglishShortDescription.updateValueAndValidity();
    this.NationalityEngDescription.setValidators([Validators.required]);
    this.NationalityEngDescription.updateValueAndValidity();
    this.NationalityArabicDescription.setValidators([Validators.required]);
    this.NationalityArabicDescription.updateValueAndValidity();
    this.Zone.setValidators([Validators.required]);
    this.Zone.updateValueAndValidity();
    this.DialCode.setValidators([Validators.required]);
    this.DialCode.updateValueAndValidity();
}
 fillEditData() {
      this.countryEditForm.patchValue({
        Code: this.chartDetails.Code,
        EnglishDescription: this.chartDetails.EnglishDescription,
        ArabicDescription: this.chartDetails.ArabicDescription,
        EnglishShortDescription: this.chartDetails.EnglishShortDescription,
        NationalityEngDescription: this.chartDetails.NationalityEngDescription,
        NationalityArabicDescription: this.chartDetails.NationalityArabicDescription,
        Zone: this.chartDetails.Zone,
        DialCode: this.chartDetails.DialCode
      });
}
saveValues(): void {
  const saveDetailsObject  = [this.countryEditForm.value]
  if (this.isEdit) {
    let val = JSON.stringify(saveDetailsObject);
    this._uwMasterService.postUnderWritingMasters(this.uwMaster, saveDetailsObject).subscribe(  dataReturn => {
      this.alertService.success('Data updated successfully.');
      this.cancelClick.emit();
      return true;
    },
    errorRturn => {
      this.alertService.error('something went wrong');
      return false;
    });
 }
  else {
  this.alertService.error('Error in updating Country Details.');
}
}
cancel() {
    this.cancelClick.emit();
}

}


