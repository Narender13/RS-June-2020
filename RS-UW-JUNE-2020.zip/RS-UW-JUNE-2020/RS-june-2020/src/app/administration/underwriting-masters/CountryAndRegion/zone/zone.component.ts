import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AgGridNg2 } from 'ag-grid-angular';

import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { AgGridAdminEditViewButtonComponent } from 'src/app/administration/admin-masters/ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { AgCustomTextComponent } from 'src/app/shared/ag-custom-text/ag-custom-text.component';
import { AgCustomHeaderComponent } from 'src/app/shared/ag-custom-header/ag-custom-header.component';
import { ActionButtonComponent } from '../../shared/action-button/action-button.component';
import { UwMastersService } from 'src/app/administration/underwriting-masters/services/uw-masters.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { CountryRegDetails } from '../model1/Contryregion';
import { GridApi, ColumnApi } from 'ag-grid-community';
import { Commonfunctions } from '../model1/CommonFunction';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
import { Router } from '@angular/router';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';

@Component({
  selector: 'rsa-zone',
  templateUrl: './zone.component.html',
  styleUrls: ['./zone.component.scss']
})
export class ZoneComponent extends Commonfunctions implements OnInit {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridApi: GridApi;
  gridColumnApi: ColumnApi;
  //paginationOptions: TextValuePair[] = [];
  rowData: CountryRegDetails[] = [];
  columnDefs: Array<object> = [];
  domLayout : string;
  
  gridConfiguration: GridOptions = {};
  frameworkComponents ={};
  editingRowIndex: number;
  suppressClickEdit: boolean;
  currentEditRow: CountryRegDetails;
  ModifiedBy: string;
  PreparedBy: string;
  isRowEditing: boolean = false;
  selectedRowIndex;
  startValue: number;
  endValue: number;
  totalRecords: number;
  currentPage: number;
  totalPages: number;
  isDisableFirst: boolean;
  isDisableLast: boolean;
  uwMaster: string ="Zone";
  PostData: any = [];

  constructor(private _uwMasterService: UwMastersService,public modalService: BsModalService,public bsModalRef: BsModalRef, private allowAccess: UserAutherizationService , private alertService: AlertService, public router: Router) {super(router); }

  ngOnInit() {
    this.columnDefs = [

      {
          headerName: 'Code', field: 'Code', sortable: true, filter: 'agTextColumnFilter', editable: false,
      },
      { headerName: 'English Description', field: 'EnglishDescription', sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput', maxLength: 40 },
      {
          headerName: 'الوصف العربي', field: 'ArabicDescription', sortable: true, filter: 'agTextColumnFilter', arabicDesc: true, headerClass: 'ag-rtl', cellClass: 'ag-rtl text-right', editable: true, cellEditor: 'agTextInput', maxLength: 40,

      },
      {
        headerName: 'Short Description English', field: 'EngShortDescription', sortable: true, filter: 'agTextColumnFilter', arabicDesc: true, headerClass: 'ag-rtl', cellClass: 'ag-rtl text-right', editable: true, cellEditor: 'agTextInput', maxLength: 40,

    },
      {
          headerName: 'Action',
          field: 'value',
          cellRendererFramework: ActionButtonComponent,
          cellRendererParams: {
              inActoionLink: 'InstrumentTypes',
              isEditAllowed:this.allowAccess.isAllowed(2302),
              isDeleteAllowed:this.allowAccess.isAllowed(2500)
          },
          colId: 'editSaveBtn',
          filter: 'none',
          headerClass: 'hidefilter'
      }
    ];
    
    
    this.frameworkComponents = { agTextInput: AgCustomTextComponent, agCustomHeaderComponent: AgCustomHeaderComponent, };
    this.GetcolumnDefs();
    this.suppressClickEdit = true;
  }
  GetcolumnDefs() {
    this.gridConfiguration = <GridOptions>{
        columnDefs: this.columnDefs,
        rowSelection: 'multiple',
        postProcessPopup: function (params) {
            const ePopup = params.ePopup;
            ePopup.style.top = '14.9838px';
        },
        rowData: this.rowData,
        rowHeight: 40,
        headerHeight: 40,
        pagination: true,
        floatingFiltersHeight: 40,
        paginationPageSize: 20,
        enableRangeSelection: true,
        rowMultiSelectWithClick: true,
        animateRows: true,
        enableColResize: true,
        enableFilter: true,
        suppressContextMenu: true,
        enableSorting: true,
        editType: 'cel',
        defaultColDef: {
            enableRowGroup: false,
            enableValue: true,
            suppressMovable: true,
            minWidth: 30,
            menuTabs: ['filterMenuTab', '', ''],
            headerComponent: 'agCustomHeaderComponent',
            headerComponentParams: {
                menuIcon: 'fa-bars'
            },
        },
        context: {
            componentParent: this
        },
    };
    this.getZoneDetails();
  }
  getZoneDetails(): any {
    this._uwMasterService.getCountryRegionDetails(this.uwMaster).subscribe((data) => {
      this.rowData = data;
      this.totalRecords = this.rowData.length;
      console.log(data, this.rowData);
  });
  }
  
  setRowData() {
    this.gridConfiguration.api.setRowData(this.rowData);
    this.gridApi.paginationGoToPage(0);
  }

  onParentCancel(rowIndex) {
    this.gridApi.stopEditing();
    let selRowData = this.rowData[rowIndex];
    if (selRowData.isNewRow) {
        this.rowData.splice(rowIndex, 1);
    }
    else {
        this.currentEditRow.editMode = false;
        this.rowData[rowIndex] = this.currentEditRow;
    }
    this.gridConfiguration.api.setRowData(this.rowData);
    this.gridApi.paginationGoToPage(0);
    this.suppressClickEdit = true;
    this.isRowEditing = false;
  }
  setAutoHeight() {
    setTimeout(() => {
        this.gridApi.setDomLayout('autoHeight');
    }, 200);
  
  }
  addNewRow(): any {
    let editedData = this.rowData.filter(data => data.editMode === true && data.isNewRow === true);
    if (editedData.length > 0) {
      //this.alertService.warn('Please save/cancel the data which already added.');
    }
    else {
      let newItem = { Code: 0, EnglishDescription: '', ArabicDescription: '', isNewRow: true, editMode: true,ModifiedBy:null, PreparedBy: sessionStorage.getItem('LoggedInUserId') };
      this.rowData.push(newItem);
      this.gridConfiguration.api.setRowData(this.rowData);
      this.gridApi.paginationGoToPage(0);
      this.onParentEditClicked(this.rowData.length - 1);
    }
  }
  ngAfterViewInit() {
    this.fitToCoulmn();
    this.setAutoHeight();
  }
  fitToCoulmn() {
    setTimeout(() => {
        this.gridApi.sizeColumnsToFit();
    }, 200);
  }
  onGridReady(params) {
    console.log(params, 'params');
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridConfiguration.api.setRowData(this.rowData);
    params.api.paginationGoToPage(0);
    this.fitToCoulmn();
  }


  onParentSaveClicked(id, rowIndex) {
    
    this.gridApi.stopEditing();
    const updatedData = this.rowData.filter(data => data.Code === id);
    this.PostData.push(updatedData);
    if (updatedData.length > 0) {
      const validate = this.validateData(updatedData[0]);
      if (validate === '') {
        const entityType = this.uwMaster;
        if (updatedData[0].isNewRow === true) {
  
          this._uwMasterService.postCountryRegionMasters(entityType, updatedData).subscribe(
            dataReturn => {
              this.alertService.success('Data saved successfully.');
              this.isRowEditing = false;
              this.getZoneDetails();
              return true;
              // }
            },
            errorRturn => {
              this.alertService.error('something went wrong');
              this.editRowData(rowIndex, 'EnglishDescription');
              return false;
            }
          );
        } else {
          updatedData[0].ModifiedBy = sessionStorage.getItem('LoggedInUserId');
          this._uwMasterService.postCountryRegionMasters(entityType, updatedData).subscribe(
            dataReturn => {
              this.alertService.success('Data updated successfully.');
              updatedData[0].editMode = false;
              this.isRowEditing = false;
              this.getZoneDetails();
              return true;
            },
            errorRturn => {
              this.alertService.error('something went wrong');
              this.editRowData(rowIndex, 'EnglishDescription');
              return false;
            }
          );
        }
      } else {
        this.editRowData(rowIndex, validate);
        return false;
      }
  
    }
  }
  onParentDeleteClicked(uwMaster, id) {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    const param = this.uwMaster + '&id=' + id;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = RSAMSGConstants.BTNPROCEED) {
        this._uwMasterService.deleteUnderWritingMasters(param).subscribe(
          dataReturn => {
            this.alertService.success('Data deleted successfully.');
            this.getZoneDetails();
          },
          errorRturn => {
            console.log(errorRturn);
          }
        );
      }
    });
  }
  displayModifybutton(functionid) {

    return this.allowAccess.isAllowed(functionid);
  }

}
