import { Component,  OnInit, ViewChild, AfterViewInit, Output, EventEmitter } from '@angular/core';
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { GridApi, ColumnApi } from 'ag-grid-community';
import { UwMastersService } from 'src/app/administration/underwriting-masters/services/uw-masters.service';

import { AgCustomTextComponent } from 'src/app/shared/ag-custom-text/ag-custom-text.component';
import { EditViewCellComponent } from 'src/app/administration/admin-masters/coa/edit-view-cell/edit-view-cell.component';
import { AgCustomDateComponent } from 'src/app/shared/ag-custom-date/ag-custom-date.component';
import { AgGirdCustomDateFilterComponent } from 'src/app/shared/ag-gird-custom-date-filter/ag-gird-custom-date-filter.component';
import { CountryRegDetails } from '../../model1/Contryregion';
import { CountryRegionComponent } from '../../../country-region/country-region.component';
import { Router } from '@angular/router';




@Component({
  selector: 'rsa-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.scss']
})
export class CountryComponent  implements OnInit {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridApi: GridApi;
  gridColumnApi: ColumnApi;
  domLayout: string;
  gridConfiguration: GridOptions = {};
  frameworkComponents = {};
  totalRecords: number;
  uwMaster:string = "Country";
  rowData: CountryRegDetails[] = [];
  @Output() selectedRowDetails = new EventEmitter();

     columnDefs = [

       {headerName: 'Code', field: 'Code', width: 80, sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput'},
       {headerName: 'DescriptionEng' , field: 'EnglishDescription' },
       {headerName: 'DescriptionArabic' , field: 'ArabicDescription'},
       {headerName: 'ShortDescription(english)' , field: 'EnglishShortDescription', sortable: true, filter: 'agTextColumnFilter',width: 120},
       {headerName: 'NationalityDescription(engilsh)' , field: 'NationalityEngDescription', sortable: true, filter: 'agTextColumnFilter'},
       {headerName: 'NationalityDescription(arabic)' , field: 'NationalityArabicDescription', sortable: true, filter: 'agTextColumnFilter'},
       {headerName: 'Zone' , field: 'Zone', sortable: true, filter: 'agTextColumnFilter', width: 100 },
       {headerName: 'DialCode' , field: 'DialCode', sortable: true, filter: 'agTextColumnFilter', width: 100},
       {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: EditViewCellComponent,
        cellRendererParams: {
          inActoionLink: 'coList'
        },
        filter: 'none',
        headerClass: 'hidefilter',
        width: 200,
        supressSizeToFit: true
      }];
   
  GetcolumnDefs() {
    this.gridConfiguration = <GridOptions>{
        columnDefs: this.columnDefs,
        
        postProcessPopup: function (params) {
            const ePopup = params.ePopup;
            ePopup.style.top = '14.9838px';
        },
        rowData: this.rowData,
        rowHeight: 40,
        headerHeight: 40,
        pagination: true,
        floatingFiltersHeight: 40,
        paginationPageSize: 20,
        enableRangeSelection: true,
        rowSelection: 'multiple',
        rowMultiSelectWithClick: true,
        animateRows: true,
        enableColResize: true,
        enableFilter: true,
        enableSorting: true,
        suppressContextMenu: true,
        masterDetail: true,
        //editable: true,
        //editType: 'cel',
        detailRowHeight: 200,
        defaultColDef: {
          enableRowGroup: false,
          enableValue: true,
          suppressMovable: true,
          minWidth: 40,
          menuTabs: ['filterMenuTab', '', '']
     
        },
        context: {
          componentParent: this
        }
        
    };
}
onGridReady(params) {
  console.log(params, 'params');
  this.gridApi = params.api;
  this.gridColumnApi = params.columnApi;
   this.gridConfiguration.api.setColumnDefs(this.columnDefs);
   this.gridConfiguration.api.setRowData(this.rowData);
  params.api.paginationGoToPage(0);
 // this.fitToCoulmn();
}
  constructor(private _uwMasterService: UwMastersService, public router: Router) { }

  ngOnInit() {
    this.GetcolumnDefs();
    this.getCountryDetails();
    this.frameworkComponents = { agTextInput: AgCustomTextComponent,
       agInputDate: AgCustomDateComponent, agDateInput: AgGirdCustomDateFilterComponent };
  }
  getCountryDetails(): any {
    this._uwMasterService.getCountryRegionDetails(this.uwMaster).subscribe((data) => {
        this.rowData = data;
        this.totalRecords = this.rowData.length;
        console.log(data, this.rowData);
    });
}
  onParentEditClicked(val: any) {
    let nodeData: CountryRegDetails = val.data;
    const vocherEmitedDetails = {
      OperationType: 'Edit',
      currentRowData: nodeData
    };
    this.selectedRowDetails.emit({
      vocherEmitedDetails
    });
  }
  onParentViewClicked(param: any) {
    let text = param.text;
    let node = param.rowData.node;
    if (text == 'Hide') {
      node.setExpanded(true);
    }
    else {
      node.setExpanded(false);
    }

  }
  onParentDeleteClicked(param: any) {
    let text = param.text;
    let node = param.rowData.node;
    if (text == 'Hide') {
      node.setExpanded(true);
    }
    else {
      node.setExpanded(false);
    }

  }

}
