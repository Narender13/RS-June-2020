import { Component, OnInit, ViewChild, AfterViewInit,  Output, EventEmitter } from '@angular/core';
import { UwMastersService } from 'src/app/administration/underwriting-masters/services/uw-masters.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AgGridNg2 } from 'ag-grid-angular';
import { Location } from './../model/location';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { AgGridAdminEditViewButtonComponent } from 'src/app/administration/admin-masters/ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { AgCustomTextComponent } from 'src/app/shared/ag-custom-text/ag-custom-text.component';
import { AgCustomHeaderComponent } from 'src/app/shared/ag-custom-header/ag-custom-header.component';

import { EditViewCellComponent } from 'src/app/administration/admin-masters/coa/edit-view-cell/edit-view-cell.component';
import { AgCustomDateComponent } from 'src/app/shared/ag-custom-date/ag-custom-date.component';
import { AgGirdCustomDateFilterComponent } from 'src/app/shared/ag-gird-custom-date-filter/ag-gird-custom-date-filter.component';
import { CountryRegDetails } from '../../model1/Contryregion';
import { GridApi, ColumnApi } from 'ag-grid-community';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';



@Component({
  selector: 'rsa-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.scss']
})
export class LocationComponent  implements OnInit {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridApi: GridApi;
  gridColumnApi: ColumnApi;
  //paginationOptions: TextValuePair[] = [];
  rowData: CountryRegDetails[] = [];
  domLayout: string;
  location: Location;
  gridConfiguration: GridOptions = {};
  frameworkComponents = {};
  editingRowIndex: number;
  suppressClickEdit: boolean;
  currentEditRow: CountryRegDetails;
  ModifiedBy: string;
  PreparedBy: string;
  isRowEditing: boolean = false;
  selectedRowIndex;
  startValue: number;
  endValue: number;
  totalRecords: number;
  currentPage: number;
  totalPages: number;
  isDisableFirst: boolean;
  isDisableLast: boolean;
  uwMaster: string = "Country";
  @Output() seelectedRowDetails = new EventEmitter();
  constructor(private _uwMasterService: UwMastersService, private allowAccess: UserAutherizationService) {}

 
    columnDefs = [

      {
          headerName: ' Location Code', field: 'Code', sortable: true, filter: 'agTextColumnFilter', editable: false, width: 80
       
      },

      { headerName: 'English Description', field: 'EnglishDescription', sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput',
       maxLength: 40 },
      {
          headerName: 'الوصف العربي', field: 'ArabicDescription', sortable: true, filter: 'agTextColumnFilter', arabicDesc: true, headerClass: 'ag-rtl',
           cellClass: 'ag-rtl text-right', editable: true, cellEditor: 'agTextInput', maxLength: 40,

      },
      { headerName: 'Short Description(Eng)', field: 'EnglishDescription'},
      { headerName: 'Short Description(Arabic)', field: 'EnglishDescription'},
      { headerName: 'Address(English)', field: 'EnglishAddress', sortable: true, filter: 'agTextColumnFilter', editable: true, 
      cellEditor: 'agTextInput'},
      { headerName: 'Address(Arabic)', field: 'ArabicAddress', sortable: true, filter: 'agTextColumnFilter', editable: true, 
      cellEditor: 'agTextInput'},
      { headerName: 'Telephone ', field: 'Telephone', sortable: true, filter: 'agTextColumnFilter', editable: true,
       cellEditor: 'agTextInput'},
      { headerName: 'Fax', field: 'Fax', sortable: true, filter: 'agTextColumnFilter', editable: true, 
      cellEditor: 'agTextInput', width: 80},
      { headerName: 'Gsm', field: 'Gsm', sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput', width: 80},
      { headerName: 'Email', field: 'EnglishEmail', sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput'},
      { headerName: 'Zip', field: 'EnglishZip', sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput',width: 80},
      { headerName: 'Location Charge', field: 'Charge', sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput',width: 80},
      { headerName: 'Status', field: 'Status', sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput',width: 80},
      { headerName: 'Zone', field: 'Zone', sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput',width: 80},
      { headerName: 'Country', field: 'CountryCode', sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput',width: 80},
      { headerName: 'Region', field: 'RegionCode', sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput',width: 80},
      
      {
          headerName: 'Action',
          field: 'value',
          cellRendererFramework: EditViewCellComponent,
          cellRendererParams: {
              inActoionLink: 'coList',
              isEditAllowed:this.allowAccess.isAllowed(2302),
              isDeleteAllowed:this.allowAccess.isAllowed(2500)
          },
          colId: 'editSaveBtn',
          filter: 'none',
          headerClass: 'hidefilter'
      }
  ];
  GetcolumnDefs() {
    this.gridConfiguration = <GridOptions>{
        columnDefs: this.columnDefs,
        
        postProcessPopup: function (params) {
            const ePopup = params.ePopup;
            ePopup.style.top = '14.9838px';
        },
        rowData: this.rowData,
        rowHeight: 40,
        headerHeight: 40,
        pagination: true,
        floatingFiltersHeight: 40,
        paginationPageSize: 20,
        enableRangeSelection: true,
        rowSelection: 'multiple',
        rowMultiSelectWithClick: true,
        animateRows: true,
        enableColResize: true,
        enableFilter: true,
        enableSorting: true,
        suppressContextMenu: true,
        masterDetail: true,
        //editable: true,
        //editType: 'cel',
        detailRowHeight: 200,
        defaultColDef: {
          enableRowGroup: false,
          enableValue: true,
          suppressMovable: true,
          minWidth: 40,
          menuTabs: ['filterMenuTab', '', '']
     
        },
        context: {
          componentParent: this
        }
        
    };
}
onGridReady(params) {
  console.log(params, 'params');
  this.gridApi = params.api;
  this.gridColumnApi = params.columnApi;
   this.gridConfiguration.api.setColumnDefs(this.columnDefs)
   this.gridConfiguration.api.setRowData(this.rowData);
  params.api.paginationGoToPage(0);
 // this.fitToCoulmn();
}
  ngOnInit() {
      this.GetcolumnDefs();
      this.frameworkComponents = { agTextInput: AgCustomTextComponent,
      agInputDate: AgCustomDateComponent, agDateInput: AgGirdCustomDateFilterComponent };
      this.getLocationDetails();
      }

getLocationDetails(): any {
  this._uwMasterService.getCountryRegionDetails(this.uwMaster).subscribe((data) => {
    this.rowData = data;
    this.totalRecords = this.rowData.length;
    console.log(data, this.rowData);
});
}
onParentEditClicked(val: any) {
  let nodeData = val.data;
  const vocherEmitedDetails = {
    OperationType: 'Edit',
    currentRowData: nodeData
  };
  this.seelectedRowDetails.emit({
    vocherEmitedDetails
  });
}
onParentViewClicked(param: any) {
  let text = param.text;
  let node = param.rowData.node;
  if (text == 'Hide') {
    node.setExpanded(true);
  }
  else {
    node.setExpanded(false);
  }

}
onParentDeleteClicked(param: any) {
  let text = param.text;
  let node = param.rowData.node;
  if (text == 'Hide') {
    node.setExpanded(true);
  }
  else {
    node.setExpanded(false);
  }

}


}
