import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Location } from 'src/app/administration/underwriting-masters/CountryAndRegion/locationcomponents/model/location';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { UwMastersService } from 'src/app/administration/underwriting-masters/services/uw-masters.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';

@Component({
  selector: 'rsa-location-edit',
  templateUrl: './location-edit.component.html',
  styleUrls: ['./location-edit.component.scss']
})
export class LocationEditComponent implements OnInit {
  locationEditForm: FormGroup;
  location: Location;
  getSaveDetails: Location;

  uwMaster = 'Location';
  @Input() isEdit: boolean;
  @Input() EditData: Location;

  @Output() cancelClick = new EventEmitter();
  constructor(private formBuilder: FormBuilder, private _uwMasterService: UwMastersService, private alertService: AlertService) { }

  ngOnInit() {
    this.location = new Location();
    this.createLocationForm();
    this.formControlAddValidator();
    if (this.isEdit) {
      this.location = this.EditData;
      this.fillEditData();
    }
  }

  createLocationForm(): void {
    this.locationEditForm = this.formBuilder.group({
      Code: [null],
      EnglishDescription: [null],
      ArabicDescription: [null],
      EnglishShortDescription: [null],
      ArabicShortDescription: [null],
      EnglishAddress: [null],
      ArabicAddress: [null],
      Fax: [null],
      Gsm: [null],
      EnglishEmail: [null],
      EnglishZip: [null],
      Charge: [null],
      Status: [null],
      Zone: [null],
      CountryCode: [null],
      RegionCode: [null],

    });
  }

  get Code() { return this.locationEditForm.controls['Code']; }
  get EnglishDescription() { return this.locationEditForm.controls['EnglishDescription']; }
  get ArabicDescription() { return this.locationEditForm.controls['ArabicDescription']; }
  get EnglishAddress() { return this.locationEditForm.controls['EnglishAddress']; }
  get ArabicShortDescription() { return this.locationEditForm.controls['ArabicShortDescription']; }
  get ArabicAddress() { return this.locationEditForm.controls['ArabicAddress']; }
  get Zone() { return this.locationEditForm.controls['Zone']; }
  get EnglishShortDescription() { return this.locationEditForm.controls['EnglishShortDescription']; }
  get Fax() { return this.locationEditForm.controls['Fax']; }
  get Gsm() { return this.locationEditForm.controls['Gsm']; }
  get EnglishEmail() { return this.locationEditForm.controls['EnglishEmail']; }
  get EnglishZip() { return this.locationEditForm.controls['EnglishZip']; }
  get Charge() { return this.locationEditForm.controls['Charge']; }
  get Status() { return this.locationEditForm.controls['Status']; }
  get CountryCode() { return this.locationEditForm.controls['CountryCode']; }
  get RegionCode() { return this.locationEditForm.controls['RegionCode']; }
  fillEditData() {
    if (this.location) {
      this.locationEditForm.patchValue({
        Code: this.location.Code,
        EnglishDescription: this.location.EnglishDescription,
        ArabicDescription: this.location.ArabicDescription,
        EnglishShortDescription: this.location.EnglishShortDescription,
        ArabicShortDescription: this.location.ArabicShortDescription,
        EnglishAddress: this.location.EnglishAddress,
        ArabicAddress: this.location.ArabicAddress,
        Fax: this.location.Fax,
        Gsm: this.location.Gsm,
        EnglishEmail: this.location.EnglishEmail,
        EnglishZip: this.location.EnglishZip,
        Charge: this.location.Charge,
        Status: this.location.Status,
        Zone: this.location.Zone,
        CountryCode: this.location.CountryCode,
        RegionCode: this.location.RegionCode,
      });
    }
  }

  formControlAddValidator() {
    this.Code.setValidators([Validators.required]);
    this.Code.updateValueAndValidity();
    this.EnglishDescription.setValidators([Validators.required]);
    this.EnglishDescription.updateValueAndValidity();
    this.ArabicDescription.setValidators([Validators.required]);
    this.ArabicDescription.updateValueAndValidity();
    this.EnglishShortDescription.setValidators([Validators.required]);
    this.EnglishShortDescription.updateValueAndValidity();
    this.EnglishAddress.setValidators([Validators.required]);
    this.EnglishAddress.updateValueAndValidity();
    this.ArabicAddress.setValidators([Validators.required]);
    this.ArabicAddress.updateValueAndValidity();
    this.Zone.setValidators([Validators.required]);
    this.Zone.updateValueAndValidity();
    this.Fax.setValidators([Validators.required]);
    this.Fax.updateValueAndValidity();
    this.Gsm.setValidators([Validators.required]);
    this.Gsm.updateValueAndValidity();
    this.EnglishEmail.setValidators([Validators.required]);
    this.EnglishEmail.updateValueAndValidity();
    this.EnglishZip.setValidators([Validators.required]);
    this.EnglishZip.updateValueAndValidity();
    this.Charge.setValidators([Validators.required]);
    this.Charge.updateValueAndValidity();
    this.Status.setValidators([Validators.required]);
    this.Status.updateValueAndValidity();
    this.CountryCode.setValidators([Validators.required]);
    this.CountryCode.updateValueAndValidity();
    this.RegionCode.setValidators([Validators.required]);
    this.RegionCode.updateValueAndValidity();
  }

  saveDetails() {

    if (this.locationEditForm.valid) {
      const saveDetailsObject = [this.locationEditForm.value];
      if (this.isEdit) {
        let val = JSON.stringify(saveDetailsObject);
        this._uwMasterService.postUnderWritingMasters(this.uwMaster, saveDetailsObject).subscribe(dataReturn => {
          this.alertService.success('Data updated successfully.');
          this.cancelClick.emit();
          return true;
        },
          errorRturn => {
            this.alertService.error('something went wrong');
            return false;
          });
      }
      //    if (reasult) {
      //          this.alertService.success("location created successfully.")
      //         this.cancelClick.emit();
      //     }
      //     else {
      //         this.alertService.error("Error in creating Chart of Account.")
      //     }
      // }
      //);
      //}
      else {
        this.alertService.error('Error in updating location Details.');
      }
    } else {
      this.alertService.error('Form is invalid.');
    }
  }

  cancel() {
    this.cancelClick.emit();
  }

}
