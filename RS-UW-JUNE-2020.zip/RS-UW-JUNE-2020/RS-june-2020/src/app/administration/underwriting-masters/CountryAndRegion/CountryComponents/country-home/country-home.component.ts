import { Component, OnInit, ViewChild, EventEmitter } from '@angular/core';
import { CountryComponent } from '../country/country.component';
import {CountryDetails} from 'src/app/administration/underwriting-masters/CountryAndRegion/CountryComponents/model/CountryDetails';
import { CountryRegDetails } from '../../model1/Contryregion';

@Component({
  selector: 'rsa-country-home',
  templateUrl: './country-home.component.html',
  styleUrls: ['./country-home.component.scss']
})
export class CountryHomeComponent implements OnInit {
  @ViewChild('countrygrid') countryComponent: CountryComponent;
  isEdit: boolean;
  isNew:boolean;
  headerText: string;
  countrydatil: CountryDetails;
  constructor() { }
  ngOnInit() {
    this.isEdit = false;
  }
  selectedRowDetails(evt) {
    this.countrydatil = evt.vocherEmitedDetails.currentRowData;
    this.isEdit = true;
  }
  cancelCallBack() {
    this.isEdit = false;
  }
  addNew() {
    this.headerText = 'Add New Record';
    this.isNew = true;
    this.isEdit = true;
    //this.sharedService.sendMessage({ 'subModule': 'Chart of Accounts', 'isAddNewClicked': true });
  }
}
