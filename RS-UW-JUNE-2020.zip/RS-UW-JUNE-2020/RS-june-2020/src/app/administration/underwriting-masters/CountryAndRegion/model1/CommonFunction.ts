import { GridApi, ColumnApi } from 'ag-grid-community';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import {  Router } from '@angular/router';
import { CountryRegDetails } from './Contryregion';
export class Commonfunctions {
    rowData: CountryRegDetails[] = [];
    columnDefs: Array<object> = [];
    gridApi: GridApi;
    gridColumnApi: ColumnApi;
    isRowEditing: boolean = false;
    selectedRowIndex;
    editingRowIndex: number;
    suppressClickEdit: boolean;
    currentEditRow: CountryRegDetails;
    startValue: number;
    endValue: number;
    totalRecords: number;
    currentPage: number;
    totalPages: number;
    isDisableFirst: boolean;
    isDisableLast: boolean;
    gridConfiguration: GridOptions = {};
    constructor( public router: Router) { }
    onParentCheckEdited() {
        let editedData = this.rowData.filter(data => data.editMode === true);
        if (editedData.length > 0) {
           // this.alertService.warn('Please save/cancel the data which has already modifed.');
            return true;
        }
        else {
            return false;
        }
      }
      
    onGoToNextPage($event) {
      if (!this.onParentCheckEdited()) {
          this.gridApi.paginationGoToNextPage();
      }
    }
    onGoToPreviousPage($event) {
      if (!this.onParentCheckEdited()) {
          this.gridApi.paginationGoToPreviousPage();
      }
    }
    onGoToFirstPage($event) {
      if (!this.onParentCheckEdited()) {
          this.gridApi.paginationGoToFirstPage();
      }
    }
    onGoToLastPage($event) {
      if (!this.onParentCheckEdited()) {
          this.gridApi.paginationGoToLastPage();
      }
    }
    onParentCancel(rowIndex) {
      debugger;
      this.gridApi.stopEditing();
      let selRowData = this.rowData[rowIndex];
      if (selRowData.isNewRow) {
          this.rowData.splice(rowIndex, 1);
      }
      else {
          this.currentEditRow.editMode = false;
          this.rowData[rowIndex] = this.currentEditRow;
      }
      this.gridConfiguration.api.setRowData(this.rowData);
      this.gridApi.paginationGoToPage(0);
      this.suppressClickEdit = true;
      this.isRowEditing = false;
    }

    onHierachialParentCancelClicked(rowIndex,gridObj:any) {
      debugger;
      gridObj.api.stopEditing();
      let selRowData = gridObj.rowData[rowIndex];
      if (selRowData.isNewRow) {
          gridObj.rowData.splice(rowIndex, 1);
      }else{
          let currentEditedRow = gridObj.api.getRowNode(rowIndex);
          currentEditedRow.data.editMode = false;
          gridObj.rowData[rowIndex] = currentEditedRow;          
      }
     // gridObj.gridOptions.api.setRowData(gridObj.rowData);
      gridObj.api.paginationGoToPage(0);
      gridObj.suppressClickEdit = true;
      gridObj.isRowEditing = false;
    }

    editRowData(rowIndex, column) {
      this.gridApi.startEditingCell({
          rowIndex: rowIndex,
          colKey: column
      });
      this.isRowEditing = true;
    }
    onCellDoubleClicked($event) {
      this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
      let colId = $event.column ? $event.column.colId : null;
      if (this.selectedRowIndex && colId) {
          this.allowEditing(this.selectedRowIndex, colId);
      }
    }
    
    onCellClicked($event) {
      this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
      let colId = $event.column ? $event.column.colId : null;
      if (this.selectedRowIndex && colId) {
          this.allowEditing(this.selectedRowIndex, colId);
      }
    }
    onCellFocused($event) {
      this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
      let colId = $event.column ? $event.column.colId : null;
      if (this.selectedRowIndex && colId) {
          this.allowEditing(this.selectedRowIndex, colId);
      }
    }
    allowEditing(rowIndex, colId) {
      if (this.isRowEditing) {
          if (rowIndex !== this.editingRowIndex) {
              this.suppressClickEdit = true;
              this.gridApi.stopEditing();
          }
          else {
              this.suppressClickEdit = false;
              this.editRowData(rowIndex, colId);
          }
      }
    }
    onParentEditClicked(rowIndex) {
      
      let editedData = this.rowData.filter(data => data.editMode === true);
      let currentEditData = this.rowData[rowIndex];    
      
      let allowRowEdit = false;
      if (editedData.length !== 0) {
          if (editedData[0].Code === currentEditData.Code) {
              allowRowEdit = true;
          }
      }
      else {
          allowRowEdit = true;
      }
      if (allowRowEdit) {
          this.suppressClickEdit = false;
          this.editingRowIndex = rowIndex;
          currentEditData.editMode = true;
          this.currentEditRow = Object.assign({}, currentEditData);
          this.editRowData(rowIndex, 'EnglishDescription');
          
         // this.editRowData(rowIndex, 'MunicipalityCode');
          return true;
      }
      else {
        //  this.alertService.warn('Please save/cancel the data which already modifed.');
          return false;
      }
    }

    onHierarchialParentEditClicked(rowIndex,gridObj:any) {
      let editedData = gridObj.rowData.filter(data => data.editMode === true);
      let currentEditData = gridObj.rowData[rowIndex];    
      
      let allowRowEdit = false;
      if (editedData.length !== 0) {
          if (editedData[0].Code === currentEditData.Code) {
              allowRowEdit = true;
          }
      }
      else {
          allowRowEdit = true;
      }
      if (allowRowEdit) {
          this.suppressClickEdit = false;
          this.editingRowIndex = rowIndex;
          currentEditData.editMode = true;
          this.currentEditRow = Object.assign({}, currentEditData);
          this.editRowData(rowIndex, 'EnglishDescription');
          return true;
      }
      else {
        //  this.alertService.warn('Please save/cancel the data which already modifed.');
          return false;
      }
    }
    validateData(currentData) {
      if (currentData.EnglishDescription === "") {
         // this.alertService.error('English Description is empty');
          return 'EnglishDescription';
      }
      return '';
    }
    onPaginationChanged($event) {
      if (this.gridApi) {
          this.currentPage = this.gridApi.paginationGetCurrentPage() + 1;
          this.totalPages = this.gridApi.paginationGetTotalPages();
          if (this.currentPage === 1) {
              this.isDisableFirst = true;
          }
          else {
              this.isDisableFirst = false;
          }
          if (this.currentPage === this.totalPages) {
              this.isDisableLast = true;
          }
          else {
              this.isDisableLast = false;
          }
          this.startValue = ((this.currentPage - 1) * this.gridConfiguration.paginationPageSize) + 1;
          this.endValue = ((this.startValue + this.gridConfiguration.paginationPageSize) - 1) < this.totalRecords ? (this.startValue + this.gridConfiguration.paginationPageSize) - 1 : this.totalRecords;
      }
    }
    // displayModifybutton(functionid) {

    //   return this.allowAccess.isAllowed(functionid);
    // }
}