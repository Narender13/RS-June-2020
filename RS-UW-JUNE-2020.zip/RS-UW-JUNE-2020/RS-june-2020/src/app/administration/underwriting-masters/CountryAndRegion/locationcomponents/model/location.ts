export class Location {
    Code: string;
    EnglishDescription: string;
    ArabicDescription: string;
    EnglishShortDescription: string;
    ArabicShortDescription:string;
    EnglishAddress: string;
    ArabicAddress: string;
    Telephone: number;
    Fax: number;
    Gsm: number;
    EnglishEmail: string;
    EnglishZip: string;
    Charge: string;
    Status: string;
    Zone: number;
    CountryCode: number;
    RegionCode: number;

}