import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { Location } from 'src/app/administration/underwriting-masters/CountryAndRegion/locationcomponents/model/location';
import { LocationComponent } from '../location/location.component';

@Component({
  selector: 'rsa-location-home',
  templateUrl: './location-home.component.html',
  styleUrls: ['./location-home.component.scss']
})
export class LocationHomeComponent implements OnInit {
  @ViewChild('locationgrid') locationComponent: LocationComponent;
  isEdit: boolean; 
  headerText: string;
  locationdetails: Location;
  constructor() { }

  ngOnInit() {
    this.isEdit = false;
  }
  selectedRowDetails(evt: any) {
    this.locationdetails = evt.vocherEmitedDetails.currentRowData;
    this.isEdit = true;
  }
  cancelCallBack() {
    this.isEdit = false;
  }
  addNew() {
    this.headerText = 'Add New Record';
    this.isEdit = true;
}
}
