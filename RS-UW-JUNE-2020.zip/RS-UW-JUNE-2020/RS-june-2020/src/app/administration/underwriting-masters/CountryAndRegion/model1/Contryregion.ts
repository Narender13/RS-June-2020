
export class CountryRegDetails { 
    Code: number;
    EnglishDescription: string;
    ArabicDescription: string;
    EnglishShortDescription?: string;
    NationalityEngDescription?: string;
    NationalityArabicDescription?: string;
    Zone?: string;
    DialCode?: string;
    Country?: string;
    ArabicShortDescription?: string;
    EnglishAddress?: string;
    ArabicAddress?: string;
    Telephone?: number;
    Fax?: number;
    Gsm?: number;
    EnglishEmail?: string;
    EnglishZip?: string;
    Charge?: string;
    Status?: string;
    CountryCode?: number;
    RegionCode?: number;
    MunicipalityCode?: number;
    FloodZone?: string;
    EarthQuakeZone?: string;
    editMode: boolean;
    isNewRow: boolean;
    ModifiedBy: string;
}