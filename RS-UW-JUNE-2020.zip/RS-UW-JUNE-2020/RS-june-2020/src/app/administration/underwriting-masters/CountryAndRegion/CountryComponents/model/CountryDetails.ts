export class CountryDetails{
    Code: string;
    EnglishDescription: string;
    ArabicDescription: string;
    EnglishShortDescription: string;
    NationalityEngDescription: string;
    NationalityArabicDescription: string;
    Zone: string;
    DialCode: string;
    CodeSet: string;
    DescriptionEnglishSet: string;
    DescriptionArabicSet: string;
    ShortDescriptionEnglishSet: string;
    NationalDescriptionEnglishSet: string;
    NationalDescriptionArabicSet: string;
    ZoneSet: string;
    DialCodeSet: string;
}