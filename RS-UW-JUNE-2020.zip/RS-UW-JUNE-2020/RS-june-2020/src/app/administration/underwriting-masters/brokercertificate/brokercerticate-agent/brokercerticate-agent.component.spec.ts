import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrokercerticateAgentComponent } from './brokercerticate-agent.component';

describe('BrokercerticateAgentComponent', () => {
  let component: BrokercerticateAgentComponent;
  let fixture: ComponentFixture<BrokercerticateAgentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrokercerticateAgentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrokercerticateAgentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
