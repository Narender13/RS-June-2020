import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrokercertificateDirectComponent } from './brokercertificate-direct.component';

describe('BrokercertificateDirectComponent', () => {
  let component: BrokercertificateDirectComponent;
  let fixture: ComponentFixture<BrokercertificateDirectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrokercertificateDirectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrokercertificateDirectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
