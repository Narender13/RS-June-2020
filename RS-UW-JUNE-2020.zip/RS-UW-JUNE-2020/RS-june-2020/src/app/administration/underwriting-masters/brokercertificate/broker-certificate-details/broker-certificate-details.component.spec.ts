import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrokerCertificateDetailsComponent } from './broker-certificate-details.component';

describe('BrokerCertificateDetailsComponent', () => {
  let component: BrokerCertificateDetailsComponent;
  let fixture: ComponentFixture<BrokerCertificateDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrokerCertificateDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrokerCertificateDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
