import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrokercertificateBrokerComponent } from './brokercertificate-broker.component';

describe('BrokercertificateBrokerComponent', () => {
  let component: BrokercertificateBrokerComponent;
  let fixture: ComponentFixture<BrokercertificateBrokerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrokercertificateBrokerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrokercertificateBrokerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
