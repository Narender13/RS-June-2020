import { Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';

@Component({
  selector: 'rsa-broker-certificate-details',
  templateUrl: './broker-certificate-details.component.html',
  styleUrls: ['./broker-certificate-details.component.scss']
})
export class BrokerCertificateDetailsComponent implements OnInit {
  brokercertifid = 1 ;
  uwmaster: string;
  constructor(public router: Router) { }

  ngOnInit() {
    this.getBrokerCertifyType(this.brokercertifid);
  }
  getBrokerCertifyType(brokercertifid: number, name?: string)
  {
    this.brokercertifid = brokercertifid;
    switch (brokercertifid)
    {
      case 1: {
          this.brokercertifid = brokercertifid;
          this.router.navigate(['admin/underwriting/BrokerCertificateDetails/direct']);
          break;
        }
        case 2: {
          this.brokercertifid = brokercertifid;
          this.router.navigate(['admin/underwriting/BrokerCertificateDetails/broker']);
          break;
        }
        case 3: {
          this.brokercertifid = brokercertifid;
          this.router.navigate(['admin/underwriting/BrokerCertificateDetails/agent']);
          break;
        } 
    }
}

}
