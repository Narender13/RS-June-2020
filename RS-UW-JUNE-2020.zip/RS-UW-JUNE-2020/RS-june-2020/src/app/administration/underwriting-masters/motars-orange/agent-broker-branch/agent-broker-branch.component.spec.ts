import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentBrokerBranchComponent } from './agent-broker-branch.component';

describe('AgentBrokerBranchComponent', () => {
  let component: AgentBrokerBranchComponent;
  let fixture: ComponentFixture<AgentBrokerBranchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentBrokerBranchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentBrokerBranchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
