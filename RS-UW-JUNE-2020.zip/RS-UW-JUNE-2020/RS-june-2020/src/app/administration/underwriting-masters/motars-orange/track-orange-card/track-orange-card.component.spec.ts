import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrackOrangeCardComponent } from './track-orange-card.component';

describe('TrackOrangeCardComponent', () => {
  let component: TrackOrangeCardComponent;
  let fixture: ComponentFixture<TrackOrangeCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrackOrangeCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrackOrangeCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
