import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MotarsOrangeTabsComponent } from './motars-orange-tabs.component';

describe('MotarsOrangeTabsComponent', () => {
  let component: MotarsOrangeTabsComponent;
  let fixture: ComponentFixture<MotarsOrangeTabsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MotarsOrangeTabsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MotarsOrangeTabsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
