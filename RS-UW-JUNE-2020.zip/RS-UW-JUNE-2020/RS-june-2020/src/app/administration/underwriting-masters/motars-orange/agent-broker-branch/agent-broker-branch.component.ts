import { Component, OnInit, ViewChild, AfterViewInit, EventEmitter,Input,Output} from '@angular/core';
import { AgGridNg2 } from 'ag-grid-angular';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';

import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { AgCustomTextComponent } from 'src/app/shared/ag-custom-text/ag-custom-text.component';
import { AgCustomHeaderComponent } from 'src/app/shared/ag-custom-header/ag-custom-header.component';
import { ActionButtonComponent } from '../../shared/action-button/action-button.component';
import { UwMastersService } from 'src/app/administration/underwriting-masters/services/uw-masters.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';

import { GridApi, ColumnApi } from 'ag-grid-community';
import { Commonfunctions } from './../../CountryAndRegion/model1/CommonFunction';
import { Router } from '@angular/router';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';

@Component({
  selector: 'rsa-agent-broker-branch',
  templateUrl: './agent-broker-branch.component.html',
  styleUrls: ['./agent-broker-branch.component.scss']
})
export class AgentBrokerBranchComponent extends Commonfunctions implements OnInit {

  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridApi:GridApi;
  gridColumnApi: ColumnApi;
  //paginationOptions: TextValuePair[] = [];
  rowData: any[] = [];
  columnDefs: Array<object> = [];
  domLayout:string;
 
  gridConfiguration: GridOptions = {};
  frameworkComponents = {};
  editingRowIndex: number;
  suppressClickEdit: boolean;
  currentEditRow: any;
  ModifiedBy: string;
  PreparedBy: string;
  isRowEditing: boolean = false;
  selectedRowIndex: boolean;
  startValue: number;
  endValue: number;
  totalRecords: number;
  currentPage: number;
  totalPages: number;
  isDisableFirst: boolean;
  isDisableLast: boolean;
  PostData: any = [];
  public myName:string;
  uwMaster = "AgentUW";
  issuedTo: number;
  @Output() onRowSelection = new EventEmitter(); 

  constructor( private _uwMasterService: UwMastersService,public bsModalRef: BsModalRef,public modalService: BsModalService,
     private allowAccess: UserAutherizationService , private alertService: AlertService,public router: Router) {super(router); }

  ngOnInit() {
    this.columnDefs = [

      {
          headerName: 'Code', field: 'Code', sortable: true, filter: 'agTextColumnFilter', editable: false,checkboxSelection: true
       
      },

      { headerName: 'English Description', field: 'EnglishDescription', sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput', maxLength: 40 },

  ];

  this.frameworkComponents = { agTextInput: AgCustomTextComponent, agCustomHeaderComponent: AgCustomHeaderComponent, };
  this.GetcolumnDefs();
  this.suppressClickEdit = true;
  }
  GetcolumnDefs() {
    this.gridConfiguration = <GridOptions>{
        columnDefs: this.columnDefs,
        rowSelection: 'multiple',
        postProcessPopup: function (params) {
            const ePopup = params.ePopup;
            ePopup.style.top = '14.9838px';
        },
        rowData: this.rowData,
        rowHeight: 40,
        headerHeight: 40,
        pagination: true,
        floatingFiltersHeight: 40,
        paginationPageSize: 15,
        enableRangeSelection: true,
        rowMultiSelectWithClick: true,
        animateRows: true,
        enableColResize: true,
        enableFilter: true,
        suppressContextMenu: true,
        enableSorting: true,
        editType: 'cel',
        defaultColDef: {
            enableRowGroup: false,
            enableValue: true,
            suppressMovable: true,
            minWidth: 30,
            menuTabs: ['filterMenuTab', '', ''],
            headerComponent: 'agCustomHeaderComponent',
            headerComponentParams: {
                menuIcon: 'fa-bars'
            },
        },
        context: {
            componentParent: this
        },
    };
    this.getIssuedToDetails();
  }
  getIssuedToDetails(): any {
    let issuedToDetailsToLookInfor:string = "AgentUW";
    if(this.issuedTo === 1){
      issuedToDetailsToLookInfor = "AgentUW";
    }else if(this.issuedTo === 2){
      issuedToDetailsToLookInfor = "BrokerUW";
    }else {
      issuedToDetailsToLookInfor = "Location";
    }
    this._uwMasterService.getUnderwritingMasters(issuedToDetailsToLookInfor).subscribe((data) => {
      this.rowData = data;
      this.totalRecords = this.rowData.length;
      console.log(data, this.rowData);
    });   
 
  }
  setRowData() {
    this.gridConfiguration.api.setRowData(this.rowData);
    this.gridApi.paginationGoToPage(0);
  }
  addNewRow(): any {
    let editedData = this.rowData.filter(data => data.editMode === true && data.isNewRow === true);
    if (editedData.length > 0) {
      //this.alertService.warn('Please save/cancel the data which already added.');
    }
    else {
      let newItem = { Code: 0, EnglishDescription: '', ArabicDescription: '', isNewRow: true, editMode: true,ModifiedBy:null, PreparedBy: sessionStorage.getItem('LoggedInUserId') };
      this.rowData.push(newItem);
      this.gridConfiguration.api.setRowData(this.rowData);
      this.gridApi.paginationGoToPage(0);
      this.onParentEditClicked(this.rowData.length - 1);
    }
  }
  onParentCancel(rowIndex) {
    this.gridApi.stopEditing();
    let selRowData = this.rowData[rowIndex];
    if (selRowData.isNewRow) {
        this.rowData.splice(rowIndex, 1);
    }
    else {
        this.currentEditRow.editMode = false;
        this.rowData[rowIndex] = this.currentEditRow;
    }
    this.gridConfiguration.api.setRowData(this.rowData);
    this.gridApi.paginationGoToPage(0);
    this.suppressClickEdit = true;
    this.isRowEditing = false;
  }
  setAutoHeight() {
    setTimeout(() => {
        this.gridApi.setDomLayout('autoHeight');
    }, 200);
  
  }
  ngAfterViewInit() {
    this.fitToCoulmn();
    this.setAutoHeight();
  }
  fitToCoulmn() {
    setTimeout(() => {
        this.gridApi.sizeColumnsToFit();
    }, 200);
  }
  onGridReady(params) {
    console.log(params, 'params');
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridConfiguration.api.setRowData(this.rowData);
    params.api.paginationGoToPage(0);
    this.fitToCoulmn();
  }


  onParentSaveClicked(id, rowIndex) {
    
    this.gridApi.stopEditing();
    const updatedData = this.rowData.filter(data => data.Code === id);
    this.PostData.push(updatedData);
    if (updatedData.length > 0) {
      const validate = this.validateData(updatedData[0]);
      if (validate === '') {
        const entityType = this.uwMaster;
        if (updatedData[0].isNewRow === true) {

          this._uwMasterService.postCountryRegionMasters(entityType, updatedData).subscribe(
            dataReturn => {
              this.alertService.success('Data saved successfully.');
              this.isRowEditing = false;
              this.getIssuedToDetails();
              return true;
              // }
            },
            errorRturn => {
              this.alertService.error('something went wrong');
              this.editRowData(rowIndex, 'EnglishDescription');
              return false;
            }
          );
        } else {
          updatedData[0].ModifiedBy = sessionStorage.getItem('LoggedInUserId');
          this._uwMasterService.postUnderWritingMasters(entityType, updatedData).subscribe(
            dataReturn => {
              this.alertService.success('Data updated successfully.');
              updatedData[0].editMode = false;
              this.isRowEditing = false;
              this.getIssuedToDetails();
              return true;
            },
            errorRturn => {
              this.alertService.error('something went wrong');
              this.editRowData(rowIndex, 'EnglishDescription');
              return false;
            }
          );
        }
      } else {
        this.editRowData(rowIndex, validate);
        return false;
      }

    }
  }

onParentDeleteClicked(uwMaster, id) {
  this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
  this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
  this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
  this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
  this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
  const param = {
    entitytype: this.uwMaster,
    ID: id
  }
  this.bsModalRef.content.valueChange.subscribe((data) => {
    if (data = RSAMSGConstants.BTNPROCEED) {
      this._uwMasterService.deleteUnderWritingMasters(param).subscribe(
        dataReturn => {
          this.alertService.success('Data deleted successfully.');
          this.getIssuedToDetails();
        },
        errorRturn => {
          console.log(errorRturn);
        }
      );
    }
  });
}
  displayModifybutton(functionid) {

    return this.allowAccess.isAllowed(functionid);
  }

  onSelectionChanged(event){
    let selectedRowsArr = this.gridApi.getSelectedRows();
    let selectedRow;
    if(selectedRowsArr.length >0){
      selectedRow = selectedRowsArr[0];
      this.onRowSelection.emit(selectedRow);
    }
  }

}
