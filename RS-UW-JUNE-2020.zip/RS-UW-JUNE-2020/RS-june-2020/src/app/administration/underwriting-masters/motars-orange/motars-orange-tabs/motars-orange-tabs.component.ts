import { Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';

@Component({
  selector: 'rsa-motars-orange-tabs',
  templateUrl: './motars-orange-tabs.component.html',
  styleUrls: ['./motars-orange-tabs.component.scss']
})
export class MotarsOrangeTabsComponent implements OnInit {
  motarorangeid = 1 ;
  uwmaster: string;
  constructor(public router: Router) { }

  ngOnInit() {
    this.getMotarOrangeType(this.motarorangeid);
  }
  getMotarOrangeType(motarorangeid: number, name?: string)
  {
  
    this.motarorangeid = motarorangeid;
    switch (motarorangeid)
    {
      case 1: {
          this.motarorangeid = motarorangeid;
          this.router.navigate(['admin/underwriting/OrangeCard/orangecardseries']);
          break;
        }
        case 2: {
          this.motarorangeid = motarorangeid;
          this.router.navigate(['admin/underwriting/OrangeCard/trackorangecard']);
          break;
        }
    }
}

}
