import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrangeCardSeriesComponent } from './orange-card-series.component';

describe('OrangeCardSeriesComponent', () => {
  let component: OrangeCardSeriesComponent;
  let fixture: ComponentFixture<OrangeCardSeriesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrangeCardSeriesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrangeCardSeriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
