import { Component, OnInit, ViewChild } from '@angular/core';
import { Commonfunctions } from '../../CountryAndRegion/model1/CommonFunction';
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AgCustomTextComponent } from 'src/app/shared/ag-custom-text/ag-custom-text.component';
import { AgCustomHeaderComponent } from 'src/app/shared/ag-custom-header/ag-custom-header.component';
import { ActionButtonComponent } from '../../shared/action-button/action-button.component';
import { UwMastersService } from 'src/app/administration/underwriting-masters/services/uw-masters.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { GridApi, ColumnApi } from 'ag-grid-community';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
import { Router } from '@angular/router';
import { DropdownRendererComponent } from './../../generic/dropdown-renderer/dropdown-renderer.component';
import { DropdownEditorComponent } from './../../generic/dropdown-editor/dropdown-editor.component';
import { RadioButtonComponent } from './../../shared/RadioButtonComponent';
import { AgentBrokerBranchComponent } from '../agent-broker-branch/agent-broker-branch.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';


@Component({
  selector: 'rsa-track-orange-card',
  templateUrl: './track-orange-card.component.html',
  styleUrls: ['./track-orange-card.component.scss']
})

export class TrackOrangeCardComponent extends Commonfunctions implements OnInit {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridApi: GridApi;
  gridColumnApi: ColumnApi;
  //paginationOptions: TextValuePair[] = [];
  rowData : any[] = [];
  columnDefs: Array<object> = [];
  domLayout: string;
  
  gridConfiguration: GridOptions = {};
  frameworkComponents = {};
  editingRowIndex: number;
  suppressClickEdit: boolean;
  currentEditRow: any;
  ModifiedBy: string;
  PreparedBy: string;
  isRowEditing: boolean = false;
  selectedRowIndex: boolean;
  startValue: number;
  endValue: number;
  totalRecords: number;
  currentPage: number;
  totalPages: number;
  PostData: any = [];
  isDisableFirst: boolean;
  isDisableLast: boolean;
  uwMaster = "MotorOrangeTrackcard";
  constructor(private modalService: BsModalService, public bsModalRef: BsModalRef, private _uwMasterService: UwMastersService,
    private alertService: AlertService, private allowAccess: UserAutherizationService, public router: Router) {super(router); }

  ngOnInit() {
    //this.getPolicydescription = this._uwMasterService.policydesc;
    
    this.columnDefs = [
      {
          headerName: 'Issued To', field: 'IssuedTo', sortable: true, filter: 'agTextColumnFilter', editable: true, 
      cellEditor: 'agRichSelectCellEditor',
      cellEditorParams: {
          cellHeight: 50,
          values: ['Broker', 'Agent', 'Branch']
      }
      },
      {
        field: "Branch",
        width: 100,
        headerName:"Branch",
        cellRendererFramework:RadioButtonComponent,
        cellRendererParams: {            
          context: {
            componentParent: this
          }
        }      
      }, 
      {
          headerName: 'Orange Card No', field: 'Numberr', sortable: true, filter: 'agTextColumnFilter', editable: true,
          cellEditor: 'agTextInput'
      },
      {
        headerName: 'Reason', field: 'Status', sortable: true, filter: 'agTextColumnFilter', editable: true,
        cellEditor: 'agTextInput'
    },
    {
      headerName: 'Description', field: 'EnglishDescription', sortable: true, filter: 'agTextColumnFilter', editable: true,
      cellEditor: 'agTextInput'
     },
     {
      headerName: 'Action',
      field: 'value',
      cellRendererFramework: ActionButtonComponent,
      cellRendererParams: {
          inActoionLink: 'Region',
          isEditAllowed: this.allowAccess.isAllowed(2302),
          isDeleteAllowed: this.allowAccess.isAllowed(2500)
      },
      colId: 'editSaveBtn',
      filter: 'none',
      headerClass: 'hidefilter'
  }

  ];


  
  this.frameworkComponents = { agTextInput: AgCustomTextComponent, agCustomHeaderComponent: AgCustomHeaderComponent, };
  this.GetcolumnDefs();
  this.suppressClickEdit = true;
  }
   countyToCityMap(match) {
     debugger
     var map = {
       'Broker': ['ncfnf', 'ndcml'],
       'Agent': ['cndc', 'nnd'],
       'Branch': [ 'ncfcl', 'ncn']
     }
     return map[match];
  }
  GetcolumnDefs() {
    this.gridConfiguration = <GridOptions>{
      columnDefs: this.columnDefs,
      rowSelection: 'multiple',
      postProcessPopup: function (params) {
        const ePopup = params.ePopup;
        ePopup.style.top = '14.9838px';
      },
      rowData: this.rowData,
      rowHeight: 40,
      headerHeight: 40,
      pagination: true,
      floatingFiltersHeight: 40,
      paginationPageSize: 20,
      enableRangeSelection: true,
      rowMultiSelectWithClick: true,
      animateRows: true,
      enableColResize: true,
      enableFilter: true,
      suppressContextMenu: true,
      enableSorting: true,
      editType: 'cel',
      defaultColDef: {
        enableRowGroup: false,
        enableValue: true,
        suppressMovable: true,
        minWidth: 30,
        menuTabs: ['filterMenuTab', '', ''],
        headerComponent: 'agCustomHeaderComponent',
        headerComponentParams: {
          menuIcon: 'fa-bars'
        },
      },
      context: {
        componentParent: this
      },
    };
this.getTrackOrangeCard();
}
// onCellValueChanged(params) {
// var colid = params.column.getId();
// if(colid === 'Issued') {
//   var selectedCountry = params.data.Issued;
//   var selectedCity = params.data.Broker;

//   var allowedCities = this.countyToCityMap(selectedCountry);
//   var cityMismatch = allowedCities.indexOf(selectedCity) < 0;

//   if (cityMismatch) {
//       params.node.setDataValue('city', null);
//   }
// }
// }
getTrackOrangeCard(): any {
  this._uwMasterService.getUnderwritingMasters(this.uwMaster).subscribe((data) => {
    this.rowData = data;
    this.totalRecords = this.rowData.length;
    console.log(data, this.rowData);
  });
}
gridSelectionChanged($event,parentGridName,rowIndex){
  debugger
   const selectedRow = this.agGrid.api.getRowNode(rowIndex);

  const initialState = {
    mode: selectedRow.data.IssuedTo
  };
  this.bsModalRef = this.modalService.show(AgentBrokerBranchComponent, {
    class: 'modal-dialog create-modal-dailog modal-dialog-centered', initialState,
    ignoreBackdropClick: false
  });
}
setRowData() {
  this.gridConfiguration.api.setRowData(this.rowData);
  this.gridApi.paginationGoToPage(0);
}
addNewRow(): any {
  let editedData = this.rowData.filter(data => data.editMode === true && data.isNewRow === true);
  if (editedData.length > 0) {
    //this.alertService.warn('Please save/cancel the data which already added.');
  }
  else {
    let newItem = { Code: 0, EnglishDescription: '', ArabicDescription: '', isNewRow: true, editMode: true,ModifiedBy:null , PreparedBy: sessionStorage.getItem('LoggedInUserId') };
    this.rowData.push(newItem);
    this.gridConfiguration.api.setRowData(this.rowData);
    this.gridApi.paginationGoToPage(0);
    this.onParentEditClicked(this.rowData.length - 1);
  }
}

setAutoHeight() {
  setTimeout(() => {
    this.gridApi.setDomLayout('autoHeight');
  }, 200);

}
ngAfterViewInit() {
  this.fitToCoulmn();
  this.setAutoHeight();
}
fitToCoulmn() {
  setTimeout(() => {
    this.gridApi.sizeColumnsToFit();
  }, 200);
}
onGridReady(params) {
  console.log(params, 'params');
  this.gridApi = params.api;
  this.gridColumnApi = params.columnApi;
  this.gridConfiguration.api.setRowData(this.rowData);
  params.api.paginationGoToPage(0);
  this.fitToCoulmn();
}
onParentSaveClicked(id, rowIndex) {
  debugger
  
  this.gridApi.stopEditing();
  const updatedData = this.rowData.filter(data => data.Code === id);
  this.PostData.push(updatedData);
  if (updatedData.length > 0) {
    const validate = this.validateData(updatedData[0]);
    if (validate === '') {
      const entityType = this.uwMaster;
      if (updatedData[0].isNewRow === true) {

        this._uwMasterService.postCountryRegionMasters(entityType, updatedData).subscribe(
          dataReturn => {
            this.alertService.success('Data saved successfully.');
            this.isRowEditing = false;
            this.getTrackOrangeCard();
            return true;
            // }
          },
          errorRturn => {
            this.alertService.error('something went wrong');
            this.editRowData(rowIndex, 'EnglishDescription');
            return false;
          }
        );
      } else {
        updatedData[0].ModifiedBy = sessionStorage.getItem('LoggedInUserId');
        this._uwMasterService.postUnderWritingMasters(entityType, updatedData).subscribe(
          dataReturn => {
            this.alertService.success('Data updated successfully.');
            updatedData[0].editMode = false;
            this.isRowEditing = false;
            this.getTrackOrangeCard();
            return true;
          },
          errorRturn => {
            this.alertService.error('something went wrong');
            this.editRowData(rowIndex, 'EnglishDescription');
            return false;
          }
        );
      }
    } else {
      this.editRowData(rowIndex, validate);
      return false;
    }

  }
}
onParentDeleteClicked(uwMaster, id) {
  this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
  this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
  this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
  this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
  this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
  const param = this.uwMaster + '&id=' + id;
  this.bsModalRef.content.valueChange.subscribe((data) => {
    if (data = RSAMSGConstants.BTNPROCEED) {
      this._uwMasterService.deleteUnderWritingMasters(param).subscribe(
        dataReturn => {
          this.alertService.success('Data deleted successfully.');
          this.getTrackOrangeCard();
        },
        errorRturn => {
          console.log(errorRturn);
        }
      );
    }
  });
}
displayModifybutton(functionid) {

  return this.allowAccess.isAllowed(functionid);
}
}
