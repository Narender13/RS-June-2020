import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EndorsementFooterComponent } from './endorsement-footer.component';

describe('EndorsementFooterComponent', () => {
  let component: EndorsementFooterComponent;
  let fixture: ComponentFixture<EndorsementFooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EndorsementFooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EndorsementFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
