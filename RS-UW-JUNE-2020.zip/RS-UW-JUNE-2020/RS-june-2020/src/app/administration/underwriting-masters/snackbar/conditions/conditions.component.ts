import { Component, OnInit, ViewChild } from '@angular/core';
import { Commonfunctions } from '../../CountryAndRegion/model1/CommonFunction';
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AgCustomTextComponent } from 'src/app/shared/ag-custom-text/ag-custom-text.component';
import { AgCustomHeaderComponent } from 'src/app/shared/ag-custom-header/ag-custom-header.component';
import { ActionButtonComponent } from '../../shared/action-button/action-button.component';
import { UwMastersService } from 'src/app/administration/underwriting-masters/services/uw-masters.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { GridApi, ColumnApi } from 'ag-grid-community';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DropdownRendererComponent } from './../../generic/dropdown-renderer/dropdown-renderer.component';
import { DropdownEditorComponent } from './../../generic/dropdown-editor/dropdown-editor.component';

@Component({
  selector: 'rsa-conditions',
  templateUrl: './conditions.component.html',
  styleUrls: ['./conditions.component.scss']
})
export class ConditionsComponent extends Commonfunctions implements  OnInit {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridApi: GridApi;
  gridColumnApi: ColumnApi;
  //paginationOptions: TextValuePair[] = [];
  rowData : any[] = [];
  columnDefs: Array<object> = [];
  domLayout: string;
  
  gridConfiguration: GridOptions = {};
  frameworkComponents = {};
  editingRowIndex: number;
  suppressClickEdit: boolean;
  currentEditRow: any;
  ModifiedBy: string;
  PreparedBy: string;
  isRowEditing: boolean = false;
  selectedRowIndex: boolean;
  startValue: number;
  endValue: number;
  totalRecords: number;
  currentPage: number;
  totalPages: number;
  PostData: any = [];
  isDisableFirst: boolean;
  isDisableLast: boolean;
  classid: number;
  policyid: number;
  coverid: number;
  covertypeid: number;
  coversubtypeid: number;
  uwMaster = "PolicyCondition";
  constructor(private modalService: BsModalService, public bsModalRef: BsModalRef, private _uwMasterService: UwMastersService,
    private alertService: AlertService, private allowAccess: UserAutherizationService, public router: Router,
    private route: ActivatedRoute) {super(router); }

  ngOnInit() {
    let isEditAllowed = this.allowAccess.isAllowed(2301);
    let isDeleteAllowed = this.allowAccess.isAllowed(2500);

    this.columnDefs = [
      {
        headerName: 'Code', field: 'Code', sortable: true, filter: 'agTextColumnFilter', editable: true,
        cellEditor: 'agTextInput', maxLength: 4
    },

   
    {
      headerName: '*Default', field: 'DefaultInd', sortable: true, filter: 'agTextColumnFilter', editable: true,
      cellEditor: 'agTextInput',maxLength: 10
  },
  {
    headerName: '*Text(English)', field: 'EnglishDescription', sortable: true, filter: 'agTextColumnFilter', editable: true,
    cellEditor: 'agTextInput',maxLength: 10
  },
{
  headerName: 'Text(Arbic)', field: 'ArabicDescription', sortable: true, filter: 'agTextColumnFilter', editable: true,
  cellEditor: 'agTextInput',maxLength: 10
},
{
  headerName: 'Limit', field: 'Limit', sortable: true, filter: 'agTextColumnFilter', editable: true,
  cellEditor: 'agTextInput',maxLength: 10
},
{
  headerName: 'Doc Template Name', field: 'DocTemplateName', sortable: true, filter: 'agTextColumnFilter', editable: true,
  cellEditor: 'agTextInput',maxLength: 10
},
{
  headerName: 'Document Flag ', field: 'DocumentFlag', sortable: true, filter: 'agTextColumnFilter', editable: true,
  cellEditor: 'agTextInput',maxLength: 10
},

      {
          headerName: 'Action', field: 'value', cellRendererFramework: ActionButtonComponent,
          cellRendererParams: {
              inActoionLink: 'CommonGrid',
              isEditAllowed:isEditAllowed,
              isDeleteAllowed:isDeleteAllowed
          },
          colId: 'editSaveBtn',
          filter: 'none',
          headerClass: 'hidefilter'
      }

  ];
  this.frameworkComponents = { agTextInput: AgCustomTextComponent, agCustomHeaderComponent: AgCustomHeaderComponent, };
  this.GetcolumnDefs();
  this.suppressClickEdit = true;
  }
  GetcolumnDefs() {
    this.gridConfiguration = <GridOptions>{
      columnDefs: this.columnDefs,
      rowSelection: 'multiple',
      postProcessPopup: function (params) {
        const ePopup = params.ePopup;
        ePopup.style.top = '14.9838px';
      },
      rowData: this.rowData,
      rowHeight: 40,
      headerHeight: 40,
      pagination: true,
      floatingFiltersHeight: 40,
      paginationPageSize: 10,
      enableRangeSelection: true,
      rowMultiSelectWithClick: true,
      animateRows: true,
      enableColResize: true,
      enableFilter: true,
      suppressContextMenu: true,
      enableSorting: true,
      editType: 'cel',
      defaultColDef: {
        enableRowGroup: false,
        enableValue: true,
        suppressMovable: true,
        minWidth: 30,
        menuTabs: ['filterMenuTab', '', ''],
        headerComponent: 'agCustomHeaderComponent',
        headerComponentParams: {
          menuIcon: 'fa-bars'
        },
      },
      context: {
        componentParent: this
      },
    };
    
    this.getPropertySurveyCriteria();
  }
  getPropertySurveyCriteria(): any {
    
    this.route.queryParams.subscribe((params) => {
      this.classid = params.classID;
      this.policyid = params.policyTypeID;
      this.coverid = params.coverID;
      this.covertypeid = params.coverTypeID;

    const param = {
       entityType: 'PolicyCondition',
      classId: params.classID,
      policyid: params.policyTypeID,
      coverid: 0,
      covertypeid: 0,
      coversubtypeid: 0
    };
    this._uwMasterService.getUnderwritingMastersHierarchyy(param).subscribe((data) => {
      this.rowData = data;
      this.totalRecords = this.rowData.length;
      console.log(data, this.rowData);
    });
  });
  }
 
  setRowData() {
    this.gridConfiguration.api.setRowData(this.rowData);
    this.gridApi.paginationGoToPage(0);
  }
  addNewRow(): any {
    let editedData = this.rowData.filter(data => data.editMode === true && data.isNewRow === true);
    if (editedData.length > 0) {
      //this.alertService.warn('Please save/cancel the data which already added.');
    }
    else {
      let newItem = { Code: 0,CLCode:this.classid,PTCode:this.policyid,COVCode:this.coverid,CTCode:this.covertypeid, EnglishDescription: '', ArabicDescription: '', isNewRow: true, editMode: true,ModifyBy: sessionStorage.getItem('LoggedInUserId')  , PreparedBy: sessionStorage.getItem('LoggedInUserId') };
      this.rowData.push(newItem);
      this.gridConfiguration.api.setRowData(this.rowData);
      this.gridApi.paginationGoToPage(0);
      this.onParentEditClicked(this.rowData.length - 1);
    }
  }
 
  setAutoHeight() {
    setTimeout(() => {
      this.gridApi.setDomLayout('autoHeight');
    }, 200);

  }
  ngAfterViewInit() {
    this.fitToCoulmn();
    this.setAutoHeight();
  }
  fitToCoulmn() {
    setTimeout(() => {
      this.gridApi.sizeColumnsToFit();
    }, 200);
  }
  onGridReady(params) {
    console.log(params, 'params');
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridConfiguration.api.setRowData(this.rowData);
    params.api.paginationGoToPage(0);
    this.fitToCoulmn();
  }
  onParentSaveClicked(id, rowIndex) {
    
    this.gridApi.stopEditing();
    const updatedData = this.rowData.filter(data => data.Code === id);
    this.PostData.push(updatedData);
    if (updatedData.length > 0) {
      const validate = this.validateData(updatedData[0]);
      if (validate === '') {
        const entityType = this.uwMaster;
        if (updatedData[0].isNewRow === true) {

          this._uwMasterService.postUnderWritingMasters(entityType, updatedData).subscribe(
            dataReturn => {
              this.alertService.success('Data saved successfully.');
              this.isRowEditing = false;
              this.getPropertySurveyCriteria();
              return true;
              // }
            },
            errorRturn => {
              this.alertService.error('something went wrong');
              this.editRowData(rowIndex, 'EnglishDescription');
              return false;
            }
          );
        } else {
          updatedData[0].ModifiedBy = sessionStorage.getItem('LoggedInUserId');
          this._uwMasterService.postUnderWritingMasters(entityType, updatedData).subscribe(
            dataReturn => {
              this.alertService.success('Data updated successfully.');
              updatedData[0].editMode = false;
              this.isRowEditing = false;
              this.getPropertySurveyCriteria();
              return true;
            },
            errorRturn => {
              this.alertService.error('something went wrong');
              this.editRowData(rowIndex, 'EnglishDescription');
              return false;
            }
          );
        }
      } else {
        this.editRowData(rowIndex, validate);
        return false;
      }

    }
  }
  displayModifybutton(functionid) {

    return this.allowAccess.isAllowed(functionid);
  }

}
