
import {AfterViewInit, Component, ViewChild, ViewContainerRef} from "@angular/core";

import {ICellEditorAngularComp} from "ag-grid-angular";


@Component({
  selector: 'rsa-dropdown-editor',
  templateUrl: './dropdown-editor.component.html',
  styleUrls: ['./dropdown-editor.component.scss']
})
export class DropdownEditorComponent implements ICellEditorAngularComp, AfterViewInit  {
  public params: any;
  public value: number;
  public options: any;
  constructor() { }

  // ngOnInit() {
  // }
  

  @ViewChild('input', { read : ViewContainerRef}) public input;

  agInit(params): void {
      this.params = params;
      this.value = this.params.value;
      this.options = params.options;

  }

  getValue(): any {
      return this.value;
  }

  ngAfterViewInit() {
      window.setTimeout(() => {
      })
  }

}
