
import { Component, OnInit, Inject } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular/main';


@Component({
  selector: 'rsa-dropdown-renderer',
  templateUrl: './dropdown-renderer.component.html',
  styleUrls: ['./dropdown-renderer.component.scss']
})
export class DropdownRendererComponent implements ICellRendererAngularComp {
  private params: any;
  public description: string;
  constructor() { }

  // ngOnInit() {
  // }
  agInit(params): void {
    this.params = params;
    this.setDescription(params);
  }

   refresh(params): boolean {
     debugger
    
      this.params = params;
      if(params.colDef.field == 'MunicipalityCode' ){
      let colDefArray:any[] = this.params.colDef.cellEditorParams.options;
      colDefArray.forEach(element => {
        if(element.Code == params.value){
          params.data.MuncipalityDescription = element.EnglishDescription;
        }
      });
    }
    if(params.colDef.field == 'PTcode'){
      let colDefArray:any[] = this.params.colDef.cellEditorParams.options;
      colDefArray.forEach(element => {
        if(element.Code == params.value){
          params.data.CommonDescription = element.EnglishDescription;
        }
      });
    }
    if(params.colDef.field == 'ModeOfTransit'){
      let colDefArray:any[] = this.params.colDef.cellEditorParams.options;
      colDefArray.forEach(element => {
        if(element.Code == params.value){
          params.data.CoverDescription = element.EnglishDescription;
        }
      });
    }
    if(params.colDef.field == 'BrokerCode'){
      let colDefArray:any[] = this.params.colDef.cellEditorParams.options;
      colDefArray.forEach(element => {
        if(element.Code == params.value){
          params.data.BrokerDescription = element.EnglishDescription;
        }
      });
    }
    if(params.colDef.field == 'CustGroup'){
      let colDefArray:any[] = this.params.colDef.cellEditorParams.options;
      colDefArray.forEach(element => {
        if(element.Code == params.value){
          params.data.CustomerDescription = element.EnglishDescription;
        }
      });
    }
    if(params.colDef.field == 'AgentCode'){
      let colDefArray:any[] = this.params.colDef.cellEditorParams.options;
      colDefArray.forEach(element => {
        if(element.Code == params.value){
          params.data.AgentDescription = element.EnglishDescription;
        }
      });
    }
    if(params.colDef.field == 'BodyType'){
      let colDefArray:any[] = this.params.colDef.cellEditorParams.options;
      colDefArray.forEach(element => {
        if(element.Code == params.value){
          params.data.BodyDescription = element.EnglishDescription;
        }
      });
    }
  

      this.setDescription(params);
      return true;
  }



  
  private setDescription(params) {
   
      if(params.colDef.field == 'MunicipalityCode'){
this.description = params.data.MuncipalityDescription;
}
else if(params.colDef.field == 'CountryCode'){
  this.description = params.data.CountryDescription;
  }
      else if(params.colDef.field == 'EarthQuakeZoneCode'){
this.description = params.data.ZoneDescription;
}
      else if(params.colDef.field == 'PTcode'){
  this.description = params.data.CommonDescription;
      }
      else if(params.colDef.field == 'RIRiskCode'){
        this.description = params.data.RiskCategoryDesc;
            }
      else if(params.colDef.field == 'SurveyFrequency'){
          this.description = params.data.Remarks;
                  }
       else if(params.colDef.field == 'ModeOfTransit'){
              this.description = params.data.CoverDescription;
               }
        else if(params.colDef.field == 'BrokerCode'){
                 this.description = params.data.BrokerDescription;
          }
        else if(params.colDef.field == 'AgentCode'){
            this.description = params.data.AgentDescription;
              }
       else if(params.colDef.field == 'CustGroup'){
                 this.description = params.data.CustGroup;
               }
  };
}
