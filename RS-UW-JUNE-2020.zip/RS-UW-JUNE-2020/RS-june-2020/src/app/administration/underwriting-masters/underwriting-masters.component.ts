import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminMastersService } from 'src/app/administration/services/admin-masters.service';

@Component({
    selector: 'rsa-underwriting-masters',
    templateUrl: './underwriting-masters.component.html',
    styleUrls: ['./underwriting-masters.component.scss']
})
export class UnderwritingMastersComponent implements OnInit {
    uwMasterType: string;
    uwType: boolean;

    constructor(private route: ActivatedRoute,
        private router: Router, private _masterService: AdminMastersService) {
        this.route.params.subscribe(params => {
            this.uwMasterType = params['uwmasterName'];
            console.log(this.uwMasterType, 'uwMasterType');
        });
    }
    ngOnInit() {
        this.getCountryRegion();
    }
    getCountryRegion(){
        this.uwType = this.uwMasterType.includes("CountryOrRegion");
    }
}