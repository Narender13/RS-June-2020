import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuminsuredDescriptionComponent } from './suminsured-description.component';

describe('SuminsuredDescriptionComponent', () => {
  let component: SuminsuredDescriptionComponent;
  let fixture: ComponentFixture<SuminsuredDescriptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuminsuredDescriptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuminsuredDescriptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
