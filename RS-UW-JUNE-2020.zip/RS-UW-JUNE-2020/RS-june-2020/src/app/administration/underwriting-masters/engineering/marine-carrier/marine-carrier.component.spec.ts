import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarineCarrierComponent } from './marine-carrier.component';

describe('MarineCarrierComponent', () => {
  let component: MarineCarrierComponent;
  let fixture: ComponentFixture<MarineCarrierComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarineCarrierComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarineCarrierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
