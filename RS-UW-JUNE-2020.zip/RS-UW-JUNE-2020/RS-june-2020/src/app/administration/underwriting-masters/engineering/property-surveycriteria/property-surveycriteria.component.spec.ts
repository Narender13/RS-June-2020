import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PropertySurveycriteriaComponent } from './property-surveycriteria.component';

describe('PropertySurveycriteriaComponent', () => {
  let component: PropertySurveycriteriaComponent;
  let fixture: ComponentFixture<PropertySurveycriteriaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PropertySurveycriteriaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PropertySurveycriteriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
