export class UnderwritingMasters {
    id: number;
    name: string;
    menuid: number;
    path: string;
    active: boolean;
    submenu: UWSubmenu[];
}
export class UWSubmenu {
    id: number;
    name: string;
    menuid: number;
    path: string;
    active: boolean;
    submenu: Submenu[];
    isDisabled:boolean;
    data:{"minRange":0,"maxRange":0};
}

export class Submenu {
    id: number;
    name: string;
    Code: string;
    menuid: number;
    path: string;
    active: boolean;    
}



export class GetMasters {
    EnglishDescription: string;
    ArabicDescription: string;
    Code: string;
    isNewRow: boolean;
    editMode: boolean;
    ModifyBy: string;
}

export class PostMasters {
    ArabicDescription: string;
    Code: string;
    CreateBy: string;
    EnglishDescription: string;
    ModifyBy: string;
    editMode: boolean;
    isNewRow: boolean;
}
