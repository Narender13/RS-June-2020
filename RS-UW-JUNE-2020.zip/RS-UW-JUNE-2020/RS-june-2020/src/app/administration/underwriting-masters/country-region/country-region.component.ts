import { Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';
@Component({
  selector: 'rsa-country-region',
  templateUrl: './country-region.component.html',
  styleUrls: ['./country-region.component.scss']
})
export class CountryRegionComponent implements OnInit {
  countryregionid = 1 ;
  uwmaster: string;

  constructor( public router: Router) { }

  ngOnInit() {
    this.getCountryRegionRoutingDetails();
  }
  getCountryRegionRoutingDetails() {
    //this.route.paramMap.subscribe((params) => {
      //  this.uwmaster = params['uwmasterName'];
        console.log(this.countryregionid);
        //this.queryParams = params;
        this.getCountryRegionType(this.countryregionid);
   // });
  }

  getCountryRegionType(countryregionid: number, name?: string)
  {
    this.countryregionid = countryregionid;
    switch (countryregionid)
    {
      case 1: {
          this.countryregionid = countryregionid;
          this.router.navigate(['admin/underwriting/CountryOrRegion/countryhome']);
          break;
        }
        case 2: {
          this.countryregionid = countryregionid;
          this.router.navigate(['admin/underwriting/CountryOrRegion/region']);
          break;
        }
        case 3: {
          this.countryregionid = countryregionid;
          this.router.navigate(['admin/underwriting/CountryOrRegion/locationhome']);
          break;
        } 
        case 4: {
          this.countryregionid = countryregionid;
          this.router.navigate(['admin/underwriting/CountryOrRegion/muncipality']);
          break;
        }
        case 5: {
          this.countryregionid = countryregionid;
          this.router.navigate(['admin/underwriting/CountryOrRegion/directorate']);
          break;
        }
        case 6: {
          this.countryregionid = countryregionid;
          this.router.navigate(['admin/underwriting/CountryOrRegion/zone']);
          break;
        }
        case 7: {
          this.countryregionid = countryregionid;
          this.router.navigate(['admin/underwriting/CountryOrRegion/geoarea']);
          break;
        }
    }
}
}

 
