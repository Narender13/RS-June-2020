import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuminsuredTypeComponent } from './suminsured-type.component';

describe('SuminsuredTypeComponent', () => {
  let component: SuminsuredTypeComponent;
  let fixture: ComponentFixture<SuminsuredTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuminsuredTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuminsuredTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
