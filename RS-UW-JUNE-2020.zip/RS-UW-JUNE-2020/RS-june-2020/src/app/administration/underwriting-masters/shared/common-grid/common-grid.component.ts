// tslint:disable: quotemark
import { Component, OnInit, Input, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { GridApi, ColumnApi, GridOptions } from 'ag-grid-community';
import { ActionButtonComponent } from '../action-button/action-button.component';
import { DataConfig } from '../../services/data-config';
import { UwMastersService } from '../../services/uw-masters.service';
import { AgGridNg2 } from 'ag-grid-angular';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { AgCustomTextComponent } from '../../../../shared/ag-custom-text/ag-custom-text.component';
import { GetMasters } from '../../entity/uw-masters';
import { Subscription } from 'rxjs';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
  selector: 'rsa-common-grid',
  templateUrl: './common-grid.component.html',
  styleUrls: ['./common-grid.component.scss']
})
export class CommonGridComponent extends DataConfig implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  @Input() uwMaster;
  rowData: GetMasters[] = [];
  domLayout: string;
  gridApi: GridApi;
  gridColumnApi: ColumnApi;
  gridConfiguration: GridOptions = {};
  isRowEditing: boolean;
  frameworkComponents = {};
  currentEditRow: GetMasters;
  suppressClickEdit: boolean;
  editingRowIndex: number;
  selectedRowIndex: number;
  startValue: number;
  endValue: number;
  totalRecords: number;
  currentPage: number;
  totalPages: number;
  isDisableFirst: boolean;
  isDisableLast: boolean;
  paginationOptions: TextValuePair[] = [];
  PostData = [];
  header: string;
  private subscription: Subscription = new Subscription();
  isAddNewAllowed: boolean;
  constructor(
    private http: HttpClient,
    private udwMasterService: UwMastersService,
    private alertService: AlertService,
    private modalService: BsModalService,
    public bsModalRef: BsModalRef,
    public allowAccess: UserAutherizationService
  ) {
    super(allowAccess);
    this.domLayout = 'autoHeight';
  }

  ngOnInit(): void {
    this.header = this.getMasterTitle(this.uwMaster);
    this.frameworkComponents = { agTextInput: AgCustomTextComponent };
    this.GetGridOptions();
    this.getGridData(this.uwMaster);
    this.getCommonMasters(this.uwMaster);
    this.suppressClickEdit = true;
    // this.header = this.uwMaster;
  }

  GetGridOptions() {
    this.gridConfiguration = <GridOptions>{
      // columnDefs: this.columnDefs,
      postProcessPopup: function(params) {
        const ePopup = params.ePopup;
        ePopup.style.top = '14.9838px';
      },
      rowHeight: 40,
      headerHeight: 40,
      pagination: true,
      floatingFiltersHeight: 40,
      paginationPageSize: 20,
      enableRangeSelection: true,
      rowSelection: 'single',
      rowMultiSelectWithClick: true,
      animateRows: true,
      enableColResize: true,
      enableFilter: true,
      suppressContextMenu: true,
      enableSorting: true,
      editType: 'cel',
      suppressCellSelection: true,
      stopEditingWhenGridLosesFocus: true,
      defaultColDef: {
        filter: 'true',
        menuTabs: ['filterMenuTab', '', '']
      },
      context: {
        componentParent: this
      }
    };
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridConfiguration.api.setRowData(this.rowData);
    params.api.paginationGoToPage(0);
    this.fitToCoulmn();
    this.setAutoHeight();
  }
  ngAfterViewInit() {
    this.fitToCoulmn();
    this.setAutoHeight();
  }
  fitToCoulmn() {
    setTimeout(() => {
      this.gridApi.sizeColumnsToFit();
    }, 200);
  }
  setAutoHeight() {
    setTimeout(() => {
      this.gridApi.setDomLayout('autoHeight');
    }, 200);
  }
  getGridData(uwMaster) {
    const filteredArray = this.getdata(uwMaster);
    this.gridConfiguration.columnDefs = filteredArray[0].ColDefs;
    this.gridConfiguration.rowData = this.rowData;
    this.isAddNewAllowed = this.isEditAllowed(filteredArray[0].editFunctionID);
  }
  onCellClicked($event) {
    this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
    const colId = $event.column ? $event.column.colId : null;
    if (this.selectedRowIndex && colId) {
      this.allowEditing(this.selectedRowIndex, colId);
    }
  }
  onCellFocused($event) {
    this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
    const colId = $event.column ? $event.column.colId : null;
    if (this.selectedRowIndex && colId) {
      this.allowEditing(this.selectedRowIndex, colId);
    }
  }
  onCellDoubleClicked($event) {
    this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
    const colId = $event.column ? $event.column.colId : null;
    if (this.selectedRowIndex && colId) {
      this.allowEditing(this.selectedRowIndex, colId);
    }
  }
  allowEditing(rowIndex, colId) {
    if (this.isRowEditing) {
      if (rowIndex !== this.editingRowIndex) {
        this.suppressClickEdit = true;
        this.gridApi.stopEditing();
      } else {
        this.suppressClickEdit = false;
        this.editRowData(rowIndex, colId);
      }
    }
  }
  editRowData(rowIndex, column) {
    this.gridApi.startEditingCell({
      rowIndex: rowIndex,
      colKey: column
    });
    this.isRowEditing = true;
  }
  validateData(currentData) {
    if (currentData.EnglishDescription.trim() === '') {
      this.alertService.error('English Description is empty');
      return 'EnglishDescription';
    }
    if (currentData.Code.toString().trim() === '') {
      this.alertService.error('Code is empty');
      return 'Code';
    }
    return '';
  }
  validateCancellation(currentData) {
    this.validateData(currentData);
    if (currentData.ClassCode.trim() === '') {
      this.alertService.error('Class Code is empty');
      return 'ClassCode';
    }
    return '';
  }
  onParentSaveClicked(id, rowIndex) {
    // check for duplicate code records
    console.log(this.rowData);
    const duplicateRows = this.rowData.filter(data => data.Code.toString() === id.toString());

    if (duplicateRows && duplicateRows.length > 1) {
      this.alertService.error('Record already exists');
      this.getCommonMasters(this.uwMaster);
      this.isRowEditing = false;
      return false;
    } else {
      this.gridApi.stopEditing();

      const updatedData = this.rowData.filter(data => data.Code === id);
      this.PostData.push(updatedData);
      if (updatedData.length > 0) {
        const validate = this.validateData(updatedData[0]);
        if (validate === '') {
          const entityType = this.uwMaster;
          if (updatedData[0].isNewRow === true) {
            this.udwMasterService.postUnderWritingMasters(entityType, updatedData).subscribe(
              dataReturn => {
                this.alertService.success('Data saved successfully.');
                this.isRowEditing = false;
                this.getCommonMasters(this.uwMaster);
                return true;
              },
              errorRturn => {
                this.alertService.error('something went wrong');
                this.editRowData(rowIndex, 'EnglishDescription');
                return false;
              }
            );
          } else {
            updatedData[0].ModifyBy = sessionStorage.getItem('LoggedInUserId');
            this.udwMasterService.postUnderWritingMasters(entityType, updatedData).subscribe(
              dataReturn => {
                this.alertService.success('Data updated successfully.');
                updatedData[0].editMode = false;
                this.isRowEditing = false;
                this.getCommonMasters(this.uwMaster);
                return true;
              },
              errorRturn => {
                this.alertService.error('something went wrong');
                this.editRowData(rowIndex, 'EnglishDescription');
                return false;
              }
            );
          }
        } else {
          this.editRowData(rowIndex, validate);
          return false;
        }
      }
    }
  }
  onParentCheckEdited() {
    const editedData = this.rowData.filter(data => data.editMode === true);
    if (editedData.length > 0) {
      this.alertService.warn('Please save/cancel the data which has already modifed.');
      return true;
    } else {
      return false;
    }
  }
  onGoToNextPage($event) {
    if (!this.onParentCheckEdited()) {
      this.gridApi.paginationGoToNextPage();
    }
  }
  onGoToPreviousPage($event) {
    if (!this.onParentCheckEdited()) {
      this.gridApi.paginationGoToPreviousPage();
    }
  }
  onGoToFirstPage($event) {
    if (!this.onParentCheckEdited()) {
      this.gridApi.paginationGoToFirstPage();
    }
  }
  onGoToLastPage($event) {
    if (!this.onParentCheckEdited()) {
      this.gridApi.paginationGoToLastPage();
    }
  }
  onParentEditClicked(rowIndex) {
    const editedData = this.rowData.filter(data => data.editMode === true);
    const currentEditData = this.rowData[rowIndex];
    let allowRowEdit = false;
    if (editedData.length !== 0) {
      if (editedData[0].Code === currentEditData.Code) {
        allowRowEdit = true;
      }
    } else {
      allowRowEdit = true;
    }
    if (allowRowEdit) {
      this.suppressClickEdit = false;
      this.editingRowIndex = rowIndex;
      currentEditData.editMode = true;
      this.currentEditRow = Object.assign({}, currentEditData);
      this.editRowData(rowIndex, 'EnglishDescription');
      return true;
    } else {
      this.alertService.warn('Please save/cancel the data which already modifed.');
      return false;
    }
  }

  onParentCancel(rowIndex) {
    this.gridApi.stopEditing();
    const selRowData = this.rowData[rowIndex];
    if (selRowData.isNewRow) {
      this.rowData.splice(rowIndex, 1);
    } else {
      this.currentEditRow.editMode = false;
      this.rowData[rowIndex] = this.currentEditRow;
    }
    this.gridConfiguration.api.setRowData(this.rowData);
    this.gridApi.paginationGoToPage(0);
    this.suppressClickEdit = true;
    this.isRowEditing = false;
  }
  onParentDeleteClicked(uwMaster, id) {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, {
      class: 'confirmation-dailog-box modal-md'
    });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    const param = this.uwMaster + '&id=' + id;
    this.bsModalRef.content.valueChange.subscribe(data => {
      if ((data = RSAMSGConstants.BTNPROCEED)) {
        this.udwMasterService.deleteUnderWritingMasters(param).subscribe(
          dataReturn => {
            this.alertService.success('Data deleted successfully.');
            this.getCommonMasters(this.uwMaster);
          },
          errorRturn => {
            console.log(errorRturn);
          }
        );
      }
    });
  }
  setRowData() {
    this.gridConfiguration.api.setRowData(this.rowData);
    this.gridApi.paginationGoToPage(0);
  }
  addNewRow(): any {
    debugger;
    const editedData = this.rowData.filter(data => data.editMode === true && data.isNewRow === true);
    if (editedData.length > 0) {
      this.alertService.warn('Please save/cancel the data which already added.');
    } else {
      const newItem = {
        Code: '',
        EnglishDescription: '',
        ArabicDescription: '',
        isNewRow: true,
        editMode: true,
        CreateBy: sessionStorage.getItem('LoggedInUserId'),
        ModifyBy: sessionStorage.getItem('LoggedInUserId')
      };
      this.rowData.push(newItem);
      this.gridConfiguration.api.setRowData(this.rowData);
      this.gridApi.paginationGoToPage(0);
      this.onParentEditClicked(this.rowData.length - 1);
    }
  }

  getCommonMasters(uwMaster) {
    this.subscription.add(
      this.udwMasterService.getUnderwritingMasters(this.uwMaster).subscribe((masterData: GetMasters[]) => {
        this.rowData = masterData;
        this.totalRecords = this.rowData.length;
      })
    );
  }
  onPaginationChanged($event) {
    if (this.gridApi) {
      this.currentPage = this.gridApi.paginationGetCurrentPage() + 1;
      this.totalPages = this.gridApi.paginationGetTotalPages();
      if (this.currentPage === 1) {
        this.isDisableFirst = true;
      } else {
        this.isDisableFirst = false;
      }
      if (this.currentPage === this.totalPages) {
        this.isDisableLast = true;
      } else {
        this.isDisableLast = false;
      }
      this.startValue = (this.currentPage - 1) * this.gridConfiguration.paginationPageSize + 1;
      this.endValue =
        this.startValue + this.gridConfiguration.paginationPageSize - 1 < this.totalRecords
          ? this.startValue + this.gridConfiguration.paginationPageSize - 1
          : this.totalRecords;
    }
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getMasterTitle(masterName: string): string {
    switch (masterName) {
      case 'Document':
        return 'Document';
      case 'Ricks':
        return 'Ricks';
      case 'Cancellation':
        return 'Cancellation Types';
      case 'RatingType':
        return 'Rating Type';
      case 'QuotationStatus':
        return 'Quotation Status';
      case 'Periodicity':
        return 'Periodicity';
      case 'InspectionResults':
        return 'Inspection Results';
      case 'Occupation':
        return 'Occupation';
      case 'PaymentFrequency':
        return 'Payment Terms';
      case 'VehiclePlate':
        return 'Vehicle Plates';
      case 'VehicleColor':
        return 'Colors';
      case 'Motordepreciationrates':
        return 'Depreciation Rates';
      case 'BlackListedVehicles':
        return 'Black Listed Vehicles';
      case 'PropertyLossItem':
        return 'Consequential Loss Items';
      case 'PropertyConSeqLossItemTypes':
        return 'Consequential Loss Item Types';
      case 'PropertyWall':
        return 'Wall types';
      case 'PropertyRoof':
        return 'Roof Types';
      case 'Occupancy':
        return 'Occupancy';
      case 'PropertySurveyCriteria':
        return 'Survey Criteria';
      case 'WctplEmploymentType':
        return 'Employment Types';
      case 'WCTPLRelations':
        return 'Relations';
      case 'Engineeringsid':
        return 'Sum Insured Descriptions';
      case 'MarinecargoCargoTypes':
        return 'Cargo Types';
      case 'MarineCarrier':
        return 'Carrier';
      case 'MarineCargoPackingTypes':
        return 'Packing Types';
      case 'Commodities':
        return 'Commodities';
      case 'CommodityGroup':
        return 'Commodity Group';
      case 'MarineCargosil':
        return 'Sum Insured Limits';
      case 'MarineCargoInvoiceValueTypes':
        return 'Invoice Value Types';
      case 'HullConstructionType':
        return 'Construction Types';
      case 'Propulsion':
        return 'Propulsion';
      default:
        return masterName;
    }
  }
}
interface TextValuePair {
  id: number;
  value: string;
}
