import { Component,OnInit} from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-button-renderer',
  template: `
    <div class="button-controler">
        <div class="ngSelectionCell" *ngIf="isConfiguredToRenderRadioButton">          
          <input name="selected" type="radio" name={{parentGridName}} (click)="onGridRowSelected($event)">
        </div>
        <div class="ngSelectionCell" *ngIf="!isConfiguredToRenderRadioButton">
          <span>{{description}}</span>
          <button type="button" style="cursor:pointer;" (click)="onGridRowSelected($event)">....</button>
        </div>
    </div> 
    `
})

export class RadioButtonComponent implements ICellRendererAngularComp {

  params;
  parentComponent: any;
  parentGridName: string;
  isConfiguredToRenderRadioButton:boolean;
  public description: string;

  agInit(params): void {
    this.params = params;
    this.parentComponent = this.params.context.componentParent;
    this.parentGridName = this.params.gridName;
    this.isConfiguredToRenderRadioButton = params.isConfiguredToRenderRadioButton;
    this.setDescription(params);
  }

  refresh(params?: any): boolean {
    this.setDescription(params);
    return true;
  }

  onGridRowSelected($event) {
    this.parentComponent.gridSelectionChanged($event,this.parentGridName,this.params.rowIndex);
  }

  private setDescription(params) {
    this.description = params.data.Code;
  }

}
