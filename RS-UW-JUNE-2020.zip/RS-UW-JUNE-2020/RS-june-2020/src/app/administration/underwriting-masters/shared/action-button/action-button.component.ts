import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { ICellRendererParams } from 'ag-grid-community';

@Component({
  selector: 'rsa-action-button',
  templateUrl: './action-button.component.html',
  styleUrls: ['./action-button.component.scss']
})
export class ActionButtonComponent implements ICellRendererAngularComp {
  params: ICellRendererParams;
  masterName: string;
  // here parent component inherits all the properties of Common grid component
  parentComponent: any;
  rowIndex: number;
  dataIndex: number;
  showSave = false;
  showCancel = false;
  pageName: string;
  isView: boolean;
  viewText: string;
  isEditAllowed:boolean=true;
  isDeleteAllowed:boolean=true;
  isHierarchialGrid:false;
  gridPropertyName:string;
  constructor(private alertService: AlertService) {
  }
  agInit(params): void {
    this.params = params;
    this.parentComponent = this.params.context.componentParent;
    this.isHierarchialGrid = this.params.context.isHierarchialGrid;
    this.gridPropertyName = this.params.context.gridPropertyName;
    this.rowIndex = this.params.rowIndex;
    this.pageName = params.inActoionLink;
    this.isEditAllowed = params.isEditAllowed;
    this.isDeleteAllowed = params.isDeleteAllowed;
    this.isView = false;
    if (this.pageName === 'CommonGrid' || 'CountryOrRegion' || 'ClassMaster') {
      if (this.params.data.isNewRow) {
        this.showSave = true;
        this.showCancel = true;
       this. isEditAllowed = false;
        this.isDeleteAllowed = false;

      }
    }
  }

  refresh(): boolean {
    return false;
  }
  editCall(rowIndex) {

 
    if (this.params.data.editMode) {
      this.alertService.warn('Please save/cancel the data which already modifed.');
      return false;
    } else {
      let edited: boolean;
      if(this.isHierarchialGrid){
        edited = this.parentComponent.onHierarchialParentEditClicked(rowIndex,this.parentComponent[this.gridPropertyName]);
      }else{
        edited = this.parentComponent.onParentEditClicked(rowIndex);
      }
      if (edited) {
        this.showSave = true;
        this.showCancel = true;
      }
    }
  }
  deleteCall(id: any, param) {
  
   // this.parentComponent.onParentDeleteClicked(val, param);
    if(this.isHierarchialGrid){
      this.parentComponent.onHierarchialParentDeleteClicked(id, param,  this.pageName);
    }else{
      this.parentComponent.onParentDeleteClicked(id, param);
    }

    
  }
  saveCall(id, rowIndex) {
    debugger
    
    // let saved = this.parentComponent.onParentSaveClicked(id, rowIndex);
 

    let saved: boolean;
    if(this.isHierarchialGrid){
      saved = this.parentComponent.onHierarchialParentSaveClicked(id, rowIndex, this.parentComponent[this.gridPropertyName], this.pageName);
    }else{
      saved = this.parentComponent.onParentSaveClicked(id,rowIndex);
   }
    if(saved) {
      this.showSave = false;
      this.showCancel = false;
    }
  }
  cancelCall(rowIndex) {
    if(this.isHierarchialGrid){
      this.parentComponent.onHierachialParentCancelClicked(rowIndex,this.parentComponent[this.gridPropertyName]);
    }else{
      this.parentComponent.onParentCancel(rowIndex);
    }
    this.showCancel = false;
    this.showSave = false;
  }  

}
