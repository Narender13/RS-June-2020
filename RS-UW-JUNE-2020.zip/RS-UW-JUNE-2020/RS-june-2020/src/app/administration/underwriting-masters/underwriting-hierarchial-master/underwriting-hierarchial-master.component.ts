import { Component, Output, EventEmitter, OnInit, AfterViewInit, ViewChild, TemplateRef, ElementRef, ViewChildren } from '@angular/core';
import { GridOptions } from 'ag-grid-community';
import { PolicySearchgridService } from 'src/app/underwriting/services/policy-search-grid/policy-search-grid.service';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { DatePipe } from '@angular/common';
import { UwMastersService } from '../services/uw-masters.service';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { AgGridNg2 } from 'ag-grid-angular';
import { ActivatedRoute, Params } from '@angular/router';
import { Router, NavigationExtras } from '@angular/router';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ConditionsComponent } from '../snackbar/conditions/conditions.component';
import { PlatformLocation } from '@angular/common';
import { ActionButtonComponent } from './../shared/action-button/action-button.component';
import { AgCustomTextComponent } from 'src/app/shared/ag-custom-text/ag-custom-text.component';
import { AgCustomHeaderComponent } from 'src/app/shared/ag-custom-header/ag-custom-header.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';


import { SuminsuredTypeComponent } from '../shared/suminsured-type/suminsured-type.component';
import { RadioButtonComponent } from '../shared/RadioButtonComponent';
import { Commonfunctions } from '../CountryAndRegion/model1/CommonFunction';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';

@Component({
  selector: 'rsa-underwriting-hierarchial-master',
  templateUrl: './underwriting-hierarchial-master.component.html',
  styleUrls: ['./underwriting-hierarchial-master.component.scss']
})
export class UnderwritingHierarchialMasterComponent extends Commonfunctions implements OnInit, AfterViewInit {
  @ViewChild('hierarchialcell') hierarchialcell: TemplateRef<any>;
  HierarchyForm: FormGroup;
  frameworkComponents: any;
  gridApi: any;
  gridColumnApi: any;
  gridConfiguration: GridOptions = {};
  isClassesAccordionOpen: boolean;
  selectedClass: string;
  selectedPolicyType:string;
  selectedCover:string;
  selectedCoverType:string;
  policyType: boolean;
  policyTypeGridData: any;
  isPolicyTypeAccordionOpen: boolean;
  isCoverAccordionOpen:boolean;
  isCoverTypeAccordionOpen:boolean;
  isCoverSubTypeAccodionOpen:boolean;
  showSnackbar: boolean = false;
  buttonName = [];
  hideForm = true;
  bsModalRef: BsModalRef;
  suppressClickEdit: boolean;
  classid: number = 0;
  policyid: number = 0;
  coverid: number = 0;
  covertypeid: number = 0;
  coversubtypeid: number ;
  hideSumIt = false;
  hideOtherCmp = true;
  hideButton = false;
  @Output() selectedRowDetails = new EventEmitter();
  

  public classGridColumnDefs;  
  public classGridRowData;
  public policyTypeGridColumnDefs;
  public policyTypeGridRowData;
  public coverGridRowData;
  public coverGridColumnDefs;
  public coverTypeGridColumnDefs;
  public coverTypeGridRowData;
  public coverSubTypeGridRowData;
  public coverSubTypeGridColumnDefs;

  @ViewChild('agClassGrid') classGrid:AgGridNg2;
  @ViewChild('policyTypeAGGrid') policyTypeGrid:AgGridNg2;
  @ViewChild('coverAGGrid') coverAgGrid:AgGridNg2;
  @ViewChild('coverTypeAGGrid') coverTypeAgGrid:AgGridNg2;
  @ViewChild('coverTypeSubAGGrid') coverSubTypeAgGrid:AgGridNg2;

  constructor(protected datePipe: DatePipe,
    protected valueFormater: UtilityClass,
    private udwMasterService: UwMastersService, public router: Router,
    private modelservice: BsModalService,
    private fb: FormBuilder,
    public location: PlatformLocation,
    public alertService: AlertService, private allowAccess: UserAutherizationService ) {
    super(router);
    this.frameworkComponents = {};

    location.onPopState(() => {

      this.hideForm = true;

  });


  }
  

  ngOnInit() {
    
    this.createform();
    
    this.setGridColumns();
    this.setGridData();
    this.frameworkComponents = { agTextInput: AgCustomTextComponent, agCustomHeaderComponent: AgCustomHeaderComponent };
    this.GetcolumnDefs();
    this.suppressClickEdit = true;
   
  }
  ngAfterViewInit() {
  }

  setGridData(){
    this.isClassesAccordionOpen = true;
    this.policyTypeGridRowData = [];
    this.coverGridRowData = [];
    this.coverTypeGridRowData = [];

    this.getClassGridData();
    
  }



  setGridColumns(){
    let isEditAllowed = this.allowAccess.isAllowed(2301);
    let isDeleteAllowed = this.allowAccess.isAllowed(2500);

    this.setColumnsForClassGrid(isEditAllowed,isDeleteAllowed);
    this.setColumnsForPolicyTypeGrid(isEditAllowed,isDeleteAllowed);
    this.setColumnsForCoverGrid(isEditAllowed,isDeleteAllowed);
    this.setColumnsForCoverTypeGrid(isEditAllowed,isDeleteAllowed);
    this.setColumnsForCoverSubTypeGrid(isEditAllowed,isDeleteAllowed);
  }
  GetcolumnDefs() {
   
    this.gridConfiguration = <GridOptions>{
      columnDefs: this.classGridColumnDefs,
        context: {
          componentParent: this
        }
    };
}

  setColumnsForClassGrid(isEditAllowed:boolean,isDeleteAllowed:boolean){
    this.classGridColumnDefs = [
      {
        field: "Code",
        width: 100,
        headerName:"Class Code",
        cellRendererFramework:RadioButtonComponent,
        cellRendererParams: {
          gridName:'Class',
          isConfiguredToRenderRadioButton:true,
          context: {
            componentParent: this
          }
        }      
      },      
      {
          headerName: "User Code",
          field: "UserCode",
          width: 100
      },
      {
        headerName: "Description",
        field: "EnglishDescription",        
        editable:true,
        width: 270
      },
      {
        headerName: "Description(AR)",
        field: "ArabicDescription",        
        editable:true,
        width: 270
      },
      {
          headerName: 'Action',
          field: 'value',
          cellRendererFramework: ActionButtonComponent,
          cellRendererParams: {
              inActoionLink: 'ClassMaster',
              isEditAllowed:isEditAllowed,
              isDeleteAllowed:isDeleteAllowed,
              context: {
                componentParent: this,
                isHierarchialGrid:true,
                gridPropertyName:"classGrid"
              }
          },
          colId: 'editSaveBtn',
          filter: 'none',
          headerClass: 'hidefilter'  
      }
    ];
  }

  setColumnsForPolicyTypeGrid(isEditAllowed:boolean,isDeleteAllowed:boolean){
    this.policyTypeGridColumnDefs = [
      {
        field: "ClCode",
        headerName: "Class Code",
        width: 100,
        cellRendererFramework:RadioButtonComponent,
        cellRendererParams: {
          gridName:'PolicyType',
          isConfiguredToRenderRadioButton:true,             
          context: {
            componentParent: this
          }
        } 
      }, 
      {
        field: "Code",
        headerName: "Code",
        width: 100
      },      
      {
          headerName: "User Code",
          field: "UserCode",
          width: 100
      },
      {
        headerName: "Description",
        field: "EnglishDescription",        
        editable:true,
        width: 270
      },
      {
        headerName: "Description(AR)",
        field: "ArabicDescription",        
        editable:true,
        width: 270
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: ActionButtonComponent,
        cellRendererParams: {
            inActoionLink: 'PolicyType',
            isEditAllowed:isEditAllowed,
            isDeleteAllowed:isDeleteAllowed,
            context: {
              componentParent: this,
              isHierarchialGrid: true,
              gridPropertyName:"policyTypeGrid"
            }
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter'  
    }
    ];
  }

  setColumnsForCoverGrid(isEditAllowed:boolean,isDeleteAllowed:boolean){
    this.coverGridColumnDefs = [
      {
        field: "ClCode",
        headerName: "Class Code",
        width: 100,
        cellRendererFramework:RadioButtonComponent,
        cellRendererParams: {
          gridName:'Cover',
          isConfiguredToRenderRadioButton:true,             
          context: {
            componentParent: this
          }
        } 
      }, 
      {
        field: "PtCode",
        headerName: "Property Code",
        width: 100
      },      
      {
          headerName: "Code",
          field: "Code",
          width: 100
      },      
      {
        headerName: "Description",
        field: "EnglishDescription",        
        editable:true,
        width: 270
      },
      {
        headerName: "Description(AR)",
        field: "ArabicDescription",        
        editable:true,
        width: 270
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: ActionButtonComponent,
        cellRendererParams: {
            inActoionLink: 'Cover',
            isEditAllowed:isEditAllowed,
            isDeleteAllowed:isDeleteAllowed,
            context: {
              componentParent: this,
              isHierarchialGrid:true,
              gridPropertyName:"coverAgGrid"
            }
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter'  
    }
    ];
  }  

  setColumnsForCoverTypeGrid(isEditAllowed:boolean,isDeleteAllowed:boolean){
    this.coverTypeGridColumnDefs = [
      {
        field: "ClCode",
        headerName: "Class Code",
        width: 100,
        cellRendererFramework:RadioButtonComponent,
        cellRendererParams: {
          gridName:'CoverType',
          isConfiguredToRenderRadioButton:true,             
          context: {
            componentParent: this
          }
        } 
      }, 
      {
        field: "PtCode",
        headerName: "Pt Code",
        width: 100
      },      
      {
          headerName: "Cover Code",
          field: "CovCode",
          width: 100
      },
      {
        headerName: "Code",
        field: "Code",
        width: 100
      },       
      {
        headerName: "Description",
        field: "EnglishDescription",        
        editable:true,
        width: 270
      },
      {
        headerName: "Description(AR)",
        field: "ArabicDescription",        
        editable:true,
        width: 270
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: ActionButtonComponent,
        cellRendererParams: {
            inActoionLink: 'CoverType',
            isEditAllowed:isEditAllowed,
            isDeleteAllowed:isDeleteAllowed,
            context: {
              componentParent: this,
              isHierarchialGrid:true,
              gridPropertyName:"coverTypeAgGrid"
            }
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter'  
    }
    ];
  }

  setColumnsForCoverSubTypeGrid(isEditAllowed:boolean,isDeleteAllowed:boolean){
    this.coverSubTypeGridColumnDefs = [
      {
        field: "Class",
        headerName: "Class Code",
        width: 100,
        cellRendererFramework:RadioButtonComponent,
        cellRendererParams: {
          gridName:'CoverSubType',   
          isConfiguredToRenderRadioButton:true,          
          context: {
            componentParent: this
          }
        } 
      }, 
      {
        field: "PolicyType",
        headerName: "Pt Code",
        width: 100
      },      
      {
          headerName: "Cover Code",
          field: "Cover",
          width: 100
      },
      {
        headerName: "Cover Type Code",
        field: "CoverType: ",
        width: 100
      },
      {
        headerName: "Code",
        field: "CoverSubType: ",
        width: 100
      },       
      {
        headerName: "Description",
        field: "EnglishDescription",        
        editable:true,
        width: 270
      },
      {
        headerName: "Description(AR)",
        field: "ArabicDescription",        
        editable: true,
        width: 270
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: ActionButtonComponent,
        cellRendererParams: {
            inActoionLink: 'CoverSubType',
            isEditAllowed:isEditAllowed,
            isDeleteAllowed:isDeleteAllowed,
            context: {
              componentParent: this,
              isHierarchialGrid:true,
              gridPropertyName:"coverSubTypeAgGrid"
            }
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter'  
    }
    ]
  }
  createNewBusines() {
    this.bsModalRef = this.modelservice.show(SuminsuredTypeComponent, {
      class: 'modal-dialog create-modal-dailog modal-dialog-centered',
      ignoreBackdropClick: false
    });
  }

  onClassGrirdRowSelected(params) {   
   this.classid = params.data.Code;
    let queryParams = {
      entityType: 'PolicyType',
      classID: params.data.Code
    };
    this.udwMasterService.getUnderwritingMastersHierarchy(queryParams).subscribe((data) => {
      this.selectedClass = " : " + params.data.EnglishDescription;
      //this.policyTypeGrid.api.sizeColumnsToFit();
      this.policyTypeGridRowData = data;
      this.isClassesAccordionOpen = false;
      this.isCoverAccordionOpen = false;
      this.isCoverTypeAccordionOpen = false;
      this.isPolicyTypeAccordionOpen = true;
    });
   
    
  }

  onPolicyTypeGridRowSelected(params) {
    this.classid = params.data.ClCode;
    this.policyid = params.data.Code;
    let queryParams = {
      entityType: 'Cover',
      classID: params.data.ClCode,
      policyTypeID: params.data.Code
    };
    
    this.udwMasterService.getUnderwritingMastersHierarchy(queryParams).subscribe((data) => {
      this.selectedPolicyType = " : " + params.data.EnglishDescription;
      //this.coverAgGrid.api.sizeColumnsToFit();
      this.coverGridRowData = data;
      this.isClassesAccordionOpen = false;
      this.isPolicyTypeAccordionOpen = false;
      this.isCoverTypeAccordionOpen = false;
      this.isCoverSubTypeAccodionOpen = false;
      this.isCoverAccordionOpen = true;      
    });   
    this.showSnackbar = true;
    this.changeEventForTranscation(true);
    this.hideSumIt = true;
  }

  onCoverGridRowSelected(params){
    this.classid = params.data.ClCode;
    this.policyid = params.data.PtCode;
    this.coverid = params.data.Code;
    let queryParams = {
      entityType: 'CoverType',
      classID: params.data.ClCode,
      policyTypeID: params.data.PtCode,
      coverID: params.data.Code
    };

    this.udwMasterService.getUnderwritingMastersHierarchy(queryParams).subscribe((data) => {
      this.selectedCover = " : " + params.data.EnglishDescription;
      //this.coverTypeAgGrid.api.sizeColumnsToFit();
      this.coverTypeGridRowData = data;
      this.isClassesAccordionOpen = false;
      this.isPolicyTypeAccordionOpen = false;
      this.isCoverTypeAccordionOpen = true;
      this.isCoverAccordionOpen = false;
      this.isCoverSubTypeAccodionOpen = false;  
    });

this.showSnackbar = true;
  }

  onCoverTypeGridRowSelected(params){
    this.classid = params.data.ClCode;
    this.policyid = params.data.PtCode;
    this.coverid = params.data.CovCode;
    this.covertypeid = params.data.Code;
    let queryParams = {
      entityType:'Coversubtype',
      classID: params.data.ClCode,
      policyTypeID: params.data.PtCode,
      coverID: params.data.CovCode,
      coverSubTypeID: params.data.Code
    }

    this.udwMasterService.getUnderwritingMastersHierarchy(queryParams).subscribe((data) => {
      this.selectedCoverType = " : " + params.data.EnglishDescription;
      //this.coverSubTypeAgGrid.api.sizeColumnsToFit();
      this.coverSubTypeGridRowData = data;
      this.isClassesAccordionOpen = false;
      this.isPolicyTypeAccordionOpen = false;
      this.isCoverTypeAccordionOpen = false;
      this.isCoverAccordionOpen = false; 
      this.isCoverSubTypeAccodionOpen = true;
    });
    this.showSnackbar = true;
    //this.changeEventForTranscation(true);

  }
  onCoverSubTypeGridRowSelected(params){
    this.classid = params.data.Class;
    this.policyid = params.data.PolicyType ;
    this.coverid = params.data.Cover ;
    this.covertypeid = params.data.CoverType ;
    this.coversubtypeid = params.data.CoverSubType ;
    this.showSnackbar = true;
    this.changeEventForTranscation(true);
  }
  createButton(buttonNames) {
    this.buttonName = buttonNames;
  }
  changeEventForTranscation(ev) {
  
    if (ev) {
      this.createButton([
        // { id: '3', name: 'Conditions', access : this.coversubtypeid >= 0 ? true : false },
        // { id: '5', name: 'Exclusions' , access : this.coversubtypeid >= 0 ? true : false},
        // { id: '11', name: 'Warranties', access : this.coversubtypeid >= 0 ? true : false },
        { id: '3', name: 'Conditions', access : this.coverid >= 0  && this.coversubtypeid == undefined? true : false },
        { id: '5', name: 'Exclusions' , access : this.coverid >= 0  && this.coversubtypeid == undefined? true : false},
        { id: '11', name: 'Warranties', access : this.coverid >= 0  && this.coversubtypeid == undefined? true : false },
        { id: '12', name: 'Endorsements', access : this.coverid >= 0  && this.coversubtypeid == undefined? true : false },
        { id: '13', name: 'Endorsements Header' , access : this.coverid >= 0 && this.coversubtypeid == undefined? true : false},
        { id: '14', name: 'Endorsements Footer' , access : this.coverid >= 0 && this.coversubtypeid == undefined? true : false}
      ]);
      setTimeout(() => {
        this.showSnackbar = true;
      }, 10);
    } else {
      this.showSnackbar = false;
    }
  }

  transButtonHandler(ev) {
    this.hideForm = false;
    this.hideOtherCmp = true;
    this.hideButton = true;
    let navigationExtras: NavigationExtras = {
       queryParams: {
        classID: this.classid,
        policyTypeID: this.policyid,
        coverID: this.coverid,
        coverTypeID : this.covertypeid,
        coverSubTypeID : this.coversubtypeid
          }
        }; 
    if (ev === '3') {
      this.router.navigate(['admin/underwriting/ClassMaster/condition'], navigationExtras);
    }
    else if (ev === '5') {
      this.router.navigate(['admin/underwriting/ClassMaster/exclusions'], navigationExtras);
    }
    else if (ev === '11') {
      this.router.navigate(['admin/underwriting/ClassMaster/warrenties'], navigationExtras);
    }
    else if (ev === '12') {
      this.router.navigate(['admin/underwriting/ClassMaster/endorsement'], navigationExtras);
    }
    else if (ev === '13') {
      this.router.navigate(['admin/underwriting/ClassMaster/endorsementheader'], navigationExtras);
    }
    else if (ev === '14') {
      this.router.navigate(['admin/underwriting/ClassMaster/endorsementfooter'], navigationExtras);
    }
  }
  
  hideSnackBar() {
    this.showSnackbar = false;
    this.gridApi.deselectAll();
  }
  BacktoClass() {
    this.router.navigate(['admin/underwriting/ClassMaster']);
   this.hideForm = true;
   this.hideOtherCmp =  false;
   this.hideButton = false;
  }
  onRowSelected(rowdata) {
    
    const isSelect = rowdata.node.isSelected();
    const selectedRows = this.gridApi.getSelectedRows();
   // this.selectedRecordData = this.gridApi.getSelectedRows()[0];
    console.log(selectedRows, 'selectedRows');

        this.changeEventForTranscation(true);
        this.createButton([
          { id: '1', name: 'Conditions', access : false},
          { id: '4', name: 'Exclusions', access : true },
          { id: '15', name: 'Warranties', access : true},
          { id: '16', name: 'Endorsements', access : true},
          { id: '1', name: 'Endorsements Header', access : true },
          { id: '1', name: 'Endorsements Footer', access : true }
        ]);
    this.showSnackbar = selectedRows.length > 0 ? true : false;
  }

  getClassGridData(){
      this.udwMasterService.getUnderwritingMasters('ClassMaster').subscribe((data) => {
        this.classGridRowData = data;
      });
  }  
  getcondition(){
    this.router.navigate(['admin/underwriting/ClassMaster/condition']);
  }

  onCellValueChanged(params) {
    var colId = params.column.getId();
  }

  onGridReady(params){
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;  
    params.api.sizeColumnsToFit();
    params.suppressRowClickSelection = true
  } 
  
  gridSelectionChanged(event,entityTypeToFetch:string,rowIndex:string){
   
    let selectedRow;
    if(entityTypeToFetch == "Class"){
      selectedRow = this.classGrid.api.getRowNode(rowIndex);
      this.onClassGrirdRowSelected(selectedRow);
    }else if(entityTypeToFetch == "PolicyType"){
      selectedRow = this.policyTypeGrid.api.getRowNode(rowIndex);
      this.onPolicyTypeGridRowSelected(selectedRow);
    }else if(entityTypeToFetch == "Cover"){
      selectedRow = this.coverAgGrid.api.getRowNode(rowIndex);
      this.onCoverGridRowSelected(selectedRow);
    }else if(entityTypeToFetch == "CoverType"){
      selectedRow = this.coverTypeAgGrid.api.getRowNode(rowIndex);
      this.onCoverTypeGridRowSelected(selectedRow);
    }else if(entityTypeToFetch == "CoverSubType"){
      selectedRow = this.coverSubTypeAgGrid.api.getRowNode(rowIndex);
      this.onCoverSubTypeGridRowSelected(selectedRow);
    }
  } 

  exportToExcel(){
    var params = {
      fileName: "fileName",
      sheetName: "sheetName"
    };
    this.classGrid.api.exportDataAsExcel(params);
  }

  createform() {
    this.HierarchyForm = this.fb.group({
      //ClassesGrid: this.fb.array([this.createContentsClasses()]),
      //PolicyGrid: this.fb.array([this.createContentsProperty()])
      classesGrid:this.fb.array([this.classGrid]),
      policyGrid:this.fb.array([this.policyTypeGrid])
    });
  }
  createContentsClasses(): FormGroup {
    return this.fb.group({
      Code: [null],
      UserCode: [''],
      EnglishDescription: [''],
      ArabicDescription: [''],
      Action: []
    });
  }
  createContentsProperty(): FormGroup {
    return this.fb.group({
      Code: [null],
      UserCode: [''],
      EnglishDescription: [''],
      Status: null,
      ArabicDescription: ['']
    });
  }
 
  validateData(currentData) {
    if (currentData.EnglishDescription === "") {
       // this.alertService.error('English Description is empty');
        return 'EnglishDescription';
    }
    return '';
  }
  onHierarchialParentDeleteClicked(val, id,pagename) {
    this.bsModalRef = this.modelservice.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    const param = pagename + '&id=' + id;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = RSAMSGConstants.BTNPROCEED) {
        this.udwMasterService.deleteUnderWritingMasters(param).subscribe(
          dataReturn => {
            this.alertService.success('Data deleted successfully.');
            this.getClassGridData();
          },
          errorRturn => {
            console.log(errorRturn);
          }
        );
      }
    });
  }

  onHierarchialParentSaveClicked(id,rowIndex,gridObj, entityType) {

    gridObj.api.stopEditing();
    const updatedData = gridObj.rowData.filter(data => data.Code === id);
    if (updatedData.length > 0) {
      const validate = this.validateData(updatedData[0]);
      if (validate === '') {
        //const entityType = 'ClassMaster';
          updatedData[0].ModifiedBy = sessionStorage.getItem('LoggedInUserId');
          this.udwMasterService.postUnderWritingMasters(entityType, updatedData).subscribe(
            dataReturn => {
              this.alertService.success('Data updated successfully.');
             // updatedData[0].data.editMode = false;
              this.isRowEditing = false;
              this.getClassGridData();
              return true;
            },
            errorRturn => {
              this.alertService.error('something went wrong');
              this.editRowData(rowIndex, 'EnglishDescription');
              return false;
            }
          );
        }
       else {
        this.editRowData(rowIndex, validate);
        return false;
      }
    
  
    }
  }

  //get contentsRowsClasses() { return this.HierarchyForm.get('ClassesGrid') as FormArray; }
  //get contentsRowsPolicy() { return this.HierarchyForm.get('PolicyGrid') as FormArray; }
}
