import { Component, Output, EventEmitter, OnInit, AfterViewInit, ViewChild, TemplateRef, ElementRef, ViewChildren } from '@angular/core';
import { GridOptions } from 'ag-grid-community';
import { GridApi, ColumnApi } from 'ag-grid-community';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { PolicySearchgridService } from 'src/app/underwriting/services/policy-search-grid/policy-search-grid.service';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { DatePipe } from '@angular/common';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
import { UwMastersService } from '../services/uw-masters.service';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { AgGridNg2 } from 'ag-grid-angular';
import { ActivatedRoute, Params } from '@angular/router';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ActionButtonComponent } from './../shared/action-button/action-button.component';
import { Commonfunctions } from './../CountryAndRegion/model1/CommonFunction';
import { VehicleBodyComponent } from './vehicle-body/vehicle-body.component';
import { DropdownRendererComponent } from './../generic/dropdown-renderer/dropdown-renderer.component';
import { DropdownEditorComponent } from './../generic/dropdown-editor/dropdown-editor.component';
import { RadioButtonComponent } from '../shared/RadioButtonComponent';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';

@Component({
  selector: 'rsa-vehicle-make',
  templateUrl: './vehicle-make.component.html',
  styleUrls: ['./vehicle-make.component.scss']
})
export class VehicleMakeComponent extends Commonfunctions implements OnInit {
  @ViewChild('vehiclemake') vehiclemake: AgGridNg2;
  @ViewChild('vehiclemodel') vehiclemodel: AgGridNg2;
  gridApi: GridApi;
  gridColumnApi: ColumnApi;
  uwMaster:string ;
  HierarchyForm: FormGroup;
  bsModalRef: BsModalRef;
  rowData: any[] = [];
  columnDefs: Array<object> = [];
  domLayout: string;
  gridConfiguration: GridOptions = {};
  frameworkComponents = {};
  editingRowIndex: number;
  suppressClickEdit: boolean;
  currentEditRow: any;
  ModifiedBy: string;
  PreparedBy: string;
  isRowEditing: boolean = false;
  selectedRowIndex;
  PostData: any = [];
  isVehicleAccordionOpen: boolean;
  isVehicleModelAccordionOpen: boolean;
  selectedVehicle: string;
  selectedVehicleModel: string;
  vehiclebodyarrDesc: any = [];
  @Output() selectedRowDetails = new EventEmitter();
  public vehicleGridColumnDefs;  
  public vehicleGridRowData;
  public vehicleModelGridColumnDefs;  
  public vehicleModelGridRowData;

  constructor(protected datePipe: DatePipe,
    protected valueFormater: UtilityClass,
    private alertService: AlertService,
    private allowAccess: UserAutherizationService ,
    private udwMasterService: UwMastersService, public router: Router,
    private modelservice: BsModalService, private fb: FormBuilder) {super(router);}

  ngOnInit() {
    this.createform();
    //this.setGridColumns();
    this.setGridData();
    this.setGridColumns();
    this.GetcolumnDefs();
  }
  setGridColumns(){
    let isEditAllowed = this.allowAccess.isAllowed(2314);
    let isDeleteAllowed = this.allowAccess.isAllowed(2500);

    this.setColumnsForVehicleMake(isEditAllowed,isDeleteAllowed);
    this.setColumnsForVehicleModel(isEditAllowed,isDeleteAllowed);
  }

  setColumnsForVehicleMake(isEditAllowed:boolean,isDeleteAllowed:boolean){
      this.vehicleGridColumnDefs = [
        {
          field: "Code",
          width: 100,
          headerName:"*Code",
          cellRendererFramework: RadioButtonComponent,
          cellRendererParams: {
            gridName: 'VehicleMake',
            isConfiguredToRenderRadioButton:true, 
            context: {
              componentParent: this
            }
          }
        },
        {
          headerName: "*Description(English)",
          field: "EnglishDescription",        
          editable:true,
          width: 270
        },
        {
          headerName: "Description(AR)",
          field: "ArabicDescription",        
          editable:true,
          width: 270
        },
        {
          headerName: "Fraud Indicator",
          field: 'ClmFraudFlag',
          editable: true,
          width: 270
        },
        {
          headerName: 'Action',
          field: 'value',
          cellRendererFramework: ActionButtonComponent,
          cellRendererParams: {
              inActoionLink: 'VehicleMake',
              isEditAllowed:isEditAllowed,
              isDeleteAllowed:isDeleteAllowed,
              context: {
                componentParent: this,
                isHierarchialGrid:true,
                gridPropertyName:"vehiclemake"
              }
          },
          colId: 'editSaveBtn',
          filter: 'none',
          headerClass: 'hidefilter'  
      }
      ];
  }

  setColumnsForVehicleModel(isEditAllowed:boolean,isDeleteAllowed:boolean){
    this.vehiclebodyarrDesc = this.udwMasterService.vehiclebody;
      this.vehicleModelGridColumnDefs = [
        {
          field: "Code",
          width: 100,
          headerName:"*Code",
          cellRendererFramework:RadioButtonComponent,
          cellRendererParams: {
            gridName:'vehiclemodel',
            isConfiguredToRenderRadioButton:true, 
            context: {
              componentParent: this
            }
          }
        },
        {
          headerName: "*Description(English)",
          field: "EnglishDescription",        
          editable:true,
          width: 270
        },
        {
          headerName: "Description(AR)",
          field: "ArabicDescription",        
          editable:true,
          width: 270
        },
        {
          headerName: 'CC',
          field: 'Cc',
          editable:true,
          width: 100
        },
        {
          headerName: 'Tonnage',
          field: 'Tonnage',        
          editable:true,
          width: 100
        },
        {
          headerName: "Seat",
          field: "Seats",        
          editable:true,
          width: 100
        },
        {
          headerName: "Vehicle Category",
          field: "VehicleCategory",        
          editable:true,
          width: 270
        },
        {
          headerName: "Doors",
          field: "Doors",        
          editable:true,
          width: 100
        },
        {
          headerName: "Market Value",
          field: "MarketValue",        
          editable:true,
          width: 270
        },
        {
          headerName: "Body Type",
          field: "BodyType",
          editable:true,
          width: 270,
          cellEditorFramework: DropdownEditorComponent,
          cellEditorParams : {
              options: this.vehiclebodyarrDesc
          },
          cellRendererFramework: DropdownRendererComponent
        },
        {
          headerName: 'Action',
          field: 'value',
          cellRendererFramework: ActionButtonComponent,
          cellRendererParams: {
              inActoionLink: 'VehicleModel',
              isEditAllowed: isEditAllowed,
              isDeleteAllowed: isDeleteAllowed,
              context: {
                componentParent: this,
                isHierarchialGrid:true,
                gridPropertyName: "vehiclemodel"
              }
          },
          colId: 'editSaveBtn',
          filter: 'none',
          headerClass: 'hidefilter'  
      }
      ];
  }
  setGridData(){
    this.isVehicleAccordionOpen = true;
    this.vehicleModelGridRowData = [];
    this.getVehicleMakeGridData();
  }
  gridSelectionChanged(event,entityTypeToFetch:string, rowIndex){
    if(entityTypeToFetch == "VehicleMake"){
      let selectedRow = this.vehiclemake.api.getRowNode(rowIndex);
      this.onVehicleGrirdRowSelected(selectedRow);
    }
  }
  onVehicleGrirdRowSelected(params) {
     let queryParams = {
       entityType: 'VehicleModel',
       classID: params.data.Code
     };
     this.udwMasterService.getVehicleHierarchy(queryParams).subscribe((data) => {
       this.selectedVehicle = " : " + params.data.EnglishDescription;
       this.vehicleModelGridRowData = data;
       this.isVehicleAccordionOpen = false;
       this.isVehicleModelAccordionOpen = true;
     });
   }
 
  getVehicleMakeGridData(){
    this.udwMasterService.getUnderwritingMasters('VehicleMake').subscribe((data) => {
      this.vehicleGridRowData = data;
    });
} 
createform() {
  this.HierarchyForm = this.fb.group({
    VehicleGrid: this.fb.array([this.createVehicleMake()]),
    //PolicyGrid: this.fb.array([this.createContentsProperty()])
  });
}
createVehicleMake(): FormGroup {
  return this.fb.group({
    Code: [null],
    EnglishDescription: [''],
    ArabicDescription: [''],
    ClmFraudFlag: ['']
  });
}
  GetcolumnDefs() {
   
    this.gridConfiguration = <GridOptions>{
      columnDefs: this.vehicleGridColumnDefs,
    };
}
onGridReady(params){
  this.gridApi = params.api;
  this.gridColumnApi = params.columnApi;
  this.gridConfiguration.api.setRowData(this.rowData);
  params.api.sizeColumnsToFit();
  params.suppressRowClickSelection = true;
} 
get contentsRowsClasses() { return this.HierarchyForm.get('VehicleGrid') as FormArray; }

createNewBusines() {
  this.bsModalRef = this.modelservice.show(VehicleBodyComponent, {
    class: 'modal-dialog create-modal-dailog modal-dialog-centered',
    ignoreBackdropClick: false
  });
}
onHierarchialParentSaveClicked(id,rowIndex,gridObj, entityType) {
  gridObj.api.stopEditing();
  const updatedData = gridObj.rowData.filter(data => data.Code === id);
  if (updatedData.length > 0) {
    const validate = this.validateData(updatedData[0]);
    if (validate === '') {
        updatedData[0].ModifiedBy = sessionStorage.getItem('LoggedInUserId');
        this.udwMasterService.postUnderWritingMasters(entityType, updatedData).subscribe(
          dataReturn => {
            this.alertService.success('Data updated successfully.');
           // updatedData[0].data.editMode = false;
           this.getVehicleMakeGridData();
            this.isRowEditing = false;
            return true;
          },
          errorRturn => {
            this.alertService.error('something went wrong');
            this.editRowData(rowIndex, 'EnglishDescription');
            return false;
          }
        );
      }
     else {
      this.editRowData(rowIndex, validate);
      return false;
     }
  }
}
onHierarchialParentDeleteClicked(val, id,pagename) {
  this.bsModalRef = this.modelservice.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
  this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
  this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
  this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
  this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
  const param = pagename + '&id=' + id;
  this.bsModalRef.content.valueChange.subscribe((data) => {
    if (data = RSAMSGConstants.BTNPROCEED) {
      this.udwMasterService.deleteUnderWritingMasters(param).subscribe(
        dataReturn => {
          this.alertService.success('Data deleted successfully.');
          
        },
        errorRturn => {
          console.log(errorRturn);
        }
      );
    }
  });
}


}
