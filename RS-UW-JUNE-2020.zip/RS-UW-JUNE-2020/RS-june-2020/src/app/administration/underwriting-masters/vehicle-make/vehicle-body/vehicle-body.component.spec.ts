import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VehicleBodyComponent } from './vehicle-body.component';

describe('VehicleBodyComponent', () => {
  let component: VehicleBodyComponent;
  let fixture: ComponentFixture<VehicleBodyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VehicleBodyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VehicleBodyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
