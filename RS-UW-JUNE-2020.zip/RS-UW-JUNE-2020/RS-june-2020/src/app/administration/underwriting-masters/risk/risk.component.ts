import { Component, Output, EventEmitter, OnInit, AfterViewInit, ViewChild, TemplateRef, ElementRef, ViewChildren } from '@angular/core';
import { GridOptions } from 'ag-grid-community';
import { GridApi, ColumnApi } from 'ag-grid-community';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { PolicySearchgridService } from 'src/app/underwriting/services/policy-search-grid/policy-search-grid.service';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { DatePipe } from '@angular/common';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
import { UwMastersService } from '../services/uw-masters.service';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { AgGridNg2 } from 'ag-grid-angular';
import { ActivatedRoute, Params } from '@angular/router';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ActionButtonComponent } from './../shared/action-button/action-button.component';
import { Commonfunctions } from './../CountryAndRegion/model1/CommonFunction';
import { RadioButtonComponent } from '../shared/RadioButtonComponent';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';


@Component({
  selector: 'rsa-risk',
  templateUrl: './risk.component.html',
  styleUrls: ['./risk.component.scss']
})
export class RiskComponent extends Commonfunctions implements  OnInit {
  @ViewChild('risk') risk: AgGridNg2;
  @ViewChild('risktype') risktype: AgGridNg2;
  @ViewChild('riskcategory') riskcategory: AgGridNg2;
  @ViewChild('risksubcategory') risksubcategory: AgGridNg2;
  gridApi: GridApi;
  gridColumnApi: ColumnApi;
  uwMaster:string ;
  HierarchyForm: FormGroup;
  bsModalRef: BsModalRef;
  rowData: any[] = [];
  columnDefs: Array<object> = [];
  domLayout: string;
  gridConfiguration: GridOptions = {};
  frameworkComponents = {};
  editingRowIndex: number;
  suppressClickEdit: boolean;
  currentEditRow: any;
  ModifiedBy: string;
  PreparedBy: string;
  isRowEditing: boolean = false;
  selectedRowIndex;
  PostData: any = [];
  isRiskAccordionOpen: boolean;
  isRiskTypeAccordionOpen: boolean;
  isRiskCatAccordionOpen: boolean;
  isRiskCatSubAccordionOpen: boolean;
  selectedRisk: string;
  selectedRisktype: string;
  selectedRiskCat: string;
  selectedRiskCatSub: string;
  public riskColumnDefs;
  public riskRowData;
  public riskTypeColumnDefs;
  public riskTypeRowData;
  public riskCatgColumnDefs;
  public riskCatgRowData;
  public riskSubCatgColumnDefs;
  public riskSubCatgRowData;
  

  constructor(protected datePipe: DatePipe,
    protected valueFormater: UtilityClass,
    private alertService: AlertService,
    private allowAccess: UserAutherizationService ,
    private udwMasterService: UwMastersService, public router: Router,
    private modelservice: BsModalService, private fb: FormBuilder) {super(router); }

  ngOnInit() {
    this.createform();
    this.setGridColumns();
    this.setGridData();
    this.GetcolumnDefs();
  }
  setGridColumns(){
    let isEditAllowed = this.allowAccess.isAllowed(2300);
    let isDeleteAllowed = this.allowAccess.isAllowed(2500);

    this.setColumnsForRisk(isEditAllowed,isDeleteAllowed);
    this.setColumnsForRiskType(isEditAllowed,isDeleteAllowed);
    this.setColumnsForRiskCatgory(isEditAllowed,isDeleteAllowed);
    this.setColumnsForRiskSubCatgory(isEditAllowed,isDeleteAllowed);
  }
  setColumnsForRisk(isEditAllowed:boolean,isDeleteAllowed:boolean){
    this.riskColumnDefs = [
      {
        field: 'Code',
        width: 100,
        headerName: 'Code',
        cellRendererFramework:RadioButtonComponent,
        cellRendererParams: {
          gridName:'Risk',
          isConfiguredToRenderRadioButton:true,             
          context: {
            componentParent: this
          }
        }
      },
      {
        field: 'UserCode',
        width: 100,
        headerName:'User Code',
        editable:true
      },
      {
        headerName: 'Description(English)',
        field: 'EnglishDescription',        
        editable:true,
        width: 270
      },
      {
        headerName: "Description(AR)",
        field: "ArabicDescription",        
        editable:true,
        width: 270
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: ActionButtonComponent,
        cellRendererParams: {
            inActoionLink: 'Risk',
            isEditAllowed:isEditAllowed,
            isDeleteAllowed:isDeleteAllowed,
            context: {
              componentParent: this,
              isHierarchialGrid:true,
              gridPropertyName:"risk"
            }
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter'  
    }
    ];
  }
  setColumnsForRiskType(isEditAllowed:boolean,isDeleteAllowed:boolean){
    this.riskTypeColumnDefs = [
      {
        field: "Code",
        width: 100,
        headerName:"*Code",
        cellRendererFramework:RadioButtonComponent,
        cellRendererParams: {
          gridName:'RiskType', 
          isConfiguredToRenderRadioButton:true,            
          context: {
            componentParent: this
          }
        }
      },
      {
        field: "UserCode",
        width: 100,
        headerName:"User Code",
       
      },
      {
        headerName: "*Description(English)",
        field: "EnglishDescription",        
        editable:true,
        width: 270
      },
      {
        headerName: "Description(AR)",
        field: "ArabicDescription",        
        editable:true,
        width: 270
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: ActionButtonComponent,
        cellRendererParams: {
            inActoionLink: 'RiskType',
            isEditAllowed:isEditAllowed,
            isDeleteAllowed:isDeleteAllowed,
            context: {
              componentParent: this,
              isHierarchialGrid:true,
              gridPropertyName:"risktype"
            }
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter'  
    }
    ];
  }
  setColumnsForRiskCatgory(isEditAllowed:boolean,isDeleteAllowed:boolean){
    this.riskCatgColumnDefs = [
      {
        field: "Code",
        width: 100,
        headerName:"*Code",
        cellRendererFramework: RadioButtonComponent,
        cellRendererParams: {
          gridName:'riskcategory',
          isConfiguredToRenderRadioButton:true,
          context: {
            componentParent: this
          }
        }
      },
      {
        field: "UserCode",
        width: 100,
        headerName:"*UserCode",
        editable:true,
      },
      {
        headerName: "*Description(English)",
        field: "EnglishDescription",        
        editable:true,
        width: 270
      },
      {
        headerName: "Description(AR)",
        field: "ArabicDescription",        
        editable:true,
        width: 270
      },      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: ActionButtonComponent,
        cellRendererParams: {
            inActoionLink: 'RiskCategory',
            isEditAllowed:isEditAllowed,
            isDeleteAllowed:isDeleteAllowed,
            context: {
              componentParent: this,
              isHierarchialGrid:true,
              gridPropertyName:"riskcategory"
            }
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter'  
    }
    ];
  }
  setColumnsForRiskSubCatgory(isEditAllowed:boolean,isDeleteAllowed:boolean){
    this.riskSubCatgColumnDefs = [
      {
        field: "Code",
        width: 100,
        headerName:"*Code",
        cellRendererFramework:RadioButtonComponent,
        cellRendererParams: {
          gridName:'risksubcategory',
          isConfiguredToRenderRadioButton:true,             
          context: {
            componentParent: this
          }
        }
      },
      {
        field: 'UserCode',
        width: 100,
        headerName:"*UserCode"
       
      },
      {
        headerName: "*Description(English)",
        field: "EnglishDescription",        
        editable:true,
        width: 270
      },
      {
        headerName: "Description(AR)",
        field: "ArabicDescription",        
        editable:true,
        width: 270
      },
      {
        headerName: "Status",
        field: "ArabicDescription",        
        editable:true,
        width: 270
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: ActionButtonComponent,
        cellRendererParams: {
            inActoionLink: 'RiskSubCategory',
            isEditAllowed:isEditAllowed,
            isDeleteAllowed:isDeleteAllowed,
            context: {
              componentParent: this,
              isHierarchialGrid:true,
              gridPropertyName:"risksubcategory"
            }
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter'  
    }
    ];
  }
  setGridData(){
    this.isRiskAccordionOpen = true;
    this.riskRowData = [];
    this.getRiskGridData();
  }
  getRiskGridData(){
    this.udwMasterService.getUnderwritingMasters('Risk').subscribe((data) => {
      this.riskRowData = data;
    });
} 
createform() {
  this.HierarchyForm = this.fb.group({
  });
}
gridSelectionChanged(event,entityTypeToFetch:string, rowIndex:string){
  
  if(entityTypeToFetch == "Risk"){
    let selectedRow = this.risk.api.getRowNode(rowIndex);
    this.onRiskGrirdRowSelected(selectedRow);
  }
  else if(entityTypeToFetch == "RiskType"){      
    let selectedRow = this.risktype.api.getRowNode(rowIndex);
    this.onRiskTypeGridRowSelected(selectedRow);
  }
  else if(entityTypeToFetch == "RiskCategory"){      
    let selectedRow = this.riskcategory.api.getRowNode(rowIndex);
    this.onRiskCatgGridRowSelected(selectedRow);
  }
}
onRiskGrirdRowSelected(params) {
   let queryParams = {
     entityType: 'RiskType',
     riskID: params.data.Code
   };
   this.udwMasterService.getRiskHierarchy(queryParams).subscribe((data) => {
     this.selectedRisk = " : " + params.data.EnglishDescription;
     this.riskTypeRowData = data;
     this.isRiskAccordionOpen = false;
     this.isRiskTypeAccordionOpen = true;
     this.isRiskCatAccordionOpen = false;
     this.isRiskCatSubAccordionOpen = false;
   });
 }
 onRiskTypeGridRowSelected(params) {
  let queryParams = {
    entityType: 'RiskCategory',
    riskID: params.data.RskCode,
    riskTypeID: params.data.Code
  };
  this.udwMasterService.getRiskHierarchy(queryParams).subscribe((data) => {
    this.selectedRisktype = " : " + params.data.EnglishDescription;
    this.riskCatgRowData = data;
    this.isRiskAccordionOpen = false;
    this.isRiskTypeAccordionOpen = false;
    this.isRiskCatAccordionOpen = true;
    this.isRiskCatSubAccordionOpen = false;
  });
}
onRiskCatgGridRowSelected(params) {
  let queryParams = {
    entityType: 'RiskSubCategory',
    riskCatgID: params.data.Code,
    riskID: params.data.RC_RSK_CODE,
    riskTypeID: params.data.RC_RT_CODE
  };
  this.udwMasterService.getRiskHierarchy(queryParams).subscribe((data) => {
    this.selectedRiskCat = " : " + params.data.EnglishDescription;
    this.riskSubCatgRowData = data;
    this.isRiskAccordionOpen = false;
    this.isRiskTypeAccordionOpen = false;
    this.isRiskCatAccordionOpen = false;
    this.isRiskCatSubAccordionOpen = true;
  });
}
GetcolumnDefs() {
   
  this.gridConfiguration = <GridOptions>{
    columnDefs: this.riskColumnDefs,
  };
}
onCellValueChanged(params) {
  var colId = params.column.getId();
}

onGridReady(params){
this.gridApi = params.api;
this.gridColumnApi = params.columnApi;
this.gridConfiguration.api.setRowData(this.riskRowData);
params.api.sizeColumnsToFit();
params.suppressRowClickSelection = true
} 
onHierarchialParentSaveClicked(id,rowIndex,gridObj, entityType) {
  gridObj.api.stopEditing();
  const updatedData = gridObj.rowData.filter(data => data.Code === id);
  if (updatedData.length > 0) {
    const validate = this.validateData(updatedData[0]);
    if (validate === '') {
        updatedData[0].ModifiedBy = sessionStorage.getItem('LoggedInUserId');
        this.udwMasterService.postUnderWritingMasters(entityType, updatedData).subscribe(
          dataReturn => {
            this.alertService.success('Data updated successfully.');
           // updatedData[0].data.editMode = false;
            this.isRowEditing = false;
            return true;
          },
          errorRturn => {
            this.alertService.error('something went wrong');
            this.editRowData(rowIndex, 'EnglishDescription');
            return false;
          }
        );
      }
     else {
      this.editRowData(rowIndex, validate);
      return false;
     }
  }
}
onHierarchialParentDeleteClicked(val, id,pagename) {
  this.bsModalRef = this.modelservice.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
  this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
  this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
  this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
  this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
  const param = pagename + '&id=' + id;
  this.bsModalRef.content.valueChange.subscribe((data) => {
    if (data = RSAMSGConstants.BTNPROCEED) {
      this.udwMasterService.deleteUnderWritingMasters(param).subscribe(
        dataReturn => {
          this.alertService.success('Data deleted successfully.');
          this.getRiskGridData();
        },
        errorRturn => {
          console.log(errorRturn);
        }
      );
    }
  });
}

}
