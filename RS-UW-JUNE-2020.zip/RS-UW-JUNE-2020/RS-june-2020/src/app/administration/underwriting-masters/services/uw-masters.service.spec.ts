import { TestBed, inject } from '@angular/core/testing';

import { UwMastersService } from './uw-masters.service';

describe('UwMastersService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UwMastersService]
    });
  });

  it('should be created', inject([UwMastersService], (service: UwMastersService) => {
    expect(service).toBeTruthy();
  }));
});
