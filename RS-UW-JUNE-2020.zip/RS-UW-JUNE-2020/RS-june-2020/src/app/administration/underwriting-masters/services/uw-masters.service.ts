import { Injectable } from '@angular/core';
import { HttpParams, HttpClient, HttpErrorResponse, HttpHeaders, HttpRequest } from '@angular/common/http';
import { map, catchError, tap, shareReplay } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { RSAUNDERWRITINGENDPOINTConstants } from 'src/app/core/under-writing-constant/under-writing-api-end-points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { CountryRegDetails } from '../CountryAndRegion/model1/Contryregion';
import { UnderwritingMasters, GetMasters, PostMasters } from './../entity/uw-masters';


@Injectable({
  providedIn: 'root'
})
export class UwMastersService {
  condesc: CountryRegDetails[] ;
  muncdesc: CountryRegDetails[] ;
  zonedesc: CountryRegDetails[] ;
  policydesc: string[];
  surveycatdesc: string[];
  carrierdesc: string[];
  bcdagent: string[];
  bcdbroker: string[];
  bcdcustomer: string[];
  vehiclebody: string[];
  constructor(private http: HttpClient) {
    this.getCountryRegionDetails('Municipality').subscribe((data) => {
     this.muncdesc = data;
    });
    this.getCountryRegionDetails('Country').subscribe((data) => {
      this.condesc = data;
     });
    this.getCountryRegionDetails('Zone').subscribe((data) => {
      this.zonedesc = data;
     });
     this.getUnderwritingMasters('PolicyType').subscribe((data) => {
      this.policydesc = data;
     });
     this.getUnderwritingMasters('PropertyRiskCategory').subscribe((data) => {
      this.surveycatdesc = data;
     });
     this.getUnderwritingMasters('CoverType').subscribe((data) => {
      this.carrierdesc = data;
     });
     this.getUnderwritingMasters('AgentUW').subscribe((data) => {
      this.bcdagent = data;
     });
     this.getUnderwritingMasters('BrokerUW').subscribe((data) => {
      this.bcdbroker = data;
     });
     this.getUnderwritingMasters('CustomerUW').subscribe((data) => {
      this.bcdcustomer = data;
     });
     this.getUnderwritingMasters('VehicleBody').subscribe((data) => {
      this.vehiclebody = data;
     });
   }
  getUnderWritingMastersList(): Observable<any> {
    return this.http.get(RSAUNDERWRITINGENDPOINTConstants.UNDERWRITINGADMINMASTERS).pipe(
      catchError(handleErrorObservable<any>('getUWUrlsList')));
  }
  getUnderwritingMasters(params): Observable<any> {
    return this.http.get(RSAUNDERWRITINGENDPOINTConstants.GETUDWMASTERS + params).pipe(
      catchError(handleErrorObservable<any>('getUDWMasters')));
  }
  getUnderwritingMastersHierarchyy(params): Observable<any> {
  
    return this.http.get(RSAUNDERWRITINGENDPOINTConstants.GETUDWMASTERSAPI + 'entityType=' +
      params.entityType + '&id=' + params.classId + '&param1=' + params.policyid+ '&param2=' + params.coverid+ '&param3=' + params.covertypeid+ '&param4=' + params.coversubtypeid).pipe(
        catchError(handleErrorObservable<any>('getUDWMasters')));
  }
  deleteUnderWritingMasters(params): Observable<any> {
   
    return this.http.delete(RSAUNDERWRITINGENDPOINTConstants.DELETEUDWMASTERS + params).pipe(
      catchError(handleErrorObservable<any>('deleteUDWMasters')));
  }
  // deleteUnderWritingMasters(params): Observable<any> {
  //   debugger
  //   return this.http.delete(RSAUNDERWRITINGENDPOINTConstants.DELETEUDWMASTERS + 'entityType=' +
  //   params.entitytype + '&id=' + params.ID).pipe(
  //     catchError(handleErrorObservable<any>('deleteUDWMasters')));
  // }
  postUnderWritingMasters(entityType, params): Observable<PostMasters[]> {
    return this.http.post(RSAUNDERWRITINGENDPOINTConstants.POSTUDWMASTERS + 'Post?entityType=' + entityType, params).pipe(
      catchError(handleErrorObservable<any>('insertAndUpdateUdwMasters')));
  }
  getCountryRegionDetails(entityType): Observable<CountryRegDetails[]> {
      return this.http.get<CountryRegDetails[]>(RSAUNDERWRITINGENDPOINTConstants.GETCOUNTRYLIST + entityType).pipe(
        catchError(handleErrorObservable<any>('getRegionDetails')));
      }

    postCountryRegionMasters(entityType, params): Observable<CountryRegDetails[]> {
     
      return this.http.post<CountryRegDetails[]>(RSAUNDERWRITINGENDPOINTConstants.POSTUDWMASTERS + 'Post?entityType=' + entityType, params).pipe(
        catchError(handleErrorObservable<any>('postCountryRegionMasters')));
    }
  
    getUnderwritingMastersHierarchy(params): Observable<any> {
      let hierarchyURLString: string;
  
      if(params.entityType == "PolicyType"){
        hierarchyURLString = RSAUNDERWRITINGENDPOINTConstants.GETUDWMASTERSAPI + 'entityType=' + params.entityType + '&id=' + params.classID;
      }else if(params.entityType == "Cover"){
        hierarchyURLString = RSAUNDERWRITINGENDPOINTConstants.GETUDWMASTERSAPI + 'entityType=' + params.entityType + '&id=' + params.classID + '&param1=' + params.policyTypeID;
      }else if(params.entityType == "CoverType" ){
        hierarchyURLString = RSAUNDERWRITINGENDPOINTConstants.GETUDWMASTERSAPI + 'entityType=' + params.entityType + '&id=' + params.classID + '&param1=' + params.policyTypeID + '&param2=' + params.coverID;
      }else if(params.entityType == "Coversubtype"){
        hierarchyURLString = RSAUNDERWRITINGENDPOINTConstants.GETUDWMASTERSAPI + 'entityType=' + params.entityType + '&id=' + params.classID + '&param1=' + params.policyTypeID + '&param2=' + params.coverID + '&param3=' + params.coverSubTypeID;
      }else{
        console.log("Please verify as entity type is not defined.");
        alert("Error.Please verify as entity type is not defined.");       
      }
          return this.http.get(hierarchyURLString).pipe(
                catchError(handleErrorObservable<any>('getUDWMasters'))); 
    }
    getVehicleHierarchy(params): Observable<any>{
      let hierarchyURLString: string;
      if(params.entityType == "VehicleModel"){
        hierarchyURLString = RSAUNDERWRITINGENDPOINTConstants.GETUDWMASTERSAPI + 'entityType=' + params.entityType + '&id=' + params.classID;
      }
      else{
        alert("Error.Please verify as entity type is not defined.");
      }
      return this.http.get(hierarchyURLString).pipe(
                catchError(handleErrorObservable<any>('getUDWMasters')));
    }

    getRiskHierarchy(params): Observable<any> {
      let hierarchyURLString: string;
  
      if(params.entityType == "RiskType"){
        hierarchyURLString = RSAUNDERWRITINGENDPOINTConstants.GETUDWMASTERSAPI + 'entityType=' + params.entityType + '&id=' + params.riskID;
      }else if(params.entityType == "RiskCategory"){
        hierarchyURLString = RSAUNDERWRITINGENDPOINTConstants.GETUDWMASTERSAPI + 'entityType=' + params.entityType + '&id=' + params.riskID + '&param1=' + params.riskTypeID;
      }else if(params.entityType == "RiskSubCategory" ){
        hierarchyURLString = RSAUNDERWRITINGENDPOINTConstants.GETUDWMASTERSAPI + 'entityType=' + params.entityType + '&id=' + params.riskID + '&param1=' + params.riskTypeID + '&param2=' + params.riskCatgID;
      }else{
        console.log("Please verify as entity type is not defined.");
        alert("Error.Please verify as entity type is not defined.");       
      }
          return this.http.get(hierarchyURLString).pipe(
                catchError(handleErrorObservable<any>('getUDWMasters'))); 
    }
  



}
