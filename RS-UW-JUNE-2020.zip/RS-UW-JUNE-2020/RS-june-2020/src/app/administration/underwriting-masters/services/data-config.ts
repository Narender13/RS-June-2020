import { ActionButtonComponent } from '../shared/action-button/action-button.component';
import { OnInit } from '@angular/core';
import { Injectable } from '@angular/core';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
export class DataConfig implements OnInit {
  constructor(public allowAccess: UserAutherizationService) {}
  maxLength: any;
  getPolicydescription: any = [];
  deleteFunctionID: number = 2500;

  ngOnInit(): void {
    console.log(this.getPolicydescription);
  }

  getCommonColumns(editFunctionID: number) {
    let commonColumns = [
      {
        headerName: 'Code',
        field: 'Code',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        cellEditor: 'agTextInput',
        maxLength: 2
      },
      {
        headerName: 'Description (English)',
        field: 'EnglishDescription',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        cellEditor: 'agTextInput',
        maxLength: 30
      },
      {
        headerName: 'وصف عربي',
        field: 'ArabicDescription',
        sortable: true,
        editable: true,
        filter: 'agTextColumnFilter',
        headerClass: 'ag-rtl',
        cellClass: 'ag-rtl text-right',
        maxLength: 30,
        cellEditor: 'agTextInput'
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: ActionButtonComponent,
        cellRendererParams: {
          inActoionLink: 'CommonGrid',
          isEditAllowed: this.isEditAllowed(editFunctionID),
          isDeleteAllowed: this.isDeleteAllowed()
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter'
      }
    ];

    return commonColumns;
  }

  getdata(masterNameInput): any {
    const ColDefs = [
      {
        masterValue: 'Document',
        ColDefs: this.getCommonColumns(2309),
        editFunctionID: 2309
      },
      {
        masterValue: 'InspectionResults',
        ColDefs: this.getCommonColumns(2310),
        editFunctionID: 2310
      },
      {
        masterValue: 'QuotationStatus',
        ColDefs: this.getCommonColumns(2307),
        editFunctionID: 2307
      },
      {
        masterValue: 'RatingType',
        ColDefs: this.getCommonColumns(2306),
        editFunctionID: 2306
      },
      {
        masterValue: 'PropertyConSeqLossItemTypes',
        ColDefs: this.getCommonColumns(2321),
        editFunctionID: 2321
      },
      {
        masterValue: 'PropertyWall',
        ColDefs: this.getCommonColumns(2322),
        editFunctionID: 2322
      },
      {
        masterValue: 'PropertyRoof',
        ColDefs: this.getCommonColumns(2323),
        editFunctionID: 2323
      },
      {
        masterValue: 'MarineCargoPackingTypes',
        ColDefs: this.getCommonColumns(2331),
        editFunctionID: 2331
      },
      {
        masterValue: 'MarineCargoInvoiceValueTypes',
        ColDefs: this.getCommonColumns(2335),
        editFunctionID: 2335
      },
      {
        masterValue: 'Commodities',
        ColDefs: this.getCommonColumns(2332),
        editFunctionID: 2332
      },

      {
        masterValue: 'CommodityGroup',
        ColDefs: this.getCommonColumns(2333),
        editFunctionID: 2333
      },
      {
        masterValue: 'MarinecargoCargoTypes',
        ColDefs: this.getCommonColumns(2329),
        editFunctionID: 2329
      },
      {
        masterValue: 'HullConstructionType',
        ColDefs: this.getCommonColumns(2336),
        editFunctionID: 2336
      },
      {
        masterValue: 'Propulsion',
        ColDefs: this.getCommonColumns(2337),
        editFunctionID: 2337
      },
      {
        masterValue: 'WctplEmploymentType',
        ColDefs: this.getCommonColumns(2326),
        editFunctionID: 2326
      },
      {
        masterValue: 'Periodicity',
        ColDefs: this.getCommonColumns(2308),
        editFunctionID: 2308
      },
      {
        masterValue: 'Occupation',
        ColDefs: this.getCommonColumns(2311),
        editFunctionID: 2311
      },
      {
        masterValue: 'VehiclePlate',
        ColDefs: this.getCommonColumns(2315),
        editFunctionID: 2315
      },
      {
        masterValue: 'VehicleColor',
        ColDefs: this.getCommonColumns(2316),
        editFunctionID: 2316
      },
      {
        masterValue: 'Cancellation',
        ColDefs: this.getCancellationColumns(2304),
        editFunctionID: 2304
      },
      {
        masterValue: 'PaymentFrequency',
        ColDefs: this.getPaymentTermsColumns(2312),
        editFunctionID: 2312
      },
      {
        masterValue: 'Motordepreciationrates',
        ColDefs: this.getDepriciationRatesColumns(2317),
        editFunctionID: 2317
      },
      {
        masterValue: 'WCTPLRelations',
        ColDefs: this.getCommonColumns(2327),
        editFunctionID: 2327
      },
      {
        masterValue: 'PropertyLossItem',
        ColDefs: this.getPropertyLossItemColumns(2320),
        editFunctionID: 2320
      },
      {
        masterValue: 'Occupancy',
        ColDefs: this.getCommonColumns(2324),
        editFunctionID: 2324
      },
      {
        masterValue: 'MarineCargosil',
        ColDefs: this.getSumInsuredLimitsColumns(2334),
        editFunctionID: 2334
      }
    ];
    const filteredMasterArray = ColDefs.filter(val => val['masterValue'] === masterNameInput);
    return filteredMasterArray;
  }

  getCancellationColumns(editFunctionID: number) {
    let cancellationTypes = [
      {
        headerName: 'Code',
        field: 'Code',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        cellEditor: 'agTextInput',
        maxLength: 5
      },
      {
        headerName: 'Class',
        field: 'ClassCode',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        cellEditor: 'agTextInput',
        maxLength: 5
      },
      {
        headerName: 'Description (English)',
        field: 'EnglishDescription',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        cellEditor: 'agTextInput',
        maxLength: 60
      },
      {
        headerName: 'وصف عربي',
        field: 'ArabicDescription',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        headerClass: 'ag-rtl',
        cellClass: 'ag-rtl text-right',
        maxLength: 60
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: ActionButtonComponent,
        cellRendererParams: {
          inActoionLink: 'CommonGrid',
          isEditAllowed: this.isEditAllowed(editFunctionID),
          isDeleteAllowed: this.isDeleteAllowed()
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter'
      }
    ];

    return cancellationTypes;
  }

  getPaymentTermsColumns(editFunctionID: number) {
    let paymentTerms = [
      {
        headerName: 'Code',
        field: 'Code',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        cellEditor: 'agTextInput',
        maxLength: 4
      },
      {
        headerName: 'Description (English)',
        field: 'EnglishDescription',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        cellEditor: 'agTextInput',
        maxLength: 100
      },
      {
        headerName: 'وصف عربي',
        field: 'ArabicDescription',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        headerClass: 'ag-rtl',
        cellClass: 'ag-rtl text-right',
        maxLength: 100
      },
      { headerName: 'Period', field: 'Period', sortable: true, filter: 'agTextColumnFilter', editable: true, maxLength: 4 },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: ActionButtonComponent,
        cellRendererParams: {
          inActoionLink: 'CommonGrid',
          isEditAllowed: this.isEditAllowed(editFunctionID),
          isDeleteAllowed: this.isDeleteAllowed()
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter'
      }
    ];

    return paymentTerms;
  }

  getDepriciationRatesColumns(editFunctionID: number) {
    let depriciationRates = [
      {
        headerName: 'Vehicle Type',
        field: 'RTcode',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        cellEditor: 'agTextInput',
        maxLength: 5
      },
      {
        headerName: 'Year',
        field: 'Year',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        cellEditor: 'agTextInput',
        maxLength: 4
      },
      {
        headerName: '%',
        field: 'Percentage',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        maxLength: 3
      },
      {
        headerName: 'Cum%',
        field: 'CummulativePerc',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        cellEditor: 'agTextInput',
        maxLength: 2
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: ActionButtonComponent,
        cellRendererParams: {
          inActoionLink: 'CommonGrid',
          isEditAllowed: this.isEditAllowed(editFunctionID),
          isDeleteAllowed: this.isDeleteAllowed()
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter'
      }
    ];

    return depriciationRates;
  }

  getPropertyLossItemColumns(editFunctionID: number) {
    let propertyLossItem = [
      {
        headerName: 'Code',
        field: 'Code',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        cellEditor: 'agTextInput',
        maxLength: 4
      },
      {
        headerName: 'Type',
        field: 'Type',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        cellEditor: 'agTextInput',
        maxLength: 2
      },
      {
        headerName: 'Description (English)',
        field: 'EnglishDescription',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        maxLength: 100
      },
      {
        headerName: 'وصف عربي',
        field: 'ArabicDescription',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        headerClass: 'ag-rtl',
        cellClass: 'ag-rtl text-right',
        maxLength: 100
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: ActionButtonComponent,
        cellRendererParams: {
          inActoionLink: 'CommonGrid',
          isEditAllowed: this.isEditAllowed(editFunctionID),
          isDeleteAllowed: this.isDeleteAllowed()
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter'
      }
    ];

    return propertyLossItem;
  }

  getSumInsuredLimitsColumns(editFunctionID: number) {
    let sumInsuredLimits = [
      {
        headerName: 'Class',
        field: 'CLcode',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        maxLength: 4,
        cellEditor: 'agSelectCellEditor',
        cellEditorParams: {
          values: [4, 99, 3]
        }
      },
      {
        headerName: 'Policy Type',
        field: 'PTcode',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        maxLength: 4,
        cellEditor: 'agSelectCellEditor',
        cellEditorParams: {
          values: [0, 2, 3, 4, 5]
        }
      },
      {
        headerName: 'SumInsuredLimitCode',
        field: 'CTcode',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        cellEditor: 'agTextInput',
        maxLength: 4
      },
      {
        headerName: 'Description(English)',
        field: 'EnglishDescription',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        cellEditor: 'agTextInput',
        maxLength: 30
      },
      {
        headerName: 'Description(Arabic)',
        field: 'ArabicDescription',
        sortable: true,
        filter: 'agTextColumnFilter',
        editable: true,
        cellEditor: 'agTextInput',
        maxLength: 30
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: ActionButtonComponent,
        cellRendererParams: {
          inActoionLink: 'CommonGrid',
          isEditAllowed: this.isEditAllowed(editFunctionID),
          isDeleteAllowed: this.isDeleteAllowed()
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter'
      }
    ];

    return sumInsuredLimits;
  }

  isEditAllowed(editFunctionID: number): boolean {
    return this.allowAccess.isAllowed(editFunctionID);
  }

  isDeleteAllowed() {
    return this.allowAccess.isAllowed(this.deleteFunctionID);
  }
}
