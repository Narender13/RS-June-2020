import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdministrationRoutingModule } from './administration-routing.module';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminMastersComponent } from './admin-masters/admin-masters.component';
import { InstrumentTypesComponent } from './admin-masters/instrument-types/instrument-types.component';
import { AgGridModule } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AgGridAdminEditViewButtonComponent } from 'src/app/administration/admin-masters/ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import { AgCustomTextComponent } from 'src/app/shared/ag-custom-text/ag-custom-text.component';
import { TransactionsComponent } from './admin-masters/transactions/transactions.component';
import { PaymentmodesComponent } from './admin-masters/paymentmodes/paymentmodes.component';
import { CostCentersComponent } from './admin-masters/cost-centers/cost-centers.component';
import { CoaHomeComponent } from '../administration/admin-masters/coa/coa-home/coa-home.component';
import { CoaListComponent } from '../administration/admin-masters/coa/coa-list/coa-list.component';
import { CoaNewComponent } from '../administration/admin-masters/coa/coa-new/coa-new.component';
import { DetailCellViewComponent } from '../administration/admin-masters/coa/detail-cell-view/detail-cell-view.component';
import { EditViewCellComponent } from '../administration/admin-masters/coa/edit-view-cell/edit-view-cell.component';
import { HeaderSettingsComponent } from '../administration/admin-masters/coa/header-settings/header-settings.component';
//import {ChartOfAccount} from '../administration/admin-masters/coa/model/coa.model'
import { GlInterfaceComponent } from './admin-masters/gl-interface/gl-interface.component';
//totalling account
import { TotallingAccountComponent } from './admin-masters/totalling-account/totalling-account.component';
import { DetailViewComponent } from './admin-masters/totalling-account/detail-view/detail-view.component';
import { FinancialAuthorityComponent } from './admin-masters/financial-authority/financial-authority.component';
import { StatusComponent } from './admin-masters/status/status.component';
import { AgGirdCustomDateFilterComponent } from 'src/app/shared/ag-gird-custom-date-filter/ag-gird-custom-date-filter.component';
import { RolesPrivilegesComponent } from './admin-masters/roles-privileges/roles-privileges.component';
import { AgCustomHeaderComponent } from '../shared/ag-custom-header/ag-custom-header.component';
import { AgCustomPaginationComponent } from '../shared/ag-custom-pagination/ag-custom-pagination.component';
import { UsersComponent } from './admin-masters/users/users.component';
import { UserNewComponent } from './admin-masters/users/user-new/user-new.component';
import { UserListComponent } from './admin-masters/users/user-list/user-list.component';
import { EmployeeDetailComponent } from './admin-masters/users/employee-detail/employee-detail.component';
import { AgentBrokerDetailComponent } from './admin-masters/users/agent-broker-detail/agent-broker-detail.component';
import { UserRolePopupComponent } from './admin-masters/users/user-role-popup/user-role-popup.component';
import { PreviligesListComponent } from './admin-masters/roles-privileges/previliges-list/previliges-list.component';
import { CommonGridComponent } from './underwriting-masters/shared/common-grid/common-grid.component';
import { ActionButtonComponent } from './underwriting-masters/shared/action-button/action-button.component';
import { UnderwritingMastersComponent } from './underwriting-masters/underwriting-masters.component';
import { CountryComponent } from './underwriting-masters/CountryAndRegion/CountryComponents/country/country.component';
import { RegionComponent } from './underwriting-masters/CountryAndRegion/region/region.component';
import { LocationComponent } from './underwriting-masters/CountryAndRegion/locationcomponents/location/location.component';
import { CountryRegionComponent } from './underwriting-masters/country-region/country-region.component';
import { MunicipalityComponent } from './underwriting-masters/CountryAndRegion/municipality/municipality.component';
import { DirectorateComponent } from './underwriting-masters/CountryAndRegion/directorate/directorate.component';
import { ZoneComponent } from './underwriting-masters/CountryAndRegion/zone/zone.component';
import { GeoAreaComponent } from './underwriting-masters/CountryAndRegion/geo-area/geo-area.component';
import { CountryHomeComponent } from './underwriting-masters/CountryAndRegion/CountryComponents/country-home/country-home.component';
import { CountryNewComponent } from './underwriting-masters/CountryAndRegion/CountryComponents/country-new/country-new.component';
import { LocationEditComponent } from './underwriting-masters/CountryAndRegion/locationcomponents/location-edit/location-edit.component';
import { LocationHomeComponent } from './underwriting-masters/CountryAndRegion/locationcomponents/location-home/location-home.component'
import { UnderwritingHierarchialMasterComponent } from './underwriting-masters/underwriting-hierarchial-master/underwriting-hierarchial-master.component'
import { AccordionModule } from 'ngx-bootstrap';


import { DropdownEditorComponent } from './underwriting-masters/generic/dropdown-editor/dropdown-editor.component';
import { DropdownRendererComponent } from './underwriting-masters/generic/dropdown-renderer/dropdown-renderer.component';
import { SuminsuredDescriptionComponent } from './underwriting-masters/engineering/suminsured-description/suminsured-description.component';
import { PropertySurveycriteriaComponent } from './underwriting-masters/engineering/property-surveycriteria/property-surveycriteria.component';
import { MarineCarrierComponent } from './underwriting-masters/engineering/marine-carrier/marine-carrier.component';
import { BrokercertificateDirectComponent } from './underwriting-masters/brokercertificate/brokercertificate-direct/brokercertificate-direct.component';
import { BrokercertificateBrokerComponent } from './underwriting-masters/brokercertificate/brokercertificate-broker/brokercertificate-broker.component';
import { BrokercerticateAgentComponent } from './underwriting-masters/brokercertificate/brokercerticate-agent/brokercerticate-agent.component';
import { BrokerCertificateDetailsComponent } from './underwriting-masters/brokercertificate/broker-certificate-details/broker-certificate-details.component';

import { SuminsuredTypeComponent } from './underwriting-masters/shared/suminsured-type/suminsured-type.component';
import { ConditionsComponent } from './underwriting-masters/snackbar/conditions/conditions.component';
import { ExclusionComponent } from './underwriting-masters/snackbar/exclusion/exclusion.component';
import { WarrantiesComponent } from './underwriting-masters/snackbar/warranties/warranties.component';
import { EndorsementsComponent } from './underwriting-masters/snackbar/endorsements/endorsements.component';
import { EndorsementHeaderComponent } from './underwriting-masters/snackbar/endorsement-header/endorsement-header.component';
import { EndorsementFooterComponent } from './underwriting-masters/snackbar/endorsement-footer/endorsement-footer.component';
import { RadioButtonComponent } from './underwriting-masters/shared/RadioButtonComponent';
import { TrackOrangeCardComponent } from './underwriting-masters/motars-orange/track-orange-card/track-orange-card.component';
import { OrangeCardSeriesComponent } from './underwriting-masters/motars-orange/orange-card-series/orange-card-series.component';
import { MotarsOrangeTabsComponent } from './underwriting-masters/motars-orange/motars-orange-tabs/motars-orange-tabs.component';
import { VehicleBodyComponent } from './underwriting-masters/vehicle-make/vehicle-body/vehicle-body.component';
import { VehicleMakeComponent } from './underwriting-masters/vehicle-make/vehicle-make.component';
import { RiskComponent } from './underwriting-masters/risk/risk.component';
import { AgentBrokerBranchComponent } from './underwriting-masters/motars-orange/agent-broker-branch/agent-broker-branch.component';


@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    AdministrationRoutingModule,
    AgGridModule.withComponents([
      AgGridAdminEditViewButtonComponent,
      AgCustomTextComponent,
      EditViewCellComponent,
      DetailCellViewComponent,
      AgGirdCustomDateFilterComponent,
      AgCustomHeaderComponent,
      AgCustomPaginationComponent,
      ActionButtonComponent,
      DropdownEditorComponent,
      DropdownRendererComponent,
      RadioButtonComponent
    ]),
    ModalModule.forRoot(),
    AccordionModule.forRoot(),
  ],
  declarations: [AdminHomeComponent, AdminMastersComponent, InstrumentTypesComponent, AgGridAdminEditViewButtonComponent,
    TransactionsComponent, PaymentmodesComponent, CostCentersComponent, CoaHomeComponent, CoaListComponent, CoaNewComponent,
    DetailCellViewComponent, EditViewCellComponent, GlInterfaceComponent, FinancialAuthorityComponent, StatusComponent,
    HeaderSettingsComponent,
    TotallingAccountComponent,
    DetailViewComponent,
    RolesPrivilegesComponent,
    UsersComponent,
    UserNewComponent,
    UserListComponent,
    EmployeeDetailComponent,
    AgentBrokerDetailComponent,
    UserRolePopupComponent,
    PreviligesListComponent,
    CommonGridComponent,
    ActionButtonComponent,
    UnderwritingMastersComponent,
    CountryComponent,
    RegionComponent,
    LocationComponent,
    CountryRegionComponent,
    MunicipalityComponent,
    DirectorateComponent,
    ZoneComponent,
    GeoAreaComponent,
    CountryHomeComponent,
    CountryNewComponent,
    LocationEditComponent,
    LocationHomeComponent,
    VehicleMakeComponent,
    VehicleBodyComponent,
    RiskComponent,
 UnderwritingHierarchialMasterComponent,
 TrackOrangeCardComponent,
 OrangeCardSeriesComponent,
 MotarsOrangeTabsComponent,
 DropdownEditorComponent,
 DropdownRendererComponent,
 SuminsuredDescriptionComponent,
 PropertySurveycriteriaComponent,
 MarineCarrierComponent,
 BrokercertificateDirectComponent,
 BrokercertificateBrokerComponent,
 BrokercerticateAgentComponent,
 BrokerCertificateDetailsComponent,

 SuminsuredTypeComponent,
 ConditionsComponent,
 ExclusionComponent,
 WarrantiesComponent,
 EndorsementsComponent,
 EndorsementHeaderComponent,
 EndorsementFooterComponent,
 RadioButtonComponent,
 AgentBrokerBranchComponent
],
  entryComponents: [DetailViewComponent, SuminsuredTypeComponent, VehicleBodyComponent,AgentBrokerBranchComponent,ActionButtonComponent,
    EmployeeDetailComponent, AgentBrokerDetailComponent, UserRolePopupComponent,
    PreviligesListComponent],
  providers: [BsModalRef]
})
export class AdministrationModule { }
