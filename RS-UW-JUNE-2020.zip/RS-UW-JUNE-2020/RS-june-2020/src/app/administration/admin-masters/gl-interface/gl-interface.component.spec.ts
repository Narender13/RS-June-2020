import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GlInterfaceComponent } from './gl-interface.component';

describe('GlInterfaceComponent', () => {
  let component: GlInterfaceComponent;
  let fixture: ComponentFixture<GlInterfaceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GlInterfaceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GlInterfaceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
