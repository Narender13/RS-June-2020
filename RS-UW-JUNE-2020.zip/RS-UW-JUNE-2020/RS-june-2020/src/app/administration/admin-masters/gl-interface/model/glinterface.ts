export class Glinterface {
    FromDate: Date;
    ToDate: Date;
    GLIGatCode: any;
    CountryCode: any;
    RegionCode: any;
    LocationCode: any;
    CostCentreCode: any;
    TotalingAccountCode: any;
    GlCode: number;
}
