import { Component, OnInit, ViewChild, AfterViewInit, ElementRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators, } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { AgCustomTextComponent } from 'src/app/shared/ag-custom-text/ag-custom-text.component';
import { AgGridAdminEditViewButtonComponent } from 'src/app/administration/admin-masters/ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { Glinterface } from './model/glinterface';
import { AdminMastersService } from './../../services/admin-masters.service';
import { DatePipe, formatDate } from '@angular/common';
import { SuccessDialogComponent } from 'src/app/shared/custom-success-model/custom-success-model.component';
import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';
import { AgCustomDateComponent } from 'src/app/shared/ag-custom-date/ag-custom-date.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
    selector: 'rsa-gl-interface',
    templateUrl: './gl-interface.component.html',
    styleUrls: ['./gl-interface.component.scss']
})
export class GlInterfaceComponent implements OnInit {
    @ViewChild('agGrid') agGrid: AgGridNg2;
    gridApi;
    gridColumnApi;
    frameworkComponents;
    suppressClickEdit;
    domLayout;
    columnDefs: Array<object> = [];
    paginationOptions: TextValuePair[] = [];
    rowData: any;
    currentEditRow;
    glinterface: Glinterface;
    isRowEditing: boolean = false;
    gridConfiguration: GridOptions = {};
    editingRowIndex: number;
    addFormOption: boolean;
    GlcodeForm: FormGroup;
    GatCodeList: any[];
    CountryList: any[];
    RegionList: any[];
    LocationList: any[];
    CostCenterList: any[];
    TotallingList: any[];
    returnValue: any;
    errorGatCode: boolean;
    errorCountry: boolean;
    errorRegion: boolean;
    errorLocation: boolean;
    errorCostCenter: boolean;
    errorTotalling: boolean;
    errorGlCode: boolean;
    selectedTypeVal: any;
    errorGatCodeExists: boolean;
    Modify: number = 305;
    @ViewChild('newGatCodename') private newGatCodename: ElementRef;
    // @ViewChild("newCategoryname") newCategoryname: ElementRef<HTMLElement, any>;
    isGatCodeAdded: boolean
    constructor(private alertService: AlertService, private modalService: BsModalService, private gridApiService: GridApiService,
        public bsModalRef: BsModalRef, private fb: FormBuilder, public datepipe: DatePipe, private glservice: AdminMastersService, private allowAccess: UserAutherizationService) {
        this.domLayout = 'autoHeight';
    }

    ngOnInit() {
        this.createGlForm();
        this.fieldStatusChanges();
        this.getGatCode();
        this.getCostcenter();
        this.getTotallingAccount();
        this.getCountry();
        this.getgl();
        //this.getLocation();
        this.getRegion();
        this.columnDefs = [
            // {
            //     headerName: '', field: 'name', headerCheckboxSelection: true, headerCheckboxSelectionFilteredOnly: true, checkboxSelection: true, filter: 'none',
            //     headerClass: 'hidefilter', width: 40
            // },

            {
                headerName: 'Gat Code', field: 'EnglishDescription', filter: 'agTextColumnFilter', editable: true, sortable: false,
            },
            {
                headerName: 'Country', field: 'CountryDesc', filter: 'agTextColumnFilter', editable: true, sortable: true,
            },
            {
                headerName: 'Region', field: 'RegionDesc', filter: 'agTextColumnFilter', editable: true, sortable: true,
            },
            {
                headerName: 'Location', field: 'LocationDesc', filter: 'agTextColumnFilter', editable: true, sortable: true,
            },
            {
                headerName: 'Cost Centre', field: 'CostCentreDescription', filter: 'agTextColumnFilter', editable: true, sortable: true,
            },

            {
                headerName: 'Totalling Account Code', field: 'TotalingAccountDescription', filter: 'agTextColumnFilter', editable: true, sortable: true,
            },
            {
                headerName: 'Gl Code', field: 'GlCode', filter: 'agTextColumnFilter', editable: true, sortable: true,
            },
            {
                headerName: 'From Date', field: 'FromDate', filter: 'agDateColumnFilter', editable: true, sortable: true,
            },
            {
                headerName: 'To Date', field: 'ToDate', filter: 'agDateColumnFilter', editable: true, sortable: true,
            },
            // {
            //     headerName: 'Action',
            //     field: 'value',
            //     width: 300,
            //     cellRendererFramework: AgGridAdminEditViewButtonComponent,
            //     cellRendererParams: {
            //         inActoionLink: 'Glinterface'
            //     },
            //     colId: 'editSaveBtn',
            //     filter: 'none',
            //     headerClass: 'hidefilter',
            //     hide: !this.displayModifybutton(305),
            // }
        ];
        this.frameworkComponents = { agTextInput: AgCustomTextComponent, agInputDate: AgCustomDateComponent, };
        this.GetcolumnDefs();
        this.suppressClickEdit = true;
    }

    createGlForm(): void {
        this.GlcodeForm = this.fb.group({
            FromDate: [''],
            ToDate: [''],
            GLIGatCode: ['', Validators.required],
            CountryCode: ['', Validators.required],
            RegionCode: ['', Validators.required],
            LocationCode: ['', Validators.required],
            CostCentreCode: ['', Validators.required],
            TotalingAccountCode: ['', Validators.required],
            GlCode: ['', Validators.required],
        });
    }

    get GLGatCode() { return this.GlcodeForm.get('GLIGatCode'); };
    get GLCountry() { return this.GlcodeForm.get('CountryCode'); };
    get GLRegion() { return this.GlcodeForm.get('RegionCode'); };
    get GLLocation() { return this.GlcodeForm.get('LocationCode'); };
    get GLCostCentre() { return this.GlcodeForm.get('CostCentreCode'); };
    get GLTotalling() { return this.GlcodeForm.get('TotalingAccountCode'); };
    get GLGlCode() { return this.GlcodeForm.get('GlCode'); };
    fieldStatusChanges() {
        this.clearerrors();
        this.GLGatCode.statusChanges.subscribe(
            status => { this.errorGatCode = (status == 'INVALID'); }
        );
        this.GLCountry.statusChanges.subscribe(
            status => {
                this.errorCountry = (status == 'INVALID');
            }
        );
        this.GLRegion.statusChanges.subscribe(
            status => { this.errorRegion = (status == 'INVALID'); }
        );
        this.GLLocation.statusChanges.subscribe(
            status => { this.errorLocation = (status == 'INVALID'); }
        );
        this.GLCostCentre.statusChanges.subscribe(
            status => { this.errorCostCenter = (status == 'INVALID'); }
        );
        this.GLTotalling.statusChanges.subscribe(
            status => { this.errorTotalling = (status == 'INVALID'); }
        );
        this.GLGlCode.statusChanges.subscribe(
            status => { this.errorGlCode = (status == 'INVALID'); }
        );
    }
    clearerrors() {
        this.errorGatCode = false;
        this.errorCountry = false;
        this.errorRegion = false;
        this.errorLocation = false;
        this.errorCostCenter = false;
        this.errorTotalling = false;
        this.errorGlCode = false;
    }
    GetcolumnDefs() {
        this.gridConfiguration = <GridOptions>{
            columnDefs: this.columnDefs,
            postProcessPopup: function (params) {
                const ePopup = params.ePopup;
                ePopup.style.top = '14.9838px';
            },
            rowData: this.rowData,
            rowHeight: 40,
            headerHeight: 40,
            pagination: true,
            floatingFiltersHeight: 40,
            paginationPageSize: 20,
            enableRangeSelection: true,
            rowSelection: 'single',
            rowMultiSelectWithClick: true,
            animateRows: true,
            enableColResize: true,
            enableFilter: true,
            suppressContextMenu: true,
            enableSorting: true,
            editType: 'cel',
            defaultColDef: {
                enableRowGroup: false,
                enableValue: true,
                suppressMovable: true,
                minWidth: 40,
                menuTabs: ['filterMenuTab', '', '']
            },
            context: {
                componentParent: this
            },
        };
    }
    setAutoHeight() {
        setTimeout(() => {
            this.gridApi.setDomLayout('autoHeight');
        }, 200);

    }
    getgl(): any {
        this.glservice.getglinterface().subscribe((data) => {
            this.rowData = data;
            //  console.log(data, this.rowData);
        });
    }
    getGatCode() {
        this.glservice.getGatCode().subscribe(
            dataReturn => {
                this.GatCodeList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getCostcenter() {
        this.glservice.getCostcenter().subscribe(
            dataReturn => {
                this.CostCenterList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getTotallingAccount() {
        const param = 'costCenter=' + sessionStorage.getItem('costCenter');
        this.glservice.getTotallingAccount(param).subscribe(
            dataReturn => {
                this.TotallingList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getCountry() {
        this.glservice.getCountries().subscribe(
            dataReturn => {
                this.CountryList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getLocation(val: any) {
        console.log("value" + val);
        const param = 'ctyCode=' + sessionStorage.getItem('countrycode') +
            '&regCode=' + val;
        this.glservice.getLocation(param).subscribe(
            dataReturn => {
                //console.log("data1" + JSON.stringify(dataReturn));
                this.LocationList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getRegion() {
        const param = 'ctyCode=' + sessionStorage.getItem('countrycode');
        this.glservice.getRegion(param).subscribe(
            dataReturn => {
                this.RegionList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    onParentCancel(rowIndex) {
        this.gridApi.stopEditing();
        this.currentEditRow.editMode = false;
        this.rowData[rowIndex] = this.currentEditRow;
        this.gridConfiguration.api.setRowData(this.rowData);
        this.suppressClickEdit = true;
        this.isRowEditing = false;
    }

    onParentDeleteClicked(id, rowIndex) {
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
        this.bsModalRef.content.valueChange.subscribe((data) => {
            if (data = RSAMSGConstants.BTNPROCEED) {
                this.glservice.deletegl(id).subscribe(
                    dataReturn => {
                        if (!dataReturn) {
                            this.alertService.success('Data cannot be deleted as it is already associated with transactions.');
                            this.getgl();
                        }
                        else if (dataReturn) {
                            this.alertService.success('Data deleted successfully.');
                            this.getgl();
                        }
                        errorRturn => {
                            console.log(errorRturn);
                        }
                    });
            }

        });
        this.getgl();
    }
    fitToCoulmn() {
        setTimeout(() => {
            this.gridApi.sizeColumnsToFit();
        }, 200);
    }
    onGridReady(params) {
        console.log(params, 'params');
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        this.gridConfiguration.api.setRowData(this.rowData);
        params.api.paginationGoToPage(0);
        this.fitToCoulmn();
    }
    addNewRow() {
        this.addFormOption = true;
        // this.GlcodeForm.enable();
    }
    changeFromDate() {
        if (this.GlcodeForm.controls['FromDate'].value) {
            const FromDate = new Date(this.GlcodeForm.controls['FromDate'].value);
            this.GlcodeForm.controls['FromDate'].setValue(new DatePipe('en-US').transform(FromDate, 'dd/MM/yyyy'));
        }
    }
    changeToDate() {
        if (this.GlcodeForm.controls['ToDate'].value) {
            const ToDate = new Date(this.GlcodeForm.controls['ToDate'].value);
            this.GlcodeForm.controls['ToDate'].setValue(new DatePipe('en-US').transform(ToDate, 'dd/MM/yyyy'));
        }
    }
    addNewGatCode(catValue: any) {
        if (catValue === 'newGatCodeType') {
            console.log(catValue + " new category " + this.GlcodeForm.controls['GLIGatCode'].value);
            this.selectedTypeVal = catValue;
            this.GlcodeForm.controls['GLIGatCode'].setValue("");
        }
    }
    addToGatCodeList() {
        this.newGatCodename.nativeElement.value = this.newGatCodename.nativeElement.value.trim();
        if (this.newGatCodename.nativeElement.value) {
            if (this.checkDuplicatesInGatCodeList() == true) {
                console.log("gggg");
                this.errorGatCodeExists = true;
            } else {
                let newGatCode: any = { "Code": 0, "E_desc": this.newGatCodename.nativeElement.value };
                this.isGatCodeAdded = true;
                this.GatCodeList.push(newGatCode);
                this.selectedTypeVal = "";
                this.errorGatCodeExists = false;
            }
        }
    }
    hideAddGatCode() {
        this.GlcodeForm.controls['GLIGatCode'].setValue("");
        this.selectedTypeVal = "";
        this.errorGatCodeExists = false;
    }
    checkDuplicatesInGatCodeList() {
        let duplicateValueExists: boolean = false;
        this.GatCodeList.forEach((item) => {
            if (this.newGatCodename.nativeElement.value == item.E_desc) {
                duplicateValueExists = true;
            }
        });
        return duplicateValueExists;
    }
    setErrorInvalid() {
        this.errorGatCode = this.GLGatCode.invalid;
        this.errorCountry = this.GLCountry.invalid;
        this.errorRegion = this.GLRegion.invalid;
        this.errorLocation = this.GLLocation.invalid;
        this.errorCostCenter = this.GLCostCentre.invalid;
        this.errorTotalling = this.GLTotalling.invalid;
        this.errorGlCode = this.GLGlCode.invalid;
    }
    submitForm() {
        //this.submitted = true;
        this.setErrorInvalid();
        // stop here if form is invalid
        if (this.GlcodeForm.invalid) {
            return;
        }
        else {
            console.log("\n second form values" + JSON.stringify(this.GlcodeForm.value) + "\n");
            let clonedGlForm: any = this.GlcodeForm.value;
            clonedGlForm.GLAccType = {
                "Code": this.GlcodeForm.controls['GLIGatCode'].value,
                "GatEnglishDesc": this.isGatCodeAdded ? this.GatCodeList[this.GatCodeList.length - 1].E_desc : "",
                "GatArabicDesc": this.isGatCodeAdded ? this.GatCodeList[this.GatCodeList.length - 1].E_desc : "",
                "IsNew": this.GlcodeForm.controls['GLIGatCode'].value === '0' ? true : false
            };
            console.log("cloned values\n" + JSON.stringify(clonedGlForm));
            this.glservice.createGl(JSON.stringify(clonedGlForm)).subscribe(
                dataReturn => {
                    this.returnValue = dataReturn;
                    console.log(this.returnValue, 'this.returnValue');
                    //success modal
                    if (this.returnValue == true) {
                        this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                        this.bsModalRef.content.modelTitle = '';
                        this.bsModalRef.content.modelBodyContent = "New GlCode Successfully Created";
                        this.bsModalRef.content.actionBtn = "Continue to Construct GlCode";
                        this.bsModalRef.content.valueChange.subscribe((data) => {
                            console.log(" success datat" + data);
                            if (data == 'Close') {
                                console.log("close btn clicked");
                            } else {
                                console.log(" else close");
                            }
                            this.resetForm();
                            // this.addFormOption = false;
                            // this.getgl();
                        });
                    }
                    else if (this.returnValue == false) {
                        this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                        this.bsModalRef.content.modelTitle = '';
                        this.bsModalRef.content.modelBodyContent = " GlCode has already exists";
                        this.bsModalRef.content.actionBtn = "Cancel";
                        this.bsModalRef.content.valueChange.subscribe((data) => {
                            console.log(" success datat" + data);
                            if (data == 'Close') {
                                console.log("close btn clicked");
                            } else {
                                console.log(" else close");
                            }
                            this.resetForm();
                        });
                    }
                },
                errorRturn => {
                    console.log(errorRturn);
                }
            );
        }
    }
    resetForm() {
        let arrayFormFields = ['FromDate', 'ToDate', 'GLIGatCode', 'CountryCode', 'RegionCode', 'LocationCode', 'CostCentreCode', 'TotalingAccountCode', 'GlCode'];
        arrayFormFields.forEach((val) => {
            if (this.GlcodeForm.controls[val] != null && this.GlcodeForm.controls[val] != undefined) {
                this.GlcodeForm.controls[val].reset();
            }
        });
        this.clearerrors();
    }
    cancelForm() {
        this.resetForm();
        this.addFormOption = false;
        this.getgl();
    }
    getRowData() {
        return this.rowData;
    }
    displayModifybutton(functionid) {

        return this.allowAccess.isAllowed(functionid);
    }
}
interface TextValuePair {
    id: number;
    value: string;
}


