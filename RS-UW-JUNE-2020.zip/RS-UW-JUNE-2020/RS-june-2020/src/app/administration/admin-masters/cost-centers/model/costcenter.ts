export class CostCenter {
    CCCode:number;
    E_Desc: string;
    A_Desc:string;
    success: boolean;
    message: string;
}