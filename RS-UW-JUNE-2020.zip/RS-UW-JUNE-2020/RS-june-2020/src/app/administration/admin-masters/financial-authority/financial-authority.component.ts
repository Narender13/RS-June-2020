import { Component, OnInit, ViewChild, AfterViewInit, ElementRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators, ValidatorFn } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { AgCustomTextComponent } from 'src/app/shared/ag-custom-text/ag-custom-text.component';
import { AgGridAdminEditViewButtonComponent } from 'src/app/administration/admin-masters/ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { DatePipe, formatDate } from '@angular/common';
import { SuccessDialogComponent } from 'src/app/shared/custom-success-model/custom-success-model.component';
import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';
import { AgCustomDateComponent } from 'src/app/shared/ag-custom-date/ag-custom-date.component';
import { FinancialAuthority } from './model/financial-authority';
import { AdminMastersService } from './../../services/admin-masters.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { SharedService } from 'src/app/finance/services/shared.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
    selector: 'rsa-financial-authority',
    templateUrl: './financial-authority.component.html',
    styleUrls: ['./financial-authority.component.scss']
})

export class FinancialAuthorityComponent implements OnInit {
    EndLimitHasError: any;
    authorityForm: FormGroup;
    financeForm: FormGroup;
    @ViewChild('agGrid') agGrid: AgGridNg2;
    gridApi;
    gridColumnApi;
    frameworkComponents;
    suppressClickEdit;
    domLayout;
    columnDefs: Array<object> = [];
    paginationOptions: TextValuePair[] = [];
    rowData: any;
    currentEditRow;
    financial: FinancialAuthority;
    isRowEditing: boolean = false;
    addNewfa = false;
    edit = false;
    gridConfiguration: GridOptions = {};
    editingRowIndex: number;
    addFormOption: boolean;
    private RoleList: any = [];
    CCList: any[];
    PTList: any[];
    TotallingList: any[];
    faRoles: any[];
    faCC: any[];
    faTotal: any[];
    faTransType: any[];
    faApprovalData: any[];
    TransactionList: any[];
    ApproverList: any[];
    returnValue: any;
    errorRole: boolean;
    errorCC: boolean;
    errorPT: boolean;
    errorTransType: boolean;
    errorTotalling: boolean;
    errorTransaction: boolean;
    errorStart: boolean;
    errorGlCode: boolean;
    errorEnd: boolean;
    errorapprover: boolean;
    editOption: boolean;
    displayAnimate: boolean;
    errorAccountCodeExists: boolean;
    //checkLimit: boolean;
    abc: boolean;
    xyz: boolean;
    constructor(private alertService: AlertService, private modalService: BsModalService, private gridApiService: GridApiService, private sharedService: SharedService,
        public bsModalRef: BsModalRef, private fb: FormBuilder, public datepipe: DatePipe, private faservice: AdminMastersService, private allowAccess: UserAutherizationService) {
        this.domLayout = 'autoHeight';
        this.paginationOptions = [
            { id: 2, value: '15' },
            { id: 2, value: '30' },
            { id: 3, value: '60' }
        ];
    }

    get f() { return this.authorityForm.controls; }

    ngOnInit() {
        this.createauthorityForm();
        this.fieldStatusChanges();
        this.getAll();
        this.getRole();
        this.sharedService.sendMessage({ 'subModule': 'Financial Authority', 'isAddNewClicked': false, 'editClicked': false });
        this.columnDefs = [
            {
                headerName: 'Role Name', field: 'RoleName', filter: 'agTextColumnFilter', editable: true, sortable: false,
            },
            {
                headerName: 'CC', field: 'CCDesc', filter: 'agTextColumnFilter', editable: true, sortable: true,
            },
            {
                headerName: 'PT', field: 'PtDesc', filter: 'agTextColumnFilter', editable: true, sortable: true,
            },
            {
                headerName: 'Totalling', field: 'Totalling', filter: 'agTextColumnFilter', editable: true, sortable: true,
            },
            {
                headerName: 'Trans Type', field: 'TransDesc', filter: 'agTextColumnFilter', editable: true, sortable: true,
            },
            {
                headerName: 'GL', field: 'GL', filter: 'agTextColumnFilter', editable: true, sortable: true,
            },

            {
                headerName: 'Start Limit', field: 'StartLimit', filter: 'agTextColumnFilter', editable: true, sortable: true,
            },
            {
                headerName: 'End Limit', field: 'EndLimit', filter: 'agTextColumnFilter', editable: true, sortable: true,
            },
            {
                headerName: 'Approver', field: 'EmpName', hide: true
            },
            {
                headerName: 'Action',
                field: 'value',
                width: 300,
                cellRendererFramework: AgGridAdminEditViewButtonComponent,
                cellRendererParams: {
                    inActoionLink: 'FinancialAuthority'
                },
                colId: 'editSaveBtn',
                filter: 'none',
                headerClass: 'hidefilter',
                hide: !this.displayModifybutton(321)
            }
        ];
        this.frameworkComponents = { agTextInput: AgCustomTextComponent, agInputDate: AgCustomDateComponent, };
        this.GetcolumnDefs();
        this.abc = this.authorityForm.controls['StartLimit'].value;
        //  this.authorityForm.get('EndLimit').setValidators(this.greaterThan('StartLimit'));
        this.authorityForm.valueChanges.subscribe(() => {
            /*if (this.authorityForm.get('EndLimit').hasError('lessThan')) {
                this.EndLimitHasError = true;
            } else {
                this.EndLimitHasError = false;
            }*/
        });

        /* this.authorityForm.get('StartLimit').valueChanges.subscribe(() =>
             console.log('ngOnInit: field2 is less than field1: ',
                 this.authorityForm.get('EndLimit').hasError('lessThan')));*/
    }
    greaterThan(field: string): ValidatorFn {
        return (control: FormControl): { [key: string]: any } => {
            const group = control.parent;
            const fieldToCompare = group.get(field);
            const isLessThan = Number(fieldToCompare.value) > Number(control.value);
            return isLessThan ? { 'lessThan': { value: control.value } } : null;
        }
    }
    getAll(): any {
        this.faservice.getFinancial().subscribe((data) => {
            this.rowData = data;
            //  console.log(data, this.rowData);
        });
    }

    getRole() {
        this.faservice.getDD().subscribe(
            dataReturn => {
                console.log("faaaaaaaaaaaaaasss" + dataReturn);
                this.RoleList = dataReturn;
                this.faRoles = this.RoleList.FaRole;
                this.faCC = this.RoleList.FaCostCenter;
                this.faTotal = this.RoleList.FaTotalling;
                this.faTransType = this.RoleList.FaTransType;
                this.faApprovalData = this.RoleList.FaApprovalData;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }

    getPT(val: any) {
        console.log("value" + val);
        const param = 'costCenter=' + val;
        if (val == 11 || val == 9 || val == 6 || val == 22) {
            this.abc = true;
        }
        else {
            this.abc = false;
        }
        this.faservice.getPT(param).subscribe(
            dataReturn => {
                //console.log("data1" + JSON.stringify(dataReturn));
                this.PTList = dataReturn;

                //if(this.PTList.length>0)
                //{
                //    this.abc = false;
                //}
                //else
                //{
                //     this.abc=true;
                //}
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }

    createauthorityForm(): void {
        this.authorityForm = this.fb.group({
            RoleName: ['', Validators.required],
            CC: ['', Validators.required],
            PT: ['', Validators.required],
            Totalling: ['', Validators.required],
            TransType: ['', Validators.required],
            GL: ['', Validators.required],
            ApprovedBy: ['', Validators.required],
            StartLimit: ['', Validators.required],
            EndLimit: ['', Validators.required],
            PreparedBy: [sessionStorage.getItem('LoggedInUserId')],
            ModifiedBy: [sessionStorage.getItem('LoggedInUserId')],
        });
    }

    get FARoleName() { return this.authorityForm.get('RoleName'); };
    get FACC() { return this.authorityForm.get('CC'); };
    get FAPT() { return this.authorityForm.get('PT'); };
    get FATotalling() { return this.authorityForm.get('Totalling'); };
    get FAGL() { return this.authorityForm.get('GL'); };
    get FATransType() { return this.authorityForm.get('TransType'); };
    get FAStartLimit() { return this.authorityForm.get('StartLimit'); };
    get FAEndLimit() { return this.authorityForm.get('EndLimit'); };
    get FAApprover() { return this.authorityForm.get('ApprovedBy'); }
    fieldStatusChanges() {
        this.clearerrors();
        this.FARoleName.statusChanges.subscribe(
            status => { this.errorRole = (status == 'INVALID'); }
        );
        this.FACC.statusChanges.subscribe(
            status => { this.errorCC = (status == 'INVALID'); }
        );
        this.FAPT.statusChanges.subscribe(
            status => { this.errorPT = (status == 'INVALID'); }
        );
        this.FATotalling.statusChanges.subscribe(
            status => { this.errorTotalling = (status == 'INVALID'); }
        );
        this.FAGL.statusChanges.subscribe(
            status => { this.errorGlCode = (status == 'INVALID'); }
        );
        this.FAStartLimit.statusChanges.subscribe(
            status => { this.errorStart = (status == 'INVALID'); }
        );
        this.FAEndLimit.statusChanges.subscribe(
            status => { this.errorEnd = (status == 'INVALID'); }
        );
        this.FATransType.statusChanges.subscribe(
            status => { this.errorTransType = (status == 'INVALID'); }
        );
        this.FAApprover.statusChanges.subscribe(
            status => { this.errorapprover = (status == 'INVALID'); }
        );
    }

    clearerrors() {
        this.errorRole = false;
        this.errorCC = false;
        this.errorPT = false;
        this.errorTotalling = false;
        this.errorGlCode = false;
        this.errorStart = false;
        this.errorEnd = false;
        this.errorTransType = false;
        this.errorapprover = false;
    }

    GetcolumnDefs() {
        this.gridConfiguration = <GridOptions>{
            columnDefs: this.columnDefs,
            postProcessPopup: function (params) {
                const ePopup = params.ePopup;
                ePopup.style.top = '14.9838px';
            },
            rowData: this.rowData,
            rowHeight: 40,
            headerHeight: 40,
            pagination: true,
            floatingFiltersHeight: 40,
            paginationPageSize: 20,
            enableRangeSelection: true,
            rowSelection: 'single',
            rowMultiSelectWithClick: true,
            animateRows: true,
            enableColResize: true,
            enableFilter: true,
            suppressContextMenu: true,
            enableSorting: true,
            editType: 'cel',
            defaultColDef: {
                enableRowGroup: false,
                enableValue: true,
                suppressMovable: true,
                minWidth: 40,
                menuTabs: ['filterMenuTab', '', '']
            },
            context: {
                componentParent: this
            },
        };
    }
    onKeyPress(event: any) {
        let val = event.target.value;
        if (val.length == 3) {
            val = val + ',';
        }
        this.FAStartLimit.setValue(val);
    }

    setAutoHeight() {
        setTimeout(() => {
            this.gridApi.setDomLayout('autoHeight');
        }, 200);
    }

    fitToCoulmn() {
        setTimeout(() => {
            this.gridApi.sizeColumnsToFit();
        }, 200);
    }

    onGridReady(params) {
        console.log(params, 'params');
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        this.gridConfiguration.api.setRowData(this.rowData);
        params.api.paginationGoToPage(0);
        this.fitToCoulmn();
    }

    addNewRow() {
        this.addFormOption = true;
        //this.authorityForm.enable();
        this.editOption = false;
        this.displayAnimate = true;
        this.sharedService.sendMessage({ 'subModule': 'Financial Authority', 'isAddNewClicked': true, 'editClicked': false });
    }

    setErrorInvalid() {
        this.errorRole = this.FARoleName.invalid;
        this.errorCC = this.FACC.invalid;
        this.errorPT = this.FAPT.invalid;
        this.errorTotalling = this.FATotalling.invalid;
        this.errorGlCode = this.FAGL.invalid;
        this.errorStart = this.FAStartLimit.invalid;
        this.errorEnd = this.FAEndLimit.invalid;
        this.errorTransType = this.FATransType.invalid;
        this.errorapprover = this.FAApprover.invalid;
    }

    onParentCancel(rowIndex) {
        this.gridApi.stopEditing();
        this.currentEditRow.editMode = false;
        this.rowData[rowIndex] = this.currentEditRow;
        this.gridConfiguration.api.setRowData(this.rowData);
        this.suppressClickEdit = true;
        this.isRowEditing = false;
        this.sharedService.sendMessage({ 'subModule': 'Financial Authority', 'isAddNewClicked': false, 'editClicked': false });
    }

    onPageSizeChanged(newPageSize: HTMLSelectElement) {
        const value = +(newPageSize.srcElement.value);
        this.gridApi.paginationSetPageSize(value);
        this.gridApi.sizeColumnsToFit();
    }

    onParentEditClicked(val: any) {
        let nodeData = val.data;
        console.log(nodeData);
        let arrayFormFields = ['RoleName', 'CC', 'Totalling', 'GL', 'StartLimit', 'EndLimit', 'TransType', 'ApprovedBy'];
        arrayFormFields.forEach((val) => {
            if (nodeData[val] != null && nodeData[val] != undefined) {
                this.authorityForm.controls[val].setValue(nodeData[val]);
            }
        });
        if (nodeData.CC || !nodeData.CC) {
            this.getPT(nodeData.CC);
            this.authorityForm.controls['PT'].setValue(nodeData.PT);
        }
        this.addFormOption = true;
        this.authorityForm.enable();
        this.editOption = true;
        this.displayAnimate = false;
        this.sharedService.sendMessage({ 'subModule': 'Financial Authority', 'isAddNewClicked': false, 'editClicked': true });
    }

    onParentDeleteClicked(val: any) {
        let rowData = val.data;
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
        this.bsModalRef.content.valueChange.subscribe((data) => {
            if (data = RSAMSGConstants.BTNPROCEED) {
                console.log(rowData);
                let params4 = { "CC": rowData.CC, "GL": rowData.GL, "PT": rowData.PT, "RoleName": rowData.RoleName, "Totalling": rowData.Totalling, "TransType": rowData.TransType };
                // console.log("delete params ->" + JSON.stringify(params));
                this.faservice.deleteFA(params4).subscribe(
                    dataReturn => {
                        if (!dataReturn) {
                            this.alertService.success('Data cannot be deleted as it is already associated with transactions.');
                            this.getAll();
                        }
                        else {
                            this.alertService.success('Data deleted successfully.');
                            this.getAll();
                        }
                    },
                    errorRturn => {
                        console.log(errorRturn);
                    }
                );
            }
        });
    }

    submitForm() {
        this.setErrorInvalid();
        if (this.authorityForm.invalid) {
            return;
        }
        else {
            if (this.editOption) {
                //update        
                this.faservice.updateFA(JSON.stringify(this.authorityForm.value)).subscribe(
                    dataReturn => {
                        this.returnValue = dataReturn;
                        if (this.returnValue) {
                            this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                            this.bsModalRef.content.modelTitle = '';
                            this.bsModalRef.content.modelBodyContent = "Record successfully updated ";
                            this.bsModalRef.content.actionBtn = "Close";
                            this.bsModalRef.content.valueChange.subscribe((data) => {
                                console.log(" success datat" + data);
                                if (data == 'Close') {
                                    console.log("close btn clicked");
                                } else {
                                    console.log(" else close");
                                }
                                this.resetForm();
                                this.editOption = false;
                                this.getAll();
                                this.addFormOption = false;
                            });
                        }
                        else if (!dataReturn) {
                            this.errorAccountCodeExists = true;
                        }
                    });
            }
            else {
                if (this.authorityForm.controls['EndLimit'].value < this.authorityForm.controls['StartLimit'].value) {
                    this.EndLimitHasError = true;
                    return false;
                } else {
                    this.EndLimitHasError = false;
                }

                this.faservice.createFA(JSON.stringify(this.authorityForm.value)).subscribe(
                    dataReturn => {
                        //this.returnValue = dataReturn;
                        if (dataReturn.success) {
                            this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                            this.bsModalRef.content.modelTitle = '';
                            this.bsModalRef.content.modelBodyContent = "Record successfully created";
                            this.bsModalRef.content.actionBtn = "continue";
                            this.bsModalRef.content.valueChange.subscribe((data) => {
                                console.log(" success datat" + data);
                                if (data == 'Close') {
                                    console.log("close btn clicked");
                                } else {
                                    console.log(" else close");
                                }
                                this.resetForm();
                                this.editOption = false;
                                this.getAll();
                                this.addFormOption = false;
                            });

                        }
                        else {
                            this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                            this.bsModalRef.content.modelBodyContent = "Record has already existed";
                            // this.errorAccountCodeExists = true;
                            this.bsModalRef.content.actionBtn = "cancel";
                            this.bsModalRef.content.valueChange.subscribe((data) => {
                                console.log(" success datat" + data);
                                if (data == 'Close') {
                                    console.log("close btn clicked");
                                } else {
                                    console.log(" else close");
                                }
                                this.resetForm();
                                this.editOption = false;
                                this.getAll();
                                this.addFormOption = false;
                            });
                        }
                    });
                this.sharedService.sendMessage({ 'subModule': 'Financial Authority', 'isAddNewClicked': false, 'editClicked': false });
            }
        }
    }
    /*   startLimit()
      {
          
          if(this.authorityForm.value.StartLimit<this.authorityForm.value.EndLimit)
          {
             
  
              this.checkLimit = true;
              
          }
  
          else{
            
              this.checkLimit = false;
          }
         
      }  */
    validateEndValue() {
        if (this.authorityForm.controls['EndLimit'].value < this.authorityForm.controls['StartLimit'].value) {
            this.EndLimitHasError = true;
            return false;
        } else {
            this.EndLimitHasError = false;
        }
    }
    resetForm() {
        let arrayFormFields = ['RoleName', 'CC', 'PT', 'Totalling', 'GL', 'StartLimit', 'EndLimit', 'TransType', 'ApprovedBy'];
        arrayFormFields.forEach((val) => {
            if (this.authorityForm.controls[val] != null && this.authorityForm.controls[val] != undefined) {
                this.authorityForm.controls[val].reset();
            }
        });
        this.clearerrors();
    }

    cancelForm() {
        this.resetForm();
        this.addFormOption = false;
        this.getAll();
        this.sharedService.sendMessage({ 'subModule': 'Financial Authority', 'isAddNewClicked': false, 'editClicked': false });
    }

    getRowData() {
        return this.rowData;
    }
    displayModifybutton(functionid) {

        return this.allowAccess.isAllowed(functionid);
    }
}

interface TextValuePair {
    id: number;
    value: string;
}


