import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinancialAuthorityComponent } from './financial-authority.component';

describe('FinancialAuthorityComponent', () => {
  let component: FinancialAuthorityComponent;
  let fixture: ComponentFixture<FinancialAuthorityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinancialAuthorityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinancialAuthorityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
