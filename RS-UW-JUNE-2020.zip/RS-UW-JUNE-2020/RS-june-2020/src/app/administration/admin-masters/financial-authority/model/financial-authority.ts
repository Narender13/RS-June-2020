export class FinancialAuthority {
    success: any;
}
