import { TestBed, inject } from '@angular/core/testing';

import { FinancialAuthorityService } from './financial-authority.service';

describe('FinancialAuthorityService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FinancialAuthorityService]
    });
  });

  it('should be created', inject([FinancialAuthorityService], (service: FinancialAuthorityService) => {
    expect(service).toBeTruthy();
  }));
});
