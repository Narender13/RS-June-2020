import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CoaNewComponent } from './coa-new.component';

describe('CoaNewComponent', () => {
  let component: CoaNewComponent;
  let fixture: ComponentFixture<CoaNewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CoaNewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoaNewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
