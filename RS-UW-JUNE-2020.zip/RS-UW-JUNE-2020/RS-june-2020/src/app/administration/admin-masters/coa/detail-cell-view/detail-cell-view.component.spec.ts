import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailCellViewComponent } from './detail-cell-view.component';

describe('DetailCellViewComponent', () => {
  let component: DetailCellViewComponent;
  let fixture: ComponentFixture<DetailCellViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailCellViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailCellViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
