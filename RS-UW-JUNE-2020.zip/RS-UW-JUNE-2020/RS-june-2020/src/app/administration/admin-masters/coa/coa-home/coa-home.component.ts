import { Component, OnInit, ViewChild } from '@angular/core';
import { ChartOfAccount } from '../model/coa.model';
import { CoaListComponent } from '../coa-list/coa-list.component';
import { SharedService } from 'src/app/finance/services/shared.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';



@Component({
  selector: 'rsa-coa-home',
  templateUrl: './coa-home.component.html',
  styleUrls: ['./coa-home.component.scss']
})
export class CoaHomeComponent implements OnInit {
  @ViewChild('coaList') coaListComponent: CoaListComponent;
  isNew: boolean;
  isEdit: boolean;
  headerText: string;
  chartOfAcc: ChartOfAccount
  settingsdata: any[];
  addNewcoa = false;

  constructor(private sharedService: SharedService, private allowAccess: UserAutherizationService) { }

  ngOnInit() {
    this.isEdit = false;
    this.headerText = 'Chart of Accounts';
    this.setSettings();
    this.sharedService.sendMessage({ 'subModule': 'Chart of Accounts', 'isAddNewClicked': false });
  }
  addNew() {
    this.headerText = 'Add New Record';
    this.isNew = true;
    this.isEdit = false;
    this.sharedService.sendMessage({ 'subModule': 'Chart of Accounts', 'isAddNewClicked': true });
  }
  selectTottalingAC(evt: any) {

  }
  selectedRowDetails(evt: any) {
    this.chartOfAcc = evt.vocherEmitedDetails.currentRowData;
    this.isNew = true;
    this.isEdit = true;
    this.headerText = 'Edit Chart of Accounts';
  }
  cancelCallBack() {
    this.isNew = false;
    this.headerText = 'Chart of Accounts';
  }
  updateTableHeader(columnConfig: any) {
    this.coaListComponent.refreshGrid(columnConfig);
  }
  setSettings() {
    this.settingsdata = [
      {
        "id": 1,
        "name": "Level",
        "field": "TotalLevel",
        "checked": true
      },
      {
        "id": 2,
        "name": "Totaling A/c",
        "field": "TotalingAccountCode",
        "checked": true
      },
      {
        "id": 3,
        "name": "Cost Centre",
        "field": "CostCenterDescription",
        "checked": true
      },
      {
        "id": 4,
        "name": "Description",
        "field": "GLEnglishDescription",
        "checked": true
      },
      {
        "id": 5,
        "name": "Old Code",
        "field": "GLOldCode",
        "checked": true
      },
      {
        "id": 6,
        "name": "Effective Date",
        "field": "GLEffectivedate",
        "checked": true
      },
      {
        "id": 7,
        "name": "Expiry Date",
        "field": "GLExpiryDate",
        "checked": true
      },
      {
        "id": 8,
        "name": "Location",
        "field": "LocationDesc",
        "checked": true
      },
      {
        "id": 9,
        "name": "Dr./Cr.",
        "field": "GLBudgetIND",
        "checked": false
      },
      {
        "id": 10,
        "name": "GL Code",
        "field": "GlCode",
        "checked": false
      },
      {
        "id": 11,
        "name": "Budget",
        "field": "GLBudgetIND",
        "checked": false
      },
      {
        "id": 12,
        "name": "GL Desc",
        "field": "GLEnglishDescription",
        "checked": false
      },
      {
        "id": 13,
        "name": "Source of Business",
        "field": "GLSourceOfBusiness",
        "checked": false
      },
      {
        "id": 14,
        "name": "Department",
        "field": "Department",
        "checked": false
      },
      {
        "id": 15,
        "name": "Project Indicator",
        "field": "ProjectIndicator",
        "checked": false
      },
      {
        "id": 16,
        "name": "Placeholder",
        "field": "Placeholder",
        "checked": false
      },
      {
        "id": 17,
        "name": "Arabic Desc",
        "field": "GLArabicDesc",
        "checked": false
      }
    ];
  }
  displayModifybutton(functionid) {
    return this.allowAccess.isAllowed(functionid);
  }
}
