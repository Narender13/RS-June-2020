import { Component, OnInit } from '@angular/core';
import {ICellRendererAngularComp} from "ag-grid-angular";
import {ChartOfAccount} from '../model/coa.model'

@Component({
  selector: 'rsa-detail-cell-view',
  templateUrl: './detail-cell-view.component.html',
  styleUrls: ['./detail-cell-view.component.scss']
})
export class DetailCellViewComponent implements ICellRendererAngularComp {
  chartOfAccount:ChartOfAccount
  params: any;
  parentComponent: any;
  constructor() { }

  agInit (params: any): void {
    this.params = params;
    this.chartOfAccount=params.data;
    this.parentComponent = this.params.context.componentParent;
}
// called when the cell is refreshed
refresh(params: any): boolean {
  return false;
}
editClick(){
  this.parentComponent.onParentEditClicked(this.params)
//   this.params.api.setFocusedCell(this.params.node.rowIndex, 'TotalLevel');
// this.params.api.startEditingCell({
// rowIndex: this.params.node.rowIndex,
// colKey: 'TotalLevel'
// });
}
}
