import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditViewCellComponent } from './edit-view-cell.component';

describe('EditViewCellComponent', () => {
  let component: EditViewCellComponent;
  let fixture: ComponentFixture<EditViewCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditViewCellComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditViewCellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
