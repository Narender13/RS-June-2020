import { Component, OnInit, ViewChild } from '@angular/core';
import { ICellRendererAngularComp, AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community';
import { SharedService } from 'src/app/finance/services/shared.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
  selector: 'rsa-edit-view-cell',
  templateUrl: './edit-view-cell.component.html',
  styleUrls: ['./edit-view-cell.component.scss']
})
export class EditViewCellComponent implements ICellRendererAngularComp {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridConfiguration: GridOptions;
  public params: any;
  parentComponent;
  pageName: string;
  isView: boolean;
  viewText: string;
  constructor(private sharedService: SharedService, private allowAccess: UserAutherizationService) { }

  agInit(params: any): void {
    this.viewText = "View";
    this.isView = false;
    this.params = params;
    this.parentComponent = this.params.context.componentParent;
    this.pageName = params.inActoionLink;
  }
  viewClick(val: any) {
    this.isView = !this.isView;
    if (this.isView) {
      this.viewText = "Hide";
    }
    else {
      this.viewText = "View";
    }
    const param = { rowData: val, text: this.viewText };
    this.parentComponent.onParentViewClicked(param)
  }
  editClick(val: any) {
    //     this.params.api.setFocusedCell(this.params.node.rowIndex, 'TotalLevel');
    //  this.params.api.startEditingCell({
    //   rowIndex: this.params.node.rowIndex,
    //   colKey: 'TotalLevel'
    //  });
    this.parentComponent.onParentEditClicked(val);
    this.sharedService.sendMessage({ 'subModule': 'Financial Authority', 'isAddNewClicked': false, 'editClicked': true });
  }
  deleteClick(val: any) {
  }
  refresh(): boolean {
    return false;
  }
  displayModifybutton(functionid) {
    return this.allowAccess.isAllowed(functionid);
  }
}
