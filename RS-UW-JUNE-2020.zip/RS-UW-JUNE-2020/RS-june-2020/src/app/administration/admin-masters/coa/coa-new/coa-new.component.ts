import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ChartOfAccount } from '../model/coa.model'
import { AdminMastersService } from '../../../services/admin-masters.service'
import { updateLocale } from 'ngx-bootstrap/chronos/locale/locales';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { SharedService } from 'src/app/finance/services/shared.service';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';

@Component({
    selector: 'rsa-coa-new',
    templateUrl: './coa-new.component.html',
    styleUrls: ['./coa-new.component.scss']
})
export class CoaNewComponent implements OnInit {
    coaNewForm: FormGroup;
    chartOfAcc: ChartOfAccount;
    chartOfAccOld: ChartOfAccount;
    tottalingACList: any[]
    // tottalingACNoList:any[];
    costCenterList: any[]
    totalingLevel: any;
    userLocations: any[] = [];
    @Input() isEdit: boolean;
    @Input() EditData: ChartOfAccount;
    @Output() cancelClick = new EventEmitter();
    locationCode: any;
    constructor(private formBuilder: FormBuilder, private adminService: AdminMastersService, private alertService: AlertService, protected modalService: BsModalService,
        protected bsModalRef: BsModalRef, private sharedService: SharedService) { }

    ngOnInit() {
        this.chartOfAcc = new ChartOfAccount();
        this.locationCode = sessionStorage.getItem('locationcode') || null;
        this.createCoaForm();
        this.getCostCenterList();
        this.getUserBranches();
        if (this.isEdit) {
            this.chartOfAcc = this.EditData;
            this.chartOfAccOld = Object.assign({}, this.EditData)
            this.fillEditData();
        }
    }


    getUserBranches() {
        this.userLocations = JSON.parse(sessionStorage.getItem(RSAConstants.allowedLocations));
    }

    fillEditData() {
        this.location.setValue(this.chartOfAcc.LocationCode.toString());
        this.level.setValue(this.chartOfAcc.TotalLevel);
        this.crdr.setValue(this.chartOfAcc.GLDBCRIND);
        this.BudgetStatus.setValue(this.chartOfAcc.GLBudgetIND);
        this.OldCode.setValue(this.chartOfAcc.GLOldCode ? this.chartOfAcc.GLOldCode.trim() : null);
        // this.TottalingACNo.setValue(this.chartOfAcc.TotalingAccountCode);
        this.GLCode.setValue(this.chartOfAcc.GlCode);
        this.EffectiveDate.setValue(this.chartOfAcc.GLEffectivedate);
        this.ExpiryDate.setValue(this.chartOfAcc.GLExpiryDate);
        this.EnglishDescription.setValue(this.chartOfAcc.GLEnglishDescription);
        this.ArabicDescription.setValue(this.chartOfAcc.GLArabicDescription);
        this.GLDescription.setValue(this.chartOfAcc.GLEnglishShortDescription);
        this.SourceofBusiness.setValue(this.chartOfAcc.GLSourceOfBusiness);
        // this.adminService.getTotalingACList(this.chartOfAcc.TotalLevel).subscribe(reasult=>{
        //   this.tottalingACList=reasult
        //   this.ddltottalingAC.setValue(this.chartOfAcc.TotalingAccountCode)
        // });

        this.ddlCostCenter.setValue(this.chartOfAcc.CostCenterCode);
        this.getTotallingAccount(this.chartOfAcc.CostCenterCode);
    }
    createCoaForm(): void {
        this.coaNewForm = this.formBuilder.group({
            location: [this.locationCode],
            level: [null],
            crdr: [null],
            BudgetStatus: [null],
            OldCode: [null],
            TottalingACNo: [null],
            GLCode: [null],
            Department: [null],
            Placeholder: [null],
            ProjectIndicator: [null],
            EffectiveDate: [null],
            ExpiryDate: [null],
            EnglishDescription: [null],
            ArabicDescription: [null],
            GLDescription: [null],
            ddltottalingAC: [null],
            ddlCostCenter: [null],
            SourceofBusiness: [null],
        });
    }
    get location() { return this.coaNewForm.controls['location']; };
    get level() { return this.coaNewForm.controls['level']; };
    get crdr() { return this.coaNewForm.controls['crdr']; };
    get BudgetStatus() { return this.coaNewForm.controls['BudgetStatus']; };
    get TottalingACNo() { return this.coaNewForm.controls['TottalingACNo']; };
    get GLCode() { return this.coaNewForm.controls['GLCode']; };
    get Department() { return this.coaNewForm.controls['Department']; };
    get Placeholder() { return this.coaNewForm.controls['Placeholder']; };
    get ProjectIndicator() { return this.coaNewForm.controls['ProjectIndicator']; };
    get EffectiveDate() { return this.coaNewForm.controls['EffectiveDate']; };
    get ExpiryDate() { return this.coaNewForm.controls['ExpiryDate']; };
    get EnglishDescription() { return this.coaNewForm.controls['EnglishDescription']; };
    get ArabicDescription() { return this.coaNewForm.controls['ArabicDescription']; };
    get GLDescription() { return this.coaNewForm.controls['GLDescription']; };
    get OldCode() { return this.coaNewForm.controls['OldCode']; };
    get ddltottalingAC() { return this.coaNewForm.controls['ddltottalingAC']; };
    get ddlCostCenter() { return this.coaNewForm.controls['ddlCostCenter']; };
    get SourceofBusiness() { return this.coaNewForm.controls['SourceofBusiness']; };
    formControlAddValidator() {
        this.location.setValidators([Validators.required]);
        this.location.updateValueAndValidity();
        this.level.setValidators([Validators.required]);
        this.level.updateValueAndValidity();
        this.ddlCostCenter.setValidators([Validators.required]);
        this.ddlCostCenter.updateValueAndValidity();
        this.BudgetStatus.setValidators([Validators.required]);
        this.BudgetStatus.updateValueAndValidity();
        this.TottalingACNo.setValidators([Validators.required]);
        this.TottalingACNo.updateValueAndValidity();
        this.GLCode.setValidators([Validators.required]);
        this.GLCode.updateValueAndValidity();
        this.EffectiveDate.setValidators([Validators.required]);
        this.EffectiveDate.updateValueAndValidity();
        this.ExpiryDate.setValidators([Validators.required]);
        this.ExpiryDate.updateValueAndValidity();
        this.EnglishDescription.setValidators([Validators.required]);
        this.EnglishDescription.updateValueAndValidity();
        this.GLDescription.setValidators([Validators.required]);
        this.GLDescription.updateValueAndValidity();
    }
    getDateFormat(val: any) {
        return new DatePipe('en-US').transform(new Date(val), 'dd/MM/yyyy')
    }

    saveCOA() {
        if (!this.isEdit) {
            this.formControlAddValidator();
            this.coaNewForm.updateValueAndValidity();
        }
        this.formControlAddValidator();
        this.coaNewForm.updateValueAndValidity();
        if (this.coaNewForm.valid) {
            this.chartOfAcc.GLOldCode = this.OldCode.value;
            this.chartOfAcc.GlCode = this.GLCode.value;
            if (this.EffectiveDate.touched || this.EffectiveDate.dirty) {
                this.chartOfAcc.GLEffectivedate = this.getDateFormat(this.EffectiveDate.value);
            }
            else {
                this.chartOfAcc.GLEffectivedate = this.EffectiveDate.value;
            }
            if (this.ExpiryDate.touched || this.ExpiryDate.dirty) {
                this.chartOfAcc.GLExpiryDate = this.getDateFormat(this.ExpiryDate.value);
            }
            else {
                this.chartOfAcc.GLExpiryDate = this.ExpiryDate.value;
            }
            this.chartOfAcc.GLEnglishDescription = this.EnglishDescription.value;
            this.chartOfAcc.GLArabicDescription = this.ArabicDescription.value;
            this.chartOfAcc.LocationCode = this.location.value;
            this.chartOfAcc.GLBudgetIND = this.BudgetStatus.value;
            this.chartOfAcc.TotalingAccountCode = this.TottalingACNo.value
            this.chartOfAcc.GLSourceOfBusiness = this.SourceofBusiness.value
            this.chartOfAcc.GLEnglishShortDescription = this.GLDescription.value;
            this.chartOfAcc.CostCenterCode = this.ddlCostCenter.value;
            if (!this.isEdit) {
                let val = JSON.stringify(this.chartOfAcc)
                this.adminService.saveCOA(this.chartOfAcc).subscribe(reasult => {
                    if (reasult) {
                        // this.clearFields();
                        this.getUserInput();
                        // alert('saved')
                        // this.alertService.success("Chart of Account created successfully.")
                        //this.cancelClick.emit();
                    }
                    else {
                        this.alertService.error("Error in creating Chart of Account.")
                    }
                });
            }
            else {
                this.updateCOA();
            }
        }
        this.sharedService.sendMessage({ 'subModule': 'Chart of Accounts', 'isAddNewClicked': false });
    }
    getUserInput() {
        let costCenter = this.costCenterList.filter(cc => cc.CCCode == this.ddlCostCenter.value)[0];
        let locationCountry = '';
        if (this.chartOfAcc.LocationCode == '20') {
            locationCountry = 'Dubai';
        }
        else if (this.chartOfAcc.LocationCode == '21') {
            locationCountry = 'Abu Dhabi';
        }
        else if (this.chartOfAcc.LocationCode == '22') {
            locationCountry = 'Sharjah';
        }
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        this.bsModalRef.content.modelBodyContent = 'You have successfully created ' + locationCountry + ' - ' + costCenter.E_Desc + ' Cost Center.Do you wish to continue Chart of Accounts?'; //RSAMSGConstants.DIRTYFLAGMSGRECIPT;
        this.bsModalRef.content.cancelBtn = "No";
        this.bsModalRef.content.actionBtn = "Yes";
        this.clearFields();
        this.bsModalRef.content.valueChange.subscribe((data) => {
            this.clearFields();
            if (data = 'Yes') {
                this.cancelClick.emit();
            }
        });
    }

    clearFields() {
        this.location.clearValidators();
        this.location.setValue(null);
        this.level.clearValidators();
        this.level.setValue(null);
        this.BudgetStatus.clearValidators();
        this.BudgetStatus.setValue(null);
        this.TottalingACNo.clearValidators();
        this.TottalingACNo.setValue(null);
        this.GLCode.clearValidators();
        this.GLCode.setValue(null);
        this.OldCode.clearValidators();
        this.OldCode.setValue(null);
        this.EffectiveDate.clearValidators();
        this.EffectiveDate.setValue(null);
        this.ExpiryDate.clearValidators();
        this.ExpiryDate.setValue(null);
        this.EnglishDescription.clearValidators();
        this.EnglishDescription.setValue(null);
        this.crdr.setValue(null);
        this.Department.setValue(null);
        this.ProjectIndicator.setValue(null);
        this.Placeholder.setValue(null);
        this.SourceofBusiness.setValue(null);
        this.GLDescription.clearValidators();
        this.GLDescription.setValue(null);
        this.ArabicDescription.setValue(null);
        this.ddlCostCenter.clearValidators();
        this.ddlCostCenter.setValue(null);
    }
    updateCOA() {
        this.chartOfAcc.GlCodeSet = this.chartOfAcc.GlCode;
        this.chartOfAcc.LocationCodeSet = this.chartOfAcc.LocationCode;
        this.chartOfAcc.TotalingAccountCodeSet = this.chartOfAcc.TotalingAccountCode;
        this.chartOfAcc.CostCenterCodeSet = this.chartOfAcc.CostCenterCode;


        if (this.chartOfAcc.GlCode != this.chartOfAccOld.GlCode) {
            this.chartOfAcc.GlCode = this.chartOfAccOld.GlCode;
        }
        if (this.chartOfAcc.LocationCode != this.chartOfAccOld.LocationCode) {
            this.chartOfAcc.LocationCode = this.chartOfAccOld.LocationCode;
        }
        if (this.chartOfAcc.TotalingAccountCode != this.chartOfAccOld.TotalingAccountCode) {
            this.chartOfAcc.TotalingAccountCode = this.chartOfAccOld.TotalingAccountCode;
        }
        if (this.chartOfAcc.CostCenterCode != this.chartOfAccOld.CostCenterCode) {
            this.chartOfAcc.CostCenterCode = this.chartOfAccOld.CostCenterCode;
        }
        let val = JSON.stringify(this.chartOfAcc)
        this.adminService.updateCOA(this.chartOfAcc).subscribe(reasult => {
            if (reasult) {
                this.alertService.success("Chart of Account updated successfully.")
                this.cancelClick.emit();
            }
            else {
                this.alertService.error("Error in updating Chart of Account.")
            }
        });
    }
    getCostCenterList() {
        this.adminService.getCCList().subscribe(reasult => {
            this.costCenterList = reasult
        });
    }
    getTotallingAccount(val: any) {
        const param = 'costCenter=' + val;
        this.adminService.getTotallingAccount(param).subscribe(
            dataReturn => {
                this.tottalingACList = dataReturn;
                if (this.isEdit) {
                    this.TottalingACNo.setValue(this.chartOfAcc.TotalingAccountCode);
                }
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    rdoCrDrChange() {
        this.chartOfAcc.GLDBCRIND = this.crdr.value;
    }
    departmentChange(evt: any) {
        if (evt.target.checked) {
            this.chartOfAcc.Department = "1";
        }
        else {
            this.chartOfAcc.Department = "0";
        }
    }
    projectIndicatorChange(evt: any) {
        if (evt.target.checked) {
            this.chartOfAcc.ProjectIndicator = "1";
        }
        else {
            this.chartOfAcc.ProjectIndicator = "0";
        }
    }
    placeholderChange(evt: any) {
        if (evt.target.checked) {
            this.chartOfAcc.Placeholder = "1";
        }
        else {
            this.chartOfAcc.Placeholder = "0";
        }
    }
    rdoTotalingChange() {
        this.totalingLevel = this.level.value;
        this.chartOfAcc.TotalLevel = this.level.value;
        // this.adminService.getTotalingACList(this.totalingLevel).subscribe(reasult=>{
        //   this.tottalingACList=reasult
        // });
    }
    ddlCostCenterchange(val: any) {
        this.chartOfAcc.CostCenterCode = val;
    }
    // ddltottalingACChange(val:any){
    //   this.chartOfAcc.TotalingAccountCode=val;
    // }
    cancel() {
        this.cancelClick.emit();
        this.sharedService.sendMessage({ 'subModule': 'Chart of Accounts', 'isAddNewClicked': false });
    }
}
