import { Component, OnInit, ViewChild, AfterViewInit, Input, Output, EventEmitter } from '@angular/core';
import { AgGridNg2 } from 'ag-grid-angular';
import { formatDate, DatePipe } from '@angular/common';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { ChartOfAccount } from '../model/coa.model'
import { AdminMastersService } from '../../../services/admin-masters.service'
import { EditViewCellComponent } from "../edit-view-cell/edit-view-cell.component";
import { GridApi, ColumnApi } from 'ag-grid-community';
import { DetailCellViewComponent } from '../detail-cell-view/detail-cell-view.component'
import { AgGirdCustomDateFilterComponent } from 'src/app/shared/ag-gird-custom-date-filter/ag-gird-custom-date-filter.component';
import { filterByDateSlash, dateComparator } from 'src/app/shared/utilites/helper';
import { AgCustomDateComponent } from 'src/app/shared/ag-custom-date/ag-custom-date.component';
import { AgCustomTextComponent } from 'src/app/shared/ag-custom-text/ag-custom-text.component';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
  selector: 'rsa-coa-list',
  templateUrl: './coa-list.component.html',
  styleUrls: ['./coa-list.component.scss']
})
export class CoaListComponent implements OnInit {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridApi: GridApi;
  gridColumnApi: ColumnApi;
  columnDefs: Array<object> = [];
  paginationOptions: TextValuePair[] = [];
  coaList: ChartOfAccount[];
  gridConfiguration: GridOptions = {};
  domLayout;
  frameworkComponents;
  detailCellViewComponent: DetailCellViewComponent
  @Output() selectedRowDetails = new EventEmitter();
  constructor(private adminService: AdminMastersService,
    public datepipe: DatePipe, private allowAccess: UserAutherizationService) {
    this.domLayout = 'autoHeight';
    this.paginationOptions = [
      { id: 2, value: '20' },
      { id: 2, value: '100' },
      { id: 3, value: '500' },
      { id: 4, value: '1000' }
    ];
  }

  ngOnInit() {
    this.defineColumnDefs();
    this.fillGridData();
  }
  getCOAList() {
    this.adminService.getCOAList().subscribe(reasult => {
      this.coaList = reasult
      this.gridColumnApi.resetColumnState();
      this.gridApi.refreshView();
    })
  }
  defineColumnDefs() {
    this.columnDefs = [
      {
        headerCheckboxSelection: true,
        headerCheckboxSelectionFilteredOnly: true,
        checkboxSelection: true,
        filter: 'none',
        headerClass: 'hidefilter',
        width: 40,
        supressSizeToFit: true
      },
      {
        headerName: 'Level', field: 'TotalLevel',
        width: 80,
        supressSizeToFit: true
      },
      {
        headerName: 'Totalling Account', field: 'TotalingAccountCode'
      },
      {
        headerName: 'Cost Centre', field: 'CostCenterDescription'
      },
      {
        headerName: "Description", field: "GLEnglishDescription", sortable: true, filter: 'agTextColumnFilter',
      },
      {
        headerName: "Old Code", field: "GLOldCode",
      },
      {
        headerName: "Effective Date", field: "GLEffectivedate",
        filter: 'agDateColumnFilter', editable: true, suppressNavigable: true,
        valueFormatter: (data) => {
          let re = /\//gi;
          let date = data.value.replace(re, "-");
          date = date.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3");
          return this.datepipe.transform(date, 'dd MMM yyyy');
        },
        cellEditor: "agInputDate", page: 'monthend',
        comparator: dateComparator,
        filterParams: {
          comparator: filterByDateSlash(),
          inRangeInclusive: true
        }
      },
      {
        headerName: "Expiry Date", field: "GLExpiryDate", sortable: true, filter: 'agDateColumnFilter', editable: true, suppressNavigable: true,
        valueFormatter: (data) => {
          let re = /\//gi;
          let date = data.value.replace(re, "-");
          date = date.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3");
          return this.datepipe.transform(date, 'dd MMM yyyy');
        }, cellEditor: "agInputDate", page: 'monthend',
        comparator: dateComparator,
        filterParams: {
          comparator: filterByDateSlash(),
          inRangeInclusive: true
        }
      },
      {
        headerName: "Location", field: "LocationDesc"
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: EditViewCellComponent,
        cellRendererParams: {
          inActoionLink: 'coaList'
        },
        filter: 'none',
        headerClass: 'hidefilter',
        width: 300,
        supressSizeToFit: true
      }
    ];
    this.frameworkComponents = { agTextInput: AgCustomTextComponent };
  }
  onGridReady(params) {

    console.log(params, 'params');
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridConfiguration.api.setRowData(this.coaList);
    params.api.paginationGoToPage(0);
    this.fitToCoulmn();
  }
  fillGridData() {
    this.GetGridOptions();
    this.getCOAList();
  }
  refreshGrid(columnConfig: any[]) {
    this.columnDefs = [];
    this.columnDefs.push({
      headerCheckboxSelection: true,
      headerCheckboxSelectionFilteredOnly: true,
      checkboxSelection: true
    });

    columnConfig.forEach(element => {
      if (element.checked) {
        if (element.name == 'Effective Date') {
          let clm = {
            headerName: "Effective Date", field: "GLEffectivedate",
            filter: 'agDateColumnFilter', editable: true, suppressNavigable: true,
            valueFormatter: (data) => {
              let re = /\//gi;
              let date = data.value.replace(re, "-");
              date = date.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3");
              return this.datepipe.transform(date, 'dd MMM yyyy');
            },
            cellEditor: "agInputDate", page: 'monthend',
            comparator: dateComparator,
            filterParams: {
              comparator: filterByDateSlash(),
              inRangeInclusive: true
            }
          };
          this.columnDefs.push(clm)
        } else if (element.name == 'Expiry Date') {
          let clm = {
            headerName: "Expiry Date", field: "GLExpiryDate", sortable: true, filter: 'agDateColumnFilter', editable: true, suppressNavigable: true,
            valueFormatter: (data) => {
              let re = /\//gi;
              let date = data.value.replace(re, "-");
              date = date.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3");
              return this.datepipe.transform(date, 'dd MMM yyyy');
            }, cellEditor: "agInputDate", page: 'monthend',
            comparator: dateComparator,
            filterParams: {
              comparator: filterByDateSlash(),
              inRangeInclusive: true
            }
          };
          this.columnDefs.push(clm)
        } else if (element.name == 'Budget') {
          this.columnDefs.push({
            headerName: element.name, field: element.field, editable: false, valueFormatter: (data) => {
              if (data == '1') {
                return 'Active';
              } else if (data == '0') {
                return 'In Active';
              }
              else {
                return '';
              }
            }
          });
        }
        else {
          this.columnDefs.push({ headerName: element.name, field: element.field, editable: false, })
        }

      }
    });

    this.columnDefs.push({
      headerName: 'Action',
      field: 'value',

      cellRendererFramework: EditViewCellComponent,
      cellRendererParams: {
        inActoionLink: 'coaList'
      },
      filter: 'none',
      headerClass: 'hidefilter'

    });
    this.gridApi.setColumnDefs(this.columnDefs);
    this.gridColumnApi.resetColumnState();
    this.gridApi.refreshView();
  }
  onPageSizeChanged(newPageSize: HTMLSelectElement) {
    const value = +(newPageSize.srcElement.value);
    this.gridApi.paginationSetPageSize(value);
    // this.gridApi.sizeColumnsToFit();
  }
  fitToCoulmn() {
    setTimeout(() => {
      this.gridApi.sizeColumnsToFit();
    }, 200);
  }
  GetGridOptions() {
    this.gridConfiguration = <GridOptions>{
      columnDefs: this.columnDefs,
      postProcessPopup: function (params) {
        const ePopup = params.ePopup;
        ePopup.style.top = '14.9838px';
      },
      //rowData: rowData,
      rowHeight: 40,
      headerHeight: 40,
      pagination: true,
      //paginationAutoPageSize: true,
      floatingFiltersHeight: 40,
      paginationPageSize: 20,
      enableRangeSelection: true,
      rowSelection: 'multiple',
      rowMultiSelectWithClick: true,
      animateRows: true,
      enableColResize: true,
      enableFilter: true,
      enableSorting: true,
      masterDetail: true,
      detailCellRenderer: "detailCellViewComponent",
      detailRowHeight: 200,
      defaultColDef: {
        enableRowGroup: false,
        enableValue: true,
        suppressMovable: true,
        minWidth: 40,
        menuTabs: ['filterMenuTab', '', '']
      },
      context: {
        componentParent: this
      },


    };
    this.frameworkComponents = { detailCellViewComponent: DetailCellViewComponent, agInputDate: AgCustomDateComponent, agDateInput: AgGirdCustomDateFilterComponent };
  }
  onParentEditClicked(val: any) {
    let nodeData = val.data;
    const vocherEmitedDetails = {
      OperationType: 'Edit',
      currentRowData: nodeData
    };
    this.selectedRowDetails.emit({
      vocherEmitedDetails
    });
  }
  onParentViewClicked(param: any) {
    let text = param.text;
    let node = param.rowData.node;
    if (text == 'Hide') {
      node.setExpanded(true);
    }
    else {
      node.setExpanded(false);
    }

  }
  onParentDeleteClicked(param: any) {
    let text = param.text;
    let node = param.rowData.node;
    if (text == 'Hide') {
      node.setExpanded(true);
    }
    else {
      node.setExpanded(false);
    }

  }

  displayModifybutton(functionid) {
    return this.allowAccess.isAllowed(functionid);
  }
}
interface TextValuePair {
  id: number;
  value: string;
}
