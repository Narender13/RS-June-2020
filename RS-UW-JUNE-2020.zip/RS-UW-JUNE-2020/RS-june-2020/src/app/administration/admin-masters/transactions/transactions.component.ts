import { Component, OnInit, ViewChild, AfterViewInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { TypeaheadMatch } from 'ngx-bootstrap';
import { Transactions } from '../transactions/model/transactions';
import { AdminMastersService } from './../../services/admin-masters.service';
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { AgGridAdminEditViewButtonComponent } from 'src/app/administration/admin-masters/ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { AgCustomTextComponent } from 'src/app/shared/ag-custom-text/ag-custom-text.component';
import { AgCustomHeaderComponent } from '../../../shared/ag-custom-header/ag-custom-header.component';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
    selector: 'rsa-transactions',
    templateUrl: './transactions.component.html',
    styleUrls: ['./transactions.component.scss']
})
export class TransactionsComponent implements OnInit, AfterViewInit {
    @ViewChild('agGrid') agGrid: AgGridNg2;
    gridApi;
    gridColumnApi;
    paginationOptions: TextValuePair[] = [];
    transactiontypes: Transactions;
    rowData: any[] = [];
    columnDefs: Array<object> = [];
    domLayout;
    gridConfiguration: GridOptions = {};
    editingRowIndex: number;
    suppressClickEdit;
    currentEditRow: any;
    isRowEditing: boolean = false;
    frameworkComponents;
    selectedRowIndex;
    startValue: number;
    endValue: number;
    totalRecords: number;
    currentPage: number;
    totalPages: number;
    isDisableFirst: boolean;
    isDisableLast: boolean;
    components;
    sortOrder;
    selectedRowData;
    constructor(private fb: FormBuilder, private _adminMasterService: AdminMastersService,
        private alertService: AlertService, private modalService: BsModalService, public bsModalRef: BsModalRef, private allowAccess: UserAutherizationService) {
        this.domLayout = 'autoHeight';
    }

    ngOnInit() {
        this.startValue = 1;
        this.currentPage = 1;
        this.isDisableFirst = true;
        this.isDisableLast = false;
        this.defineColumnDefs();
        this.GetGridOptions();
        this.gettransactions();
        this.suppressClickEdit = true;
    }
    defineColumnDefs() {
        this.columnDefs = [
            {
                headerName: '', field: 'name', headerCheckboxSelection: true, headerCheckboxSelectionFilteredOnly: true, checkboxSelection: true, filter: 'none',
                headerClass: 'hidefilter', width: 30
            },
            {
                headerName: 'Code', field: 'Code', sortable: true, filter: 'agTextColumnFilter', editable: false,
            },
            { headerName: 'English Description', field: 'EnglishDescription', sortable: true, filter: 'agTextColumnFilter', editable: true, cellEditor: 'agTextInput', maxLength: 60 },
            { headerName: 'الوصف العربي', field: 'ArabicDescription', sortable: true, filter: 'agTextColumnFilter', headerClass: 'ag-rtl', arabicDesc: true, cellClass: 'ag-rtl text-right', editable: true, cellEditor: 'agTextInput', enableRtl: true, maxLength: 60 },
            {
                headerName: 'Action',
                field: 'value',
                cellRendererFramework: AgGridAdminEditViewButtonComponent,
                cellRendererParams: {
                    inActoionLink: 'Transactions'
                },
                colId: 'editSaveBtn',
                filter: 'none',
                headerClass: 'hidefilter',
                hide: !this.displayModifybutton(309)

            }
        ];
        this.frameworkComponents = { agTextInput: AgCustomTextComponent, agCustomHeaderComponent: AgCustomHeaderComponent };
        // this.components = { inputField: getInputField() };
    }


    GetGridOptions() {
        this.gridConfiguration = <GridOptions>{
            columnDefs: this.columnDefs,
            postProcessPopup: function (params) {
                const ePopup = params.ePopup;
                ePopup.style.top = '14.9838px';
            },
            // rowData: this.rowData,
            rowHeight: 40,
            headerHeight: 40,
            pagination: true,
            floatingFiltersHeight: 40,
            paginationPageSize: 20,
            enableRangeSelection: true,
            rowSelection: 'single',
            rowMultiSelectWithClick: true,
            animateRows: true,
            enableColResize: true,
            enableFilter: true,
            suppressContextMenu: true,
            enableSorting: true,
            // suppressExcelExport = true,
            editType: 'cel',
            defaultColDef: {
                enableRowGroup: false,
                enableValue: true,
                suppressMovable: true,
                headerCheckboxSelectionFilteredOnly: false,
                minWidth: 30,
                menuTabs: ['filterMenuTab', '', ''],
                headerComponent: 'agCustomHeaderComponent',
                headerComponentParams: {
                    menuIcon: 'fa-bars'
                },
            },
            context: {
                componentParent: this
            },
        };
    }

    onCellDoubleClicked($event) {
        this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
        let colId = $event.column ? $event.column.colId : null;
        if (this.selectedRowIndex && colId) {
            this.allowEditing(this.selectedRowIndex, colId);
        }
    }

    onCellClicked($event) {
        this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
        let colId = $event.column ? $event.column.colId : null;
        if (this.selectedRowIndex && colId) {
            this.allowEditing(this.selectedRowIndex, colId);
        }
    }

    onCellFocused($event) {
        this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
        let colId = $event.column ? $event.column.colId : null;
        if (this.selectedRowIndex && colId) {
            this.allowEditing(this.selectedRowIndex, colId);
        }
    }
    allowEditing(rowIndex, colId) {
        if (this.isRowEditing) {
            if (rowIndex !== this.editingRowIndex) {
                this.suppressClickEdit = true;
                this.gridApi.stopEditing();
            }
            else {
                this.suppressClickEdit = false;
                this.editRowData(rowIndex, colId);
            }
        }
    }

    validateData(currentData) {
        if (currentData.EnglishDescription === "") {
            this.alertService.error('English Description is empty');
            return 'EnglishDescription';
        }
        return '';
    }
    setDataError(rowIndex, isError) {
        let selData = this.rowData[rowIndex];
        selData.isError = isError;
    }



    setAutoHeight() {
        setTimeout(() => {
            this.gridApi.setDomLayout('autoHeight');
        }, 200);

    }

    ngAfterViewInit() {
        this.fitToCoulmn();
        this.setAutoHeight();
    }
    fitToCoulmn() {
        setTimeout(() => {
            this.gridApi.sizeColumnsToFit();
        }, 200);
    }


    onGridReady(params) {
        console.log(params, 'params');
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        this.gridConfiguration.api.setRowData(this.rowData);
        params.api.paginationGoToPage(0);
        this.fitToCoulmn();
    }

    addNewRow(): any {
        //let Code =  this.rowData.length + 1;
        let editedData = this.rowData.filter(data => data.editMode === true && data.isNewRow === true);
        if (editedData.length > 0) {
            this.alertService.warn('Please save/cancel the data which already added.');
        }
        else {
            let newItem = { Code: '', EnglishDescription: '', ArabicDescription: '', PreparedBy: sessionStorage.getItem('LoggedInUserId'), isNewRow: true, editMode: true };
            //this.gridApi.updateRowData({ add: [newItem] });
            this.rowData.push(newItem);
            this.gridConfiguration.api.setRowData(this.rowData);
            this.gridApi.paginationGoToPage(0);
            //var sort = [{colId: "StartDate",sort: "desc"}];
            //this.gridApi.setSortModel(sort);
            this.onParentEditClicked(this.rowData.length - 1);
            /*   let newRowIndex = this.sortOrder === 'asc' ? 0 : this.rowData.length - 1; */
            //this.onParentEditClicked(newItem.Code, newRowIndex, this.rowData.length - 1);

        }
    }
    setRowData(order) {
        this.gridConfiguration.api.setRowData(this.rowData);
        this.gridApi.paginationGoToPage(0);
        this.sortOrder = order;
    }
    gettransactions(): any {
        this._adminMasterService.gettransactions().subscribe((data) => {
            this.rowData = data;
            this.totalRecords = this.rowData.length;
            //    console.log(data, this.rowData);
        });
    }
    getRowData() {
        return this.rowData;
    }
    onParentEditClicked(rowIndex) {
        let editedData = this.rowData.filter(data => data.editMode === true);
        let currentEditData = this.rowData[rowIndex];
        let allowRowEdit = false;
        if (editedData.length !== 0) {
            if (editedData[0].Code === currentEditData.Code) {
                allowRowEdit = true;
            }
        }
        else {
            allowRowEdit = true;
        }
        if (allowRowEdit) {
            this.suppressClickEdit = false;
            this.editingRowIndex = rowIndex;
            currentEditData.editMode = true;
            this.currentEditRow = Object.assign({}, currentEditData);
            this.editRowData(rowIndex, 'EnglishDescription');
            return true;
        }
        else {
            this.alertService.warn('Please save/cancel the data which already modifed.');
            return false;
        }
    }

    onParentCancel(rowIndex) {

        this.gridApi.stopEditing();
        let selRowData = this.rowData[rowIndex];
        if (selRowData.isNewRow) {
            this.rowData.splice(rowIndex, 1);
        }
        else {
            this.currentEditRow.editMode = false;
            this.rowData[rowIndex] = this.currentEditRow;
        }
        this.gridConfiguration.api.setRowData(this.rowData);
        this.gridApi.paginationGoToPage(0);
        this.suppressClickEdit = true;
        this.isRowEditing = false;
    }
    editRowData(rowIndex, column) {
        this.gridApi.startEditingCell({
            rowIndex: rowIndex,
            colKey: column
        });
        this.isRowEditing = true;
    }
    onParentSaveClicked(id, rowIndex) {
        console.log(this.rowData);
        this.gridApi.stopEditing();

        let updatedData = this.rowData.filter(data => data.Code === id);
        console.log(updatedData);
        if (updatedData.length > 0) {

            let validate = this.validateData(updatedData[0]);
            if (validate === '') {
                if (id === '') {

                    this._adminMasterService.createtransactions(updatedData[0]).subscribe(
                        dataReturn => {

                            if (!dataReturn) {
                                this.alertService.warn('Record has already existed');
                                this.editRowData(rowIndex, 'EnglishDescription');
                            }
                            else {
                                this.alertService.success('Data saved successfully.');
                                this.isRowEditing = false;
                                this.gettransactions();
                                return true;
                            }
                        },
                        errorRturn => {
                            this.alertService.error('something went wrong');
                            this.editRowData(rowIndex, 'EnglishDescription');
                            return false;
                        }
                    );
                }
                else {

                    updatedData[0].ModifiedBy = sessionStorage.getItem('LoggedInUserId');
                    this._adminMasterService.updatetransactions(updatedData[0]).subscribe(
                        dataReturn => {
                            updatedData[0].editMode = false;
                            this.isRowEditing = false;
                            this.alertService.success('Data updated successfully.');
                            this.gettransactions();
                            return true;
                        },
                        errorRturn => {
                            this.alertService.error('something went wrong');
                            this.editRowData(rowIndex, 'EnglishDescription');
                            return false;
                        }
                    );
                }
            }
            else {
                this.editRowData(rowIndex, validate);
                return false;
            }
        }
    }

    onParentDeleteClicked(code, rowIndex) {
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
        this.bsModalRef.content.valueChange.subscribe((data) => {
            if (data = RSAMSGConstants.BTNPROCEED) {
                this._adminMasterService.deletetransactions(code).subscribe(
                    dataReturn => {
                        if (dataReturn) {
                            this.alertService.success('Data deleted successfully.');
                            this.gettransactions();
                        }
                        else {
                            this.alertService.warn('This record cannot be deleted since, it has transactions associated with it.');
                        }
                        errorRturn => {
                            console.log(errorRturn);
                            // this.alertService.error('Something went wrong');
                        }
                    });
            }
        });

    }
    onParentCheckEdited() {
        let editedData = this.rowData.filter(data => data.editMode === true);
        if (editedData.length > 0) {
            this.alertService.warn('Please save/cancel the data which has already modifed.');
            return true;
        }
        else {
            return false;
        }
    }
    onGoToNextPage($event) {
        if (!this.onParentCheckEdited()) {
            this.gridApi.paginationGoToNextPage();
        }
    }
    onGoToPreviousPage($event) {
        if (!this.onParentCheckEdited()) {
            this.gridApi.paginationGoToPreviousPage();
        }
    }
    onGoToFirstPage($event) {
        if (!this.onParentCheckEdited()) {
            this.gridApi.paginationGoToFirstPage();
        }
    }
    onGoToLastPage($event) {
        if (!this.onParentCheckEdited()) {
            this.gridApi.paginationGoToLastPage();
        }
    }
    onPaginationChanged($event) {
        if (this.gridApi) {
            this.currentPage = this.gridApi.paginationGetCurrentPage() + 1;
            this.totalPages = this.gridApi.paginationGetTotalPages();
            if (this.currentPage === 1) {
                this.isDisableFirst = true;
            }
            else {
                this.isDisableFirst = false;
            }
            if (this.currentPage === this.totalPages) {
                this.isDisableLast = true;
            }
            else {
                this.isDisableLast = false;
            }
            this.startValue = ((this.currentPage - 1) * this.gridConfiguration.paginationPageSize) + 1;
            this.endValue = ((this.startValue + this.gridConfiguration.paginationPageSize) - 1) < this.totalRecords ? (this.startValue + this.gridConfiguration.paginationPageSize) - 1 : this.totalRecords;
        }
    }
    displayModifybutton(functionid) {

        return this.allowAccess.isAllowed(functionid);
    }
}
interface TextValuePair {
    id: number;
    value: string;
}





