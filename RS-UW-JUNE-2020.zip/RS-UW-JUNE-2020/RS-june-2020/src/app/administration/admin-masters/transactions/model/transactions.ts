export class Transactions {
    Code: number;
    EnglishDescription: string;
    ArabicDescription: string;
    success: boolean;
    message: string;
}
