export class TotallingAccount {
    StrLevelNo:number;
    StrDesc:string;
    StrTotOrPostInt:number;
    SegSerialNo:number;
    SegPrefix:number;
    SegAccountCode:number;
    SegEnglishDescription: string;
    SegEffectiveDate:string;
    StrStatus:string;
    SegStatus:string;
    StrMask:string;
    SegAccountDescription:string;
    SegAccClass:string;
    SegParentLevelNo:number;
    EmailID:string;
    SegModifiedDateStr:string;
    
}