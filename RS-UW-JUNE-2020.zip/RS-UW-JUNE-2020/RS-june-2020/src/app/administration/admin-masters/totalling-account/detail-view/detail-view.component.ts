import { Component, OnInit } from '@angular/core';
import {TotallingAccount} from 'src/app/administration/admin-masters/totalling-account/model/totallingaccount';
import {ICellRendererAngularComp} from "ag-grid-angular";
@Component({
  selector: 'rsa-detail-view',
  templateUrl: './detail-view.component.html',
  styleUrls: ['./detail-view.component.scss']
})
export class DetailViewComponent implements ICellRendererAngularComp {
  totallingAccount:TotallingAccount;
  params: any;
  parentComponent: any;
  constructor() { }
  agInit (params: any): void {
    console.log("hjhjh" + this.params);
     this.params = params;
     this.totallingAccount=params.data;
     this.parentComponent = this.params.context.componentParent;
 
 }
 // called when the cell is refreshed
refresh(params: any): boolean {
  return false;
}

}
