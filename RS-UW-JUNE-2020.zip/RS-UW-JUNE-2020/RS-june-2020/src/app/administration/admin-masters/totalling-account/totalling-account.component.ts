import { Component, OnInit, ViewChild, AfterViewInit, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators, } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { AgGridAdminEditViewButtonComponent } from 'src/app/administration/admin-masters/ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { TotallingAccount } from 'src/app/administration/admin-masters/totalling-account/model/totallingaccount';
import { AdminMastersService } from './../../services/admin-masters.service';
import { DatePipe } from '@angular/common';
import { SuccessDialogComponent } from 'src/app/shared/custom-success-model/custom-success-model.component';
import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { GridApi, ColumnApi } from 'ag-grid-community';
import { DetailViewComponent } from './detail-view/detail-view.component';
import { AgGirdCustomDateFilterComponent } from 'src/app/shared/ag-gird-custom-date-filter/ag-gird-custom-date-filter.component';
import { filterByDateSlash, dateComparator } from 'src/app/shared/utilites/helper';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
  selector: 'rsa-totalling-account',
  templateUrl: './totalling-account.component.html',
  styleUrls: ['./totalling-account.component.scss']
})
export class TotallingAccountComponent implements OnInit {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  totallingAccountform: FormGroup;
  gridApi: GridApi;
  gridColumnApi: ColumnApi;
  frameworkComponents;
  suppressClickEdit;
  domLayout;
  columnDefs: Array<object> = [];
  paginationOptions: TextValuePair[] = [];
  rowData: any;
  currentEditRow;
  totallingAccount: TotallingAccount[];
  isRowEditing: boolean = false;
  gridConfiguration: GridOptions = {};
  editingRowIndex: number;
  addFormOption: boolean;
  editOption: boolean;
  accountClass: any = [];
  returnValue: any;
  errorLevelDescription: boolean;
  errorSerialNo: boolean;
  errorPrefix: boolean;
  errorAccountCode: boolean;
  errorAccountClass: boolean;
  //errorTotalling:boolean;
  totallinglevel: any;
  totallingHeder: any;
  headerList: any = [];
  getTotaling: number;
  getStatus: number;
  getSegStatus: number;
  errorAccountCodeExists: boolean;
  displayAnimate; boolean;
  detailViewComponent: DetailViewComponent;
  @Output() selectedRowDetails = new EventEmitter();
  @Output() cancelClick = new EventEmitter();
  constructor(private alertService: AlertService, private modalService: BsModalService, private gridApiService: GridApiService, public bsModalRef: BsModalRef, private fb: FormBuilder,
    public datepipe: DatePipe, private totallingAccountService: AdminMastersService, private allowAccess: UserAutherizationService) {
    this.domLayout = 'autoHeight';
    this.paginationOptions = [
      { id: 2, value: '15' },
      { id: 2, value: '30' },
      { id: 3, value: '60' }
    ];
  }


  ngOnInit() {
    this.getTotallingLevel();
    this.gettotallingAccount();
    this.getaccountClass();
    this.createTotallingAccountForm();
    this.fieldStatusChanges();
    this.gridApiService.isUnCheck().subscribe(() => {
      this.gridConfiguration.api.deselectAll();

    });
    this.columnDefs = [
      /* {field: 'name', cellRenderer: 'agGroupCellRenderer'},*/
      {
        headerName: '', field: 'name', headerCheckboxSelection: true, headerCheckboxSelectionFilteredOnly: true, checkboxSelection: true, filter: 'none',
        headerClass: 'hidefilter', width: 40
      },
      {
        headerName: 'Level', field: 'StrLevelNo',
        filter: 'agTextColumnFilter', editable: false, sortable: true
      },
      {
        headerName: 'Level Description', field: 'StrDesc',
        filter: 'agTextColumnFilter', editable: false, sortable: true,
      },
      {
        headerName: 'Totalling/Posting', field: 'StrToOrPostString', filter: 'agTextColumnFilter', editable: true, sortable: false,
      },
      {
        headerName: 'S.No', field: 'SegSerialNo', filter: 'agTextColumnFilter', editable: true, sortable: true,
      },
      {
        headerName: 'Prefix', field: 'SegPrefix', filter: 'agTextColumnFilter', editable: true, sortable: true,
      },
      {
        headerName: 'A/C Code', field: 'SegAccountCode', filter: 'agTextColumnFilter', editable: true, sortable: true,
      },
      {
        headerName: 'Short description', field: 'SegEnglishDescription', filter: 'agTextColumnFilter', editable: true, sortable: true,
      },
      {
        headerName: 'Effective Date', field: 'SegEffectiveDate', filter: 'agDateColumnFilter', editable: true, sortable: true,
        cellEditor: "agInputDate",
        comparator: dateComparator,
        filterParams: {
          comparator: filterByDateSlash(),
          inRangeInclusive: true,
          browserDatePicker: true,
          valueFormatter: (data) => {
            return this.datepipe.transform(data.value, 'dd/MM/yyyy');
          }
        }
      },
      {
        headerName: 'Status', field: 'StrStatus', filter: 'agTextColumnFilter', editable: true, sortable: true,
      },
      {
        headerName: 'Action',
        field: 'value',
        width: 350,
        cellRendererFramework: AgGridAdminEditViewButtonComponent,
        cellRendererParams: {
          inActoionLink: 'TotallingAC'
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter'
      }
    ];

    this.GetcolumnDefs();
    this.suppressClickEdit = true;
  }

  createTotallingAccountForm() {
    this.totallingAccountform = this.fb.group({
      StrDesc: ['', Validators.required],
      StrLevelNo: [],
      StrMask: [],
      StrTotOrPostInt: [],
      StrStatus: [],
      SegSerialNo: ['', Validators.required],
      SegPrefix: ['', Validators.required],
      SegAccountCode: ['', Validators.required],
      SegParentLevelNo: [],
      SegAccountDescription: [],
      SegEnglishDescription: [],
      SegEffectiveDate: [],
      SegGCLCode: ['', Validators.required],
      SegStatus: [],
      SegLevelNo: [],
      StrSerialNo: [],
      SegPreparedBy: [sessionStorage.getItem('LoggedInUserId')],
    });
  }
  get leveldesc() { return this.totallingAccountform.get('StrDesc'); }
  get serialno() { return this.totallingAccountform.get('SegSerialNo'); }
  get prefix() { return this.totallingAccountform.get('SegPrefix'); }
  get acCode() { return this.totallingAccountform.get('SegAccountCode'); }
  get acClass() { return this.totallingAccountform.get('SegGCLCode'); }
  fieldStatusChanges() {
    this.clearerrors();
    this.leveldesc.statusChanges.subscribe(
      status => {
        this.errorLevelDescription = (status == 'INVALID');
      }
    );
    this.serialno.statusChanges.subscribe(
      status => {
        this.errorSerialNo = (status == 'INVALID');
      }
    );
    this.prefix.statusChanges.subscribe(
      status => {
        this.errorPrefix = (status == 'INVALID');
      }
    );
    this.acCode.statusChanges.subscribe(
      status => {
        this.errorAccountCode = (status == 'INVALID');
      }
    );
    this.acClass.statusChanges.subscribe(
      status => {
        this.errorAccountClass = (status == 'INVALID');
      }
    );
  }
  clearerrors() {
    this.errorLevelDescription = false;
    this.errorSerialNo = false;
    this.errorPrefix = false;
    this.errorAccountCode = false;
    this.errorAccountClass = false;
    this.errorAccountCodeExists = false;
  }
  GetcolumnDefs() {
    this.gridConfiguration = <GridOptions>{
      columnDefs: this.columnDefs,
      postProcessPopup: function (params) {
        const ePopup = params.ePopup;
        ePopup.style.top = '14.9838px';
      },
      rowData: this.rowData,
      rowHeight: 40,
      headerHeight: 40,
      pagination: true,
      floatingFiltersHeight: 40,
      paginationPageSize: 15,
      enableRangeSelection: true,
      rowSelection: 'single',
      rowMultiSelectWithClick: true,
      animateRows: true,
      enableColResize: true,
      enableFilter: true,
      suppressContextMenu: true,
      enableSorting: true,
      editType: 'cel',
      masterDetail: true,
      detailCellRenderer: "detailViewComponent",
      detailRowHeight: 100,
      defaultColDef: {
        enableRowGroup: false,
        enableValue: true,
        suppressMovable: true,
        minWidth: 40,
        menuTabs: ['filterMenuTab', '', '']
      },
      context: {
        componentParent: this
      },
    };
    this.frameworkComponents = { detailViewComponent: DetailViewComponent, agDateInput: AgGirdCustomDateFilterComponent };
  }
  setAutoHeight() {
    setTimeout(() => {
      this.gridApi.setDomLayout('autoHeight');
    }, 200);
  }
  gettotallingAccount() {
    this.totallingAccountService.gettotallingAccount().subscribe((data) => {
      var result = data.map(item => {
        if (item.SegStatus != null) {
          item.SegStatus = (item.SegStatus == '1') ? 'Active' : 'Inactive';
        }
        if (item.StrStatus != null) {
          item.StrStatus = (item.StrStatus == '1') ? 'Active' : 'Inactive';
        }
        return item;
      });
      this.rowData = result;
    });
  }
  getaccountClass() {
    this.totallingAccountService.getAccountClass().subscribe(
      dataReturn => {
        this.accountClass = dataReturn;
      },
      errorRturn => {
        console.log(errorRturn);
      }
    );
  }
  getTotallingLevel() {
    this.totallingAccountService.getTotallingLevel().subscribe(
      dataReturn => {
        this.totallinglevel = dataReturn;
        //this.getHeaderData();
      },
      errorRturn => {
        console.log(errorRturn);
      }
    );
  }

  changeHeader() {
    let param = this.leveldesc.value;
    this.totallingAccountService.getHeaderData(param).subscribe(
      dataReturn => {
        this.totallingHeder = dataReturn;
        this.totallingAccountform.controls['StrLevelNo'].setValue(this.totallingHeder.StrLevelNo);
        this.totallingAccountform.controls['StrMask'].setValue(this.totallingHeder.StrMask);
        this.getTotaling = this.totallingHeder.StrTotOrPostInt;
        this.getStatus = this.totallingHeder.StrStatus;
      },
      errorRturn => {
        console.log(errorRturn);
      }
    );
  }
  onParentViewClicked(param: any) {
    let text = param.text;
    let node = param.rowData.node;
    if (text == 'Hide') {
      node.setExpanded(true);
    }
    else {
      node.setExpanded(false);
    }
  }
  onParentCancel(rowIndex) {
    this.gridApi.stopEditing();
    this.currentEditRow.editMode = false;
    this.rowData[rowIndex] = this.currentEditRow;
    this.gridConfiguration.api.setRowData(this.rowData);
    this.suppressClickEdit = true;
    this.isRowEditing = false;
  }
  onParentEditClicked(val: any) {
    let nodeData = val.data;
    console.log(nodeData);
    const vocherEmitedDetails = {
      OperationType: 'Edit',
      currentRowData: nodeData
    };
    this.addFormOption = true;
    this.totallingAccountform.enable();
    this.editOption = true;
    this.getRowData(nodeData.SegAccountCode);
    this.displayAnimate = false;
  }
  getRowData(segmentvalue: Number) {
    // let params = this.totallingAccountform.value.SegAccountCode;
    this.totallingAccountService.getRowData(segmentvalue).subscribe((data) => {
      this.totallingAccountform.value.SegLevelNo = data.StrLevelNo;
      let arrayFormFields = ['StrDesc', 'StrLevelNo', 'StrMask', 'SegSerialNo', 'SegPrefix', 'SegAccountCode', 'SegParentLevelNo', 'SegAccountDescription', 'SegEnglishDescription', 'SegEffectiveDate', 'SegGCLCode', 'SegLevelNo'];
      arrayFormFields.forEach((val) => {
        if (data[val] != null && data[val] != undefined) {
          this.totallingAccountform.controls[val].setValue(data[val]);
        }
      });

      this.getTotaling = data.StrTotOrPostInt;
      this.getStatus = Number(data.StrStatus);
      this.getSegStatus = Number(data.SegStatus);
    });
  }
  refreshGrid(columnConfig: any[]) {
    this.columnDefs = [];
  }
  fitToCoulmn() {
    setTimeout(() => {
      this.gridApi.sizeColumnsToFit();
    }, 200);
  }
  onGridReady(params) {
    console.log(params, 'params');
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridConfiguration.api.setRowData(this.rowData);
    params.api.paginationGoToPage(0);
    this.fitToCoulmn();
  }
  onPageSizeChanged(newPageSize: HTMLSelectElement) {
    const value = +(newPageSize.srcElement.value);
    this.gridApi.paginationSetPageSize(value);
    this.gridApi.sizeColumnsToFit();
  }
  editRowData(rowIndex, column) {
    this.gridApi.startEditingCell({
      rowIndex: rowIndex,
      colKey: column
    });
    this.isRowEditing = true;
  }
  allowEditing(rowIndex, colId) {
    if (this.isRowEditing) {
      if (rowIndex !== this.editingRowIndex) {
        this.suppressClickEdit = true;
        this.gridApi.stopEditing();
      }
      else {
        this.suppressClickEdit = false;
        this.editRowData(rowIndex, colId);
      }
    }
  }
  addNewRow() {
    this.clearerrors();
    this.addFormOption = true;
    this.totallingAccountform.enable();
    this.editOption = false;
    this.resetForm();
    this.displayAnimate = true;
  }
  onParentDeleteClicked(id) {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = RSAMSGConstants.BTNPROCEED) {
        this.totallingAccountService.removeTotallingAccount(id).subscribe(
          dataReturn => {
            if (!dataReturn) {
              this.alertService.success('Data cannot be deleted as it is already associated with transactions.');
              this.gettotallingAccount();
            }
            else {
              this.alertService.success('Data deleted successfully.');
              this.gettotallingAccount();

            }
          },
          errorRturn => {
            console.log(errorRturn);
          }
        );
      }
    });
  }
  changeEffectiveDate() {
    if (this.totallingAccountform.controls['SegEffectiveDate'].value) {
      const effectiveDate = new Date(this.totallingAccountform.controls['SegEffectiveDate'].value);
      this.totallingAccountform.controls['SegEffectiveDate'].setValue(new DatePipe('en-US').transform(effectiveDate, 'dd/MM/yyyy'));
    }
  }

  submitForm() {
    this.errorLevelDescription = this.leveldesc.invalid;
    this.errorSerialNo = this.serialno.invalid;
    this.errorPrefix = this.prefix.invalid;
    this.errorAccountCode = this.acCode.invalid;
    this.errorAccountClass = this.acClass.invalid;
    if (this.totallingAccountform.invalid) {
      return;
    }
    else {

      if (this.editOption) {
        //update                      
        this.totallingAccountform.value.SegModifiedBy = sessionStorage.getItem('LoggedInUserId');
        this.totallingAccountform.value.StrTotOrPostInt = this.getTotaling;
        this.totallingAccountform.value.StrStatus = this.getStatus;
        this.totallingAccountform.value.SegStatus = this.getSegStatus;
        this.totallingAccountform.value.SegLevelNo = this.totallingAccountform.value.StrLevelNo;
        this.totallingAccountService.updateTotallingAccount(JSON.stringify(this.totallingAccountform.value)).subscribe(
          dataReturn => {
            this.returnValue = dataReturn;
            if (this.returnValue) {
              this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
              this.bsModalRef.content.modelTitle = '';
              this.bsModalRef.content.modelBodyContent = "You have successfully updated totalling account";
              this.bsModalRef.content.actionBtn = "Close";
              this.bsModalRef.content.valueChange.subscribe((data) => {
                console.log(" success datat" + data);
                if (data == 'Close') {
                  console.log("close btn clicked");
                } else {
                  console.log(" else close");
                }
                this.resetForm();
                this.editOption = false;
                this.gettotallingAccount();
                this.addFormOption = false;

              });
            }
            else if (!dataReturn) {
              this.errorAccountCodeExists = true;
            }
          });

      }
      else {
        this.totallingAccountform.value.StrTotOrPostInt = this.getTotaling;
        this.totallingAccountform.value.StrStatus = this.getStatus;
        this.totallingAccountform.value.SegLevelNo = this.totallingAccountform.value.StrLevelNo;
        this.totallingAccountService.createTotallingAccount(JSON.stringify(this.totallingAccountform.value)).subscribe(
          dataReturn => {
            this.returnValue = dataReturn;
            if (this.returnValue) {
              this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
              this.bsModalRef.content.modelTitle = '';
              this.bsModalRef.content.modelBodyContent = "You have successfully created totalling account";
              this.bsModalRef.content.actionBtn = "Close";
              this.bsModalRef.content.valueChange.subscribe((data) => {
                console.log(" success datat" + data);
                if (data == 'Close') {
                  console.log("close btn clicked");
                } else {
                  console.log(" else close");
                }
                this.resetForm();
                this.editOption = false;
                this.gettotallingAccount();
                this.addFormOption = false;

              });
            }
            else if (!dataReturn) {
              this.errorAccountCodeExists = true;
            }
          });
      }
    }
  }
  resetForm() {
    let arrayFormFields = ['StrDesc', 'StrLevelNo', 'StrMask', 'StrTotOrPostInt', 'StrStatus', 'SegSerialNo', 'SegPrefix', 'SegAccountCode', 'SegParentLevelNo', 'SegAccountDescription', 'SegEnglishDescription', 'SegEffectiveDate', 'SegGCLCode', 'SegStatus', 'SegLevelNo'];
    arrayFormFields.forEach((val) => {
      if (this.totallingAccountform.controls[val] != null && this.totallingAccountform.controls[val] != undefined) {
        this.totallingAccountform.controls[val].reset();
      }
    });
    this.clearerrors();
  }
  cancel() {
    this.addFormOption = false;
    this.editOption = false;
  }
  displayModifybutton(functionid) {
    return this.allowAccess.isAllowed(functionid);
  }
}
interface TextValuePair {
  id: number;
  value: string;
}
