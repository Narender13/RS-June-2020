import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TotallingAccountComponent } from './totalling-account.component';

describe('TotallingAccountComponent', () => {
  let component: TotallingAccountComponent;
  let fixture: ComponentFixture<TotallingAccountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TotallingAccountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TotallingAccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
