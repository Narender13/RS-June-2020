import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap';
import { AdminMastersService } from 'src/app/administration/services/admin-masters.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { PARAMETERS } from '@angular/core/src/util/decorators';
import { Body } from '@angular/http/src/body';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { filter } from '@angular-devkit/schematics';

@Component({
  selector: 'rsa-previliges-list',
  templateUrl: './previliges-list.component.html',
  styleUrls: ['./previliges-list.component.scss']
})
export class PreviligesListComponent implements OnInit {
  itemsList: any;
  collapsetoheader: boolean;
  previewFlag: boolean;
  previligeList: boolean;
  mode: string;
  editMode: boolean;
  rolename: any;
  getData: any;
  addNew: boolean;
  PreviligeList: string;
  previligeForm: FormGroup;
  getAllPreviligesdata: any;
  @Output() valueChange = new EventEmitter();
  previligeListEmpty: boolean;
  applicationList: any;
  allPreviligeList: any;
  checkedList = [];

  unamePattern: string;
  constructor(protected modalService: BsModalService, private rolesAndPrivilegesService: AdminMastersService,
    private alertService: AlertService, private fb: FormBuilder) { }

  ngOnInit() {

    if (this.mode === 'Edit') {
      this.getPreviliges(this.rolename);
      this.editMode = true;
      this.PreviligeList = "Edit Privileges"
    }
    else if (this.mode === 'New') {
      this.getAllPreviliges();
      this.addNew = true;
      this.PreviligeList = "Add Role and Privileges"
    }
    else {
      this.getPreviligesView(this.rolename);
      this.editMode = false;
      this.PreviligeList = "Privileges List";

    }

    this.unamePattern = "^[a-zA-Z0-9s_]+$";
    this.previligeForm = this.fb.group({
      RoleName: ['', Validators.required],
      Description: ['', Validators.required],
    })
  }
  getPreviliges(RoleName) {
    this.rolesAndPrivilegesService.getPrivileges(RoleName).subscribe((data) => {
      let response = data;
      console.log(data, 'data');
      this.getData = data;
      let getData = [];
      getData = data['FunctionalData'];
      this.applicationList = getData.filter((item) => item.Category === 'Application');
      this.allPreviligeList = getData.filter((item) => item.Category !== 'Application')
        .sort((a, b) => (a.Category < b.Category ? -1 : 1));
      this.ifAlredayCheckBoxChecked();
      return response;
    });
  }
  getPreviligesView(RoleName) {
    this.rolesAndPrivilegesService.getPrivileges(RoleName).subscribe((data) => {
      let response = data;
      this.getData = data;
      this.allPreviligeList = data['FunctionalData'].filter(x => x['IsAllowed'] === true)
        .sort((a, b) => (a.Category < b.Category ? -1 : 1));
      if (this.allPreviligeList.length === 0) {
        this.previligeListEmpty = true;
      }
      return response;
    });
  }

  getAllPreviliges() {
    this.rolesAndPrivilegesService.getAllPrivileges().subscribe((data) => {
      let response = data;
      this.getAllPreviligesdata = data;
      this.applicationList = this.getAllPreviligesdata.filter((item) => item.Category === 'Application');
      this.allPreviligeList = this.getAllPreviligesdata.filter((item) => item.Category !== 'Application')
        .sort((a, b) => (a.Category < b.Category ? -1 : 1));
      this.itemsList = data;
      return response;
    });
  }

  onApplicationModuleChange(data, event) {
    if (event.target.checked) {
      this.checkedList.push(data.Decription);
    } else {
      this.removeSelectedCheckBox(data.Decription);
      for (let i = 0; i < this.applicationList.length; i++) {
        if (this.checkedList[i] == data.Decription) {
          this.checkedList.splice(i, 1);
        }
      }
    }
  }

  removeSelectedCheckBox(data) {
    this.allPreviligeList.map(item => {
      if (item.Module === data) {
        item.IsAllowed = false;
      }
    });
  }

  ifAlredayCheckBoxChecked() {
    this.applicationList.map((item) => {
      if (item.IsAllowed) {
        let checklist = [];
        checklist.push(item);
        checklist.map((checkitem) => {
          this.checkedList.push(checkitem.Decription);
        });
        console.log(this.checkedList, '  this.checkedList');
        this.checkCurrentParentModuleSeleted(item.Module);
      }
    });
  }



  checkCurrentParentModuleSeleted(currentModule): boolean {
    if (this.checkedList.length) {
      if (this.checkedList.indexOf(currentModule) !== -1) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }


  onInActive(evt, item) {
    var target = evt.target;
    item.IsAllowed = target.checked;

  }
  /* collapse modal header */
  collapseToheader() {
    this.collapsetoheader = !this.collapsetoheader;
    let modalCLassList = document.querySelectorAll('.modal-dialog');
    if (this.collapsetoheader) {
      modalCLassList[0].classList.remove('modal-dialog-centered');
    }
    else {
      modalCLassList[0].classList.add('modal-dialog-centered');
    }
  }
  checkIsformDirty() {
    this.modalService.hide(1);
  }
  save() {
    if (this.mode === 'Edit') {
      console.log(this.applicationList, 'this.applicationList');
      let editRole = this.getData;
      console.log(editRole, 'EditRole');
      const concatData = [...this.allPreviligeList, ...this.applicationList];
      console.log(concatData, 'concatData');
      editRole['FunctionalData'] = concatData;
      editRole['ModifiedBy'] = sessionStorage.getItem('LoggedInUserId');
      console.log(editRole, 'EditRole');
      this.rolesAndPrivilegesService.editPrivileges(editRole).subscribe(
        dataReturn => {
          if (dataReturn) {
            this.alertService.success('Data saved successfully.');
            this.modalService.hide(1);
          }
          else {
            this.alertService.error('something went wrong');
            return false;
          }
        },
        errorRturn => {
          this.alertService.error('something went wrong');
          return false;
        }
      );
    }
    else if (this.mode === 'New') {
      if (this.previligeForm.controls.RoleName.touched && this.previligeForm.controls.RoleName.value.trim().length === 0) {
        this.previligeForm.controls.RoleName.setErrors({ 'invalid': true });
      }

      if (this.previligeForm.controls.Description.touched && this.previligeForm.controls.Description.value.trim().length === 0) {
        this.previligeForm.controls.Description.setErrors({ 'invalid': true });

      }
      if (this.previligeForm.invalid) {
        this.previligeForm.get('RoleName').markAsTouched();
        this.previligeForm.get('Description').markAsTouched();
      }
      else {
        let newRole = {};
        newRole['FunctionalData'] = this.itemsList;
        let rolenamelength = this.previligeForm.controls.RoleName.value.length;
        let rolename = this.previligeForm.controls.RoleName.value;
        let namefinal = rolename[rolenamelength - 1];
        let abc = namefinal === '_' ? rolename + 'JPTR' : rolename + '_JPTR'
        newRole['RoleName'] = abc;
        newRole['Description'] = this.previligeForm.controls.Description.value;
        newRole['ModifiedBy'] = null;
        newRole['ModifiedByStr'] = null;
        newRole['ModifiedDate'] = null
        newRole['PreparedBy'] = sessionStorage.getItem('LoggedInUserId');
        newRole['PreparedByStr'] = null;
        newRole['PreparedDate'] = null;
        this.rolesAndPrivilegesService.addnewRoleAndPrivileges(newRole).subscribe(
          dataReturn => {
            if (dataReturn) {
              if (dataReturn['message'] === 'Role already exist' && dataReturn['success'] === false) {
                this.alertService.warn('Role Name already exists. Please provide another Role Name');
                // this.modalService.hide(1);
              }
              else {
                this.alertService.success('Role added successfully.');
                this.modalService.hide(1);
                this.valueChange.emit(newRole);
              }
            }
            else {
              this.alertService.error('something went wrong');
              return false;
            }
          },
          errorRturn => {
            this.alertService.error('something went wrong');
            return false;
          }
        );
      }
    }

  }
  selectAll() {
    this.checkedList = [];
    this.allPreviligeList.filter(cbstatus => cbstatus.IsAllowed = true);
    const checklist = this.applicationList.filter(cbstatus => cbstatus.IsAllowed = true);
    checklist.map((item) => {
      this.checkedList.push(item.Decription);
    });
  }
  clear() {
    this.allPreviligeList.filter(cbstatus => cbstatus.IsAllowed = false);
    const checklist = this.applicationList.filter(cbstatus => cbstatus.IsAllowed = false);
    this.checkedList = [];
  }
  Reset() {
    this.allPreviligeList = this.getPreviliges(this.rolename);
  }
  get role() { return this.previligeForm.get('RoleName'); }
  get description() { return this.previligeForm.get('Description'); }
}
