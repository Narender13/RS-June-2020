export class RolesPrivileges {
    RoleName:string;
    Description;string;
    success:boolean;

}
