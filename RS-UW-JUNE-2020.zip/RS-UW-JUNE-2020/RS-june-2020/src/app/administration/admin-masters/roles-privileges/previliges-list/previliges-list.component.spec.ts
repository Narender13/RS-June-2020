import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreviligesListComponent } from './previliges-list.component';

describe('PreviligesListComponent', () => {
  let component: PreviligesListComponent;
  let fixture: ComponentFixture<PreviligesListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreviligesListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreviligesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
