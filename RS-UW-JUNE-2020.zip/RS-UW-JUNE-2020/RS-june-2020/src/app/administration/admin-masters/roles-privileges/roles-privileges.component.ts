import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { AgGridAdminEditViewButtonComponent } from 'src/app/administration/admin-masters/ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { AdminMastersService } from './../../services/admin-masters.service';
import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';
import { GridApi, ColumnApi } from 'ag-grid-community';
import { AgGirdCustomDateFilterComponent } from 'src/app/shared/ag-gird-custom-date-filter/ag-gird-custom-date-filter.component';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';
import { PreviligesListComponent } from './previliges-list/previliges-list.component';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
@Component({
  selector: 'rsa-roles-privileges',
  templateUrl: './roles-privileges.component.html',
  styleUrls: ['./roles-privileges.component.scss']
})
export class RolesPrivilegesComponent implements OnInit {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridApi: GridApi;
  gridColumnApi: ColumnApi;
  frameworkComponents;
  suppressClickEdit;
  domLayout;
  columnDefs: Array<object> = [];
  rowData: any;
  gridConfiguration: GridOptions = {};
  dataReturn: any;
  constructor(private alertService: AlertService,
    private gridApiService: GridApiService,
    private rolesAndPrivilegesService: AdminMastersService,
    protected bsModalRef: BsModalRef, protected modalService: BsModalService, private allowAccess: UserAutherizationService) {
    this.domLayout = 'autoHeight';
  }
  ngOnInit() {
    this.getRoles();
    this.gridApiService.isUnCheck().subscribe(() => {
      this.gridConfiguration.api.deselectAll();

    });
    this.columnDefs = [
      {
        headerName: '', field: 'name', headerCheckboxSelection: true, headerCheckboxSelectionFilteredOnly: true, checkboxSelection: true, filter: 'none',
        headerClass: 'hidefilter', width: 20
      },
      {
        headerName: 'Role', field: 'RoleName',
        filter: 'agTextColumnFilter', editable: false, sortable: true, width: 200
      },
      {
        headerName: 'Description', field: 'Description',
        filter: 'agTextColumnFilter', editable: false, sortable: true, width: 200
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: AgGridAdminEditViewButtonComponent,
        cellRendererParams: {
          inActoionLink: 'RolesPrivileges'
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter',
      }];
    this.GetcolumnDefs();
    this.suppressClickEdit = true;
  }
  GetcolumnDefs() {
    this.gridConfiguration = <GridOptions>{
      columnDefs: this.columnDefs,
      postProcessPopup: function (params) {
        const ePopup = params.ePopup;
        ePopup.style.top = '14.9838px';
      },
      rowData: this.rowData,
      rowHeight: 40,
      headerHeight: 40,
      pagination: true,
      floatingFiltersHeight: 40,
      paginationPageSize: 15,
      enableRangeSelection: true,
      rowSelection: 'single',
      rowMultiSelectWithClick: true,
      animateRows: true,
      enableColResize: true,
      enableFilter: true,
      suppressContextMenu: true,
      enableSorting: true,
      editType: 'cel',
      detailRowHeight: 100,
      defaultColDef: {
        enableRowGroup: false,
        enableValue: true,
        suppressMovable: true,
        minWidth: 20,
        menuTabs: ['filterMenuTab', '', '']
      },
      context: {
        componentParent: this
      },
    };
    this.frameworkComponents = { agDateInput: AgGirdCustomDateFilterComponent };
  }
  onGridReady(params) {
    console.log(params, 'params');
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridConfiguration.api.setRowData(this.rowData);
    params.api.paginationGoToPage(0);
    this.fitToCoulmn();
  }
  fitToCoulmn() {
    setTimeout(() => {
      this.gridApi.sizeColumnsToFit();
    }, 200);
  }

  getRoles() {
    this.rolesAndPrivilegesService.getRoles().subscribe((data) => {
      this.rowData = data;
    });
  }
  onParentDeleteClicked(params1, params2) {
    params2 = sessionStorage.LoggedInUserId;
    this.rolesAndPrivilegesService.removeRolesAndPrivileges(params1, params2).subscribe(
      dataReturn => {
        if (dataReturn.success) {
          this.alertService.success('Data deleted successfully.');
          this.getRoles();
        }
      });
  }
  addNew() {
    const initialState = {
      mode: 'New'
    };
    this.bsModalRef = this.modalService.show(PreviligesListComponent,
      { class: 'create-modal-dailog modal-dialog-centered', initialState, ignoreBackdropClick: true, backdrop: 'static' });
    this.bsModalRef.content.valueChange.subscribe((data) => {
      this.getRoles();
    });
  }
  displayModifybutton(functionid) {
    return this.allowAccess.isAllowed(functionid);
  }
}
