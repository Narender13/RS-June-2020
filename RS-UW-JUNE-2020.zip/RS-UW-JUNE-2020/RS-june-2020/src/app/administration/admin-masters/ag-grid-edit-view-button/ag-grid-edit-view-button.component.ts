import { AdminMastersService } from './../../services/admin-masters.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ICellRendererAngularComp, AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { PreviligesListComponent } from '../roles-privileges/previliges-list/previliges-list.component';
import { MessageService } from 'src/app/core/message/service/message.service';

@Component({
  selector: 'rsa-admin-ag-grid-edit-view-button',
  templateUrl: './ag-grid-edit-view-button.component.html',
  styleUrls: ['./ag-grid-edit-view-button.component.scss']
})
export class AgGridAdminEditViewButtonComponent implements ICellRendererAngularComp {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridConfiguration: GridOptions;
  public params: any;
  showSave = false;
  showCancel = false;
  parentComponent;
  pageName: string;
  isView: boolean;
  viewText: string;
  employeeData: any;

  constructor(private alertService: AlertService, private allowAccess: UserAutherizationService,
    protected bsModalRef: BsModalRef, protected modalService: BsModalService,
    private userService: AdminMastersService) {
  }

  agInit(params: any): void {
    //console.log(params, 'params');
    this.params = params;
    this.parentComponent = this.params.context.componentParent;
    this.pageName = params.inActoionLink;
    this.isView = false;
    this.viewText = "View";
    if (this.pageName === 'InstrumentTypes' || this.pageName === 'Transactions' || this.pageName === 'PaymentModes' || this.pageName === 'CostCenters' || this.pageName === 'Glinterface' || this.pageName === 'TotallingAC' || this.pageName === 'Statusanalysis' || this.pageName === 'FinancialAuthority') {
      if (this.params.data.isNewRow) {
        this.showSave = true;
        this.showCancel = true;
      }
    }
  }

  editCall(rowIndex) {
    if (this.params.data.editMode) {
      this.alertService.warn('Please save/cancel the data which already modifed.');
      return false;
    }
    else {
      let edited = this.parentComponent.onParentEditClicked(rowIndex);
      if (edited) {
        this.showSave = true;
        this.showCancel = true;
      }
    }
  }
  editCalls(val: any) {
    this.parentComponent.onParentEditClicked(val)
  }

  deleteCall(val: any, rowIndex) {
    this.parentComponent.onParentDeleteClicked(val, rowIndex);
  }
  saveCall(id, rowIndex) {
    let saved = this.parentComponent.onParentSaveClicked(id, rowIndex);
    if (saved) {
      this.showSave = false;
      this.showCancel = false;
    }
  }
  cancelCall(rowIndex) {
    this.parentComponent.onParentCancel(rowIndex);
    this.showCancel = false;
    this.showSave = false;
  }
  refresh(): boolean {
    return false;
  }
  //totalling account
  viewTotAcc(val: any) {
    this.isView = !this.isView;
    if (this.isView) {
      this.viewText = "Hide";
    }
    else {
      this.viewText = "View";
    }

    const param = { rowData: val, text: this.viewText };
    this.parentComponent.onParentViewClicked(param)
  }
  editTotAcc(val: any) {
    this.parentComponent.onParentEditClicked(val)
  }
  deleteTotAcc(id) {

    this.parentComponent.onParentDeleteClicked(id);
  }

  //Roles and Privileges
  viewRolesPrivil(params) {
    const initialState = {
      mode: 'View',
      rolename: params.data.RoleName

    };
    this.bsModalRef = this.modalService.show(PreviligesListComponent,
      { class: 'create-modal-dailog modal-dialog-centered', initialState, ignoreBackdropClick: true, backdrop: 'static' });

  }
  editRolesPrivil(params) {
    const initialState = {
      rolename: params.data.RoleName,
      mode: 'Edit'
    };
    this.bsModalRef = this.modalService.show(PreviligesListComponent,
      { class: 'create-modal-dailog modal-dialog-centered', initialState, ignoreBackdropClick: true, backdrop: 'static' });
  }
  deleteRolesPrivil(params1, params2) {

    this.parentComponent.onParentDeleteClicked(params1, params2);
  }
  displayModifyItem(functionid) {
    return this.allowAccess.isAllowed(functionid);
  }
  displaymastersItem(pageName) {
    let tasks = {
      'Transactions': 309,
      'Statusanalysis': 315,
      'InstrumentTypes': 313,
      'PaymentModes': 311,
      'CostCenters': 307,
      'Glinterface': 305,
      'TotallingAC': 303,
      'FinancialAuthority': 321,
      'Users': 612,
      'RolesPrivileges': 317
    }
    let functionidVal = tasks[pageName];
    //console.log('functionidVal>>>>',functionidVal);
    return this.displayModifyItem(parseInt(functionidVal));
  }
  displayModifyItemView(functionid) {
    return this.allowAccess.isAllowed(functionid);
  }


  viewUser(params) {
    console.log(params.data, 'UserID');
    const userid = 'UserID=' + params.data.UserID;
    this.isView = !this.isView;
    if (this.isView) {
      this.viewText = "Hide";
    }
    else {
      this.viewText = "View";
    }
    if (params.data.EmployeedID !== null) {
      this.userService.getEmployeDetails(userid).subscribe((data) => {
        this.employeeData = data;
        console.log(this.employeeData, 'data');
        Object.assign(params['data'], this.employeeData);
        if (this.employeeData) {
          const employeedata = { rowData: params, text: this.viewText };
          this.parentComponent.onParentViewClicked(employeedata);
        }
      });
    } else {
      const param = { rowData: params, text: this.viewText };
      this.parentComponent.onParentViewClicked(param);
    }
    console.log(params, 'ousideget-empl-details');

  }

  deleteUser(userId) {
    this.parentComponent.onParentDeleteClicked(userId);
  }

}
