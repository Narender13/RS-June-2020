import { Component, OnInit } from '@angular/core';
import { AdminMastersService } from '../../services/admin-masters.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
  selector: 'rsa-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  headerText: string;
  isNew: boolean;
  isEmployeeLoad: boolean;
  userRoleList: any;
  constructor(private userService: AdminMastersService, private allowAccess: UserAutherizationService) {

  }

  ngOnInit() {
    this.isNew = false;
    this.headerText = "Users";
    this.isEmployeeLoad = true;
  }

  addNew() {
    this.isNew = true;
    this.headerText = "Add User";
  }

  onSwitchChange() {
    this.isEmployeeLoad = !this.isEmployeeLoad;
  }
  displayModifybutton(functionid) {
    return this.allowAccess.isAllowed(functionid);
  }

}
