import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AdminMastersService } from 'src/app/administration/services/admin-masters.service';
import { FormBuilder } from '@angular/forms';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';

@Component({
  selector: 'rsa-user-role-popup',
  templateUrl: './user-role-popup.component.html',
  styleUrls: ['./user-role-popup.component.scss']
})
export class UserRolePopupComponent implements OnInit {
  userRoleList: any;
  selectedUserRoles: any;
  dropdownSettings: {};
  maxHeightMultiSelectDropdown = 195;
  userRoleForm: any;
  @Output() valueChange = new EventEmitter();
  selectedRoles: any;
  constructor(private userService: AdminMastersService, private formBuilder: FormBuilder,
    private modalService: BsModalService, public bsModalRef: BsModalRef,
    private alertService: AlertService) { }

  ngOnInit() {
    this.setDropDownConfigSetting();
    this.createUserForm();
    this.getAllUserRoles();
  }

  createUserForm(): void {
    this.userRoleForm = this.formBuilder.group({
      UserRoles: [null],
      RoleSearch: [null],
    });
  }

  get userRoleSearchCtrl() { return this.userRoleForm.controls['RoleSearch']; };

  setDropDownConfigSetting(): void {
    this.dropdownSettings = {
      singleSelection: false,
      text: 'Select Role',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      primaryKey: 'Role',
      labelKey: 'Role',
      badgeShowLimit: 1,
      enableSearchFilter: true,
      maxHeight: this.maxHeightMultiSelectDropdown,
      classes: 'rsa-dropdown'
    };
  }

  getAllUserRoles() {
    let searchValue = this.userRoleSearchCtrl.value ? this.userRoleSearchCtrl.value : '';
    this.userService.getAllUserRoles(searchValue).subscribe((data) => {
      this.userRoleList = data;
    });
  }

  onRoleItemSelect(evt) {
    const selectednames = this.selectedRoles.filter(x => x.Role === evt.Role);
    if (selectednames.length) {
      this.alertService.error('This role is already added.Please select another role.');
      this.selectedUserRoles.splice(this.selectedUserRoles.indexOf(evt), 1)
    }
  }

  onRoleItemDeSelect(evt) {

  }

  onRoleSelectAll(evt) {

  }

  onRoleDeSelectAll(evt) {

  }

  addNewUserRoles() {
    if (this.selectedUserRoles.length === 0) {
      this.alertService.warn('Please select atleast one role.');
      return false;
    }
    else {
      this.valueChange.emit(this.selectedUserRoles);
      this.bsModalRef.hide();
    }
  }

  hideRolePopUp() {
    this.selectedUserRoles = [];
    this.bsModalRef.hide();
  }

}
