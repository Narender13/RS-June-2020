export class User {
    userType: string;
    userRoleType: string;
    UserEngName: string;
    EmployeedID: number;
    BrokerId: number;
    AgentId: number;
    EmailID: string;
    MobileNo: string;
    StatusID: number;
    PreparedBy: string;
    PreparedDate: Date;
    UserRoleMaps: Array<any>;
    AccountExecutive: number;
}
