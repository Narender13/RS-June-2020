import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserRolePopupComponent } from './user-role-popup.component';

describe('UserRolePopupComponent', () => {
  let component: UserRolePopupComponent;
  let fixture: ComponentFixture<UserRolePopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserRolePopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserRolePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
