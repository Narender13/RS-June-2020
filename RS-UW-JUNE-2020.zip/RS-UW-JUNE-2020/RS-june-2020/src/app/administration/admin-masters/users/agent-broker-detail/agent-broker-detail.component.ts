import { Component, OnInit } from '@angular/core';
import { AdminMastersService } from 'src/app/administration/services/admin-masters.service';
import { FormBuilder, Validators } from '@angular/forms';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';

@Component({
  selector: 'rsa-agent-broker-detail',
  templateUrl: './agent-broker-detail.component.html',
  styleUrls: ['./agent-broker-detail.component.scss']
})
export class AgentBrokerDetailComponent implements OnInit {
  params: any;
  agentBrokerData: any;
  parentComponent: any;
  userAccountForm: any;
  inActivePeriod: any;
  endDateMinValue: any;
  agentBrokerOrigData: any;

  constructor(private formBuilder: FormBuilder, private userService: AdminMastersService, 
    private alertService: AlertService) { }

  ngOnInit() {
    
  }
  
  agInit (params: any): void {
    this.params = params;
    console.log(params.data);
    this.agentBrokerOrigData = JSON.stringify(params.data);
    this.agentBrokerData = JSON.parse(JSON.stringify(params.data));
    this.parentComponent = this.params.context.componentParent;
    this.inActivePeriod = this.agentBrokerData.Status === 'INACTIVE' ? true : false;
    this.createUserForm();
    if(this.inActivePeriod){
      this.userStartDateCtrl.setValue(this.agentBrokerData.StatusStartDate ? new Date(this.agentBrokerData.StatusStartDate) : '');
      this.userEndDateCtrl.setValue(this.agentBrokerData.StatusEndDate ? new Date(this.agentBrokerData.StatusEndDate) : '');
    }
  }

  viewAccount(evt){

  }

  viewRole(evt){

  }

  createUserForm(): void {
    this.userAccountForm = this.formBuilder.group({
      Status: [null, Validators.required],
      StartDate: [null, Validators.required],
      EndDate: [null, Validators.required]
    });
  }

  get userStatusCtrl() { return this.userAccountForm.controls['Status']; };
  get userStartDateCtrl() { return this.userAccountForm.controls['StartDate']; };
  get userEndDateCtrl() { return this.userAccountForm.controls['EndDate']; };

  moreAction(role){
    role.showOnClick=!role.showOnClick
  }

  removeRole(role){
    if(!role.isNew){
      role.isValue = 2;
    }
    else
    {
      let idxRole = this.agentBrokerData.UserRoleMaps.indexOf(role);
      if(idxRole >= 0){
        this.agentBrokerData.UserRoleMaps.splice(idxRole, 1);
      }
    }
  }

  saveUser(){
    if(this.agentBrokerData.Status === 'INACTIVE'){
      this.agentBrokerData.StatusStartDate = this.userStartDateCtrl.value;
      this.agentBrokerData.StatusEndDate = this.userEndDateCtrl.value;
    }
    this.userService.updateAgentBroker(this.agentBrokerData).subscribe(  
      dataReturn => {
          if (dataReturn.success) {
            this.alertService.success('Data saved successfully.');
            this.parentComponent.onParentReload(false);
          }
          else{
            this.alertService.error('something went wrong');
            return false;
          }
        },
      errorRturn => {
          this.alertService.error('something went wrong');
          return false;
      }
    );
  }

  cancelUser(){
    this.agentBrokerData = JSON.parse(this.agentBrokerOrigData);
    this.inActivePeriod = false;
    //this.parentComponent.onParentCancelClicked(this.params);
  }

  viewCompanyInfo(evt){

  }

  onStatusChange(evt){
    var target = evt.target;
    if (target.checked) {
      this.agentBrokerData.StatusID = target.value;
      switch(target.value){
        case "1":
            this.agentBrokerData.Status = 'ACTIVE';
            break;
        case "2":
            this.agentBrokerData.Status = 'INACTIVE';
            break;
        case "3":
            this.agentBrokerData.Status = 'LOCKED';
            break;
        case "4":
            this.agentBrokerData.Status = 'LEAVER';
            break;
      }
    }
    this.inActivePeriod = false;
    this.userStartDateCtrl.setValue('');
    this.userEndDateCtrl.setValue('');
  }

  onInActive(evt){
    var target = evt.target;
    this.inActivePeriod = target.checked;
    if(!this.inActivePeriod){
      this.userStartDateCtrl.setValue('');
      this.userEndDateCtrl.setValue('');
    }
  }

  onStartDateValueChange(evt){
    if(evt){
      this.endDateMinValue = evt > new Date() ? evt : new Date();
    }
  }
}
