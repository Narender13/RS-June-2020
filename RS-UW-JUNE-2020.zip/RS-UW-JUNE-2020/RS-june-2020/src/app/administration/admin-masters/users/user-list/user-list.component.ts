import { SharedService } from 'src/app/finance/services/shared.service';
import { Component, OnInit, Input } from '@angular/core';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';
import { AdminMastersService } from 'src/app/administration/services/admin-masters.service';
import { AgGridAdminEditViewButtonComponent } from 'src/app/administration/admin-masters/ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import { EmployeeDetailComponent } from '../employee-detail/employee-detail.component';
import { AgentBrokerDetailComponent } from '../agent-broker-detail/agent-broker-detail.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
  selector: 'rsa-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})
export class UserListComponent implements OnInit {
  gridApi: any;
  gridColumnApi: any;
  gridConfiguration: any;
  gridAgtBrokConfiguration: any;
  columnDefs: any;
  suppressClickEdit: boolean;
  rowData: any;
  domLayout: string;
  _isEmployeeLoad: boolean;
  frameworkComponents;
  employeeDetailViewComponent: EmployeeDetailComponent;
  agntBrokDetailViewComponent: AgentBrokerDetailComponent;
  detailCellRenderer: string;
  detailCellRendererParams: any;
  getRowHeight: (params: any) => number;
  paginationOptions: { id: number; value: string; }[];

  constructor(private alertService: AlertService, private gridApiService: GridApiService,
    private userService: AdminMastersService,
    private allowAccess: UserAutherizationService,
    private modalService: BsModalService, public bsModalRef: BsModalRef,
    private sharedService: SharedService) {
    this.domLayout = 'autoHeight';
    this.detailCellRendererParams = {
      detailGridOptions: {
        defaultColDef: {
          resizable: true
        },
        domLayout: "autoHeight",
        onGridReady: function (params) {
          params.api.setDomLayout("autoHeight");
        },
        onFirstDataRendered(params) {
          params.api.sizeColumnsToFit();
        }
      },
      getDetailRowData: function (params) {
        params.successCallback(params.data.UserRoleMaps);
      }
    };
    this.getRowHeight = function (params) {
      if (params.node && params.node.detail) {
        const allDetailRowHeight = params.data.UserRoleMaps.length * 120;
        return allDetailRowHeight < 700 ? 700 : allDetailRowHeight;
      } else {
        return 40;
      }
    };
    this.paginationOptions = [
      { id: 1, value: '15' },
      { id: 2, value: '30' },
      { id: 3, value: '60' },
      { id: 4, value: '100' }
    ];
  }

  ngOnInit() {
    this.suppressClickEdit = true;
  }

  @Input()
  public set isEmployeeLoad(val: boolean) {
    this._isEmployeeLoad = val;
    this.loadGrid();
  }

  loadGrid() {
    if (this._isEmployeeLoad) {
      this.getEmployeeColumnDefs();
      this.getAllEmployees();
    }
    else {
      this.getAgtBrokColumnDefs();
      this.getAllAgentBrokers();
    }
    this.getGridConfigs();
  }

  getAllEmployees() {
    this.userService.getAllEmployees().subscribe((data) => {
      this.rowData = data;
    });
  }

  getAllAgentBrokers() {
    this.userService.getAllAgentBrokers().subscribe((data) => {
      this.rowData = data;
    });
  }

  onParentReload(isEmployeeLoad) {
    this._isEmployeeLoad = isEmployeeLoad;
    this.loadGrid();
  }

  getEmployeeColumnDefs() {
    this.columnDefs = [
      {
        headerName: 'Full Name', field: 'UserEngName',
        filter: 'agTextColumnFilter', editable: false, sortable: true
      },
      {
        headerName: 'Title', field: 'Designation',
        filter: 'agTextColumnFilter', editable: false, sortable: true
      },
      {
        headerName: 'Department', field: 'Department',
        filter: 'agTextColumnFilter', editable: false, sortable: true
      },
      {
        headerName: 'Email', field: 'EmailID',
        filter: 'agTextColumnFilter', editable: false, sortable: true
      },
      {
        headerName: 'Mobile Number', field: 'MobileNo',
        filter: 'agTextColumnFilter', editable: false, sortable: true
      },
      {
        headerName: 'Status', field: 'Status',
        filter: 'agTextColumnFilter', editable: false, sortable: true,
        valueGetter: function (params) {
          return params.data.Status === 'LEAVER' ? 'DISABLED' : params.data.Status;
        }
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: AgGridAdminEditViewButtonComponent,
        cellRendererParams: {
          inActoionLink: 'Users'
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter',
      }
    ];
    this.frameworkComponents = { employeeDetailViewComponent: EmployeeDetailComponent };
    this.detailCellRenderer = "employeeDetailViewComponent";
  }

  getAgtBrokColumnDefs() {
    this.columnDefs = [
      {
        headerName: '', field: 'name', headerCheckboxSelection: true, headerCheckboxSelectionFilteredOnly: true, checkboxSelection: true, filter: 'none',
        headerClass: 'hidefilter', width: 35
      },
      {
        headerName: 'Full Name', field: 'UserEngName',
        filter: 'agTextColumnFilter', editable: false, sortable: true
      },
      {
        headerName: 'Company Name', field: 'Designation',
        filter: 'agTextColumnFilter', editable: false, sortable: true
      },
      {
        headerName: 'License Number', field: 'LicenceNo',
        filter: 'agTextColumnFilter', editable: false, sortable: true
      },
      {
        headerName: 'Email', field: 'EmailID',
        filter: 'agTextColumnFilter', editable: false, sortable: true
      },
      {
        headerName: 'Mobile Number', field: 'MobileNo',
        filter: 'agTextColumnFilter', editable: false, sortable: true
      },
      {
        headerName: 'Status', field: 'Status',
        filter: 'agTextColumnFilter', editable: false, sortable: true,
        valueGetter: function (params) {
          return params.data.Status === 'LEAVER' ? 'DISABLED' : params.data.Status;
        }
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: AgGridAdminEditViewButtonComponent,
        cellRendererParams: {
          inActoionLink: 'Users'
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter',
        hide: !this.displayModifybutton(319),
      }
    ];
    this.frameworkComponents = { agntBrokDetailViewComponent: AgentBrokerDetailComponent };
    this.detailCellRenderer = "agntBrokDetailViewComponent";
  }

  getGridConfigs() {
    this.gridConfiguration = <GridOptions>{
      columnDefs: this.columnDefs,
      postProcessPopup: function (params) {
        const ePopup = params.ePopup;
        ePopup.style.top = '14.9838px';
      },
      rowData: this.rowData,
      rowHeight: 40,
      headerHeight: 40,
      pagination: true,
      floatingFiltersHeight: 40,
      paginationPageSize: 15,
      enableRangeSelection: true,
      rowSelection: 'single',
      rowMultiSelectWithClick: true,
      animateRows: true,
      enableColResize: true,
      enableFilter: true,
      suppressContextMenu: true,
      enableSorting: true,
      editType: 'cel',
      defaultColDef: {
        enableRowGroup: false,
        enableValue: true,
        suppressMovable: true,
        minWidth: 20,
        menuTabs: ['filterMenuTab', '', '']
      },
      context: {
        componentParent: this
      },
      detailCellRenderer: this.detailCellRenderer,
      detailRowHeight: 600,
      masterDetail: true,
    };
  }

  onGridReady(params) {
    console.log(params, 'params');
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridConfiguration.api.setRowData(this.rowData);
    params.api.paginationGoToPage(0);
    this.fitToCoulmn();
  }

  fitToCoulmn() {
    setTimeout(() => {
      this.gridApi.sizeColumnsToFit();
    }, 200);
  }

  onParentViewClicked(param) {
    console.log(param, 'param-clikedview');
    if (param) {
      let text = param.text;
      let node = param.rowData.node;
      if (text == 'Hide') {
        node.setExpanded(true);
      }
      else {
        node.setExpanded(false);
      }
    }
  }

  onParentCancelClicked(param) {
    let parentNode = param.node.parent;
    parentNode.setExpanded(false);
  }

  onParentDeleteClicked(userId) {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = RSAMSGConstants.BTNPROCEED) {
        this.userService.removeUser(userId).subscribe(
          dataReturn => {
            if (!dataReturn.success) {
              this.alertService.success('Data deleted successfully.');
              this.loadGrid();
            }
            else {
              this.alertService.error('Something went wrong');
            }
          },
          errorRturn => {
            this.alertService.error('Something went wrong');
          }
        );
      }
    });
  }

  onPageSizeChanged(newPageSize: HTMLSelectElement) {
    const value = +(newPageSize.srcElement.value);
    this.gridApi.paginationSetPageSize(value);
    // this.gridApi.sizeColumnsToFit();
  }

  displayModifybutton(functionid) {
    return this.allowAccess.isAllowed(functionid);
  }
}
