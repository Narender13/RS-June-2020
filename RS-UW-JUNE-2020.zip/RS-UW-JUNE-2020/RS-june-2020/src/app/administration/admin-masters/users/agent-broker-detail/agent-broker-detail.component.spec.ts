import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentBrokerDetailComponent } from './agent-broker-detail.component';

describe('AgentBrokerDetailComponent', () => {
  let component: AgentBrokerDetailComponent;
  let fixture: ComponentFixture<AgentBrokerDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentBrokerDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentBrokerDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
