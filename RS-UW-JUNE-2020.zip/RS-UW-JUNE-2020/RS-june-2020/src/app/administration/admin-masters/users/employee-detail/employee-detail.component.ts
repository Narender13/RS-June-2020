import { Location } from '@angular/common';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
import { AdminMastersService } from 'src/app/administration/services/admin-masters.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { UserRolePopupComponent } from '../user-role-popup/user-role-popup.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { SharedService } from 'src/app/finance/services/shared.service';
import { Subscription } from 'rxjs';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
  selector: 'rsa-employee-detail',
  templateUrl: './employee-detail.component.html',
  styleUrls: ['./employee-detail.component.scss']
})
export class EmployeeDetailComponent implements OnInit, ICellRendererAngularComp {
  params: any;
  parentComponent: any;
  employeeData: any;
  userAccountForm: any;
  showOnClick: boolean;
  detailCellRendererParams: any;
  allLocationSelected: boolean;
  inActivePeriod: any;
  endDateMinValue: any;
  employeeOrigData: any;
  imageToShow: any;
  sub: Subscription;
  userLocations = [];
  employeeLocation = [];
  isUserLocationArray = [];
  oldEmpData = [];
  isSelectedEmploeeData = [];
  @ViewChild('signImgRef') signImgRef: ElementRef;
  constructor(private formBuilder: FormBuilder, private userService: AdminMastersService,
    private modalService: BsModalService, public bsModalRef: BsModalRef,
    private alertService: AlertService, private sharedService: SharedService,
    private allowAccess: UserAutherizationService) {

  }

  ngOnInit() {
    this.getUserBranches();
    if (this.isUserLocationArray) {
      this.allLocationSelected = this.isUserLocationArray.every((data) => data === true);
    }
    // this.getEmployeeData();
  }

  // getEmployeeData() {
  //   this.sharedService.getMessage().subscribe((employee) => {
  //     console.log(employee.data, 'sharevice-data-employee');
  //   });
  // }


  agInit(params: any): void {
    console.log(params, 'emploepagge');
    this.params = params;
    this.employeeOrigData = JSON.stringify(params.data);
    console.log(params.data);
    this.employeeData = JSON.parse(JSON.stringify(params.data));
    if (this.employeeData.Location.length === JSON.parse(sessionStorage.getItem(RSAConstants.allowedLocations)).length) {
      this.allLocationSelected = true;
    }
    this.parentComponent = this.params.context.componentParent;
    this.inActivePeriod = this.employeeData.Status === 'INACTIVE' ? true : false;
    this.createUserForm();
    if (this.inActivePeriod) {
      this.userStartDateCtrl.setValue(this.employeeData.StatusStartDate ? new Date(this.employeeData.StatusStartDate) : '');
      this.userEndDateCtrl.setValue(this.employeeData.StatusEndDate ? new Date(this.employeeData.StatusEndDate) : '');
    }
    if (this.employeeData.Signatures.SignatureImage) {
      this.signImgRef.nativeElement.src = 'data:image/jpg;base64,' + this.employeeData.Signatures.SignatureImage;
    }
    if (this.employeeData.Location.length) {
      this.oldEmpData = this.employeeData.Location;
      this.employeeLocation = this.oldEmpData.map(item => Object.assign(item));
      this.isSelectedEmploeeData = this.oldEmpData.map(item => Object.assign(item));
      console.log(this.oldEmpData, 'oldempdata');
      console.log(this.employeeLocation, 'employlocation');
    }
  }

  // called when the cell is refreshed
  refresh(params: any): boolean {
    console.log(params, 'params');
    return false;
  }



  get userStatusCtrl() { return this.userAccountForm.controls['Status']; };
  get userSignatureCtrl() { return this.userAccountForm.controls['Signature']; };
  get userStartDateCtrl() { return this.userAccountForm.controls['StartDate']; };
  get userEndDateCtrl() { return this.userAccountForm.controls['EndDate']; };

  isDisabled(): boolean {
    if (this.displayModifyItemView(612)) {
      if ((this.displayModifyItemView(612) && this.displayModifyItemView(319))) {
        return false;
      }
      return true;
    }
  }
  createUserForm(): void {
    this.userAccountForm = this.formBuilder.group({
      Status: [null, Validators.required],
      Signature: [null, Validators.required],
      StartDate: [null, Validators.required],
      EndDate: [null, Validators.required]
    });
  }

  moreAction(role) {
    role.showOnClick = !role.showOnClick;
  }

  removeRole(role) {
    if (!role.isNew) {
      role.isValue = 2;
    }
    else {
      let idxRole = this.employeeData.UserRoleMaps.indexOf(role);
      if (idxRole >= 0) {
        this.employeeData.UserRoleMaps.splice(idxRole, 1);
      }
    }
  }

  getUserBranches() {
    this.userLocations = JSON.parse(sessionStorage.getItem(RSAConstants.allowedLocations));
    this.isUserLocation();
  }


  cancelUser() {
    this.employeeData = JSON.parse(this.employeeOrigData);
    this.allLocationSelected = false;
    this.inActivePeriod = false;
    //this.parentComponent.onParentCancelClicked(this.params);
  }

  getAdditionalRoles() {
    const initialState = {
      selectedRoles: this.employeeData.UserRoleMaps
    };
    this.bsModalRef = this.modalService.show(UserRolePopupComponent,
      { class: 'preview-modal-dailog-send-email', initialState, backdrop: 'static', keyboard: false });
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data !== null) {
        data.forEach(element => {
          element.isNew = true;
          element.isValue = 1;
          this.employeeData.UserRoleMaps.push(element);
        });
      }
    });
  }

  onAllLocationSelected(evt) {
    const target = evt.target.checked;
    if (target) {
      this.userLocations.map((data, index) => {
        if (this.isUserLocationArray[index] === false) {
          this.isUserLocationArray[index] = true;
          this.isSelectedEmploeeData.push(data);
          this.allLocationSelected = true;
        }
      });
    } else {
      this.userLocations.map((data, index) => {
        this.isUserLocationArray[index] = false;
        this.isSelectedEmploeeData = [];
        this.allLocationSelected = false;
      });
    }
  }

  isUserLocation() {
    this.userLocations.map((itemLocation, i) => {
      let ismatch = false;
      this.employeeLocation.map((itemEmp, j) => {
        if (this.userLocations[i].locationCode === this.employeeLocation[j].Branch) {
          ismatch = true;
          this.isUserLocationArray[i] = true;
        }
      });
      if (!ismatch) {
        ismatch = false;
        this.isUserLocationArray[i] = false;
      }
    });
    console.log(this.isUserLocationArray);
  }

  saveEmpData() {
    const resultArry = [];
    if (this.userLocations.length) {
      let isDataMatch = false;
      this.userLocations.map((data, i) => {
        isDataMatch = false;
        this.oldEmpData.map((d, j) => {
          if (this.userLocations[i].locationCode === this.oldEmpData[j].Branch) {
            isDataMatch = true;
            if (this.isUserLocationArray[i] === true) {
              const oldLocation = { IsValue: 0, Branch: d.Branch, Country: d.Country };
              resultArry.push(oldLocation);
            } else {
              const oldLocation = { IsValue: 2, Branch: d.Branch, Country: d.Country };
              resultArry.push(oldLocation);
            }
          }
        });
        if (this.isUserLocationArray[i] === true && !isDataMatch) {
          const oldLocation = { IsValue: 1, Branch: data.locationCode, Country: data.countryCode, isNew: true };
          resultArry.push(oldLocation);
        }
      });
      this.employeeData.Location = resultArry;
    }

  }



  onLocationSelected(evt, index, location) {
    const target = evt.target.checked;
    if (target) {
      this.isSelectedEmploeeData.push(location);
      this.isUserLocationArray[index] = true;
    } else {
      const i = this.isSelectedEmploeeData.findIndex((item) => item.locationCode == location.locationCode);
      this.isSelectedEmploeeData.splice(i, 1);
      this.isUserLocationArray[index] = false;
    }
    this.allLocationSelected = this.isUserLocationArray.every((data) => data === true);
    console.log(this.isSelectedEmploeeData, 'isSelectedEmploeeData');
  }


  onStatusChange(evt) {
    var target = evt.target;
    if (target.checked) {
      this.employeeData.StatusID = target.value;
      switch (target.value) {
        case "1":
          this.employeeData.Status = 'ACTIVE';
          break;
        case "2":
          this.employeeData.Status = 'INACTIVE';
          break;
        case "3":
          this.employeeData.Status = 'LOCKED';
          break;
        case "4":
          this.employeeData.Status = 'LEAVER';
          break;
      }
    }
    this.inActivePeriod = false;
    this.userStartDateCtrl.setValue('');
    this.userEndDateCtrl.setValue('');
  }

  onSignatureStatusChange(evt) {
    var target = evt.target;
    if (target.checked) {
      this.employeeData.Signatures.SignatureStatus = target.value;
    }
  }

  onInActive(evt) {
    var target = evt.target;
    this.inActivePeriod = target.checked;
    if (!this.inActivePeriod) {
      this.userStartDateCtrl.setValue('');
      this.userEndDateCtrl.setValue('');
    }
  }

  onStartDateValueChange(evt) {
    if (evt) {
      this.endDateMinValue = evt > new Date() ? evt : new Date();
    }
  }

  createImageFromBlob(image: Blob) {
    let reader = new FileReader();
    reader.addEventListener("load", () => {
      this.imageToShow = reader.result;
    }, false);

    if (image) {
      reader.readAsDataURL(image);
    }
  }

  displayModifyItemView(functionid) {
    return this.allowAccess.isAllowed(functionid);
  }


  /* save User */
  saveUser() {
    this.saveEmpData();
    console.log(this.employeeData, 'this.employeeData');
    if (this.employeeData.Status === 'INACTIVE') {
      this.employeeData.StatusStartDate = this.userStartDateCtrl.value;
      this.employeeData.StatusEndDate = this.userEndDateCtrl.value;
    }
    console.log(this.employeeData, 'this.employeeData');
    this.userService.updateEmployee(this.employeeData).subscribe(
      dataReturn => {
        if (dataReturn.success) {
          this.alertService.success('Data saved successfully.');
          this.parentComponent.onParentReload(true);
        }
        else {
          this.alertService.error('something went wrong');
          return false;
        }
      },
      errorRturn => {
        this.alertService.error('something went wrong');
        return false;
      }
    );
  }


}
