import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { AdminMastersService } from 'src/app/administration/services/admin-masters.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { User } from '../model/user';

@Component({
  selector: 'rsa-user-new',
  templateUrl: './user-new.component.html',
  styleUrls: ['./user-new.component.scss']
})
export class UserNewComponent implements OnInit {
  userNewForm: any;
  newUser: User;
  isNewEmployee: boolean;
  emailList: any;
  selectedUser: any;
  selectedUserRoles: any;
  maxHeightMultiSelectDropdown = 195;
  dropdownSettings: {};
  selectedRoleUser: any;
  userRoleList: any;
  userEmailList: any;
  constructor(private formBuilder: FormBuilder, private userService: AdminMastersService,
    private alertService: AlertService) { }

  ngOnInit() {
    this.newUser = new User();
    this.createUserForm();
    this.setDropDownConfigSetting();
    this.getAllUserRoles();
  }

  createUserForm(): void {
    this.userNewForm = this.formBuilder.group({
      UserType: [null, Validators.required],
      UserEmailID: [null, Validators.required],
      UserRoleType: [null, Validators.required],
      UserRoles: [null],
      UserRoleEmailID: [null],
      RoleSearch: [null],
    });
  }
  get userTypeCtrl() { return this.userNewForm.controls['UserType']; };
  get userEmailIdCtrl() { return this.userNewForm.controls['UserEmailID']; };
  get userRoleTypeCtrl() { return this.userNewForm.controls['UserRoleType']; };
  get userRoleEmailIdCtrl() { return this.userNewForm.controls['UserRoleEmailID']; };
  get userRolesCtrl() { return this.userNewForm.controls['UserRoles']; };
  get userRoleSearchCtrl() { return this.userNewForm.controls['RoleSearch']; };

  getAllUserRoles() {
    let searchValue = this.userRoleSearchCtrl.value ? this.userRoleSearchCtrl.value : '';
    this.userService.getAllUserRoles(searchValue).subscribe((data) => {
      this.userRoleList = data;
    });
  }

  onUserTypeChange(evt) {
    var target = evt.target;
    if (target.checked) {
      if (target.value === 'Employee') {
        this.isNewEmployee = true;
        this.getAllEmployeeEmails();
      }
      else {
        this.isNewEmployee = false;
        this.getAllAgentBrokerEmails();
      }
      this.newUser.userType = target.value;
    }
    this.userEmailIdCtrl.setValue('');
    this.selectedUser = null;
    this.newUser.userRoleType = null;
    this.userRoleEmailIdCtrl.setValue('');
    this.selectedRoleUser = null;
  }

  onRoleTypeChange(evt) {
    var target = evt.target;
    if (target.checked) {
      if (target.value !== 'ExistUserRoles') {
        this.userRolesCtrl.setValidators([Validators.required]);
        this.userRolesCtrl.updateValueAndValidity();
        this.userRoleEmailIdCtrl.clearValidators();
      }
      else {
        this.getUserEmails();
        this.userRoleEmailIdCtrl.setValidators([Validators.required]);
        this.userRoleEmailIdCtrl.updateValueAndValidity();
        this.userRolesCtrl.clearValidators();
      }
      this.newUser.userRoleType = target.value;
    }
    this.userRoleEmailIdCtrl.setValue('');
    this.selectedRoleUser = null;
    this.selectedUserRoles = [];
  }

  onSetUserValue(evt) {
    if (evt.value !== null && evt.value !== '') {
      this.getSelectedUserDetail(evt.value, this.getIsEmpAgentField());
    }
    this.selectedUser = null;
    this.selectedRoleUser = null;
    this.userRoleEmailIdCtrl.setValue('');
    this.selectedUserRoles = [];
    this.newUser.userRoleType = null;
  }

  getSelectedUserDetail(emailId, isEmpAgtBrk) {
    this.userService.getUserInfoByEmail(emailId, isEmpAgtBrk).subscribe((data) => {
      this.selectedUser = data;
    });
  }

  getSelectedRoleUserDetail(emailId, isEmpAgtBrk) {
    this.userService.getAllUserRolesByEmail(emailId, isEmpAgtBrk).subscribe((data) => {
      this.selectedRoleUser = data;
      this.selectedUserRoles = data.UserRoleMaps;
    });
  }

  onClearUserValue(evt) {
    this.userEmailIdCtrl.setValue('');
  }

  onSetRoleValue(evt) {
    this.selectedUserRoles = [];
    if (evt.value !== null && evt.value !== '') {
      this.getSelectedRoleUserDetail(evt.value, this.getIsEmpAgentField());
    }
  }

  getIsEmpAgentField() {
    return this.newUser.userType === 'Employee' ? 1 : 2;
  }

  onClearRoleValue(evt) {
    this.userRoleEmailIdCtrl.setValue('');
  }

  getAllEmployeeEmails() {
    this.userService.getAllEmployeeEmails().subscribe((data) => {
      this.emailList = data;
    });
  }

  getAllAgentBrokerEmails() {
    this.userService.getAllAgentBrokerEmails().subscribe((data) => {
      this.emailList = data;
    });
  }

  getUserEmails() {
    this.userService.getUserEmails(this.getIsEmpAgentField()).subscribe((data) => {
      this.userEmailList = data;
    });
  }

  setDropDownConfigSetting(): void {
    this.dropdownSettings = {
      singleSelection: false,
      text: 'Select Role',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      primaryKey: 'Role',
      labelKey: 'Role',
      badgeShowLimit: 1,
      maxHeight: this.maxHeightMultiSelectDropdown,
      classes: 'rsa-dropdown'
    };
  }

  onRoleItemSelect(evt) {

  }

  onRoleItemDeSelect(evt) {

  }

  onRoleSelectAll(evt) {

  }

  onRoleDeSelectAll(evt) {

  }

  saveUser() {
    if (!this.userNewForm.invalid) {
      if (this.newUser.userType === 'Employee') {
        this.newUser.EmployeedID = this.selectedUser.EmployeedID ? this.selectedUser.EmployeedID : null;
      }
      else {
        this.newUser.AgentId = this.selectedUser.AgentId ? this.selectedUser.AgentId : null;
        this.newUser.BrokerId = this.selectedUser.BrokerId ? this.selectedUser.BrokerId : null;
        this.newUser.AccountExecutive = this.selectedUser.AccountExecutive ? this.selectedUser.AccountExecutive : null;
      }
      this.newUser.UserEngName = this.selectedUser.EngName;
      this.newUser.StatusID = 1; //Active
      this.newUser.EmailID = this.userEmailIdCtrl.value;
      this.newUser.MobileNo = this.selectedUser.MobileNo;
      this.newUser.UserRoleMaps = this.selectedUserRoles;
      this.userService.createNewUser(this.newUser).subscribe(
        dataReturn => {
          if (dataReturn.success) {
            this.alertService.success('Data saved successfully.');
            this.cancelUser();
          }
          else {
            this.alertService.error('something went wrong');
            return false;
          }
        },
        errorRturn => {
          this.alertService.error('something went wrong');
          return false;
        }
      );
    }
    else {
      this.alertService.warn('Please fill all required fields!!');
    }
  }

  cancelUser() {
    this.selectedUser = null;
    this.userEmailIdCtrl.setValue('');
    this.selectedRoleUser = null;
    this.userRoleEmailIdCtrl.setValue('');
    this.selectedUserRoles = [];
    this.newUser.userType = null;
    this.newUser.userRoleType = null;
    this.userNewForm.reset();
  }

  removeSelectedUser() {
    this.selectedUser = null;
    this.userEmailIdCtrl.setValue('');
    this.selectedRoleUser = null;
    this.userRoleEmailIdCtrl.setValue('');
  }

  removeSelectedRoleUser() {
    this.selectedRoleUser = null;
    this.userRoleEmailIdCtrl.setValue('');
  }

}
