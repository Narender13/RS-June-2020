import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminMastersComponent } from './admin-masters/admin-masters.component';
import { UnderwritingMastersComponent } from './underwriting-masters/underwriting-masters.component';
import { CountryComponent } from './underwriting-masters/CountryAndRegion/CountryComponents/country/country.component';
import { RegionComponent } from './underwriting-masters/CountryAndRegion/region/region.component';
import { LocationComponent } from './underwriting-masters/CountryAndRegion/locationcomponents/location/location.component';
import { CountryRegionComponent } from './underwriting-masters/country-region/country-region.component';
import { MunicipalityComponent } from './underwriting-masters/CountryAndRegion/municipality/municipality.component';
import { DirectorateComponent } from './underwriting-masters/CountryAndRegion/directorate/directorate.component';
import { ZoneComponent } from './underwriting-masters/CountryAndRegion/zone/zone.component';
import { GeoAreaComponent } from './underwriting-masters/CountryAndRegion/geo-area/geo-area.component';
import { CountryNewComponent } from './underwriting-masters/CountryAndRegion/CountryComponents/country-new/country-new.component';
import { CountryHomeComponent } from './underwriting-masters/CountryAndRegion/CountryComponents/country-home/country-home.component';
import { LocationHomeComponent } from './underwriting-masters/CountryAndRegion/locationcomponents/location-home/location-home.component';
import { BrokercertificateDirectComponent } from './underwriting-masters/brokercertificate/brokercertificate-direct/brokercertificate-direct.component';
import { BrokercertificateBrokerComponent } from './underwriting-masters/brokercertificate/brokercertificate-broker/brokercertificate-broker.component';
import { BrokercerticateAgentComponent } from './underwriting-masters/brokercertificate/brokercerticate-agent/brokercerticate-agent.component';

import { ConditionsComponent } from './underwriting-masters/snackbar/conditions/conditions.component';
import { ExclusionComponent } from './underwriting-masters/snackbar/exclusion/exclusion.component';
import { WarrantiesComponent } from './underwriting-masters/snackbar/warranties/warranties.component';
import { EndorsementsComponent } from './underwriting-masters/snackbar/endorsements/endorsements.component';
import { EndorsementHeaderComponent } from './underwriting-masters/snackbar/endorsement-header/endorsement-header.component';
import { EndorsementFooterComponent } from './underwriting-masters/snackbar/endorsement-footer/endorsement-footer.component';
import { TrackOrangeCardComponent } from './underwriting-masters/motars-orange/track-orange-card/track-orange-card.component';
import { OrangeCardSeriesComponent } from './underwriting-masters/motars-orange/orange-card-series/orange-card-series.component';

const routes: Routes = [
  {
    path: '',
    children: [
      { path: '', component: AdminHomeComponent },
      { path: ':masterName', component: AdminMastersComponent, data: { breadcrumb: 'home', path: 'Finance' } },
      { path: 'underwriting/:uwmasterName', component: UnderwritingMastersComponent  ,
      children: [
        {
          path: 'countryhome' , component: CountryHomeComponent,
          data: {breadcrumb: '', path: 'countryhome'}
        },
        {
          path: 'region' , component: RegionComponent,
          data: {breadcrumb: '', path: 'region'}
        },
        {
          path: 'locationhome' , component: LocationHomeComponent,
          data: {breadcrumb: '', path: 'locationhome'}
        },
        {
          path: 'muncipality' , component: MunicipalityComponent,
          data: {breadcrumb: '', path: 'muncipality'}
        },
        {
          path: 'directorate' , component: DirectorateComponent,
          data: {breadcrumb: '', path: 'directorate'}
        },
        {
          path: 'zone' , component: ZoneComponent,
          data: {breadcrumb: '', path: 'zone'}
        },
        {
          path: 'geoarea' , component: GeoAreaComponent,
          data: {breadcrumb: '', path: 'geoarea'}
        },
        {
          path: 'direct' , component: BrokercertificateDirectComponent,
          data: {breadcrumb: '', path: 'direct'}
        },
        {
          path: 'broker' , component: BrokercertificateBrokerComponent,
          data: {breadcrumb: '', path: 'broker'}
        },
        {
          path: 'agent' , component: BrokercerticateAgentComponent,
          data: {breadcrumb: '', path: 'agent'}
        },
 
        {
          path: 'condition' , component: ConditionsComponent,
          data: {breadcrumb: '', path: 'condition'}
        },
        {
          path: 'exclusions' , component: ExclusionComponent,
          data: {breadcrumb: '', path: 'exclusions'}
        },
        {
          path: 'warrenties' , component: WarrantiesComponent,
          data: {breadcrumb: '', path: 'warrenties'}
        },
        {
          path: 'endorsement' , component: EndorsementsComponent,
          data: {breadcrumb: '', path: 'endorsement'}
        },
        {
          path: 'endorsementheader' , component: EndorsementHeaderComponent,
          data: {breadcrumb: '', path: 'endorsementheader'}
        },
        {
          path: 'endorsementfooter' , component: EndorsementFooterComponent,
          data: {breadcrumb: '', path: 'endorsementfooter'}
        },
        {
          path: 'orangecardseries' , component: OrangeCardSeriesComponent ,
          data: {breadcrumb: '', path: 'orangecardseries'}
        },
        {
          path: 'trackorangecard' , component: TrackOrangeCardComponent,
          data: {breadcrumb: '', path: 'trackorangecard'}
        },

      ],
      data: { breadcrumb: 'Home',  path: 'Underwriting' } },
    ]
  }
//]},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdministrationRoutingModule { }
