import { Injectable } from '@angular/core';
import { HttpParams, HttpClient, HttpErrorResponse, HttpHeaders, HttpRequest } from '@angular/common/http';
import { map, catchError, tap, shareReplay } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { RSAENDPOINTConstants } from '../../core/constants/rsa.api.end.points'
import { handleErrorObservable } from '../../shared/utilites/helper';
import { Instrumenttypes } from './../admin-masters/instrument-types/Model/instrumenttypes';
import { Transactions } from './../admin-masters/transactions/model/transactions';
import { PaymentModes } from './../admin-masters/paymentmodes/model/paymentmodes';
import { Statusanalysis } from './../admin-masters/status/model/statusanalysis';
import { FinancialAuthority } from './../admin-masters/financial-authority/model/financial-authority';
import { Glinterface } from 'src/app/administration/admin-masters/gl-interface/model/glinterface';
import { CostCenter } from './../admin-masters/cost-centers/model/costcenter';
import { ChartOfAccount } from '../admin-masters/coa/model/coa.model';
import { TotallingAccount } from '../admin-masters/Totalling-Account/model/totallingaccount';
import { RolesPrivileges } from '../admin-masters/roles-privileges/Model/roles-privileges';
@Injectable({
    providedIn: 'root'
})
export class AdminMastersService {

    constructor(private http: HttpClient) { }

    getAdminUrlsList(): Observable<any> {
        return this.http.get(RSAENDPOINTConstants.FINANCEADMINMASTERS).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAdminUrlsList')));
    }
    getInstrumentTypes(): Observable<Array<Instrumenttypes>> {
        return this.http.get(RSAENDPOINTConstants.INSRUMENTTYPES + '/GetAll').pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getInstrumentTypes')));
    }
    addInstrumentType(params): Observable<Instrumenttypes> {
        return this.http.post<Instrumenttypes>(RSAENDPOINTConstants.INSRUMENTTYPES + '/Post', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('addInstrumentType')));
    }
    updateInstrumentType(params): Observable<Instrumenttypes> {
        return this.http.put<Instrumenttypes>(RSAENDPOINTConstants.INSRUMENTTYPES + '/Put', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updateInstrumentType')));
    }
    deleteInstrumentType(params): Observable<Instrumenttypes> {
        return this.http.delete<Instrumenttypes>(RSAENDPOINTConstants.INSRUMENTTYPES + '/Delete?code=' + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('deleteInstrumentType')));
    }
    gettransactions(): Observable<Array<Transactions>> {
        return this.http.get(RSAENDPOINTConstants.TRANSACTIONS + '/GetAll').pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('gettransactions')));

    }
    updatetransactions(params): Observable<Transactions> {
        return this.http.put<Transactions>(RSAENDPOINTConstants.TRANSACTIONS + '/Put', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updatetransactions')));
    }
    createtransactions(params): Observable<Transactions> {
        return this.http.post<Transactions>(RSAENDPOINTConstants.TRANSACTIONS + '/Post', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createtransactions')));
    }

    deletetransactions(params) {
        return this.http.delete<Transactions>(RSAENDPOINTConstants.TRANSACTIONS + '/Delete?code=' + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('deletetransactions')));
    }
    getPaymentMode(): Observable<Array<PaymentModes>> {
        return this.http.get(RSAENDPOINTConstants.PAYMENTMODES + '/GetAll').pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPaymentMode')));
    }
    createPaymentMode(params): Observable<PaymentModes> {
        return this.http.post<PaymentModes>(RSAENDPOINTConstants.PAYMENTMODES + '/Post', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createPaymentMode')));
    }
    updatePaymentMode(params): Observable<PaymentModes> {
        return this.http.put<PaymentModes>(RSAENDPOINTConstants.PAYMENTMODES + '/Put', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updatePaymentMode')));
    }
    deletePaymentMode(params): Observable<PaymentModes> {
        return this.http.delete<PaymentModes>(RSAENDPOINTConstants.PAYMENTMODES + '/Delete?pmCode=' + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('deletePaymentMode')));
    }
    getCostCenters(): Observable<Array<CostCenter>> {
        return this.http.get(RSAENDPOINTConstants.COSTCENTER + '/GetAll').pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getCostCenters')));
    }
    addCostCenters(params): Observable<CostCenter> {
        return this.http.post<CostCenter>(RSAENDPOINTConstants.COSTCENTER + '/Post', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('addCostCenters')));
    }
    updateCostCenter(params): Observable<CostCenter> {
        return this.http.put<CostCenter>(RSAENDPOINTConstants.COSTCENTER + '/Put', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updateCostCenter')));
    }
    removeCostCenters(params): Observable<CostCenter> {
        return this.http.delete<CostCenter>(RSAENDPOINTConstants.COSTCENTER + '/Delete?ccCode=' + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('removeCostCenters')));
    }
    getCOAList(): Observable<ChartOfAccount[]> {
        let header = new HttpHeaders().append('loccode', '20');
        return this.http.get<ChartOfAccount[]>(RSAENDPOINTConstants.GETCOADETAIL, { headers: header }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getCOAList')));
    }
    getCCList(): Observable<any> {
        let header = new HttpHeaders().append('loccode', '20');
        return this.http.get(RSAENDPOINTConstants.RECEIPTCCFETCH, { headers: header }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getCCList')));
    }
    getTotalingACList(param: any): Observable<any> {
        let header = new HttpHeaders().append('loccode', '20');
        return this.http.get(RSAENDPOINTConstants.GETTTADETAIL + param, { headers: header }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getCCList')));
    }
    saveCOA(param: ChartOfAccount): Observable<any> {
        let header = new HttpHeaders().append('loccode', '20');
        const postdData = JSON.stringify(param);
        return this.http.post(RSAENDPOINTConstants.SAVECOA, postdData, { headers: header }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('saveCOA')));
    }
    updateCOA(param: ChartOfAccount): Observable<any> {
        let header = new HttpHeaders().append('loccode', '20');
        const postdData = JSON.stringify(param);
        return this.http.put(RSAENDPOINTConstants.UPDATECOA, postdData, { headers: header })
            .pipe(
                map(res => res),
                catchError(handleErrorObservable<any>('updateCOA')));
    }
    createGl(params: any) {
        return this.http.post<any>(RSAENDPOINTConstants.CREATEGL, params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createGl')));
    }
    getCountries() {
        return this.http.get<any>(RSAENDPOINTConstants.GLCOUNTRIES).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getCountries')));
    }
    getCostcenter() {
        return this.http.get<any>(RSAENDPOINTConstants.GLCOSTCENTER).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getCostcenter')));
    }
    getRegion(params: any) {
        return this.http.get<any>(RSAENDPOINTConstants.GLREGION + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getRegion')));
    }
    getLocation(params: any) {
        return this.http.get<any>(RSAENDPOINTConstants.GLLOCATION + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getLocation')));
    }
    getTotallingAccount(params: any) {
        return this.http.get<any>(RSAENDPOINTConstants.GLTOTALLINGAC + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getTotallingAccount')));
    }
    getGatCode() {
        return this.http.get<any>(RSAENDPOINTConstants.GLGATCODE).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getGatCode')));
    }

    getglinterface(): Observable<Array<Glinterface>> {
        return this.http.get(RSAENDPOINTConstants.GLINTERFACE + 'GetAll').pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getglinterface')));
    }
    deletegl(params: any) {
        return this.http.delete<any>(RSAENDPOINTConstants.DELETEGL + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('deletegl')));
    }
    getsystemstatus(): Observable<Array<Statusanalysis>> {
        return this.http.get(RSAENDPOINTConstants.SYSTEMSTATUS + '/GetAllStatus').pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getsystemstatus')));
    }
    updatestatus(params): Observable<Statusanalysis> {
        return this.http.put<Statusanalysis>(RSAENDPOINTConstants.SYSTEMSTATUS + '/Update', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updatestatus')));
    }
    createstatus(params): Observable<Statusanalysis> {
        return this.http.post<Statusanalysis>(RSAENDPOINTConstants.SYSTEMSTATUS + '/Create', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createstatus')));
    }
    deletestatus(params): Observable<Statusanalysis> {

        return this.http.delete<Statusanalysis>(RSAENDPOINTConstants.SYSTEMSTATUS + '/Delete' + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('deletestatus')));
    }
    getFinancial(): Observable<Array<FinancialAuthority>> {
        return this.http.get(RSAENDPOINTConstants.GETFINANCIAL).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getFinancial')));
    }
    getDD(): Observable<Array<FinancialAuthority>> {
        return this.http.get(RSAENDPOINTConstants.FADROPDOWNS).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDD')));
    }
    getPT(params: any) {
        return this.http.get<any>(RSAENDPOINTConstants.FAPOLICYTYPE + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPT')));
    }
    createFA(params): Observable<FinancialAuthority> {
        return this.http.post<FinancialAuthority>(RSAENDPOINTConstants.FINANCIALAUTHORITY + 'Create', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createFA')));
    }
    updateFA(params): Observable<FinancialAuthority> {
        return this.http.put<FinancialAuthority>(RSAENDPOINTConstants.FINANCIALAUTHORITY + 'Update', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updateFA')));
    }
    deleteFA(params): Observable<any> {
        var url = RSAENDPOINTConstants.FINANCIALAUTHORITY + 'Delete';
        return this.http.request('delete', url, { body: params }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('deleteFA')));

    }
    //totalling account 
    gettotallingAccount(): Observable<Array<TotallingAccount>> {
        return this.http.get(RSAENDPOINTConstants.TOTALLINGACCOUNT + 'GetAll').pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('gettotallingAccount')));
    }
    getHeaderData(params: any): Observable<Array<TotallingAccount>> {
        return this.http.get(RSAENDPOINTConstants.TOTALLINGACCOUNT + 'GetHdrDtl?Desc=' + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getHeaderData')));
    }
    getTotallingLevel(): Observable<Array<TotallingAccount>> {
        return this.http.get(RSAENDPOINTConstants.GETTOTALLINGLEVEL).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getTotallingLevel')));
    }
    getAccountClass() {
        return this.http.get(RSAENDPOINTConstants.ACCOUNTCLASS).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAccountClass')));
    }
    getDetailView(params: any): Observable<Array<TotallingAccount>> {
        return this.http.get(RSAENDPOINTConstants.TOTALLINGACCOUNT + 'Get?accCode=' + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDetailView')));
    }
    createTotallingAccount(params) {
        return this.http.post(RSAENDPOINTConstants.TOTALLINGACCOUNT + 'POST', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createTotallingAccount')));
    }
    removeTotallingAccount(params): Observable<TotallingAccount> {
        return this.http.delete<TotallingAccount>(RSAENDPOINTConstants.TOTALLINGACCOUNT + '/Delete?segAccCode=' + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('removeTotallingAccount')));
    }
    updateTotallingAccount(params): Observable<TotallingAccount> {
        return this.http.put<TotallingAccount>(RSAENDPOINTConstants.TOTALLINGACCOUNT + '/Put', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updateTotallingAccount')));
    }
    getRowData(params: any): Observable<TotallingAccount> {
        return this.http.get(RSAENDPOINTConstants.TOTALLINGACCOUNT + 'Get?accCode=' + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getRowData')));
    }
    //Roles and privileges
    getRoles(): Observable<Array<RolesPrivileges>> {
        return this.http.get(RSAENDPOINTConstants.ROLE + 'GetAllRoles').pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getRoles')));
    }
    getPrivileges(params: any): Observable<Array<RolesPrivileges>> {
        return this.http.get(RSAENDPOINTConstants.ROLE + 'GetPrivileges?' + 'roleName=' + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPrivileges')));
    }
    editPrivileges(params): Observable<Array<RolesPrivileges>> {
        return this.http.put<Array<RolesPrivileges>>(RSAENDPOINTConstants.ROLE + '/Update', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('editPrivileges')));
    }
    removeRolesAndPrivileges(params1, params2): Observable<RolesPrivileges> {
        return this.http.delete<RolesPrivileges>(RSAENDPOINTConstants.ROLE + 'Delete?roleName=' + params1 + '&modifiedBy=' + params2).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('removeRolesAndPrivileges')));
    }
    addnewRoleAndPrivileges(params): Observable<Array<RolesPrivileges>> {
        return this.http.post<Array<RolesPrivileges>>(RSAENDPOINTConstants.ROLE + 'Create', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('editPrivaddnewRoleAndPrivilegesileges')));
    }
    getAllPrivileges(): Observable<Array<RolesPrivileges>> {
        return this.http.get(RSAENDPOINTConstants.ROLE + 'GetMasterFunctionIds').pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAllPrivileges')));
    }
    //Users
    getAllEmployees(): Observable<any> {
        return this.http.get(RSAENDPOINTConstants.USER + 'GetAllEmployees').pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAllEmployees')));
    }

    getEmployeDetails(param): Observable<any> {
        return this.http.get(RSAENDPOINTConstants.GETEMPLOYEEDETAILS + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAllEmployees')));
    }
    getAllEmployeeEmails(): Observable<any> {
        return this.http.get(RSAENDPOINTConstants.USER + 'GetEmpEmailID').pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAllEmployeeEmails')));
    }
    getAllAgentBrokers(): Observable<any> {
        return this.http.get(RSAENDPOINTConstants.USER + 'GetAgtBrk').pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAllAgentBrokers')));
    }
    getUserEmails(isEmpAgtBrk): Observable<any> {
        return this.http.get(RSAENDPOINTConstants.USER + 'GetUserEmailId?IsEmpAgtBrk=' + isEmpAgtBrk).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getUserEmails')));
    }
    getAllAgentBrokerEmails(): Observable<any> {
        return this.http.get(RSAENDPOINTConstants.USER + 'GetAgtBrkEmailID').pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAllAgentBrokerEmails')));
    }
    getAllUserRoles(searchValue): Observable<any> {
        return this.http.get(RSAENDPOINTConstants.USER + 'GetAllUserRoles?searchValue=' + searchValue).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAllUserRoles')));
    }
    getUserInfoByEmail(emailId, isEmpAgtBrk): Observable<any> {
        return this.http.get(RSAENDPOINTConstants.USER + 'GetEmpAgtBrk?email=' + emailId + '&IsEmpAgtBrk=' + isEmpAgtBrk).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getUserInfoByEmail')));
    }
    getAllUserRolesByEmail(emailId, isEmpAgtBrk): Observable<any> {
        return this.http.get(RSAENDPOINTConstants.USER + 'GetEmpAgtBrkRoles?email=' + emailId + '&IsEmpAgtBrk=' + isEmpAgtBrk).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAllUserRolesByEmail')));
    }
    createNewUser(params): Observable<any> {
        return this.http.post<any>(RSAENDPOINTConstants.USER + 'Create', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createNewUser')));
    }
    updateAgentBroker(params): Observable<any> {
        return this.http.put<any>(RSAENDPOINTConstants.USER + 'UpdateAgtBrk', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updateAgentBroker')));
    }
    updateEmployee(params): Observable<any> {
        return this.http.put<any>(RSAENDPOINTConstants.USER + 'UpdateEmp', params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updateEmployee')));
    }
    removeUser(userId): Observable<any> {
        return this.http.delete<any>(RSAENDPOINTConstants.USER + 'Remove/' + userId).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('removeUser')));
    }
}

