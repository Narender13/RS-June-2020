export class AdminMasters {
    id: number;
    name: string;
    menuid: number;
    path: string;
    active: boolean;
    submenu: Submenu[];
}

export class Submenu {
    id: number;
    name: string;
    menuid: number;
    path: string;
    active: boolean;
    submenu: string;
    data: string;
}
