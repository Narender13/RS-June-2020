
export class EntiteType {
    id: number;
    name: string;
}

