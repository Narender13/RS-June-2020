import { Component, OnInit, ViewChild, AfterViewInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { TypeaheadMatch } from 'ngx-bootstrap';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { formatDate, DatePipe } from '@angular/common';
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { Entitie } from 'src/app/shared/datatable/model/entitie';
import { AgGridEditViewButtonComponent } from '../reports/report-account/report-account-results/ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import { MonthendSetting } from './model/monthend-setting'
import { MonthendService } from './service/monthend.service'
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { ConfirmSetDateComponent } from './confirm-set-date/confirm-set-date.component'
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import {AgCustomDateComponent} from '../../shared/ag-custom-date/ag-custom-date.component';
import {AgCustomSelectComponent} from '../../shared/ag-custom-select/ag-custom-select.component';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import {AgCustomHeaderComponent} from '../../shared/ag-custom-header/ag-custom-header.component';
import { AgGirdCustomDateFilterComponent } from 'src/app/shared/ag-gird-custom-date-filter/ag-gird-custom-date-filter.component';
import { filterByFullDate, isF2Pressed } from 'src/app/shared/utilites/helper';
@Component({
    selector: 'rsa-monthend',
    templateUrl: './monthend.component.html',
    styleUrls: ['./monthend.component.scss']
})
export class MonthendComponent implements OnInit {
    @ViewChild('tabset') tabset: TabsetComponent;
    @ViewChild('agGrid') agGrid: AgGridNg2;
    gridApi;
    gridColumnApi;
    paginationOptions: TextValuePair[] = [];
    monthEndSettingForm: FormGroup;
    monthEndSetting: MonthendSetting;
    underWritingData: any[] = [];
    monthEndData: any[] = [];
    rowData: any[] = [];
    columnDefs: Array<object> = [];
    domLayout;
    detailRowHeight;
    detailCellRendererParams;
    gridConfiguration: GridOptions = {};
    components;
    viewMonthEndSetting: boolean = true;
    updateMonthEndSetting: boolean = true;
    earlyAlertData = [];
    currentModuleName: string;
    isNewRecord: boolean;
    currentEditRow: any;
    suppressClickEdit;
    @Output() selectedRowDetails = new EventEmitter();
    @Output() deSelectCheckbox = new EventEmitter();
    editingRowIndex: number;
    isRowEditing: boolean = false;
    frameworkComponents;
    selectedRowIndex;
    selectedRowData;
    sortOrder;
    startValue : number = 1;
    endValue : number = 1;
    totalRecords : number = 1;
    currentPage : number = 1;
    totalPages : number = 1;
    isDisableFirst : boolean;
    isDisableLast : boolean;
    constructor(private monthendService: MonthendService, private fb: FormBuilder,
        private modalService: BsModalService, public bsModalRef: BsModalRef, public datepipe: DatePipe,
        private alertService: AlertService) {
        this.domLayout = 'autoHeight';
    }

    ngOnInit() {
        this.startValue = 1;
        this.currentPage = 1;
        this.isDisableFirst = true;
        this.isDisableLast = false;
        this.earlyAlertData = [{ value: '24', text: '24 Hours' }, { value: '48', text: '48 Hours' }, { value: '96', text: '96 Hours' }];
        this.createMonthEndSettingForm();
        this.defineColumnDefs();
        this.GetGridOptions();
        this.suppressClickEdit = true;
        this.currentModuleName = 'Accounts';
        this.getAsyncAllMonthEndSetting(this.currentModuleName);
    }
    defineColumnDefs() {
        
        this.columnDefs = [
            {
                headerName: 'Month', field: 'MonthYear', sortable: true, filter: 'agTextColumnFilter', 
                editable: false,
                valueFormatter: (data) => {
                    return this.datepipe.transform(data.value, 'MMMM yyyy');
                }
            },
            {
                headerName: 'Closing Date', field: 'EndDate', sortable: true, filter: 'agDateColumnFilter', 
                editable: true, suppressNavigable: true,
                valueFormatter: (data) => {
                    return this.datepipe.transform(data.value, 'dd/MM/yyyy');
                }, cellEditor: "agInputDate", page: 'monthend', 
                filterParams: {
                    comparator: filterByFullDate(),
                    inRangeInclusive: true
                }
            },
            {
                headerName: 'Opening Date', field: 'StartDate', sortable: true, filter: 'agDateColumnFilter', 
                editable: true,
                valueFormatter: (data) => {
                    return this.datepipe.transform(data.value, 'dd/MM/yyyy');
                }, cellEditor: "agInputDate", page: 'monthend', enableCopyBtn: true,
                filterParams: {
                    comparator: filterByFullDate(),
                    inRangeInclusive: true
                }
            },
            {
                headerName: "Early Alert", field: "EarlyAlert", width: 150, cellEditor: 'agInputSelect',
                editable: true, filter: 'agSetColumnFilter', enableCopyBtn: true, sortable: true
            },
            {
                headerName: 'Action', field: 'value', cellRendererFramework: AgGridEditViewButtonComponent,
                cellRendererParams: {
                    inActoionLink: 'monthEndSetting'
                },
                colId: 'editSaveBtn', filter: 'none', headerClass: 'hidefilter'
            }
        ];
        this.frameworkComponents = { agInputDate: AgCustomDateComponent, agInputSelect: AgCustomSelectComponent, agCustomHeaderComponent: AgCustomHeaderComponent, agDateInput: AgGirdCustomDateFilterComponent };
    }
    createMonthEndSettingForm(): void {
        this.monthEndSettingForm = this.fb.group({
            StartDate: [null, Validators.required],
            EndDate: [null, Validators.required],
            FrmEarlyAlert: [null, Validators.required],
            EmailIds: [null]
        });
    }

    getAsyncAllMonthEndSetting(moduleName): any {
        this.monthendService.getAllMonthEndSetting().subscribe((data) => {
            this.monthEndData = data;
            this.getModuleData(moduleName);
        });
    }

    addNewRow(): any {
        let editedData = this.rowData.filter(data => data.editMode === true && data.isNewRow === true);
        if (editedData.length > 0) {
            this.alertService.warn('Please save/cancel the data which has already added.');
        }
        else {
            let newItem = { DetailTranCode: 0, TranCode:0, Module: this.currentModuleName, EarlyAlert: '', StartDate: '', EndDate: '', isNewRow: true, editMode: true, MonthYear:null };
            this.rowData.push(newItem);
            this.gridConfiguration.api.setRowData(this.rowData);
            this.gridApi.paginationGoToPage(0);
            let newRowIndex = this.sortOrder === 'asc' ? 0 : this.rowData.length - 1;
            this.onParentEditClicked(newItem.DetailTranCode, newRowIndex, this.rowData.length - 1);
        }
    }

    updateAsyncMonthEndSetting(): any {

    }
    setAutoHeight() {
        setTimeout(() => {
            this.gridApi.setDomLayout('autoHeight');
        }, 200);
    }

    ngAfterViewInit() {
        this.fitToCoulmn();
        this.setAutoHeight();
    }

    fitToCoulmn() {
        setTimeout(() => {
            this.gridApi.sizeColumnsToFit();
        }, 200);
    }

    onGridReady(params) {
        console.log(params, 'params');
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        this.gridConfiguration.api.setRowData(this.rowData);
        params.api.paginationGoToPage(0);
        this.fitToCoulmn();
    }

    getModuleData(moduleName) {
        this.currentModuleName = moduleName;
        let editedData = this.rowData.filter(data => data.editMode === true);
        editedData.forEach(element => {
            element.editMode = false;
        });
        let moduleData = this.monthEndData.filter(data => data.Module === moduleName);
        this.rowData = [];
        moduleData.forEach(element => {
            let startDate = typeof element.StartDate === 'string' ? new Date(element.StartDate) : element.StartDate;
            element.MonthYear = startDate;
            this.rowData.push(element);
        });
        this.isRowEditing = false;
        this.selectedRowIndex = null;
        this.selectedRowData = null;
        if (this.gridConfiguration.api) {
            this.gridConfiguration.api.setRowData(this.rowData); // Refresh grid
            if(this.gridApi){
                this.gridApi.paginationGoToPage(0);
            }
        }
        this.totalRecords = this.rowData.length;
    }

    confirmTabSwitch(event){
        const parentElement = event.target.parentElement;
        const target = event.target.parentElement.text;
        if(target){
            if(this.isRowEditing){
                this.alertService.warn('Please save/cancel your changes, before navigation.');
                return false;
            }
            this.currentModuleName = target;
            this.getModuleData(this.currentModuleName);
            setTimeout(() => {
                this.tabset.tabs.forEach(item => {
                  if (item.heading == target) {
                    item.active = true;
                  }
                });
              }, 1);
        }
    }

    GetGridOptions() {
        this.gridConfiguration = <GridOptions>{
            columnDefs: this.columnDefs,
            postProcessPopup: function (params) {
                const ePopup = params.ePopup;
                ePopup.style.top = '14.9838px';
            },
            rowHeight: 40,
            headerHeight: 40,
            pagination: true,
            floatingFiltersHeight: 40,
            paginationPageSize: 20,
            enableRangeSelection: true,
            rowSelection: 'single',
            rowMultiSelectWithClick: true,
            animateRows: true,
            enableColResize: true,
            enableFilter: true,
            suppressContextMenu: true,
            enableSorting: true,
            editType: 'cel',
            // masterDetail: true,
            defaultColDef: {
                enableRowGroup: false,
                enableValue: true,
                suppressMovable: true,
                minWidth: 100,
                menuTabs: ['filterMenuTab', '', ''],
                headerComponent: 'agCustomHeaderComponent',
                headerComponentParams: {
                    menuIcon: 'fa-bars'
                },
                suppressKeyboardEvent: function(params){
                    let keyCode = params.event.keyCode;
                    //disable F2
                    return isF2Pressed(keyCode);
                }
            },
            context: {
                componentParent: this
            },
        };
    }
    onCellValueChanged($event) {

    }

    onCellDoubleClicked($event){
        this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
        let colId = $event.column ? $event.column.colId : null;
        if(this.selectedRowIndex !== null && colId){
            this.allowEditing(this.selectedRowIndex, colId);
            this.selectedRowData =  $event.api.rowModel.rowsToDisplay[$event.rowIndex].data;
        }
    }

    onCellClicked($event) {
        this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
        let colId = $event.column ? $event.column.colId : null;
        if(this.selectedRowIndex !== null && colId){
            this.allowEditing(this.selectedRowIndex, colId);
            this.selectedRowData =  $event.api.rowModel.rowsToDisplay[$event.rowIndex].data;
        }
    }

    onCellFocused($event){
        this.selectedRowIndex = $event.rowIndex !== null ? $event.rowIndex : null;
        let colId = $event.column ? $event.column.colId : null;
        if(this.selectedRowIndex !== null && colId){
            this.allowEditing(this.selectedRowIndex, colId);
            this.selectedRowData =  $event.api.rowModel.rowsToDisplay[$event.rowIndex].data;
        }
    }

    allowEditing(rowIndex, colId){
        if(this.isRowEditing){
            if(rowIndex !== this.editingRowIndex){
                this.suppressClickEdit = true;
                this.gridApi.stopEditing();
            }
            else{
                this.suppressClickEdit = false;
                this.editRowData(rowIndex, colId);
            }
        }
    }

    onParentCheckEdited(){
        let editedData = this.rowData.filter(data => data.editMode === true);
        if (editedData.length > 0) {
            this.alertService.warn('Please save/cancel the data which has already modifed.');
            return true;
        }
        else{
            return false;
        }
    }

    onParentEditClicked(id, rowIndex, dataIndex) {
        let editedData = this.rowData.filter(data => data.editMode === true);
        let currentEditData = this.rowData[dataIndex];
        let allowRowEdit = false;
        if (editedData.length !== 0) {
            if (editedData[0].DetailTranCode === currentEditData.DetailTranCode) {
                allowRowEdit = true;
            }
        }
        else {
            allowRowEdit = true;
        }
        let recEndDate = typeof currentEditData.EndDate === 'string' ? new Date(currentEditData.EndDate) : currentEditData.EndDate;
        if(recEndDate < new Date()){
            this.alertService.warn('Sorry, you can not edit this record');
            return false;
        }
        if (allowRowEdit) {
            this.suppressClickEdit = false;
            let selectedNode = this.gridConfiguration.api.getRowNode(dataIndex);
            rowIndex = selectedNode.rowIndex;
            this.editingRowIndex = rowIndex;
            currentEditData.editMode = true;
            this.currentEditRow = Object.assign({}, currentEditData);
            this.editRowData(rowIndex, 'EndDate');
            return true;
        }
        else {
            this.alertService.warn('Please save/cancel the data which has already modifed.');
            return false;
        }
    }

    onParentCancel(id, rowIndex, dataIndex) {
        this.gridApi.stopEditing();
        let selRowData = this.rowData[dataIndex];
        if (selRowData.isNewRow) {
            this.rowData.splice(dataIndex, 1);
            this.gridConfiguration.api.setRowData(this.rowData);
            this.gridApi.paginationGoToPage(0);
        }
        else {
            this.currentEditRow.editMode = false;
            this.rowData[dataIndex] = this.currentEditRow;
            let selectedNode = this.gridConfiguration.api.getRowNode(dataIndex);
            selectedNode.setData(this.currentEditRow);
        }
        this.suppressClickEdit = true;
        this.isRowEditing = false;
        this.editingRowIndex = null;
        this.currentEditRow = Object.assign({}, null);
        this.selectedRowIndex = null;
        this.selectedRowData = Object.assign({}, null);
    }

    diffMinutes(dt2, dt1) {
        var diff = (dt2.getTime() - dt1.getTime()) / 1000;
        diff /= 60;
        diff /= 60;
        return Math.abs(Math.round(diff));
    }

    getRowData(){
       return this.rowData;
    }

    setRowData(order){
        this.gridConfiguration.api.setRowData(this.rowData);
        this.gridApi.paginationGoToPage(0);
        this.sortOrder = order;
     }

    convertDateToString(dateValue, format){
        return this.datepipe.transform(dateValue, format);
    }
    validateData(currentData) {
        if (currentData.EndDate === "") {
            this.alertService.error('Closing date is empty');
            return 'EndDate';
        }
        if (currentData.StartDate === "") {
            this.alertService.error('Opening date is empty');
            return 'StartDate_1';
        }
        if (currentData.EarlyAlert === "") {
            this.alertService.error('Early Alert is empty');
            return 'EarlyAlert';
        }
        let endDate = typeof currentData.EndDate === 'string' ? new Date(currentData.EndDate) : currentData.EndDate;
        let startDate = typeof currentData.StartDate === 'string' ? new Date(currentData.StartDate) : currentData.StartDate;
        if (startDate > endDate) {
            this.alertService.error('Closing date should be greater than Opening date');
            return 'EndDate';
        }
        let erroredData = this.rowData.filter(data => data.isError === true);
        if(erroredData.length > 0){
            this.alertService.error('Record is already existed for the same month and year');
            return false;
        }
        if (this.diffMinutes(endDate, new Date()) < currentData.EarlyAlert) {
            this.alertService.error('As per the Current System Date and Closing Date, Early Alert Can not be delivered by ' + currentData.EarlyAlert + ' Hours');
            return 'EarlyAlert';
        }
        return '';
    }

    setDates() {
        if(this.selectedRowIndex === null){
            this.alertService.warn('Please select month to set.');
            return false;
        }
        else{
            
            if(this.selectedRowData.EndDate === ''){
                this.alertService.warn('Closing date is empty');
                return false;
            }
            if(this.selectedRowData.StartDate === ''){
                this.alertService.warn('Opening date is empty');
                return false;
            }
            let startDate = typeof this.selectedRowData.StartDate === 'string' ? new Date(this.selectedRowData.StartDate) : this.selectedRowData.StartDate;
            let endDate = typeof this.selectedRowData.EndDate === 'string' ? new Date(this.selectedRowData.EndDate) : this.selectedRowData.EndDate;
            if(endDate < new Date()){
                this.alertService.warn('Sorry, you can not set past date.');
                return false;
            }
            this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
            this.bsModalRef.content.modelTitle = '';
            this.bsModalRef.content.modelBodyContent = 'Are you sure to set for ' + this.convertDateToString(startDate, 'MMMM yyyy');
            this.bsModalRef.content.cancelBtn = RSAMSGConstants.NOTEXT;
            this.bsModalRef.content.actionBtn = RSAMSGConstants.YESTEXT;
            this.bsModalRef.content.valueChange.subscribe((data) => {
            if (data.toString().trim() === 'YES') {
                let setDate = this.convertDateToString(startDate, 'yyyy-MM-ddTHH:mm:ss');
                this.monthendService.setMonthEndDates({StartDate: setDate}).subscribe((dataReturn) => {
                    console.log(dataReturn);
                    if (!dataReturn) {
                        this.alertService.error('something went wrong');
                    }
                    else {
                        const initialState = {
                            StartDate: setDate
                          };
                        this.modalService.show(ConfirmSetDateComponent, { class: 'preview-modal-dailog-send-email', initialState, backdrop: 'static', keyboard: false});
                    }
                },
                errorRturn => {
                    console.log(errorRturn);
                });
            }
            this.bsModalRef.hide();
            });     
        }
    }

    setDataError(rowIndex, isError){
        let selData = this.rowData[rowIndex];
        selData.isError = isError;
    }

    editRowData(rowIndex, column) {
        this.gridApi.startEditingCell({
            rowIndex: rowIndex,
            colKey: column
        });
        this.isRowEditing = true;
    }

    onParentSaveClicked(id, rowIndex, dataIndex) {
        console.log(this.rowData);
        this.gridApi.stopEditing();
        
        let updatedData = this.rowData.filter(data => data.DetailTranCode === id);
        console.log(updatedData);
        if (updatedData.length > 0) {

            let validate = this.validateData(updatedData[0]);
            if (validate === '') {
                updatedData[0].EndDate = this.convertDateToString(updatedData[0].EndDate, 'yyyy-MM-ddTHH:mm:ss');
                updatedData[0].StartDate = this.convertDateToString(updatedData[0].StartDate, 'yyyy-MM-ddTHH:mm:ss');
                if (id === 0) {
                        this.monthendService.addMonthEndSetting(updatedData[0]).subscribe(
                        dataReturn => {
                            if (!dataReturn.success) {
                                dataReturn.errors.forEach(element => {
                                    this.alertService.error(element);
                                });
                                this.editRowData(rowIndex, 'EndDate');
                                return false;
                            }
                            else {
                                this.alertService.success('Data saved successfully.');
                                this.isRowEditing = false;
                                this.suppressClickEdit = true;
                                this.getAsyncAllMonthEndSetting(this.currentModuleName);
                                return true;
                            }
                        },
                        errorRturn => {
                            this.alertService.error('something went wrong');
                            this.editRowData(rowIndex, 'EndDate');
                            return false;
                        }
                    );
                }
                else {
                        this.monthendService.updateMonthEndSetting(updatedData[0]).subscribe(
                        dataReturn => {
                            if (!dataReturn.success) {
                                dataReturn.errors.forEach(element => {
                                    this.alertService.error(element);
                                });
                                this.editRowData(rowIndex, 'EndDate');
                                return false;
                            }
                            else {
                                updatedData[0].editMode = false;
                                this.isRowEditing = false;
                                this.suppressClickEdit = true;
                                this.alertService.success('Data saved successfully.');
                                this.getAsyncAllMonthEndSetting(this.currentModuleName);
                                return true;
                            }
                        },
                        errorRturn => {
                            this.alertService.error('something went wrong');
                            this.editRowData(rowIndex, 'EndDate');
                            return false;
                        }
                    );
                }
            }
            else {
                this.editRowData(rowIndex, validate);
                return false;
            }
        }
    }

    onParentDeleteClicked(id, rowIndex, dataIndex) {
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
        this.bsModalRef.content.valueChange.subscribe((data) => {
            if (data = RSAMSGConstants.BTNPROCEED) {
                this.monthendService.removeMonthEnd(id).subscribe(
                    dataReturn => {
                        if (!dataReturn) {
                            this.alertService.error('something went wrong');
                        }
                        else {
                            this.alertService.success('Data deleted successfully.');
                            this.getAsyncAllMonthEndSetting(this.currentModuleName);
                        }
                    },
                    errorRturn => {
                        console.log(errorRturn);
                    }
                );
            }
        });
    }

    onParentCopySeries(callFrom){   
        let editedData = this.rowData.filter(data => data.editMode === true);
        if(editedData.length > 0){
            this.alertService.warn('Please save/cancel your changes, before navigation.');
            return false;
        }   
        if(this.selectedRowIndex === null){
            this.alertService.warn('Please select month to copy.');
            return false;
        }     
        let startDate = typeof this.selectedRowData.StartDate === 'string' ? new Date(this.selectedRowData.StartDate) : this.selectedRowData.StartDate;
        let nextStartDate = startDate.setMonth(startDate.getMonth() + 1);
        if(nextStartDate < new Date()){
            this.alertService.warn('Sorry, you can not copy to past month.');
            return false;
        }
        else{
            let copyStartDate = callFrom === 'StartDate' ? true : false;   
            this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
            this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
            this.bsModalRef.content.modelBodyContent = 'Are you sure to copy the selected data of ' + this.convertDateToString(this.selectedRowData.StartDate, 'MMMM yyyy') + ' to all upcoming months?';
            this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
            this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
            this.bsModalRef.content.valueChange.subscribe((data) => {
                if (data = RSAMSGConstants.BTNPROCEED) {
                    this.monthendService.copySeries(copyStartDate, !copyStartDate, this.selectedRowData ).subscribe(
                        dataReturn => {
                            if (!dataReturn) {
                                this.alertService.error('something went wrong');
                            }
                            else {
                                this.alertService.success('Copied successfully.');
                                this.getAsyncAllMonthEndSetting(this.currentModuleName);
                            }
                        },
                        errorRturn => {
                            console.log(errorRturn);
                        }
                    );
                }
            });
        }
    }
    onGoToNextPage($event){
        if(!this.onParentCheckEdited())
        {
            this.gridApi.paginationGoToNextPage();
        }
    }
    onGoToPreviousPage($event){
        if(!this.onParentCheckEdited())
        {
        this.gridApi.paginationGoToPreviousPage();
        }
    }
    onGoToFirstPage($event){
        if(!this.onParentCheckEdited())
        {
        this.gridApi.paginationGoToFirstPage();
        }
    }
    onGoToLastPage($event){
        if(!this.onParentCheckEdited())
        {
        this.gridApi.paginationGoToLastPage();
        }
    }
    onPaginationChanged($event){
        if (this.gridApi) {
            this.currentPage = this.gridApi.paginationGetCurrentPage() + 1;
            this.totalPages = this.gridApi.paginationGetTotalPages();
            if(this.currentPage === 1){
                this.isDisableFirst = true;
            }
            else{
                this.isDisableFirst = false;
            }
            if(this.currentPage === this.totalPages){
                this.isDisableLast = true;
            }
            else{
                this.isDisableLast = false;
            }
            this.startValue = ((this.currentPage - 1) * this.gridConfiguration.paginationPageSize) + 1;
            this.endValue = ((this.startValue + this.gridConfiguration.paginationPageSize)- 1) < this.totalRecords ? (this.startValue + this.gridConfiguration.paginationPageSize)- 1 : this.totalRecords;
        }
    }
}

interface TextValuePair {
    id: number;
    value: string;
}
