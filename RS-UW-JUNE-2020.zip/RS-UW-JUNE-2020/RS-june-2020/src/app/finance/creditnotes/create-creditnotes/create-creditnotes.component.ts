
import { Component, OnInit, ViewChild } from '@angular/core';
import { SharedService } from '../../services/shared.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreateCreditNotes } from 'src/app/finance/creditnotes/create-creditnotes/model/create-cn';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { CreateCreditnotesService } from 'src/app/finance/creditnotes/create-creditnotes/service/create-creditnotes.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { CnpreviewComponent } from 'src/app/finance/preview/uae/cnpreview/cnpreview.component';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';

@Component({
  selector: 'rsa-create-creditnotes',
  templateUrl: './create-creditnotes.component.html',
  styleUrls: ['./create-creditnotes.component.scss']
})
export class CreateCreditnotesComponent extends BasevoucherComponent implements OnInit {
  title = 'Credit Note';
  currency = sessionStorage.getItem(RSAConstants.currency);
  errorpayee: boolean;
  errordetail: boolean;
  errorglCode: boolean;
  /* form error-feilds */
  errorbankcodeCheque: boolean;
  level: any = 2;
  errorbankcodeBanktransfer: boolean;
  errorpaayeebanknameCheque: boolean;
  errorpaayeebanknameBanktransfer: boolean;
  errorchequedateCheque: boolean;
  errorchequedateBankT: boolean;
  errorchequedateCreditCard: boolean;
  errorchequenoCheque: boolean;
  errorchequenoCreditCard: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  errorvoucherdate: boolean;
  matchedRecords = [];
  isUploadUnmatched;
  returnValue: any;
  usersReq;
  symbol;
  glAcountHeader: any = [];
  createCreditNotes: CreateCreditNotes;
  clonedCreditNotes: CreateCreditNotes;
  animatedClass = true;
  selectedRowItem: any = [];
  customerName = "";
  ondemandFlag = true;
  ondemandFlagClaim = true;
  TotAcccode;
  glnumber;
  cnVATFlag = false;
  isFromEntity = false;
  selectedRowItemWithVAT: any = [];
  formArray: any;
  cnClaimsFlag: any;
  cnClaimDetails: any;
  headerDescription: string = "";
  isStateClosed: boolean = false;
  defaultTotallingAccCode;
  defaultGLCode;

  @ViewChild('tabset') tabset: TabsetComponent;
  ifnewlyAddedRow = false;
  toggleValueCredit = [];
  errorReportHeader: boolean;
  isUAE: boolean = false;
  isOMAN: boolean = false;
  isReportHeaderFlag: boolean = false;
  constructor(
    protected sharedService: SharedService,
    private fb: FormBuilder,
    protected modalService: BsModalService,
    protected bsModalRef: BsModalRef,
    protected masterDataService: MasterDataService,
    protected utilityClass: UtilityClass,
    protected createPaymentService: CreateCreditnotesService,
    private alertService: AlertService,
  ) {
    super(masterDataService, sharedService, modalService, utilityClass, bsModalRef);
    //super.setMinMaxDate();
  }


  ngOnInit() {
    this.regionCode = sessionStorage.getItem(RSAConstants.regionCode);
    /* super with method is calling from BasevoucherComponent */
    this.createVoucherForm(this.paymentMode);
    this.isClaimFlag = this.cnClaimsFlag;
    this.isVATFlag = this.cnVATFlag;
    this.isCreditNote = true;
    this.rowClaimData = this.selectedRowItem;
    this.isOnDemandFlag = !this.isAllLob && !this.isFromEntity
      && this.ondemandFlag && !(this.isPaymentFromEntity || this.claimPayment || this.cnVATFlag || this.cnClaimsFlag);
    this.isReportHeaderFlag = (this.isOnDemandFlag || this.isFromEntity) && !this.isAllLob;
    console.log(this.isOnDemandFlag, 'this.isOnDemandFlag');
    this.isUAE = (sessionStorage.getItem('regioncode') == '2') ? true : false;
    this.isOMAN = sessionStorage.getItem(RSAConstants.regionCode) == '3' ? true : false;
    if (this.isUAE && this.isReportHeaderFlag) {
      super.getAllReportHeadersCreditNote();
      this.mainVoucherForm.controls['Title'].setValidators([Validators.required]);
      this.mainVoucherForm.controls['Title'].updateValueAndValidity();
    }
    else {
      this.mainVoucherForm.controls['Title'].setValue("CREDIT NOTE");
    }
    super.getEntityDefaultData();
    super.getAllBranchData();
    super.getAllCostCenterData({ ev: null, index: 0, flag: true });
    super.getAllTotallingData(true);
    super.getAllProjData();
    super.getAllDeptData();
    super.getAllMasterData2();
    this.fieldStatusChanges();
    super.getModelPreviousClose();
    super.closeModel();
    super.getAllTranData();
    this.symbol = (sessionStorage.getItem('symbol'));
    // super.setMinMaxDate();
    super.GetAccountingDates(new Date());

    // this.getDetailsArrayFormGroup();
    super.getModelPreviousClose();
    super.getAllgetLookupBanksData();
    console.log(this.selectedRowItem, 'selectedRowItem');
    super.getTotalingHeaderDataCnDn();
    this.getDetailsArrayFormGroup();
    let totcode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    if (this.selectedRowItem && this.selectedRowItem.length > 0) {
      // tslint:disable-next-line:max-line-length
      totcode = totcode ? totcode : this.selectedRowItem[0].CNTotallingAcc ? this.selectedRowItem[0].CNTotallingAcc : this.selectedRowItem[0].TotallingAccCode;
    }
    super.getGlAccountHeaderDataCnDn(totcode);
    this.getGlAccountHeader();

    
    setTimeout(() => {
      if (this.TotAcccode) {
        this.defaultTotallingAccCode = this.TotAcccode;
        this.defaultGLCode = this.glnumber;
      }
      this.setTotAccTransCreCredit();
    }, 0);
    if (this.headerDescription != null && this.headerDescription != undefined && this.headerDescription != '') {
      this.setHeaderDescription(this.headerDescription);
    }
    this.setAmountWithdecimal();
    if (this.cnClaimsFlag) {
      this.setClaimDetails();
    }
    /*multiple GL Code*/
    this.updateFromSession();
    this.sharedService.getMessage().subscribe(val => {
      if (val == 'ClearState') {
        if (sessionStorage.getItem('CNStateExists') != null) {
          sessionStorage.setItem('CNStateExists', 'false');
          this.isStateClosed = true;
        }
      }
      if(val == 'close'){
        this.isStateClosed = true;
        this.mainVoucherForm.markAsPristine();
        this.mainVoucherForm.markAsUntouched();
      }
    });
    this.updateVoucherNo();
  }
  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    if (!this.isStateClosed) {
      this.addToSession();
    }
  }

  updateVoucherNo() {
    let isFromDraft = sessionStorage.getItem('isFromDraft');
    if (isFromDraft == 'true') {
      let voucherDetail = JSON.parse(sessionStorage.getItem('VoucherDetail'));
      this.prevPreviewID = voucherDetail.VoucherNo;
    }
  }
  addToSession() {
    if (this.mainVoucherForm.dirty || this.mainVoucherForm.touched) {
      let voucherDate = this.mainVoucherForm['controls'].VoucherDate.value;
      let totallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
      let glCode = this.mainVoucherForm.controls.accountInfo['controls'].GLCode.value;
      let description = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
      let payeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
      var commonData = { VoucherDate: voucherDate, TotallingAccCode: totallingAccCode, GLCode: glCode, Description: description, PayeeName: payeeName, PrevReceipt: this.prevPreviewID }
      sessionStorage.setItem('CommonCNData', JSON.stringify(commonData));
      sessionStorage.setItem('CNStateExists', 'true');
    }
    this.updateRows();
  }

  updateRows() {
    let formarray = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    if (formarray.controls.length > 0) {
      let voucherDetail = JSON.parse(sessionStorage.getItem('VoucherDetail'));
      voucherDetail.SelectedRows = [];
      formarray.controls.forEach(ctrl => {
        let rowClone = Object.assign({}, ctrl.value);
        rowClone.Amount = (rowClone.Amount) ? rowClone.Amount : 0;
        rowClone.Amount = +(rowClone.Amount);
        rowClone.CNTotallingAcc = rowClone.TotallingAccCode;
        rowClone.DNTotallingAcc = rowClone.TotallingAccCode;
        rowClone.CNVATAmount = 0;
        rowClone.SerialNumber = rowClone.SerialNo;
        voucherDetail.SelectedRows.push(rowClone);
      });
      if(voucherDetail.SelectedRows && voucherDetail.SelectedRows.length>0){
        voucherDetail.SelectedRows.map((item, index) => {
          if (item.TypeCode == 2) {
            item.Amount = item.Amount * -1;
            item.CNVATAmount = (item.CNVATAmount) * -1;
          } else {
            item.Amount = item.Amount;
            item.CNVATAmount = item.CNVATAmount;
          }
        });
      }
      sessionStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
      this.sharedService.sendMessage('RefreshRows');
    }
  }
  updateFromSession() {
    let entityCNStateExists = sessionStorage.getItem('CNStateExists');
    if (entityCNStateExists == 'true') {
      let itemDetail = sessionStorage.getItem('CommonCNData');
      if (itemDetail) {
        this.mainVoucherForm.markAsDirty();
        let commonData = JSON.parse(itemDetail);
        // if(commonData.VoucherDate) this.mainVoucherForm['controls'].VoucherDate.setValue(new DatePipe('en-US').transform(new Date(commonData.VoucherDate), 'dd/MM/yyyy'));
        if (commonData.TotallingAccCode) {
          this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(commonData.TotallingAccCode);
          setTimeout(() => {
            super.getGlAccountHeaderDataCnDn(commonData.TotallingAccCode);

          }, 500);
          if (commonData.GLCode) this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(commonData.GLCode);
        }
        if (commonData.Description) this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(commonData.Description);
        if (commonData.PayeeName) this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.setValue(commonData.PayeeName);
        if (commonData.PrevReceipt) { this.prevPreviewID = commonData.PrevReceipt; }
      }
    }

  }
  checkIsformDirtyCN() {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = 'Proceed') {
        this.modalService.hide(1);
        this.sharedService.sendMessage('close');
        this.isStateClosed = true;
        if (sessionStorage.getItem('EntityCNStateExists') != null) {
          sessionStorage.setItem('EntityCNStateExists', 'false');
        }
      }
    });
  }
  /*End*/
  /* create entiti form */
  createVoucherForm(param): void {
    this.mainVoucherForm = null;

    this.mainVoucherForm = this.fb.group({
      VoucherDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      CreditNoteDate: [],
      ApprovedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      ArabicDescription: [],
      Amount: [],
      CountryCode: [sessionStorage.getItem(RSAConstants.countrycode)],
      CustomerID: [],
      CustCode: [],
      ModifiedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      ModifiedDate: [],
      PreparedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ReprintNo: [],
      PrintDate: [],
      RefreshDate: [],
      PostedDate: [],
      PreprintNo: [],
      Title: [],
      RegionCode: [sessionStorage.getItem(RSAConstants.regionCode)],
      Approvers: this.fb.array([]),
      detailInfo: this.fb.group({
        PayeeName: [this.customerName, Validators.required],
        EnglishDescription: ['', Validators.required],
      }),
      accountInfo: this.fb.group({
        LocationCode: [sessionStorage.getItem('locationcode')],
        CostCenterCode: [sessionStorage.getItem('costcentre')],
        TotallingAccCode: [sessionStorage.getItem(RSAConstants.totallingaccount)],
        GLCode: [sessionStorage.getItem(RSAConstants.defaultGLCode), Validators.required],
      }),
      VoucherDetails: this.fb.array([]),
      TaxPointDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]
    });
  }

  setHeaderDescription(desc) {
    this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(desc);
  }
  setTotAccTransCreCredit() {
    // getTotallingDetailData
    if (this.selectedRowItem.length) {
      this.selectedRowItem.map((item, index) => {
        const control = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index];
        if (control) {
          super.getTotallingDetailData({ index: index, flag: true });
        }
      });
    }
  }

  // getSelectedRowValue() {
  //   this.selectedRowItem.forEach((element, index) => {
  //     if ((index % 2 === 0)) {
  //       this.toggleValueCredit[index] = element.Amount < 0 ? false : true;
  //       console.log(this.toggleValueCredit, 'this.toggleValueCredit');
  //       // this.setFormArrayCTRLDefaultValue('IsDebitEntry', index, this.toggleValueCredit);
  //     }
  //   });
  // }

  getGLdataCnDn(ev) {
    const totcode = ev.ev;
    console.log(totcode, 'totcode');
    super.getGlAccountHeaderDataCnDn(totcode, true);
  }

  getDetailsArrayFormGroup() {
    const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    if (!this.ondemandFlag) {
      this.mainVoucherForm.controls['CustomerID'].setValue(this.selectedRowItem[0].CustomerID);
      this.mainVoucherForm.controls['CustCode'].setValue(this.selectedRowItem[0].CustCode);

      console.log(this.selectedRowItem, 'this.selectedRowItem');
      this.selectedRowItem.map((item, index) => {
        // super.getAllCostCenterData({ ev: null, index: index, flag: false });
        let group = this.createDetailsArrayGroup();
        item['IsDebitEntry'] = (item.Amount < 0) ? false : true;
        group.patchValue(item.item);
        group.get("newAddedRow").setValue(false);
        group.get('IsDebitEntry').setValue((parseFloat(group.get("Amount").value) < 0) ? false : true);

        control.push(group);
      });
    }
    if (!this.ondemandFlagClaim) {
      this.mainVoucherForm.controls['CustomerID'].setValue(this.selectedRowItem[0].CustomerID);
      this.mainVoucherForm.controls['CustCode'].setValue(this.selectedRowItem[0].CustCode);
      this.mainVoucherForm.controls['accountInfo'].get('TotallingAccCode').setValue(this.selectedRowItem[0].CNTotallingAcc ? this.selectedRowItem[0].CNTotallingAcc : this.selectedRowItem[0].TotallingAccCode);
      this.mainVoucherForm.controls['accountInfo'].get('GLCode').setValue(this.selectedRowItem[0].CNGLCode ? this.selectedRowItem[0].CNGLCode : this.selectedRowItem[0].GLCode);


      console.log(this.selectedRowItem, 'this.selectedRowItem');
      this.selectedRowItem.map((item, index) => {
        let group = this.createDetailsArrayGroup();
        if (this.cnClaimsFlag) {
          group.addControl('EntryTypeCode', new FormControl());
          group.addControl('TypeCode', new FormControl());
        }
        item['IsDebitEntry'] = (item.Amount < 0) ? false : true;
        console.log(item, 'item');
        // if ((index % 2 === 0)) {
        //   this.toggleValueCredit[index] = item.Amount < 0 ? false : true;
        //   console.log(this.toggleValueCredit, 'this.toggleValueCredit');
        // }
        group.patchValue(item);
        group.get("newAddedRow").setValue(false);
        // if (!item.isVatRow) {
        //   if (item.CNVATAmount !== 0) {
        //     //this.toggleValueCredit[index] = item.Amount < 0 ? false : true;
        //     control.push(group);
        //   }
        // } else  {
        // this.toggleValueCredit[index] = item.Amount < 0 ? false : true;
        control.push(group);
        // }
        const ctrl = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
        ctrl.controls.forEach((val, i) => {
          const amount = val.get('Amount').value;
          this.toggleValueCredit[i] = amount < 0 ? false : true;
        });
      });
    } else {
      if (this.isAllLob) {
        this.mainVoucherForm.controls['CustomerID'].setValue(this.selectedRowItem[0].CustomerID);
        this.mainVoucherForm.controls['CustCode'].setValue(this.selectedRowItem[0].CustCode);
        this.selectedRowItem.map((item, index) => {
          console.log(item, 'item for allLob');
          const group = this.createDetailsArrayGroup();
          item['IsDebitEntry'] = (item.Amount < 0) ? false : true;
          group.patchValue(item);
          group.get('Description').setValue(item.ConcDescription);
          group.get('GLCodeDesc').setValue(item.GLCodeDesc);
          group.get("newAddedRow").setValue(false);
          control.push(group);
          // const ccentre = this.getFromFormArrayControlVal('CostCenterCode', index);
          // console.log(ccentre, 'ccentre>>>>>>>>>');
          // const totcode = this.getFromFormArrayControlVal('TotallingAccCode', index);
          // console.log(totcode, 'totcode>>>>>>>>>');
          // const param = 'totAccCode=' + totcode +
          //   '&ccCode=' + ccentre;
          // console.log('param-GL', param);
          // this.masterDataService.getDetailGlAccount(param).subscribe(
          //   dataReturn => {
          //     this.glaccount[index] = dataReturn;
          //     console.log(this.glaccount, 'dataretrun>>>>>>>>>> all lob');
          //   });
          // this.setFormArrayCTRLDefaultValue('GLCode', index, item.GLCode);
          // this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, 'hhhhhhhhhhhhh')
          // const GLCodeDesc = this.getFromFormArrayControlVal('GLCodeDesc', index);
          // console.log(GLCodeDesc, 'GLCodeDesc>>>>>>>>>');

        });

      }
      else {
        const group = this.createDetailsArrayGroup();
        if (this.TotAcccode && this.glnumber) {
          group.get('TotallingAccCode').setValue(this.TotAcccode);
          group.get('GLCode').setValue(this.glnumber);
        } else {
          group.get('GLCode').setValue('');
          group.get('GLCodeDesc').setValue('');
          group.get('TotallingAccCode').setValue('');
        }
        control.push(group);
      }
    }
  }
  setAmountWithdecimal() {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach(item => {
      const amountVal = parseFloat(item.get('Amount').value);
      item.get('Amount').setValue(amountVal);
    });
  }

  getActualAmountSum(processFlag) {
    let total = 0;
    let amt = 0;
    let actualamt = 0;
    let flagtoggle = false;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {

      if (this.getFromFormArrayControlVal('Amount', index) != undefined
        && this.getFromFormArrayControlVal('Amount', index) != null) {
        flagtoggle = this.getFromFormArrayControlVal('IsDebitEntry', index);
        const Camt = parseFloat(this.getFromFormArrayControlVal('Amount', index));
        amt = Math.abs(Camt);
        if (processFlag == 'CN') {
          actualamt = (flagtoggle) ? amt : (amt * -1);
        }
        console.log('flagtoggle:' + flagtoggle + ',amt:' + amt + ',actualamt:' + actualamt);
        total = total + actualamt;
      }
    });
    this.totalAmount = total;
  }


  setDebitEntry(ev) {
    console.log(ev, '<<<<key');
    const actualData = Number(ev.data.controls['Amount'].value);
    if (actualData === 0 || actualData === undefined) {
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': ev.event.target.checked ? RSAMSGConstants.EMPTYAMOUNTCHECK : RSAMSGConstants.EMPTYAMOUNTCHECKCR,
        'btnaction': RSAMSGConstants.OKTEXT
      });
      ev.event.target.checked = !ev.event.target.checked;

    }
    this.setFormArrayCTRLDefaultValue(ev.isDebit, ev.index, ev.event.target.checked);
    this.getActualAmountSum('CN');
    if (this.totalAmount < 0) {
      ev.event.target.checked = true;
      this.setFormArrayCTRLDefaultValue(ev.isDebit, ev.index, true);
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.DEBITEXCEEDMSG,
        'btnaction': RSAMSGConstants.OKTEXT
      });
    }
    this.getActualAmountSum('CN');
  }

  /* form array for recept details */
  createDetailsArrayGroup(): FormGroup {
    return this.fb.group({
      Amount: [0, Validators.required],
      AnalysisCode: [],
      CostCenterCode: [sessionStorage.getItem('costcentre')],
      ClaimID: [],
      ClassCode: [],
      CauseOfLossCode: [],
      CounterPartyRef: [],
      CountryCode: [sessionStorage.getItem(RSAConstants.countrycode)],
      Description: [],
      DocumentCode: [],
      EntityID: [],
      GLCode: [sessionStorage.getItem(RSAConstants.defaultGLCode), Validators.required],
      GLCodeDesc: [sessionStorage.getItem(RSAConstants.defaultGLCodeDesc), Validators.required],
      LocationCode: [sessionStorage.getItem('locationcode')],
      LocationDesc: [sessionStorage.getItem(RSAConstants.locationdesc)],
      ModifiedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      ModifiedDate: [],
      NatureOfLossCode: [],
      PolicyID: [],
      PolicyYear: [],
      Endt_ID: [],
      PreparedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [],
      RefTransactionID: [],
      RefTransactionSerialNo: [],
      RefTransactionType: [10],
      RegionCode: [sessionStorage.getItem(RSAConstants.regionCode)],
      TotallingAccCode: [sessionStorage.getItem(RSAConstants.totallingaccount), Validators.required],
      PolicyType: [],
      newAddedRow: true,
      VoucherNo: [],
      CNVATAmount: [],
      IsDebitEntry: [true],
      SerialNo: [],
      DepartmentCode: [],
      Department: [],
      SrNO: []
    });
  }

  /* set receipt mode and set default values   */
  setReceiptMode(val, paymentname) {
    this.mainVoucherForm.controls['PaymentMode'].setValue(val);
    this.paymentMode = val;
    this.paymentname = paymentname;
    this.createVoucherForm(this.paymentMode);
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;
    if (this.paymentMode == 1) {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1210');
    } else {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(sessionStorage.getItem(RSAConstants.totallingaccount));
      // this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue(sessionStorage.getItem(RSAConstants.defaultBankCode));
    }
    this.setdefaultHeaderData();
    this.fieldStatusChanges();
    super.GetAccountingDates(new Date());
  }


  /* using req fields and update status  */
  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );
    if (this.voucherdate != null && this.voucherdate !== undefined) {
      this.voucherdate.statusChanges.subscribe(
        status => {
          this.errorvoucherdate = (status === 'INVALID');
        }
      );
    }
    this.cshreportHeaders.statusChanges.subscribe(
      status => {
        this.errorReportHeader = (status === 'INVALID');
      }
    );

  }

  /* clear all errors after reset   */
  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    this.errorvoucherdate = false;
    this.errorReportHeader = false;
    // this.errorglCode = false;
  }

  /* get the controls of each fields   */
  get voucherdate() { return this.mainVoucherForm.get('VoucherDate'); }
  get cshpayeename() { return this.mainVoucherForm.controls.detailInfo['controls'].PayeeName; }
  get cshdetails() { return this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription; }
  get cshreportHeaders() { return this.mainVoucherForm['controls'].Title; }
  // get glCodeValue() { return this.mainVoucherForm.controls.detailInfo['controls'].GLCode; }


  /* set Description in receptdetails desc   */
  setDescription() {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[0].get('Description').setValue(this.cshdetails.value);
  }


  /* add receipt in review screen */
  addReceipt(len) {
    this.ifnewlyAddedRow = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('newAddedRow').value;
    const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    const CurrentAmount = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('Amount').value;
    if (CurrentAmount != null && CurrentAmount != 0 && CurrentAmount != undefined) {
      this.isNewRow = true;
      control.push(this.createDetailsArrayGroup());
      this.setFormArrayCTRLDefaultValue('GLCode', len, '');
      this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '');
      this.setFormArrayCTRLDefaultValue('TotallingAccCode', len, '');
      // this.setFormArrayCTRLDefaultValue('TotallingAccCode', len, 1110);
      // super.getTotallingDetailData({ index: len, flag: true, isOndemand: true });
      // this.dtltotallingacc[len] = this.cachedDtlTot;
      this.setOndemandTotallingDetail({ index: len });
      this.glaccount[len] = [];
    } else {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      return false;
    }
  }

  preSubmission(precessFlag) {
    let flagtoggle = true;
    let amt = 0;
    this.clonedCreditNotes = Object.assign({}, this.createCreditNotes);
    this.clonedCreditNotes.CreditNoteDetail.forEach((element, index) => {
      flagtoggle = element.IsDebitEntry;
      if (!flagtoggle && precessFlag == 'CN') {
        element.Amount = (Math.abs(element.Amount)) * -1;
      }
      if (this.cnVATFlag && !this.ifnewlyAddedRow) {
        if ((index % 2) !== 0) {
          console.log(element, 'element');
          element.CNVATAmount = element.Amount;
          element.Amount = element.Amount;
        }
        element['CNVATflag'] = true;
      }
    });
    console.log('this.clonedDebitNotes', this.clonedCreditNotes);
  }


  reSetForm(params) {
    const param = params.defaultParam;
    /*set default value here and reset */
    if (param == 1) {
      super.validateAllFormFields(this.mainVoucherForm);
      this.mainVoucherForm.controls.VoucherDate.setValue([new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]);
      this.mainVoucherForm.controls.GLCode.setValue(sessionStorage.getItem(RSAConstants.defaultGLCode));
      this.mainVoucherForm.controls.GLCodeDesc.setValue(sessionStorage.getItem(RSAConstants.defaultGLCodeDesc));
      this.clearerrors();
    } else if (param == 2) {
      this.mainVoucherForm.controls['VoucherDetails'].reset();
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('LocationCode').setValue([sessionStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([sessionStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(sessionStorage.getItem(RSAConstants.totallingaccount));
        item.get('GLCode').setValue(sessionStorage.getItem(RSAConstants.defaultGLCode));
        item.get('GLCodeDesc').setValue(sessionStorage.getItem(RSAConstants.defaultGLCodeDesc));
      });
      this.getSum();
    }
    super.GetAccountingDates(new Date());
  }
  updateCreditVoucherValues(dataReturn: any) {
    this.mainVoucherForm.addControl('CreditNoteNo', new FormControl(dataReturn.CreditNoteNo));
  }
  /* update  form values to create-receipt objects*/
  createCNFormValues() {
    this.createCreditNotes = new CreateCreditNotes();
    const mainFormFieldArray = ['VoucherDate', 'ApprovedBy', 'ArabicDescription',
      'CountryCode', 'CustomerID', 'CustCode', 'ModifiedDate', 'ModifiedBy', 'PostedDate',
      'PreparedBy', 'PreparedDate', 'PreprintNo', 'PrintDate', 'RefreshDate', 'RegionCode', 'Title',
      'Approvers'];
    mainFormFieldArray.forEach(item => {
      console.log('this.item****', item);
      this.createCreditNotes[item] = this.mainVoucherForm.controls[item].value;

    });
    if (this.mainVoucherForm.controls['CreditNoteNo']) {
      this.prevPreviewID = this.mainVoucherForm.controls['CreditNoteNo'].value;
    }
    this.createCreditNotes.CreditNoteDate = this.createCreditNotes.VoucherDate;
    this.createCreditNotes.PreparedDate = this.mainVoucherForm.controls['VoucherDate'].value;
    this.createCreditNotes.LocationCode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    this.createCreditNotes.CostCenterCode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    this.createCreditNotes.TotallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    this.createCreditNotes.GLCode = this.mainVoucherForm.controls.accountInfo['controls'].GLCode.value;
    this.createCreditNotes.PayeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
    this.createCreditNotes.EnglishDescription = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
    this.createCreditNotes.CreditNoteDetail = this.mainVoucherForm.controls['VoucherDetails'].value;
    this.createCreditNotes.TaxPointDate = this.mainVoucherForm.controls['TaxPointDate'].value;
    console.log('this.createCreditNotes****', this.createCreditNotes);
    // this.preSubmission('CN');
  }

  /* create-receipt form*/
  submitForm() {
    console.log(this.totalAmount, 'totalAmount');
    super.validateDetailInfo();
    this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;
    this.errorvoucherdate = this.voucherdate.invalid;
    if (this.isUAE && this.isReportHeaderFlag) {
      this.errorReportHeader = this.cshreportHeaders.invalid;
    }
    //  this.errorglCode = this.glCodeValue.invalid;
    if (!(!this.errorpayee && !this.errordetail && !this.errorglCode && !this.errorvoucherdate)) {
      return false;
    }
    if (this.amountLimitCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTEXCEEDMSG);
      return false;
    }
    if (this.amountZeroCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTZEROCHECK);
      return false;
    }
    if (this.glerrorcount > 0) {
      return false;
    }
    if (this.totaccrorcount > 0) {
      return false;
    }
    if (this.submitError > 0) {
      this.alertService.warn(RSAMSGConstants.REQFIELDERROR);
      return false;
    }
    // this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
    //  this.approverusers.length > 0);
    if (this.totalAmount > 0) {
      // no approver required for UAE
      // if (!(sessionStorage.getItem(RSAConstants.regionCode) == '2')) {
      // if (this.totalAmount > 99999 && !this.usersReq) {
      //   return false;
      // }
      // }

      this.createCNFormValues();
      console.log(this.createCreditNotes, ' this.createCreditNotes');
      if (this.prevPreviewID == null || this.prevPreviewID == undefined) {
        this.prevPreviewID = 0;

        // this.clonedCreditNotes['CreditNoteNo'] = this.prevPreviewID;
      }
      this.createCreditNotes['CreditNoteNo'] = this.prevPreviewID;
      this.preSubmission('CN');

      if (this.cnVATFlag) {
        this.clonedCreditNotes['CNVATflag'] = true;
      }
      if (this.isUAE && this.errorReportHeader && this.isReportHeaderFlag) {
        return false;
      }
      //console.log("\ncreate credit note"+JSON.stringify(this.clonedCreditNotes));
      this.createPaymentService.createCreditNote(JSON.stringify(this.clonedCreditNotes)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.updateCreditVoucherValues(dataReturn);
          this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = true;
          this.previewFlag = true;
          this.bsModalRef = this.modalService.show(CnpreviewComponent, {
            class: 'preview-modal-dailog',
            keyboard: false,
            ignoreBackdropClick: true
          });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
          this.bsModalRef.content.backdrop = true;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
    if (this.totalAmount <= 0) {
      this.alertService.warn(RSAMSGConstants.DEBITEXCEEDMSG);
    }
  }


  getGlAccountHeader() {
    let totcode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    let totAccCode = totcode ? totcode : this.selectedRowItem[0].CNTotallingAcc ? this.selectedRowItem[0].CNTotallingAcc : this.selectedRowItem[0].TotallingAccCode;
    const param = 'totAccCode=' + totAccCode +
      '&ccCode=' + this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    this.masterDataService.getDetailGlAccount(param).subscribe(data => {
      this.glAcountHeader = data;
      let glCode: any;
      if (this.selectedRowItem && this.selectedRowItem.length > 0) {
        // tslint:disable-next-line:max-line-length
        glCode = (this.selectedRowItem && this.selectedRowItem[0].CNGLCode) ? this.selectedRowItem[0].CNGLCode : this.selectedRowItem[0].GLCode;
      } else {
        glCode = this.glnumber;
      }
      const isGLCodeAvailableFromRow = data.filter(item => item.Code == glCode);
      if (isGLCodeAvailableFromRow.length > 0) {
        this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(isGLCodeAvailableFromRow[0].Code);
      } else {
        this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(data[0].Code);
      }
    });
  }

  setGLHdrHiddenValue(ev) {
    console.log(ev);
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue(ev.item.Code);
  }
  clearHdrGLCode(ev) {
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue('');
    this.mainVoucherForm.controls.detailInfo['controls'].GLCodeDesc.setValue('');
  }
  setClaimDetails() {
    this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(this.cnClaimDetails);
  }
  changeTaxPointDate() {
    if (this.mainVoucherForm.controls['TaxPointDate'].value) {
      const TaxPointDate = new Date(this.mainVoucherForm.controls['TaxPointDate'].value);
      this.mainVoucherForm.controls['TaxPointDate'].setValue(new DatePipe('en-US').transform(TaxPointDate, 'dd/MM/yyyy'));
    }
  }
}

