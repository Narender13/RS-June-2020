
import { Component, OnInit, ViewChild, TemplateRef, OnDestroy, SimpleChanges } from '@angular/core';
import { SharedService } from '../services/shared.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { CreateReceipt } from '../search/model/create-receipt';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreateCreditNotes } from 'src/app/finance/creditnotes/create-creditnotes/model/create-cn';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { CreateCreditnotesService } from 'src/app/finance/creditnotes/create-creditnotes/service/create-creditnotes.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { CnpreviewComponent } from 'src/app/finance/preview/uae/cnpreview/cnpreview.component';
import { Location } from '@angular/common';
import { CreateJvService } from 'src/app/finance/createjv/service/create-jv.service';
import { CreateJvModel } from 'src/app/finance/createjv/model/create-jv';
import { JvpreviewComponent } from '../preview/uae/jvpreview/jvpreview.component';
import { BatchUploadService } from 'src/app/finance/search/service/batch-upload.service';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
import { element } from '@angular/core/src/render3/instructions';



@Component({
  selector: 'rsa-createjv',
  templateUrl: './createjv.component.html',
  styleUrls: ['./createjv.component.scss']
})
export class CreatejvComponent extends BasevoucherComponent implements OnInit, OnDestroy {
  titleJV = 'Journal Voucher';
  currency = sessionStorage.getItem(RSAConstants.currency);
  onFlagClaim = false;

  setDecimalpoint: any;
  // errorpayee: boolean; 
  errordetail: boolean;
  errortotallingCode: boolean;
  //errorglCode: boolean;
  /* form error-feilds */
  errorbankcodeCheque: boolean;
  level: any = 2;
  errorbankcodeBanktransfer: boolean;
  errorpaayeebanknameCheque: boolean;
  errorpaayeebanknameBanktransfer: boolean;
  errorchequedateCheque: boolean;
  errorchequedateBankT: boolean;
  errorchequedateCreditCard: boolean;
  errorchequenoCheque: boolean;
  errorchequenoCreditCard: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  matchedRecords = [];
  isUploadUnmatched;
  detaildescription = [];
  detaildescriptionJv = [];
  jvoucherno: any;
  approverror: boolean = false;
  clonedJV: any;
  returnValue: any;
  unApproved;
  usersReq;
  symbol;
  glAcountHeader: any = [];
  createCreditNotes: CreateCreditNotes;
  animatedClass = true;
  selectedRowItem: any = [];
  fromDraft: boolean = false;
  isRowPaymentEntityClaim: any;
  jvEditData: any = [];
  customerName: string = "";
  ondemandFlag: boolean = true;
  formArray: any;

  isBatch = false;
  createJvModel: CreateJvModel;
  tamtcr;
  tamtdr;
  ifUploadSuccess = true;
  totalAmount;
  bulkuploadData;
  JVuploadData = [];
  totalUploadedRecords;
  jvImportvoucherDetails: FormGroup;
  bsModalRef2: BsModalRef;
  ondemandFlagClaim = true;
  isStateClosed: boolean = false;
  newindex: 0;
  grAdj: any;
  glerrorcount = 0;
  totAccerrorcount = 0;
  receiptAccountingDate: any;
  isRowPaymentEntity = false;
  @ViewChild('tabset') tabset: TabsetComponent;
  deleteRecordFromJv = false;
  submitError: any;
  isclaimJV = false;
  headerDescription = '';
  isUAE;
  isOMAN;
  constructor(
    protected sharedService: SharedService,
    private fb: FormBuilder,
    protected modalService: BsModalService,
    protected bsModalRef: BsModalRef,
    protected masterDataService: MasterDataService,
    protected utilityClass: UtilityClass,
    protected createPaymentService: CreateCreditnotesService,
    private alertService: AlertService,
    private location: Location,
    protected createJvService: CreateJvService,
    private batchUploadService: BatchUploadService,

  ) {
    super(masterDataService, sharedService, modalService, utilityClass, bsModalRef);
    //super.setMinMaxDate();
  }

  ngOnInit() {

    const precison = +(sessionStorage.getItem('precisionDecimalValue'));
    if (precison) {
      this.setDecimalpoint = {
        precision: precison,
      };
    }

    /* super with method is calling from BasevoucherComponent */
    this.createVoucherForm(this.paymentMode);  // can i use paymentMode = 2;
    this.isRowDraftJV = this.fromDraft;
    this.isclaimJV = this.isclaimJV;
    this.isJV = true;
    this.isClaimRowPaymentEntity = this.isRowPaymentEntityClaim;
    this.jvBaseVoucherEditData = this.jvEditData;
    this.isOnDemandFlag = !this.isAllLob && this.ondemandFlag && !this.isclaimJV;
    super.getAllBranchData();
    console.log('Branch DATA>>>>>>>>>>>>>>>>>>>>>>>>>>>', this.branchdata);
    super.getEntityDefaultData();
    if (!this.isclaimJV) {
      super.getAllCostCenterData({ ev: null, index: 0, flag: true });
    }
    // super.getAllTotallingData(true);
    super.getAllDeptData();
    super.getAllProjData();
    super.getAllMasterData2();
    this.fieldStatusChanges();
    super.closeModel();
    super.getAllTranData();
    this.symbol = (sessionStorage.getItem('symbol'));
    //super.setMinMaxDate();
    super.GetAccountingDates(this.jvEditData.VoucherDate);
    this.getGlAccountHeader();
    this.getDetailsArrayFormGroup();
    super.getModelPreviousClose();
    this.createjvImportvoucherDetailsForm();
    this.ValidateDrCrAmtjvImport();
    /* mutiple GL Code starts*/
    this.updateFromSession();
    this.sharedService.getMessage().subscribe(val => {
      if (val == 'ClearState') {
        if (sessionStorage.getItem('EntityJVStateExists') != null) {
          sessionStorage.setItem('EntityJVStateExists', 'false');
          this.isStateClosed = true
        }
      }
      if (val == 'close') {
        this.isStateClosed = true;
        this.mainVoucherForm.markAsPristine();
        this.mainVoucherForm.markAsUntouched();
      }
    });
    if (this.headerDescription != null && this.headerDescription != undefined && this.headerDescription != '') {
      this.setHeaderDescription(this.headerDescription);
    }
    this.isUAE = sessionStorage.getItem(RSAConstants.regionCode) == '2' ? true : false;
    this.isOMAN = sessionStorage.getItem(RSAConstants.regionCode) == '3' ? true : false;
  }

  ngOnChanges(changes: SimpleChanges) {
    const precison = +(sessionStorage.getItem('precisionDecimalValue'));
    if (precison) {
      this.setDecimalpoint = {
        precision: precison,
      };
    }
  }

  ngOnDestroy() {
    if (!this.isStateClosed) {
      this.addToSession();
    }
  }
  addToSession() {
    let voucherDate = this.mainVoucherForm.controls.VoucherDate.value;
    let description = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
    // tslint:disable-next-line:max-line-length
    var commonData = { VoucherDate: voucherDate, IsBatch: false, Description: description, Approverusers: this.approverusers, prevPreviewID: this.prevPreviewID }
    sessionStorage.setItem('EntityJVData', JSON.stringify(commonData));
    sessionStorage.setItem('EntityJVStateExists', 'true');
  }
  updateFromSession() {
    let entityJVStateExists = sessionStorage.getItem('EntityJVStateExists');
    if (entityJVStateExists == 'true') {
      let itemDetail = sessionStorage.getItem('EntityJVData');
      if (itemDetail) {
        this.mainVoucherForm.markAsDirty();
        let commonData = JSON.parse(itemDetail);
        this.prevPreviewID = commonData.prevPreviewID;
        if (commonData.VoucherDate) this.mainVoucherForm.controls.VoucherDate.setValue(commonData.VoucherDate);
        if (commonData.Description) this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(commonData.Description)
        this.isBatch = commonData.IsBatch;
        if (commonData.Approverusers) this.approverusers = commonData.Approverusers;
      }
    }

  }
  checkIsformDirtyJV() {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = 'Proceed') {
        this.modalService.hide(1);
        this.sharedService.sendMessage('close');
        this.isStateClosed = true;
      }
    });
  }
  /*mutiple GL code end*/
  createjvImportvoucherDetailsForm() {
    this.jvImportvoucherDetails = this.createDetailsArrayGroup();
    console.log("previous call....");
  }
  /* create entiti form */
  createVoucherForm(param): void {
    this.mainVoucherForm = null;

    this.mainVoucherForm = this.fb.group({
      VoucherDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ApprovedBy: [],
      ArabicDescription: [],
      AmountCr: [''],
      AmountDr: [''],
      CountryCode: [sessionStorage.getItem(RSAConstants.countrycode)],
      CustomerID: [],
      CustCode: [],
      ModifiedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      ModifiedDate: [],
      PreparedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [],
      ReprintNo: [],
      PrintDate: [],
      RefreshDate: [],
      PostedDate: [],
      PreprintNo: [],
      Title: ['Journal Voucher'],
      RegionCode: [sessionStorage.getItem(RSAConstants.regionCode)],
      Approvers: this.fb.array([]),
      detailInfo: this.fb.group({
        // PayeeName: [this.customerName, Validators.required],
        EnglishDescription: ['', Validators.required],
        // GLCode: [4, Validators.required],
        //GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required],
      }),
      accountInfo: this.fb.group({
        LocationCode: [sessionStorage.getItem('locationcode')],
        CostCenterCode: [sessionStorage.getItem(RSAConstants.costcentre)],
        TotallingAccCode: [sessionStorage.getItem(RSAConstants.totallingaccount)]
      }),
      VoucherDetails: this.fb.array([])
    });
  }
  goPrevious() {
    this.isBatch = true;
    this.ifUploadSuccess = true;
    this.sharedService.sendMessage(true);
  }


  doPatchDescrptionFields() {
    const formarray = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']);
    formarray.controls.map((item, index) => {
      item.get('DescriptionDtl').setValue(this.previewDataDtl[index].RefTransactionID);
    });
  }
  setHeaderDescription(desc) {
    this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(desc);
  }

  getDetailsArrayFormGroup() {
    let control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    this.detaildescription = this.jvEditData.Description;
    this.jvoucherno = this.selectedRowItem.VoucherNo;
    if (this.fromDraft) {
      this.selectedRowItem = this.jvEditData.JournalVoucherDetails;
      this.ondemandFlag = false;
    }
    if (this.isclaimJV) {
      this.jvBaseVoucherRowData = this.selectedRowItem;
    }
    console.log('this.selectedRowItem>>>>' + this.jvEditData);
    if (!this.ondemandFlag) {

      this.selectedRowItem.map((item, index) => {
        super.getAllCostCenterData({ ev: null, index: index, flag: false });
        let group = this.createDetailsArrayGroup();
        console.log('item.item>>', item);
        group.patchValue(item);
        group.get("TotallingAccCode").setValue(item.TotallingAccCode);
        group.get("newAddedRow").setValue(false);
        if (this.fromDraft) {
          group.get('AmountDr').setValue(Math.abs(item.AmountDr));
          group.get('AmountCr').setValue(Math.abs(item.AmountCr));
          group.patchValue({ 'Department': item.DepartmentCode });
        }
        control.push(group);
        this.getSumDr();
        this.getSumCr();
        super.getTotallingDetailData({ index: index, flag: false });
      });
      this.setDescription();
    }
    //ondemandFlagClaim
    if (!this.fromDraft) {
      if (!this.ondemandFlagClaim) {
        this.selectedRowItem.map((item, index) => {
          super.getAllCostCenterData({ ev: null, index: index, flag: false });
          let group = this.createDetailsArrayGroup();
          console.log('item.item from entity>>', item.Description);
          if (this.isAllLob || this.isRowPaymentEntity) {
            this.detaildescriptionJv[index] = item.ConcDescription;
          } else {
            this.detaildescriptionJv[index] = item.Description;
          }
          group.patchValue(item);
          if (item.Amt) {
            let amountType = item.Amt;
            if (amountType.indexOf('Dr') !== -1) {
              group.get('AmountDr').setValue(item.Amount);
            } else {
              group.get('AmountCr').setValue(Math.abs(item.Amount));
            }
          }
          group.get("newAddedRow").setValue(false);
          control.push(group);
          this.getSumDr();
          this.getSumCr();
        });
        const formarray = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']);
        formarray.controls.map((item, index) => {
          console.log(this.detaildescriptionJv[index], 'this.detaildescriptionJv[index]');
          item.get('DescriptionDtl').setValue(this.detaildescriptionJv[index]);
        });
      }
    }
    if (!this.onFlagClaim && !this.fromDraft && !this.isRowPaymentEntity) {
      // alert('anki');
      console.log(this.selectedRowItem, ' this.selectedRowItem');
      this.selectedRowItem.map((item, index) => {
        super.getAllCostCenterData({ ev: null, index: index, flag: false });
        let group = this.createDetailsArrayGroup();
        console.log('item.item>>', item);
        group.patchValue(item);
        if (item.Amt) {
          let amountType = item.Amt;
          if (amountType.indexOf('Dr') !== -1) {
            group.get('AmountDr').setValue(item.Amount);
          } else {
            group.get('AmountCr').setValue(Math.abs(item.Amount));
          }
        }
        // group.get("TotallingAccCode").setValue(item.TotallingAccCode);
        group.get("newAddedRow").setValue(false);
        control.push(group);
        this.getSumDr();
        this.getSumCr();
      });
    }
    // set adjustment or ondemand values
    if (this.ondemandFlag) {
      if (!this.fromDraft) {
        if (!this.ondemandFlagClaim || this.isclaimJV) {
          // code for adjustment / additional row data mapping
          this.newindex = this.selectedRowItem.length;
          super.getAllCostCenterData({ ev: null, index: this.newindex, flag: false });
          let groupAdjRow = this.createDetailsArrayGroup();
          //  groupAdjRow.addControl('adjustmentRow', new FormControl(''));
          groupAdjRow.get("newAddedRow").setValue(false);
          console.log(groupAdjRow, '  groupAdjRow');
          if (this.isRowPaymentEntity && this.selectedRowItem.length > 0) {
            groupAdjRow.get('CostCenterCode').setValue(this.selectedRowItem[0].CostCenterCode);
          }
          control.push(groupAdjRow);
          /* groupAdjRow.get("TotallingAccCode").setValue(' ');
           groupAdjRow.get("GLCode").setValue('');
           groupAdjRow.get("GLCodeDesc").setValue('');
          groupAdjRow.controls[newindex].TotallingAccCode.reset('');*/
        } else {
          this.isRowJV = true;
          const group = this.createDetailsArrayGroup();
          group.get('GLCode').setValue('');
          group.get('GLCodeDesc').setValue('');
          group.get('TotallingAccCode').setValue('');
          control.push(group);
        }
      } else {
        console.log('anki-jerr');
        control.push(this.createDetailsArrayGroup());
      }
    }


  }


  /* form array for recept details */
  createDetailsArrayGroup(): FormGroup {
    return this.fb.group({
      //Amount: ['0.00', Validators.required],
      AmountCr: [(0).toFixed(2), Validators.required],
      AmountDr: [(0).toFixed(2), Validators.required],
      AnalysisCode: [],
      CostCenterCode: [sessionStorage.getItem('costcentre')],
      ClaimID: [],
      ClassCode: [],
      CauseOfLossCode: [],
      CounterPartyRef: [],
      CountryCode: [sessionStorage.getItem(RSAConstants.countrycode)],
      DescriptionDtl: [],
      DocumentCode: [],
      //EntityID:[],

      GLCode: [null, Validators.required],
      GLCodeDesc: [null, Validators.required],
      LocationCode: [sessionStorage.getItem('locationcode')],
      LocationDesc: [sessionStorage.getItem(RSAConstants.locationdesc)],
      ModifiedBy: [],
      ModifiedDate: [],
      NatureOfLossCode: [],
      PolicyID: [],
      PolicyYear: [],
      PreparedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [],
      RefTransactionID: [],
      RefTransactionSerialNo: [],
      RefTransactionType: [6],
      RegionCode: [sessionStorage.getItem('regioncode')],
      TotallingAccCode: ['', Validators.required],
      PolicyType: [],
      newAddedRow: true,
      VoucherNo: [],
      SerialNo: [],
      PolicyNo: [],
      RefPolicyNo: [],
      ArrangementId: [],
      ArrangementType: [],
      ArrangementLayerId: [],
      Endt_ID: [],
      SLCode: [],
      Department: []
    });
  }

  /* set receipt mode and set default values   */
  setReceiptMode(val, paymentname) {
    this.mainVoucherForm.controls['PaymentMode'].setValue(val);
    this.paymentMode = val;
    this.paymentname = paymentname;
    this.createVoucherForm(this.paymentMode);
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;
    if (this.paymentMode == 1) {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1210');
    } else {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(sessionStorage.getItem(RSAConstants.totallingaccount));
      this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue(sessionStorage.getItem(RSAConstants.defaultBankCode));
    }
    this.setdefaultHeaderData();
    this.fieldStatusChanges();
    super.GetAccountingDates(this.jvEditData.VoucherDate);
  }


  /* using req fields and update status  */
  fieldStatusChanges() {
    this.clearerrors();
    // this.cshpayeename.statusChanges.subscribe(
    //   status => {
    //     this.errorpayee = (status === 'INVALID');
    //     console.log(this.errorpayee, 'his.errorpayee');
    //   }
    // );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );

    // this.glCodeValue.statusChanges.subscribe(
    //   status => {
    //     this.errorglCode = (status === 'INVALID');       
    //   }
    // );    

  }

  /* clear all errors after reset   */
  clearerrors() {
    // this.errorpayee = false;
    this.errordetail = false;
    // this.errorglCode = false;
  }

  /* get the controls of each fields   */
  //get cshpayeename() { return this.mainVoucherForm.controls.detailInfo['controls'].PayeeName; }
  get cshdetails() { return this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription; }
  //get glCodeValue() { return this.mainVoucherForm.controls.detailInfo['controls'].GLCode; }
  get totCodeValue() { return this.mainVoucherForm.controls.VoucherDetails['controls'].TotallingAccCode; }

  /* set Description in receptdetails desc   */
  setDescription() {
    console.log('this.detaildescription', this.detaildescription);
    this.cshdetails.setValue(this.detaildescription);
    console.log(this.cshdetails.value, 'value');
  }


  /* add receipt in review screen */
  addJournalDetail(len) {

    const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    let validValue = this.validationCrDrValues(len);
    //   console.log(validValue,"va");
    if (validValue) {
      control.push(this.createDetailsArrayGroup());
      this.setFormArrayCTRLDefaultValue('GLCode', len, '');
      this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '');
      this.setFormArrayCTRLDefaultValue('TotallingAccCode', len, '');
      console.log('this.cachedDtlTot++++++++++', this.cachedDtlTot);
      // this.dtltotallingacc[len] = this.cachedDtlTot;
      this.setOndemandTotallingDetail({ index: len });
      // this.glaccount[len] = this.cachedGL;
      this.glaccount[len] = [];
      // this.setFormArrayCTRLDefaultValue('newAddedRow',len,true);

    }


  }

  validationCrDrValues(len) {

    var isValid = true;
    let CurrentAmountCr = 0;
    let CurrentAmountDr = 0;
    let errorcount = 0;
    let errorcntzerochk = 0;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {
      CurrentAmountCr = element.get('AmountCr').value;
      CurrentAmountDr = element.get('AmountDr').value;
      if (CurrentAmountDr > 0 && CurrentAmountCr > 0) {
        errorcount++;
        //element.get('AmountDr').updateValueAndValidity();
        //element.get('AmountDr').markAsTouched();
      }
      if (CurrentAmountDr == 0 && CurrentAmountCr == 0) {
        errorcntzerochk++;
      }

    });
    if (errorcount > 0) {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONDRCR;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      return false;
    }
    else if (errorcntzerochk > 0) {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      return false;
    }
    return true;

  }




  reSetForm(params) {
    const param = params.defaultParam;
    /*set default value here and reset */
    if (param == 1) {
      super.validateAllFormFields(this.mainVoucherForm);
      this.mainVoucherForm.controls.VoucherDate.setValue([new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]);
      this.mainVoucherForm.controls.GLCode.setValue(sessionStorage.getItem(RSAConstants.defaultGLCode));
      this.mainVoucherForm.controls.GLCodeDesc.setValue(sessionStorage.getItem(RSAConstants.defaultGLCodeDesc));
      this.clearerrors();
    } else if (param == 2) {
      this.mainVoucherForm.controls['VoucherDetails'].reset();
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('LocationCode').setValue([sessionStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([sessionStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(6);
        item.get('TotallingAccCode').setValue(sessionStorage.getItem(RSAConstants.totallingaccount));
        item.get('GLCode').setValue(sessionStorage.getItem(RSAConstants.defaultGLCode));
        item.get('GLCodeDesc').setValue(sessionStorage.getItem(RSAConstants.defaultGLCodeDesc));
        item.get('AmountCr').setValue(0);
        item.get('AmountDr').setValue(0);
      });
      //this.getSum();
      this.getSumDr();
      this.getSumCr();
    }
    super.GetAccountingDates(this.jvEditData.VoucherDate);
  }

  getSumDr() {
    this.totaldr = 0;
    const ctrldr = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    ctrldr.controls.forEach(val => {
      const amtdr = (val.get('AmountDr').value == null || isNaN(val.get('AmountDr').value) ||
        val.get('AmountDr').value == '') ? 0 : val.get('AmountDr').value;
      this.totaldr += Math.abs(parseFloat(amtdr));
    });
    this.totaldr = (isNaN(this.totaldr)) ? 0 : this.totaldr;
  }

  getSumCr() {
    this.totalcr = 0;
    const ctrlcr = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    ctrlcr.controls.forEach(val => {
      const amtcr = (val.get('AmountCr').value == null || isNaN(val.get('AmountCr').value) ||
        val.get('AmountCr').value == '') ? 0 : val.get('AmountCr').value;
      this.totalcr += Math.abs(parseFloat(amtcr));
    });
    this.totalcr = (isNaN(this.totalcr)) ? 0 : this.totalcr;


  }

  updateJVVoucherValues(dataReturn: any) {
    this.mainVoucherForm.addControl('VoucherNo', new FormControl(dataReturn.VoucherNo));
  }
  /* update  form values to create-receipt objects*/
  createJVFormValues() {
    //this.createCreditNotes = new CreateCreditNotes();
    this.createJvModel = new CreateJvModel();
    const mainFormFieldArray = ['VoucherDate', 'ApprovedBy', 'ArabicDescription',
      'CountryCode', 'CustomerID', 'CustCode', 'ModifiedDate', 'ModifiedBy', 'PostedDate',
      'PreparedBy', 'PreparedDate', 'PreprintNo', 'PrintDate', 'RefreshDate', 'RegionCode', 'Title',
      'Approvers'];
    mainFormFieldArray.forEach(item => {
      // console.log('this.item****', item);
      this.createJvModel[item] = this.mainVoucherForm.controls[item].value;

    });
    if (this.mainVoucherForm.controls['VoucherNo']) {
      this.prevPreviewID = this.mainVoucherForm.controls['VoucherNo'].value;
    }
    this.createJvModel.LocationCode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    this.createJvModel.CostCenterCode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    this.createJvModel.TotallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    // this.createJvModel.PayeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
    this.createJvModel.EnglishDescription = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
    this.createJvModel.JournalVoucherDetails = this.mainVoucherForm.controls['VoucherDetails'].value;
    // console.log('this.createJvModel****', this.createJvModel);
    //console.log('this.createJvModel lenght ****', this.createJvModel.JournalVoucherDetails.length);



  }
  validateDetailInfoJv() {
    this.glerrorcount = 0;
    this.totAccerrorcount = 0;
    this.submitError = 0;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map((item, index) => {

      item.get('GLCode').updateValueAndValidity();
      item.get('AmountDr').updateValueAndValidity();
      item.get('AmountCr').updateValueAndValidity();
      item.get('TotallingAccCode').updateValueAndValidity();
      //item.get('Amount').markAsTouched();
      item.get('GLCode').markAsTouched();
      item.get('AmountDr').markAsTouched();
      item.get('AmountCr').markAsTouched();
      item.get('TotallingAccCode').markAsTouched();
      if (item.get('GLCode').value == null || item.get('GLCode').value == undefined || item.get('GLCode').value == '') {
        this.glerrorcount = this.glerrorcount + 1;
      }
      // tslint:disable-next-line:triple-equals
      // tslint:disable-next-line:max-line-length
      if (item.get('TotallingAccCode').value == null || item.get('TotallingAccCode').value == undefined || item.get('TotallingAccCode').value == '') {
        this.totAccerrorcount = this.totAccerrorcount + 1;
      }

      if (item.get('GLCode').value !== null &&
        item.get('GLCode').value !== undefined &&
        item.get('GLCode').value !== "") {
        let selGlAccntId = parseInt(item.get('GLCode').value);
        let lstGLAccnt = this.glaccount[index].filter(data => data.Code === selGlAccntId);
        if (lstGLAccnt.length > 0) {
          let selGLAccnt = lstGLAccnt[0];
          if (item.get('Department').value == null
            || item.get('Department').value == undefined
            || item.get('Department').value == "") {
            if (selGLAccnt.Department) {
              this.setReqValFormArrayControl('Department', index, selGLAccnt.Department ? true : false);
              this.submitError++;
            }
          }
          if (item.get('AnalysisCode').value == null ||
            item.get('AnalysisCode').value == undefined ||
            item.get('AnalysisCode').value == "") {
            if (selGLAccnt.ProjectIndicator) {
              this.setReqValFormArrayControl('AnalysisCode', index, selGLAccnt.ProjectIndicator ? true : false);
              this.submitError++;
            }
          }
        }
      }
      if (item.get('AnalysisCode').invalid) {
        this.submitError++;
      }
      if (item.get('Department').invalid) {
        this.submitError++;
      }
    });
  }


  presubmission(objModel) {
    let flagtoggle = true;
    let amt = 0;
    this.clonedJV = Object.assign({}, objModel);
    console.log('this.clonedJV', this.clonedJV);
    this.clonedJV.JournalVoucherDetails.forEach((element, index) => {
      const amtdr = element.AmountDr;
      const amtcr = element.AmountCr;

      element.AmountDr = (Math.abs(amtdr));
      element.AmountCr = (Math.abs(amtcr) * -1);

    });
    console.log('this.clonedJV', this.clonedJV);
  }

  /* create-receipt form*/

  submitForm() {
    console.log(this.isBatch, 'isbath');
    if (this.isBatch && !this.ifUploadSuccess) {
      this.submitPreviewForJvImport();
    } else {
      //this.errorpayee = this.cshpayeename.invalid;
      this.errordetail = this.cshdetails.invalid;
      //this.errorglCode = this.glCodeValue.invalid;
      if (!(!this.errordetail)) {
        return false;
      }
      this.validateDetailInfoJv();
      if (this.glerrorcount > 0) {
        return false;
      }
      if (this.totAccerrorcount > 0) {
        return false;
      }
      if (this.submitError > 0) {
        this.alertService.warn(RSAMSGConstants.REQFIELDERROR);
        return false;
      }
      // this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
      //   this.approverusers.length > 0);
      // this.approverror = false;
      // if (!this.usersReq) {
      //   this.approverror = true;
      //   return false;
      // }
      // if (this.totalcr > 0 || this.totaldr > 0) {
      // if ((this.totalcr > 99999 || this.totaldr > 99999) && !this.usersReq) {
      //   return false;
      // }
      this.createJVFormValues();
      if (this.validationCrDrValues(this.createJvModel.JournalVoucherDetails.length)) {
        if (this.totalcr <= 0) {
          this.alertService.warn(RSAMSGConstants.AMOUNTNOTMATCHED);
          return false;
        }
        else if (this.totaldr <= 0) {
          this.alertService.warn(RSAMSGConstants.AMOUNTNOTMATCHED);
          return false;
        }
        else if (this.totalcr != this.totaldr) {
          //this.alertService.warn(RSAMSGConstants.AMOUNTNOTMATCHED);
          this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
          this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTNOTMATCHED;
          this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
          return false;

        }
      }
      else
        return false;

      console.log(this.createJvModel, ' this.createJvModel');
      if (this.prevPreviewID == null || this.prevPreviewID == undefined)
        this.prevPreviewID = 0;
      if (this.fromDraft) {
        this.prevPreviewID = this.jvEditData.VoucherNo;
      }


      this.createJvModel["VoucherNo"] = this.prevPreviewID;
      this.presubmission(this.createJvModel);
      this.clonedJV.IsRejectandEdit = true;

      this.createJvService.createJv(JSON.stringify(this.clonedJV)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.updateJVVoucherValues(dataReturn);
          console.log(this.returnValue, "testing222..");
          //this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = true;
          this.previewFlag = true;
          this.bsModalRef = this.modalService.show(JvpreviewComponent, {
            class: 'preview-modal-dailog',
            keyboard: false,
            ignoreBackdropClick: true
          });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalamountcr = this.totalcr;
          this.bsModalRef.content.totalamountdr = this.totaldr;
          this.bsModalRef.content.backdrop = true;
          this.bsModalRef.content.unApproved = this.unApproved;
          // this.bsModalRef.content.clonedJV = this.clonedJV;

        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
    // }
  } //submition
  submitPreviewForJvImport() {
    if (this.JVuploadData.length > 1) {
      this.calculateTotalDrAmtCrAmt();
      if (Math.abs(this.totalcr) != Math.abs(this.totaldr)) {
        this.alertService.error(RSAMSGConstants.AMOUNTNOTMATCHED);
        return false;
      } else {
        this.createJVFormValues();
        if (this.prevPreviewID == null || this.prevPreviewID == undefined) {
          this.prevPreviewID = 0;
        }

        if (this.prevPreviewID > 0) {
          this.returnValue.JournalVoucherDetails.forEach((item, index) => {
            if (index < this.JVuploadData.length) {
              this.JVuploadData[index]['SerialNo'] = item.SerialNo;
            }
          });
        }
        this.createJvModel["VoucherNo"] = this.prevPreviewID;
        this.createJvModel.JournalVoucherDetails = this.JVuploadData;
        /* started added for user approval */
        // this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
        //   this.approverusers.length > 0);
        // this.approverror = false;
        // if (!this.usersReq) {
        //   this.approverror = true;
        //   return false;
        // }
        /* ended added for user approval */

        this.createJvModel['IsRejectandEdit'] = true;

        this.createJvService.createJv(JSON.stringify(this.createJvModel)).subscribe(
          dataReturn => {
            this.returnValue = dataReturn;
            console.log(this.returnValue, "testing222..");
            this.returnValue['approverlist'] = this.approverusers;
            this.returnValue['ondemand'] = true;
            this.previewFlag = true;
            this.bsModalRef = this.modalService.show(JvpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
            this.bsModalRef.content.data = this.returnValue;
            this.bsModalRef.content.totalamountcr = this.totalcr;
            this.bsModalRef.content.totalamountdr = this.totaldr;
            this.bsModalRef.content.backdrop = true;
          },
          errorRturn => {
            this.errorMsg = errorRturn;
          }
        );
      }
    } else {
      this.alertService.warn('Amount is not tallied');
    }
  }



  getGlAccountHeader() {
    const param = 'totAccCode=' + sessionStorage.getItem(RSAConstants.totallingaccount) +
      '&ccCode=' + sessionStorage.getItem('costcentre');
    this.masterDataService.getDetailGlAccount(param).subscribe(data => {
      this.glAcountHeader = data;
      console.log('gldata', data);
    });
  }

  setGLHdrHiddenValue(ev) {
    console.log(ev);
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue(ev.item.Code);
  }
  clearHdrGLCode(ev) {
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue('');
    this.mainVoucherForm.controls.detailInfo['controls'].GLCodeDesc.setValue('');
  }

  /* check single or batch upload */
  checkSingleOrbatch(e) {
    this.isBatch = !this.isBatch;
    console.log(this.isBatch);
    if (this.isBatch) {
      this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue('');
      const statCtrl = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription;
     statCtrl.setValidators([Validators.required]);
     statCtrl.updateValueAndValidity();
      this.mainVoucherForm.controls['VoucherDetails'].reset();
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('LocationCode').setValue([sessionStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([sessionStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(6);
        item.get('TotallingAccCode').setValue(null);
        item.get('GLCode').setValue(null);
        item.get('GLCodeDesc').setValue('');
        item.get('AmountCr').setValue(0);
        item.get('AmountDr').setValue(0);
        item.get('AnalysisCode').setValue(null);
        item.get('Department').setValue(null);
        item.get('AnalysisCode').clearValidators();
        item.get('Department').clearValidators();
      });
      this.getSumDr();
      this.getSumCr();
      super.GetAccountingDates(this.jvEditData.VoucherDate);
    } else {
      this.totaldr = 0;
      this.totalcr = 0;
      this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue('');
      const statCtrl = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription;
      statCtrl.setValidators([Validators.required]);
      statCtrl.updateValueAndValidity();
      this.errordetail = false;
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('LocationCode').setValue(sessionStorage.getItem('locationcode'));
        item.get('CostCenterCode').setValue(sessionStorage.getItem('costcentre'));
      });

    }
  }

  reCancel() {
    this.bsModalRef.hide();
    this.modalService.hide(1);
    this.sharedService.sendMessage("close");
  }
  goBackOp() {
    this.location.back();
  }

  uploadXlsFile(e) {
    if(this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value.trim()==''){
      this.alertService.warn('Please enter details and upload the file again');
      return false;
    }
    if (e.target.files && e.target.files.length) {
      if (e.target.files[0].name.indexOf('.xlsx') === -1) {
        this.alertService.warn(`Please upload a valid Excel file.`);
        return false;
      } else {
        if (e.target.files[0].name.length > 50) {
          this.alertService.warn(`File name cannot exceed 50 characters.`);
          return false;
        }
      }
      const selectedFiles = e.target.files;
      console.log(selectedFiles.item(0), 'selectedFiles.item(0)');
      const VoucherDate = new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy');
      const param = {
        'VoucherDate': VoucherDate,
        'Type': 2,
        'GLCode': sessionStorage.getItem(RSAConstants.defaultGLCode),
        'TotallingAccCode': sessionStorage.getItem(RSAConstants.totallingaccount)
      };
      this.batchUploadService.uploadJvBatchFile(selectedFiles.item(0), param,
      ).subscribe((data) => {
        console.log(data, '>>>>>>>>>>>data from API');
        //setting the value agin to 
        let itemDetail = sessionStorage.getItem('EntityJVData');
        if (itemDetail) {
          // alert("item detail"+JSON.stringify(itemDetail));
          let commonData = JSON.parse(itemDetail);
          commonData.IsBatch = false;
          //   var commonData = { VoucherDate: voucherDate, IsBatch: this.isBatch, Description: description, Approverusers: this.approverusers }
          sessionStorage.setItem('EntityJVData', JSON.stringify(commonData));
        }
        //end for setting again
        if (data.Message) {
          this.alertService.error(data.Message);
          return false;
        }
        this.ifUploadSuccess = false;
        this.sharedService.sendMessage(this.ifUploadSuccess);
        this.totalUploadedRecords = data.length;
        this.JVuploadData = data.map((item) => {
          return this.setJVPreviewData(item);
        });
        console.log(this.JVuploadData);
        if (this.JVuploadData.length > 0) {
          this.calculateTotalDrAmtCrAmt();
        }

      });
    } else {
      console.log('Error while file selection');
    }
  }


  clearXlsFile(e: any) {
    e.target.value = '';
  }
  setJVPreviewData(item) {
    const details = {} as any;
    details['AmountCr'] = String(item.Sum_Amount).charAt(0) == '-' ? item.Sum_Amount : 0;
    details['AmountDr'] = String(item.Sum_Amount).charAt(0) !== '-' ? item.Sum_Amount : 0;
    details['AnalysisCode'] = null;
    details['ArrangementId'] = null;
    details['ArrangementLayerId'] = null;
    details['ArrangementType'] = null;
    details['CauseOfLossCode'] = null;
    details['ClaimID'] = null;
    details['ClassCode'] = item.class_code;
    details['CostCenterCode'] = sessionStorage.getItem('costcentre');
    details['CounterPartyRef'] = null;
    details['CountryCode'] = sessionStorage.getItem(RSAConstants.countrycode);
    details['Department'] = null;
    details['DescriptionDtl'] = item.Dtl_Description || '-';
    // details['Description'] = item.Dtl_Description || '-';
    details['DocumentCode'] = null;
    details['Endt_ID'] = null;
    details['GLCode'] = item.GlCode;
    details['GLCodeDesc'] = sessionStorage.getItem(RSAConstants.defaultGLCodeDesc);
    details['LocationCode'] = sessionStorage.getItem('locationcode');
    details['LocationDesc'] = item.Loc_code;
    details['ModifiedBy'] = '';
    details['ModifiedDate'] = null;
    details['NatureOfLossCode'] = '';
    details['PolicyID'] = null;
    details['PolicyNo'] = item.Policy_No || '';
    details['PolicyType'] = null;
    details['PolicyYear'] = null;
    details['PreparedBy'] = sessionStorage.getItem(RSAConstants.LoggedInUserId);
    details['PreparedDate'] = null;
    details['RefPolicyNo'] = null;
    details['RefTransactionID'] = null;
    details['RefTransactionSerialNo'] = item.Ref_Tran_Serial_No;
    details['RefTransactionType'] = item.Ref_Tran_Type;
    details['RegionCode'] = sessionStorage.getItem(RSAConstants.regionCode);
    details['SLCode'] = null;
    details['SerialNo'] = item.SerialNo;
    details['TotallingAccCode'] = item.Tot_Acc_Code;
    details['VoucherDate'] = item.VoucherDate || new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy');
    details['VoucherNo'] = item.VoucherNo || 0;
    details['newAddedRow'] = false;
    return details;
  }

  calculateTotalDrAmtCrAmt() {

    this.totalcr = 0;
    this.totaldr = 0;
    this.JVuploadData.forEach((data) => {
      data.AmountCr = data.AmountCr == undefined || isNaN(data.AmountCr) ? 0 : data.AmountCr;
      this.totalcr += Number(data.AmountCr) || 0;
      data.AmountDr = data.AmountDr == undefined || isNaN(data.AmountDr) ? 0 : data.AmountDr;
      this.totaldr += Number(data.AmountDr) || 0;
    });

  }
  removeRecordImportJV(index) {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = 'Proceed') {
        console.log(index);
        this.JVuploadData.splice(index, 1);
        this.calculateTotalDrAmtCrAmt();
        this.totalUploadedRecords = this.totalUploadedRecords - 1;
        this.deleteRecordFromJv = true;
      }
    });

  }

  addNewJvRecord(template: TemplateRef<any>) {
    this.jvImportvoucherDetails = this.createDetailsArrayGroup();
    this.bsModalRef2 = this.modalService.show(
      template,
      { class: 'gray modal-add-new-receipt', backdrop: 'static' });
  }
  /* after changing the branch while adding new record import jv */
  changeCostcenterJvImport(ev) {
    this.getAllCostCenterDataJvimport(ev);
  }

  /* get all cost Centre  data for  header and details */
  getAllCostCenterDataJvimport(ev) {
    this.masterDataService.getLookupCostCenters().subscribe((data) => {
      this.costcentredata = data;
      console.log(data, 'costcentredata');
      this.getTotallingDetailDataJvImport(ev);
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* after changing TotallingDetailData  details */
  getTotallingDetailDataJvImport(ev) {
    //this.mainVoucherForm.get('AnalysisCode').setValidators([Validators.required]);
    //this.mainVoucherForm.get('Department').setValidators([Validators.required]);
    console.log(ev);
    const initFlag = false;
    const ccentre = this.jvImportvoucherDetails['controls'].CostCenterCode.value;

    const param = 'ccCode=' + ccentre;

    this.masterDataService.getDetailTotallingAccount(param).subscribe(
      dataReturn => {
        this.dtltotallingacc[0] = dataReturn;
        console.log('this.dtltotallingacc[index]>>', this.dtltotallingacc[0]);
        const totcode = this.dtltotallingacc[0][0].Code;
        if (!initFlag) {
          if (this.isPaymentFromEntity) {
            // this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, this.defaultTotallingAccCode);
            this.jvImportvoucherDetails.get('TotallingAccCode').setValue(this.defaultTotallingAccCode);
          }
          this.jvImportvoucherDetails.get('TotallingAccCode').setValue(totcode);
          // this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, totcode);
        }
        if (this.isPaymentFromEntity) {
          this.getGLDataJvimport({ ev: this.defaultGLCode });
        }
        this.getGLDataJvimport({ ev: totcode });
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  /*get gldata  */
  getGLDataJvimport(ev) {
    console.log(ev);
    const initFlag = false;
    const val = ev.ev;
    const ccentre = this.jvImportvoucherDetails['controls'].CostCenterCode.value;
    const totcode = val;

    const param = 'totAccCode=' + totcode +
      '&ccCode=' + ccentre;
    console.log('param-GL', param);

    this.masterDataService.getDetailGlAccount(param).subscribe(
      dataReturn => {
        console.log(dataReturn, 'dataretrun');
        this.glaccount[0] = dataReturn;
        if (!initFlag) {
          this.jvImportvoucherDetails.get('GLCode').setValue(this.glaccount[0][0].Code);
          this.jvImportvoucherDetails.get('GLCodeDesc').setValue(this.glaccount[0][0].E_Code_Desc);
        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  setReqValFormArrayControl(contrlname, index, isRequired) {
    //isRequired = true;
    let selCtrl = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get(contrlname);
    if (!selCtrl) {
      selCtrl = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get('Department');
    }
    if (isRequired) {
      if (selCtrl.value === null || selCtrl.value === '') {
        selCtrl.setValidators([Validators.required]);
        selCtrl.markAsTouched();
        selCtrl.markAsDirty();
        selCtrl.setErrors({ 'incorrect': true });
      }
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].updateValueAndValidity();
    }
    else {
      selCtrl.clearValidators();
      selCtrl.updateValueAndValidity();
    }
  }

  setHiddenValuejvImport(val) {
    console.log(val);
    const ev = val.item.Code;
    this.jvImportvoucherDetails.get('GLCode').setValue(ev);
  }
  clearGLCodejvImport() {
    this.jvImportvoucherDetails.get('GLCode').setValue('');
    this.jvImportvoucherDetails.get('GLCodeDesc').setValue('');
  }
  ValidateDrCrAmtjvImport() {
    const crAmt = this.jvImportvoucherDetails.get('AmountCr');
    const drAmt = this.jvImportvoucherDetails.get('AmountDr');
    drAmt.valueChanges.subscribe((val) => {
      if (val > 0) {
        crAmt.setValue((0).toFixed(2));
      }
    });
    crAmt.valueChanges.subscribe((val) => {
      if (val > 0) {
        drAmt.setValue((0).toFixed(2));
      }
    });
    console.log('end of call last');
  }

  setDecimalwithFormatting(event) {
    event.target.value = Number(event.target.value).toFixed(2);
  }
  addNewJvRecordForReview() {
    this.jvImportvoucherDetails.controls.AmountCr.markAsTouched();
    this.jvImportvoucherDetails.controls.AmountDr.markAsTouched();
    this.jvImportvoucherDetails.controls.TotallingAccCode.markAsTouched();
    this.jvImportvoucherDetails.controls.GLCode.markAsTouched();
    const Cr = this.jvImportvoucherDetails.controls.AmountCr.value;
    const Dr = this.jvImportvoucherDetails.controls.AmountDr.value;
    if (Cr == 0 && Dr == 0) {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      return false;
    }
    if (this.jvImportvoucherDetails.valid) {
      const details = this.jvImportvoucherDetails.value;
      console.log(details);
      details['VoucherDate'] = new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy');
      if (details.AmountCr != 0) {
        details['AmountCr'] = -Math.abs(details['AmountCr']);
      }
      details.LocationDesc = this.jvImportvoucherDetails.controls.LocationCode.value;
      this.JVuploadData.push(details);
      console.log(this.JVuploadData, "jvuploadData");
      this.calculateTotalDrAmtCrAmt();
      this.bsModalRef2.hide();
      this.jvImportvoucherDetails.controls.AmountCr.reset('0.00');
      this.jvImportvoucherDetails.controls.AmountDr.reset('0.00');
      this.jvImportvoucherDetails.controls.Description.reset('');
      this.jvImportvoucherDetails.controls.RefTransactionSerialNo.reset('');
      this.jvImportvoucherDetails.controls.RefTransactionID.reset('');
    }

  }
}
