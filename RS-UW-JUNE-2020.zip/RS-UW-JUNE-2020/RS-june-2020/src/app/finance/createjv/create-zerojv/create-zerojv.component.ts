import { Component, OnInit, ViewChild } from '@angular/core';
import { SharedService } from '../../services/shared.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { CreateReceipt } from '../../search/model/create-receipt';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreateCreditNotes } from 'src/app/finance/creditnotes/create-creditnotes/model/create-cn';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { CreateCreditnotesService } from 'src/app/finance/creditnotes/create-creditnotes/service/create-creditnotes.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { CnpreviewComponent } from 'src/app/finance/preview/uae/cnpreview/cnpreview.component';
import { Location } from '@angular/common';
import { CreateJvService } from 'src/app/finance/createjv/service/create-jv.service';
import { CreateJvModel } from 'src/app/finance/createjv/model/create-jv';
import { JvpreviewComponent } from '../../preview/uae/jvpreview/jvpreview.component';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';

@Component({
  selector: 'rsa-create-zerojv',
  templateUrl: './create-zerojv.component.html',
  styleUrls: ['./create-zerojv.component.scss']
})
export class CreateZerojvComponent extends BasevoucherComponent implements OnInit {

  titleJV = 'Journal Voucher';
  currency = sessionStorage.getItem(RSAConstants.currency);
  // errorpayee: boolean;
  errordetail: boolean;
  //errorglCode: boolean;
  /* form error-feilds */
  errorbankcodeCheque: boolean;
  level: any = 2;
  errorbankcodeBanktransfer: boolean;
  errorpaayeebanknameCheque: boolean;
  errorpaayeebanknameBanktransfer: boolean;
  errorchequedateCheque: boolean;
  errorchequedateBankT: boolean;
  errorchequedateCreditCard: boolean;
  errorchequenoCheque: boolean;
  errorchequenoCreditCard: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  matchedRecords = [];
  isUploadUnmatched;
  returnValue: any;
  usersReq;
  approverror: boolean = false;
  symbol;
  clonedZeroJV: any;
  glAcountHeader: any = [];
  createCreditNotes: CreateCreditNotes;
  animatedClass = true;
  selectedRowItem: any;
  customerName: string = "";
  ondemandFlag: boolean = false;
  formArray: any;
  isRowDraftJV;
  isBatch = false;
  createJvModel: CreateJvModel;
  tamtcr;
  tamtdr;
  ondemandFlagClaim: boolean = true;
  detaildescription: string;
  receiptAccountingDate: any;

  @ViewChild('tabset') tabset: TabsetComponent;
  constructor(
    protected sharedService: SharedService,
    private fb: FormBuilder,
    protected modalService: BsModalService,
    protected bsModalRef: BsModalRef,
    protected masterDataService: MasterDataService,
    protected utilityClass: UtilityClass,
    protected createPaymentService: CreateCreditnotesService,
    private alertService: AlertService,
    private location: Location,
    protected createJvService: CreateJvService,

  ) {
    super(masterDataService, sharedService, modalService, utilityClass, bsModalRef);
    //super.setMinMaxDate();
  }

  ngOnInit() {
    /* super with method is calling from BasevoucherComponent */
    this.createVoucherForm(this.paymentMode);  // can i use paymentMode = 2;
    super.getAllBranchData();
    super.getAllCostCenterData({ ev: null, index: 0, flag: true });
    //super.getAllTotallingData(true);
    super.getAllDeptData();
    super.getAllProjData();
    super.getAllMasterData2();
    this.fieldStatusChanges();
    super.getModelPreviousClose();
    super.closeModel();
    super.getAllTranData();
    this.symbol = (sessionStorage.getItem('symbol'));
    //super.setMinMaxDate();
    super.GetAccountingDates(new Date());
    //this.getGlAccountHeader();
    this.getDetailsArrayFormGroup();
    super.getModelPreviousClose();
    this.zeroJV();
    this.isRowDraftJV = true;
  }
  zeroJV() {
    const ctrlcr = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    ctrlcr.controls.forEach(val => {

      val.get('AmountDr').setValue(0);
      val.get('AmountCr').setValue(0);

    });
    this.getSumCr();
    this.getSumDr();
  }

  /* create entiti form */
  createVoucherForm(param): void {
    this.mainVoucherForm = null;

    this.mainVoucherForm = this.fb.group({
      VoucherDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ApprovedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      ArabicDescription: [],
      AmountCr: [''],
      AmountDr: [''],
      CountryCode: [sessionStorage.getItem(RSAConstants.countrycode)],
      CustomerID: [],
      CustCode: [],
      ModifiedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      ModifiedDate: [],
      PreparedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [],
      ReprintNo: [],
      PrintDate: [],
      RefreshDate: [],
      PostedDate: [],
      PreprintNo: [],
      Title: ['Journal Voucher'],
      RegionCode: [sessionStorage.getItem(RSAConstants.regionCode)],
      Approvers: this.fb.array([]),
      detailInfo: this.fb.group({
        // PayeeName: [this.customerName, Validators.required],
        EnglishDescription: ['', Validators.required],
        // GLCode: [4, Validators.required],
        //GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required],
      }),
      accountInfo: this.fb.group({
        LocationCode: [sessionStorage.getItem('locationcode')],
        CostCenterCode: [sessionStorage.getItem(RSAConstants.costcentre)],
        TotallingAccCode: [sessionStorage.getItem(RSAConstants.totallingaccount)]
      }),
      VoucherDetails: this.fb.array([])
    });
  }

  getDetailsArrayFormGroup() {
    this.detaildescription = this.selectedRowItem.Description;
    this.selectedRowItem = this.selectedRowItem.JournalVoucherDetails;
    let control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    if (!this.ondemandFlag) {

      this.selectedRowItem.map((item, index) => {
        super.getAllCostCenterData({ ev: null, index: index, flag: false });
        let group = this.createDetailsArrayGroup();
        console.log('item.item>>', item);
        group.patchValue(item);
        group.get('AmountCr').setValue(Math.abs(item.AmountCr));
        group.get('TotallingAccCode').setValue(item.TotallingAccCode);
        group.get('VoucherNo').setValue(null);
        group.get('RefTransactionID').setValue(null);
        group.get('newAddedRow').setValue(false);
        control.push(group);
      });
    } else {
      control.push(this.createDetailsArrayGroup());
    }

    // if (!this.ondemandFlagClaim) {
    //   console.log(this.selectedRowItem, 'this.selectedRowItem');
    //   this.selectedRowItem.map(item => {
    //     let group = this.createDetailsArrayGroup();
    //     group.patchValue(item);
    //     group.get("newAddedRow").setValue(false);
    //     control.push(group);
    //   });
    // } else {
    //   control.push(this.createDetailsArrayGroup());
    // }
    this.setDescription();
  }



  /* form array for recept details */
  createDetailsArrayGroup(): FormGroup {
    return this.fb.group({
      //Amount: ['0.00', Validators.required],
      AmountCr: ['0', Validators.required],
      AmountDr: ['0', Validators.required],
      AnalysisCode: [],
      CostCenterCode: [sessionStorage.getItem('costcentre')],
      ClaimID: [],
      ClassCode: [],
      CauseOfLossCode: [],
      CounterPartyRef: [],
      CountryCode: [sessionStorage.getItem(RSAConstants.countrycode)],
      DescriptionDtl: [],
      DocumentCode: [],
      //EntityID:[],

      GLCode: [sessionStorage.getItem(RSAConstants.defaultGLCode), Validators.required],
      GLCodeDesc: [sessionStorage.getItem(RSAConstants.defaultGLCodeDesc), Validators.required],
      LocationCode: [sessionStorage.getItem('locationcode')],
      LocationDesc: [sessionStorage.getItem(RSAConstants.locationdesc)],
      ModifiedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      ModifiedDate: [],
      NatureOfLossCode: [],
      PolicyID: [],
      PolicyYear: [],
      PreparedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [],
      RefTransactionID: [],
      RefTransactionSerialNo: [],
      RefTransactionType: [3],
      RegionCode: [sessionStorage.getItem(RSAConstants.regionCode)],
      TotallingAccCode: [sessionStorage.getItem(RSAConstants.totallingaccount), Validators.required],
      PolicyType: [],
      newAddedRow: true,
      VoucherNo: [],
      SerialNo: [],
      Department: [],
      PolicyNo: [],
      RefPolicyNo: [],
      ArrangementId: [],
      ArrangementType: [],
      ArrangementLayerId: [],
      Endt_ID: [],
      SLCode: [],
    });
  }

  /* set receipt mode and set default values   
  // since payment mode is not there in this flow so commenting the function.
  setReceiptMode(val, paymentname) {
    this.mainVoucherForm.controls['PaymentMode'].setValue(val);
    this.paymentMode = val;
    this.paymentname = paymentname;
    this.createVoucherForm(this.paymentMode);
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;
    if (this.paymentMode == 1) {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1210');
    } else {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(sessionStorage.getItem(RSAConstants.totallingaccount));
      this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue(sessionStorage.getItem(RSAConstants.defaultBankCode));
    }
    this.setdefaultHeaderData();
    this.fieldStatusChanges();
    super.GetAccountingDates(new Date());
  }
*/

  /* using req fields and update status  */
  fieldStatusChanges() {
    this.clearerrors();
    // this.cshpayeename.statusChanges.subscribe(
    //   status => {
    //     this.errorpayee = (status === 'INVALID');
    //     console.log(this.errorpayee, 'his.errorpayee');
    //   }
    // );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );

    // this.glCodeValue.statusChanges.subscribe(
    //   status => {
    //     this.errorglCode = (status === 'INVALID');
    //   }
    // );

  }

  /* clear all errors after reset   */
  clearerrors() {
    // this.errorpayee = false;
    this.errordetail = false;
    // this.errorglCode = false;
  }

  /* get the controls of each fields   */
  //get cshpayeename() { return this.mainVoucherForm.controls.detailInfo['controls'].PayeeName; }
  get cshdetails() { return this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription; }
  //get glCodeValue() { return this.mainVoucherForm.controls.detailInfo['controls'].GLCode; }


  /* set Description in receptdetails desc   */
  setDescription() {
    this.cshdetails.setValue(this.detaildescription);
    //this.mainVoucherForm.controls.detailInfo.controls[0].get('Description').setValue(this.cshdetails.value);
  }


  /* add receipt in review screen */
  addJournalDetail(len) {
    const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    var validValue = this.validationCrDrValues(len);
    //   console.log(validValue,"va");
    if (validValue) {
      control.push(this.createDetailsArrayGroup());
      this.setFormArrayCTRLDefaultValue('GLCode', len, '');
      this.setFormArrayCTRLDefaultValue('TotallingAccCode', len, '');
      this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '');
      this.setOndemandTotallingDetail({ index: len });
      this.glaccount[len] = [];
      // this.setFormArrayCTRLDefaultValue('newAddedRow',len,true);
    }
  }

  validationCrDrValues(len) {

    var isValid = true;
    let CurrentAmountCr = 0;
    let CurrentAmountDr = 0;
    let errorcount = 0;
    let errorcntzerochk = 0;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {
      CurrentAmountCr = element.get('AmountCr').value;
      CurrentAmountDr = element.get('AmountDr').value;
      if (CurrentAmountDr > 0 && CurrentAmountCr > 0) {
        errorcount++;
        //element.get('AmountDr').updateValueAndValidity();
        //element.get('AmountDr').markAsTouched();
      }
      if (CurrentAmountDr == 0 && CurrentAmountCr == 0) {
        errorcntzerochk++;
      }

    });
    if (errorcount > 0) {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONDRCR;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      return false;
    } else if (errorcntzerochk > 0) {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      return false;
    }
    return true;

  }


  reSetForm(params) {
    const param = params.defaultParam;
    /*set default value here and reset */
    if (param == 1) {
      super.validateAllFormFields(this.mainVoucherForm);
      this.mainVoucherForm.controls.VoucherDate.setValue([new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]);
      this.mainVoucherForm.controls.GLCode.setValue(sessionStorage.getItem(RSAConstants.defaultGLCode));
      this.mainVoucherForm.controls.GLCodeDesc.setValue(sessionStorage.getItem(RSAConstants.defaultGLCodeDesc));
      this.clearerrors();
    } else if (param == 2) {
      this.mainVoucherForm.controls['VoucherDetails'].reset();
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('LocationCode').setValue([sessionStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([sessionStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(sessionStorage.getItem(RSAConstants.totallingaccount));
        item.get('GLCode').setValue(sessionStorage.getItem(RSAConstants.defaultGLCode));
        item.get('GLCodeDesc').setValue(sessionStorage.getItem(RSAConstants.defaultGLCodeDesc));
      });
      //this.getSum();
      this.getSumDr();
      this.getSumCr();
    }
    super.GetAccountingDates(new Date());
  }

  getSumDr() {
    this.totaldr = 0;
    const ctrldr = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    ctrldr.controls.forEach(val => {
      const amtdr = (val.get('AmountDr').value == null || isNaN(val.get('AmountDr').value) ||
        val.get('AmountDr').value == '') ? 0 : val.get('AmountDr').value;
      this.totaldr += Math.abs(parseFloat(amtdr));
    });
    this.totaldr = (isNaN(this.totaldr)) ? 0 : this.totaldr;
  }

  getSumCr() {

    this.totalcr = 0;
    const ctrlcr = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    ctrlcr.controls.forEach(val => {
      const amtcr = (val.get('AmountCr').value == null || isNaN(val.get('AmountCr').value) ||
        val.get('AmountCr').value == '') ? 0 : val.get('AmountCr').value;
      this.totalcr += Math.abs(parseFloat(amtcr));
    });
    this.totalcr = (isNaN(this.totalcr)) ? 0 : this.totalcr;
  }

  /* update  form values to create-receipt objects*/
  createJVFormValues() {
    //this.createCreditNotes = new CreateCreditNotes();
    this.createJvModel = new CreateJvModel();
    const mainFormFieldArray = ['VoucherDate', 'ApprovedBy', 'ArabicDescription',
      'CountryCode', 'CustomerID', 'CustCode', 'ModifiedDate', 'ModifiedBy', 'PostedDate',
      'PreparedBy', 'PreparedDate', 'PreprintNo', 'PrintDate', 'RefreshDate', 'RegionCode', 'Title',
      'Approvers'];
    mainFormFieldArray.forEach(item => {
      // console.log('this.item****', item);
      this.createJvModel[item] = this.mainVoucherForm.controls[item].value;

    });
    this.createJvModel.LocationCode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    this.createJvModel.CostCenterCode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    this.createJvModel.TotallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    // this.createJvModel.PayeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
    this.createJvModel.EnglishDescription = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
    this.createJvModel.JournalVoucherDetails = this.mainVoucherForm.controls['VoucherDetails'].value;
    // console.log('this.createJvModel****', this.createJvModel);
    //console.log('this.createJvModel lenght ****', this.createJvModel.JournalVoucherDetails.length);



  }
  validateDetailInfoJv() {

    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map((item, index) => {
      item.get('TotallingAccCode').updateValueAndValidity();
      item.get('GLCode').updateValueAndValidity();
      item.get('AmountDr').updateValueAndValidity();
      item.get('AmountCr').updateValueAndValidity();
      //item.get('Amount').markAsTouched();
      item.get('TotallingAccCode').markAsTouched();
      item.get('GLCode').markAsTouched();
      item.get('AmountDr').markAsTouched();
      item.get('AmountCr').markAsTouched();
      this.glerrorcount = 0;
      this.totaccrorcount = 0;
      this.submitError = 0;
      if (item.get('GLCode').value == null || item.get('GLCode').value == undefined || item.get('GLCode').value == '') {
        this.glerrorcount = this.glerrorcount + 1;
      }
      // tslint:disable-next-line:triple-equals
      // tslint:disable-next-line:max-line-length
      if (item.get('TotallingAccCode').value == null || item.get('TotallingAccCode').value == undefined || item.get('TotallingAccCode').value == '') {
        this.totaccrorcount = this.totaccrorcount + 1;
      }
      if (item.get('GLCode').value !== null &&
        item.get('GLCode').value !== undefined &&
        item.get('GLCode').value !== "") {
        let selGlAccntId = parseInt(item.get('GLCode').value);
        let lstGLAccnt = this.glaccount[index].filter(data => data.Code === selGlAccntId);
        if (lstGLAccnt.length > 0) {
          let selGLAccnt = lstGLAccnt[0];
          if (item.get('Department').value == null
            || item.get('Department').value == undefined
            || item.get('Department').value == "") {
            if (selGLAccnt.Department) {
              this.setReqValFormArrayControl('Department', index, selGLAccnt.Department ? true : false);
              this.submitError++;
            }
          }
          if (item.get('AnalysisCode').value == null ||
            item.get('AnalysisCode').value == undefined ||
            item.get('AnalysisCode').value == "") {
            if (selGLAccnt.ProjectIndicator) {
              this.setReqValFormArrayControl('AnalysisCode', index, selGLAccnt.ProjectIndicator ? true : false);
              this.submitError++;
            }
          }
        }
      }
      if (item.get('AnalysisCode').invalid) {
        this.submitError++;
      }
      if (item.get('Department').invalid) {
        this.submitError++;
      }
    });
  }
  presubmission(objModel) {
    let flagtoggle = true;
    let amt = 0;
    this.clonedZeroJV = Object.assign({}, objModel);
    console.log('this.clonedZeroJV', this.clonedZeroJV);
    const prevPreviewID = +(this.prevPreviewID === 0) ? null : this.prevPreviewID;
    this.clonedZeroJV.JournalVoucherDetails.forEach((element, index) => {
      const amtdr = element.AmountDr;
      const amtcr = element.AmountCr;
      element.AmountDr = (Math.abs(amtdr));
      element.AmountCr = (Math.abs(amtcr) * -1);
      if (element.RefTransactionID == null || element.RefTransactionID == '') {
        element.RefTransactionID = prevPreviewID;
      }
      element.VoucherNo = prevPreviewID;
    });
    console.log('this.clonedZeroJV', this.clonedZeroJV);
  }
  /* create-receipt form*/
  submitForm() {
    this.validateDetailInfoJv();
    //this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;
    //this.errorglCode = this.glCodeValue.invalid;
    if (!(!this.errordetail)) {
      return false;
    }

    if (this.glerrorcount > 0) {
      return false;
    }
    if (this.submitError > 0) {
      this.alertService.warn(RSAMSGConstants.REQFIELDERROR);
      return false;
    }
    // this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
    //   this.approverusers.length > 0);
    //   this.approverror = false;
    //   if (!this.usersReq) {
    //     this.approverror = true;
    //     return false;
    //   }
    //if (this.totalcr > 0 || this.totaldr > 0) {


    this.createJVFormValues();
    // this.validationCrDrValues(this.createJvModel.JournalVoucherDetails.length);

    console.log(this.createJvModel, ' this.createJvModel');
    if (this.prevPreviewID == null || this.prevPreviewID == undefined)
      this.prevPreviewID = 0;


    this.createJvModel["VoucherNo"] = this.prevPreviewID;
    this.presubmission(this.createJvModel);
    if (this.validationCrDrValues(this.createJvModel.JournalVoucherDetails.length)) {
      if (this.totalcr <= 0) {
        this.alertService.warn(RSAMSGConstants.AMOUNTTEXTREQ);
        return false;
      }
      else if (this.totaldr <= 0) {
        this.alertService.warn(RSAMSGConstants.AMOUNTTEXTREQ);
        return false;
      }

      else if (this.totalcr != this.totaldr) {
        //this.alertService.warn(RSAMSGConstants.AMOUNTNOTMATCHED);
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTNOTMATCHED;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
        return false;

      }
    }
    else
      return false;

    this.createJvService.createJv(JSON.stringify(this.clonedZeroJV)).subscribe(
      dataReturn => {
        this.returnValue = dataReturn;
        console.log(this.returnValue, "testing222..");
        this.returnValue['approverlist'] = this.approverusers;
        this.returnValue['ondemand'] = true;
        this.previewFlag = true;
        this.bsModalRef = this.modalService.show(JvpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
        this.bsModalRef.content.data = this.returnValue;
        this.bsModalRef.content.totalamountcr = this.totalcr;
        this.bsModalRef.content.totalamountdr = this.totaldr;
        this.bsModalRef.content.backdrop = true;
        this.bsModalRef.content.clonedJV = this.clonedZeroJV;

      },
      errorRturn => {
        this.errorMsg = errorRturn;
      }
    );
    //}

  }//submition


  getGlAccountHeader() {
    const param = 'totAccCode=' + sessionStorage.getItem(RSAConstants.totallingaccount) +
      '&ccCode=' + sessionStorage.getItem('costcentre');
    this.masterDataService.getDetailGlAccount(param).subscribe(data => {
      this.glAcountHeader = data;
      console.log('gldata', data);
    })
  }

  setGLHdrHiddenValue(ev) {
    console.log(ev);
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue(ev.item.Code);
  }
  clearHdrGLCode(ev) {
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue('');
    this.mainVoucherForm.controls.detailInfo['controls'].GLCodeDesc.setValue('');
  }

  /* check single or batch upload */
  checkSingleOrbatch(e) {
    this.isBatch = !this.isBatch;
    console.log(this.isBatch);
  }

  goBackOp() {
    this.location.back();
  }

  reCancel() {
    this.bsModalRef.hide();
    this.modalService.hide(1);
    this.sharedService.sendMessage("close");
  }

  setReqValFormArrayControl(contrlname, index, isRequired) {
    //isRequired = true;
    let selCtrl = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get(contrlname);
    if (!selCtrl) {
      selCtrl = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get('Department');
    }
    if (isRequired) {
      if (selCtrl.value === null || selCtrl.value === '') {
        selCtrl.setValidators([Validators.required]);
        selCtrl.markAsTouched();
        selCtrl.markAsDirty();
        selCtrl.setErrors({ 'incorrect': true });
      }
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].updateValueAndValidity();
    }
    else {
      selCtrl.clearValidators();
      selCtrl.updateValueAndValidity();
    }
  }
}

