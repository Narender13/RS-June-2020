export class CreateJvModel{
    VoucherDate:string;
    ApprovedBy?: string;
    ArabicDescription?: any;
    CostCenterCode?: string;
    CountryCode: number;
    CustomerID?: any;
    CustCode?: string;
    EnglishDescription: string;
    GLCode: number;
    LocationCode: string;
    ModifiedDate?: string;
    ModifiedBy?: string;
    PayeeName: string;
    PostedDate?: string;
    PreparedBy: string;
    PreparedDate?: string;
    PreprintNo?:string;
    PrintDate?: string;
    RefreshDate?: string;
    RegionCode: string;
    Title:string;
    TotallingAccCode?:string;
    Approvers?: any[];    
   // VoucherDetails: CreatejvsDetail[]; 
   JournalVoucherDetails: CreatejvsDetail[]; 
       
}

export class CreatejvsDetail {
    Amount: string;
    AmountDr: string;
    AnalysisCode: string;
    ArrangementId:any;
    ArrangementType:any;
    ArrangementLayerId?:any;
    CostCenterCode: string;
    ClaimID:number;
    ClassCode: string;
    CauseOfLossCode?:number;
    CounterPartyRef?: any;
    CountryCode: number;
    Description: string;
    DocumentCode?: any;
    //EntityID?:any;
    Endt_ID?:any;
    GLCode: number;
    LocationCode: string;
    ModifiedBy: string;
    ModifiedDate?: string;
    NatureOfLossCode?:number;
    PolicyID?: any; 
    PolicyNo:number;
    PolicyType:any;
    PolicyYear?: any;
    PreparedBy?: any;
    PreparedDate?: string;
    RefTransactionID?: any;
    RefTransactionSerialNo?: any;
    RefTransactionType: number;    
    RegionCode: string;
    SLCode:number;
    TotallingAccCode: number;
    newAddedRow?:boolean;
    VoucherNo?:number;
   
}
