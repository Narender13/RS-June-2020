import { Injectable } from '@angular/core';
import { HttpHeaders, HttpErrorResponse, HttpClient, HttpParams, } from '@angular/common/http';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { catchError, map, shareReplay } from 'rxjs/operators'; 

@Injectable({
  providedIn: 'root'
})
export class AdvocateService {

    constructor(private http: HttpClient) { }
 
    getspecialization() {
        return this.http.get<any>(RSAENDPOINTConstants.ADVSPECIALIZATION).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getspecialization')));

    }
    getstatus() {
        return this.http.get<any>(RSAENDPOINTConstants.STATUS).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getstatus')));

    }
    getrating(params:any) {
        return this.http.get<any>(RSAENDPOINTConstants.RATING+params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getrating')));

    }
    createAdvocate(params: any) {
        return this.http.post<any>(RSAENDPOINTConstants.CREATEADVOCATE, params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createAdvocate')));
    }
    getAdvocateDetails(params:any) {
        return this.http.get<any>(RSAENDPOINTConstants.GETADVOCATE+params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAdvocateDetails')));
    }
    updateAdvocateDetails(params: any) {
        return this.http.put<any>(RSAENDPOINTConstants.UPDATEADVOCATE, params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updateAdvocateDetails')));
    }
}
