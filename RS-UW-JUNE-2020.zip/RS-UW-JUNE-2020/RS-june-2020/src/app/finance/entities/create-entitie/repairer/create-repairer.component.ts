import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { slideInOut } from '../../../../shared/animation/slidein';
import { catchError, map, shareReplay } from 'rxjs/operators';
import { RepairerService } from 'src/app/finance/entities/create-entitie/repairer/service/repairer.service';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { SuccessDialogComponent } from 'src/app/shared/custom-success-model/custom-success-model.component';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
    selector: 'rsa-create-repairer',
    templateUrl: './create-repairer.component.html',
    styleUrls: ['./create-repairer.component.scss'],
    animations: [slideInOut]
})
export class CreateRepairerComponent implements OnInit {
    repairerForm: FormGroup;
    submitted = false;
    isArabicField = false;
    address3 = false;
    address1 = false;
    address2 = false;
    errorName: boolean;
    errorNameExists: boolean;
    errorVatRegno: boolean;
    errorVatRegnoExists: boolean;
    errorVatRegcountry: boolean;
    errorEmail: boolean;
    errorEmailExists: boolean;
    errorPhoneno: boolean;
    errorPhonenoExists: boolean;
    errorMobileno: boolean;
    errorMobilenoExists: boolean;
    errorSerialno: boolean;
    errorAddress: boolean;
    errorAddress1: boolean;
    erroraddress2: boolean;
    errorPostalcode: boolean;
    errorPobox: boolean;
    bankNamesList: any = [];
    vatCodesList: any = [];
    vatRegCountryList: any = [];
    statusList: any = [];
    returnValue: any;
    isOman: any;
    today = new Date();
    previous = new Date('01/01/2000');
    errorStartDate: boolean = false;
    errorEndDate: boolean = false;
    errorStart: boolean = false;
    errorEnd: boolean = false;
    enableVATRegnEndDate: boolean = false;
    nextDay: Date;
    endDate: Date;
    isUAE: boolean = false;
    functionIDModify: number = 407;
    constructor(private fb: FormBuilder,
        protected repairerService: RepairerService,
        public bsModalRef: BsModalRef,
        private modalService: BsModalService, private router: Router, private allowAccess: UserAutherizationService
    ) { }
    get f() { return this.repairerForm.controls; }

    ngOnInit() {
        this.createEntiteForm();
        this.fieldStatusChanges();
        this.getPayeeBankNames();
        this.getVatCode();
        this.getVatRegCountry();
        this.getStatus();
        this.isOman = sessionStorage.getItem('regioncode') == '3' ? true : false;
        this.isUAE = (sessionStorage.getItem('regioncode') == '2') ? true : false;
        if (this.isUAE) {
            this.formControlAddValidator();
        }
        else {
            this.formControlClearValidator();
        }
        this.errorVatRegcountry = false;
        this.errorVatRegno = false;
    }
    formControlClearValidator() {
        const VatRegistrationNumber = this.repairerForm.get('VatRegistrationNumber');
        const VatRegistrationCountry = this.repairerForm.get('VatRegistrationCountry');
        VatRegistrationNumber.clearValidators();
        VatRegistrationNumber.updateValueAndValidity();
        VatRegistrationCountry.clearValidators();
        VatRegistrationCountry.updateValueAndValidity();
    }
    formControlAddValidator() {
        const VatRegistrationNumber = this.repairerForm.get('VatRegistrationNumber');
        const VatRegistrationCountry = this.repairerForm.get('VatRegistrationCountry');
        // VatRegistrationNumber.setValidators([Validators.required]);
        VatRegistrationNumber.updateValueAndValidity();
        // VatRegistrationCountry.setValidators([Validators.required]);
        VatRegistrationCountry.updateValueAndValidity();
    }
    createEntiteForm(): void {
        this.repairerForm = this.fb.group({

            //title: ['', Validators.required],
            EnglishName: ['', Validators.required],
            ArabicName: [],
            VatCode: [],
            VatRegistrationNumber: ['', Validators.required],
            VatRate: [],
            VatRegistrationCountry: ['', Validators.required],
            Email: ['', [Validators.required, Validators.email]],
            PhoneNumber: ['', Validators.required],
            Mobile: ['', Validators.required],
            FaxNumber: [],
            VATRegnStrtDate: [''],
            VATRegnEndDate: [''],
            //branch: ['', Validators.required],
            SerialNumber: ['', Validators.required],
            EnglishAddress1: ['', Validators.required],
            ArabicAddress1: [],
            EnglishAddress2: [],
            ArabicAddress2: [],
            EnglishAddress3: [],
            ArabicAddress3: [],
            PostalCode: ['', Validators.required],
            // pobox: ['', Validators.required],
            BeneficiaryBankName: [],
            BeneficiaryAccNo: [],
            IBAN: [],
            BenBankAddress: [],
            BenSwiftCode: [],
            BenSortCode: [],
            CorrespondentBankName: [],
            CorrAccNo: [],
            CorrSwiftCode: [],
            CorrSortCode: [],
            CorrBankAddress: [],
            Fees: [],
            ContactPerson: [],
            ExpenseTypeMotor: [],
            ExpenseTypeNonMotor: [],
            Status: [],
            PreparedBy: [sessionStorage.getItem('LoggedInUserId')],
            IsValid: [0]
            //acexective: ['', Validators.required]
        });
    }
    clearerrors() {
        this.errorName = false;
        this.errorNameExists = false;
        this.errorVatRegno = false;
        this.errorVatRegnoExists = false;
        this.errorVatRegcountry = false;
        this.errorEmail = false;
        this.errorEmailExists = false;
        this.errorPhoneno = false;
        this.errorPhonenoExists = false;
        this.errorMobileno = false;
        this.errorMobilenoExists = false;
        this.errorSerialno = false;
        this.errorAddress = false;
        this.errorPostalcode = false;
        this.errorStart = false;
        this.errorEnd = false;
        this.errorStartDate = false;
        this.errorEndDate = false;
        // this.errorPobox = false;
    }
    get name() { return this.repairerForm.get('EnglishName'); }
    get vatregno() { return this.repairerForm.get('VatRegistrationNumber'); }
    get vatregcountry() { return this.repairerForm.get('VatRegistrationCountry'); }
    get email() { return this.repairerForm.get('Email'); }
    get phoneno() { return this.repairerForm.get('PhoneNumber'); }
    get mobileno() { return this.repairerForm.get('Mobile'); }
    get serialno() { return this.repairerForm.get('SerialNumber'); }
    get address() { return this.repairerForm.get('EnglishAddress1'); }
    //get addressone() { return this.repairerForm.get('EnglishAddress2'); }
    //get addresstwo() { return this.repairerForm.get('EnglishAddress3'); }
    get postalcode() { return this.repairerForm.get('PostalCode'); }
    get poBox() { return this.repairerForm.get('pobox'); }

    fieldStatusChanges() {
        this.clearerrors();
        this.name.statusChanges.subscribe(
            status => {
                this.errorName = (status == 'INVALID');

            }
        );
        this.vatregno.statusChanges.subscribe(
            status => {
                this.errorVatRegno = (status == 'INVALID');

            }
        );
        this.vatregcountry.statusChanges.subscribe(
            status => {
                this.errorVatRegcountry = (status == 'INVALID');

            }
        );
        this.email.statusChanges.subscribe(
            status => {
                this.errorEmail = (status == 'INVALID');

            }
        );
        this.phoneno.statusChanges.subscribe(
            status => {
                this.errorPhoneno = (status == 'INVALID');

            }
        );
        this.mobileno.statusChanges.subscribe(
            status => {
                this.errorMobileno = (status == 'INVALID');

            }
        );
        this.serialno.statusChanges.subscribe(
            status => {
                this.errorSerialno = (status == 'INVALID');

            }
        );
        this.address.statusChanges.subscribe(
            status => {
                this.errorAddress = (status == 'INVALID');

            }
        );

        this.postalcode.statusChanges.subscribe(
            status => {
                this.errorPostalcode = (status == 'INVALID');

            }
        );
        /*  this.poBox.statusChanges.subscribe(
              status => {
                  this.errorPobox = (status == 'INVALID');
               
              }
          );*/
    }
    changeStartDate(sValue: Date) {
        if (sValue) {
            this.enableVATRegnEndDate = true;
            this.errorStartDate = true;
            this.nextDay = new Date(sValue);
            this.nextDay.setDate(sValue.getDate() + 1);
        }
    }
    changeEndDate(eValue: Date) {
        if (eValue) {
            this.errorEndDate = true;
            this.endDate = new Date(eValue);
            this.endDate.setDate(eValue.getDate() - 1);
        }
    }
    changeStartDateValue() {
        if (this.repairerForm.controls['VATRegnStrtDate'].value) {
            const RegistrationExpiry = new Date(this.repairerForm.controls['VATRegnStrtDate'].value);
            this.repairerForm.controls['VATRegnStrtDate'].setValue(new DatePipe('en-US').transform(RegistrationExpiry, 'dd/MM/yyyy'));
        }
    }
    changeEndDateValue() {
        if (this.repairerForm.controls['VATRegnEndDate'].value) {
            const RegistrationExpiry = new Date(this.repairerForm.controls['VATRegnEndDate'].value);
            this.repairerForm.controls['VATRegnEndDate'].setValue(new DatePipe('en-US').transform(RegistrationExpiry, 'dd/MM/yyyy'));
        }
      }      

    submitForm() {
        this.errorName = this.name.invalid;
        this.errorVatRegno = this.vatregno.invalid;
        this.errorVatRegcountry = this.vatregcountry.invalid;
        this.errorEmail = this.email.invalid;
        this.errorPhoneno = this.phoneno.invalid;
        this.errorMobileno = this.mobileno.invalid;
        this.errorSerialno = this.serialno.invalid;
        this.errorAddress = this.address.invalid;
        this.errorPostalcode = this.postalcode.invalid;
        // this.errorPobox = this.poBox.invalid;
        if (this.repairerForm.invalid) {
            return;
        }
        if (this.errorStartDate != this.errorEndDate) {

            if (this.errorStartDate == false) {
                this.errorStart = true;
                return false;
            }
            else {
                this.errorEnd = true;
                return false;
            }
        }
        else {

            console.log("\n second form values" + JSON.stringify(this.repairerForm.value) + "\n");

            this.repairerService.createRepairer(JSON.stringify(this.repairerForm.value)).subscribe(
                dataReturn => {
                    this.returnValue = dataReturn;

                    console.log(this.returnValue, 'this.returnValue');

                    //success modal
                    if (this.returnValue.IsValid == 0) {
                        this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                        this.bsModalRef.content.modelTitle = '';
                        this.bsModalRef.content.modelBodyContent = "Repairer successfully created.";
                        this.bsModalRef.content.smallMessage = "ID: " + this.returnValue.Code;
                        this.bsModalRef.content.bigMessage = "Repairer Name: " + this.returnValue.EngName;
                        // this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
                        this.bsModalRef.content.actionBtn = "Close";
                        this.bsModalRef.content.valueChange.subscribe((data) => {
                            console.log(" success datat" + data);
                            if (data == 'Close') {
                                console.log("close btn clicked");
                            } else {
                                console.log(" else close");
                            }
                            this.resetForm();
                            //  this.modalService.hide(1);    
                        });
                    } else if (this.returnValue.IsValid == 1) {
                        //alert modal
                        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                        this.bsModalRef.content.modelTitle = '';
                        this.bsModalRef.content.modelBodyContent = "Alert! Other than VAT Registration Number remaining fields already exists.";
                        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
                        this.bsModalRef.content.actionBtn = "Proceed";
                        this.bsModalRef.content.valueChange.subscribe((data) => {
                            console.log("datat" + data);

                            if (data = 'Proceed') {
                                console.log("proceed btn clicked");
                                this.repairerForm.value.IsValid = 1;
                                this.submitForm();
                            }
                            else if (data = 'PROCEED') {
                                console.log("erer");
                            }
                            else {
                                console.log(" else close");
                            }
                        });
                        //end for alert modal
                    }
                    else if (this.returnValue.IsValid == 2) {
                        this.errorEmailExists = true;
                        this.errorMobilenoExists = true;
                        this.errorNameExists = true;
                        this.errorPhonenoExists = true;
                        this.errorVatRegnoExists = true;

                    }
                },
                errorRturn => {
                    console.log(errorRturn);
                }
            );
        }
        console.log(this.repairerForm.value);

    }
    setVatRate(vatvalue: number) {
        this.vatCodesList.forEach(element => {
            if (element.Code == vatvalue) {
                this.repairerForm.controls['VatRate'].setValue(element.VATRate);
                //  console.log(element.VATRate+"elelel"+this.repairerForm.value.vatrate);
            }
        });


    }

    getPayeeBankNames() {
        this.repairerService.getPayeeBankNames().subscribe(
            dataReturn => {
                //console.log("data" + JSON.stringify(dataReturn));
                this.bankNamesList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }

    getVatCode() {
        this.repairerService.getVatCode().subscribe(
            dataReturn => {
                //  console.log("data6" + JSON.stringify(dataReturn));
                this.vatCodesList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getVatRegCountry() {
        this.repairerService.getVatRegCountry().subscribe(
            dataReturn => {
                //console.log("data6" + JSON.stringify(dataReturn));
                this.vatRegCountryList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getStatus() {
        this.repairerService.getStatus().subscribe(
            dataReturn => {
                //console.log("data6" + JSON.stringify(dataReturn));
                this.statusList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    resetForm() {
        let arrayFormFields = ['EnglishName', 'ArabicName', 'VatCode', 'VatRegistrationNumber', 'VatRate',
            'VatRegistrationCountry', 'Email', 'PhoneNumber', 'Mobile', 'FaxNumber', 'SerialNumber', 'EnglishAddress1',
            'ArabicAddress1', 'EnglishAddress2', 'ArabicAddress2', 'EnglishAddress3', 'ArabicAddress3', 'PostalCode', 'BeneficiaryBankName', 'BeneficiaryAccNo', 'IBAN',
            'BenBankAddress', 'BenSwiftCode', 'BenSortCode', 'CorrespondentBankName', 'CorrAccNo', 'CorrSwiftCode', 'CorrSortCode', 'CorrBankAddress', 'Fees',
            'ContactPerson', 'ExpenseTypeMotor', 'ExpenseTypeNonMotor', 'Status', 'VATRegnStrtDate', 'VATRegnEndDate'];
        this.repairerForm.controls['IsValid'].reset(0);
        arrayFormFields.forEach((val) => {
            if (this.repairerForm.controls[val] != null && this.repairerForm.controls[val] != undefined) {
                this.repairerForm.controls[val].reset();
            }
        });
        this.clearerrors();
    }
    cancelForm(){
        if(this.checkValueEnteredOrNot()===true){
         this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
         this.bsModalRef.content.modelTitle = '';
         this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
         this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
         this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
         this.bsModalRef.content.valueChange.subscribe((data) => {
             if (data === 'PROCEED') {
                 this.router.navigate(['/finance']);
             }         
         });
        }else{
            this.router.navigate(['/finance']);
        }
     }
    displayModifyButton(functionid) {
        return this.allowAccess.isAllowed(functionid);
    }
    checkValueEnteredOrNot(){
        let arrayFormFields = ['EnglishName', 'ArabicName', 'VatCode', 'VatRegistrationNumber', 'VatRate',
        'VatRegistrationCountry', 'Email', 'PhoneNumber', 'Mobile', 'FaxNumber', 'SerialNumber', 'EnglishAddress1',
        'ArabicAddress1', 'EnglishAddress2', 'ArabicAddress2', 'EnglishAddress3', 'ArabicAddress3', 'PostalCode', 'BeneficiaryBankName', 'BeneficiaryAccNo', 'IBAN',
        'BenBankAddress', 'BenSwiftCode', 'BenSortCode', 'CorrespondentBankName', 'CorrAccNo', 'CorrSwiftCode', 'CorrSortCode', 'CorrBankAddress', 'Fees',
        'ContactPerson', 'ExpenseTypeMotor', 'ExpenseTypeNonMotor', 'Status', 'VATRegnStrtDate', 'VATRegnEndDate'];
        let valueEntered:boolean=false;
        arrayFormFields.forEach((val) => {
            if (this.repairerForm.controls[val].value !=="" && this.repairerForm.controls[val].value !==null) {
                valueEntered=true;
            }
        });
        return valueEntered;
    }
}
