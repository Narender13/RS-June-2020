﻿import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { slideInOut } from '../../../../shared/animation/slidein';
import { AgentService } from './service/agent.service';
import { catchError, map, shareReplay } from 'rxjs/operators';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { SuccessDialogComponent } from 'src/app/shared/custom-success-model/custom-success-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
    selector: 'rsa-create-agent',
    templateUrl: './create-agent.component.html',
    styleUrls: ['./create-agent.component.scss'],
    animations: [slideInOut]
})

export class CreateAgentComponent implements OnInit {

    agentForm: FormGroup;
    isArabicField = false;
    address = false;
    address1 = false;
    address2 = false;
    submitted = false;
    today = new Date();
    previous = new Date('01/01/2000');
    branchList: any[];
    vatcodeList: any[];
    VatRegCountryList: any[];
    categoryList: any[];
    statusList: any[];
    acExecuteList: any[];
    returnValue: any;
    @Input() entityType: number;

    errorEname: boolean;
    errorEnameExists: boolean;
    errorElicno: boolean;
    errorElicnoExists: boolean;
    errorLicExpry: boolean;
    errorVatRegNo: boolean;
    errorVatRegNoExists: boolean;
    errorEmail: boolean;
    errorEmailExists: boolean;
    errorPhone: boolean;
    errorPhoneExists: boolean;
    errorMobile: boolean;
    errorMobileExists: boolean;
    errorBranch: boolean;
    errorEngAddress1: boolean;
    errorpostalcode: boolean;
    errorStatus: boolean;
    errorACExecutive: boolean;
    isUAE: boolean = false;
    selectedTypeVal: any;
    errorCategoryExists: boolean;
    errorStartDate: boolean = false;
    errorEndDate: boolean = false;
    errorStart: boolean = false;
    errorEnd: boolean = false;
    enableVATRegnEndDate: boolean = false;
    nextDay: Date;
    endDate: Date;
    functionIDModify: number = 400;

    @ViewChild('newCategoryname') private newCategoryname: ElementRef;
    // @ViewChild("newCategoryname") newCategoryname: ElementRef<HTMLElement, any>;
    isCategoryAdded: boolean;


    get agentStatus() { return this.agentForm.get('Status'); };
    get agentAcc_Executive() { return this.agentForm.get('Int_Acc_Executive'); };
    get agentEngAddress1() { return this.agentForm.get('EngAddress1'); };
    get agentpostalcode() { return this.agentForm.get('EngZIP'); };
    get agentEname() { return this.agentForm.get('EngName'); };
    get agentElicno() { return this.agentForm.get('E_Licence_No'); };
    get agentLicExpry() { return this.agentForm.get('LicenceEpiry'); };
    get agentVatRegNo() { return this.agentForm.get('VATRegistartionNo'); };
    get agentEmail() { return this.agentForm.get('EngEmail'); };
    get agentPhone() { return this.agentForm.get('PhoneNumber'); };
    get agentMobile() { return this.agentForm.get('MobileNumber'); };
    get agentBranch() { return this.agentForm.get('Branch'); };


    changeLicenceEpiry() {
        if (this.agentForm.controls['LicenceEpiry'].value) {
            const LicenceEpiry = new Date(this.agentForm.controls['LicenceEpiry'].value);
            this.agentForm.controls['LicenceEpiry'].setValue(new DatePipe('en-US').transform(LicenceEpiry, 'dd/MM/yyyy'));
        }
    }
    changeAppDate() {
        if (this.agentForm.controls['AppDate'].value) {
            const AppDate = new Date(this.agentForm.controls['AppDate'].value);
            this.agentForm.controls['AppDate'].setValue(new DatePipe('en-US').transform(AppDate, 'dd/MM/yyyy'));
        }
    }



    fieldStatusChanges() {
        this.clearerrors();
        this.agentEname.statusChanges.subscribe(
            status => { this.errorEname = (status == 'INVALID'); }
        );
        this.agentElicno.statusChanges.subscribe(
            status => {
                this.errorElicno = (status == 'INVALID');
            }
        );
        this.agentLicExpry.statusChanges.subscribe(
            status => { this.errorLicExpry = (status == 'INVALID'); }
        );
        this.agentVatRegNo.statusChanges.subscribe(
            status => { this.errorVatRegNo = (status == 'INVALID'); }
        );
        this.agentEmail.statusChanges.subscribe(
            status => { this.errorEmail = (status == 'INVALID'); }
        );
        this.agentPhone.statusChanges.subscribe(
            status => { this.errorPhone = (status == 'INVALID'); }
        );
        this.agentMobile.statusChanges.subscribe(
            status => { this.errorMobile = (status == 'INVALID'); }
        );
        this.agentBranch.statusChanges.subscribe(
            status => { this.errorBranch = (status == 'INVALID'); }
        );
        this.agentEngAddress1.statusChanges.subscribe(
            status => { this.errorEngAddress1 = (status == 'INVALID'); }
        );
        this.agentpostalcode.statusChanges.subscribe(
            status => { this.errorpostalcode = (status == 'INVALID'); }
        );
        this.agentStatus.statusChanges.subscribe(
            status => { this.errorStatus = (status == 'INVALID'); }
        );
        this.agentAcc_Executive.statusChanges.subscribe(
            status => { this.errorACExecutive = (status == 'INVALID'); }
        );
    }

    clearerrors() {
        this.errorEname = false;
        this.errorElicno = false;
        this.errorLicExpry = false;
        this.errorVatRegNo = false;
        this.errorEmail = false;
        this.errorPhone = false;
        this.errorMobile = false;
        this.errorBranch = false;
        this.errorpostalcode = false;
        this.errorEngAddress1 = false;
        this.errorEnameExists = false;
        this.errorElicnoExists = false;
        this.errorVatRegNoExists = false;
        this.errorEmailExists = false;
        this.errorPhoneExists = false;
        this.errorMobileExists = false;
        this.errorStatus = false;
        this.errorACExecutive = false;
        this.errorStart = false;
        this.errorEnd = false;
        this.errorStartDate = false;
        this.errorEndDate = false;
    }

    get f() { return this.agentForm.controls; }

    constructor(private fb: FormBuilder, protected agentService: AgentService, public bsModalRef: BsModalRef, private modalService: BsModalService, private router: Router, private allowAccess: UserAutherizationService) { }

    ngOnInit() {
        this.createEntityForm();
        this.fieldStatusChanges();
        this.getBranchNames();
        this.getVATCode();
        this.getVATRegCountry();
        this.getCategory();
        this.getStatus();
        this.getACExecute();
        this.isUAE = (sessionStorage.getItem('regioncode') == '2') ? true : false;
        if (this.isUAE) {
            this.formControlAddValidator();
        }
        else {
            this.formControlClearValidator();
        }
        this.errorVatRegNo = false;
    }
    formControlClearValidator() {
        const VATRegistartionNo = this.agentForm.get('VATRegistartionNo');
        VATRegistartionNo.clearValidators();
        VATRegistartionNo.updateValueAndValidity();
    }
    formControlAddValidator() {
        const VATRegistartionNo = this.agentForm.get('VATRegistartionNo');
        // VATRegistartionNo.setValidators([Validators.required]);
        this.errorVatRegNo = false;
        VATRegistartionNo.updateValueAndValidity();
    }

    setVatRate(vatvalue: number) {
        this.vatcodeList.forEach(element => {
            if (element.Code == vatvalue) {
                this.agentForm.controls['VATRate'].setValue(element.VATRate);
            }
        });
    }

    getBranchNames() {
        const param = 'ctyCode=' + sessionStorage.getItem('countrycode') +
            '&regCode=' + sessionStorage.getItem('regioncode');
        this.agentService.getBranchNames(param).subscribe(
            dataReturn => {
                //console.log("data1" + JSON.stringify(dataReturn));
                this.branchList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getVATCode() {
        this.agentService.getVATCode().subscribe(
            dataReturn => {
                this.vatcodeList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getVATRegCountry() {
        this.agentService.getVATRegCountry().subscribe(
            dataReturn => {
                this.VatRegCountryList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getCategory() {
        const param = 'entityType=' + 2;
        this.agentService.getCategory(param).subscribe(
            dataReturn => {
                this.categoryList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getStatus() {
        this.agentService.getStatus().subscribe(
            dataReturn => {
                this.statusList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getACExecute() {
        this.agentService.getACExecute().subscribe(
            dataReturn => {
                this.acExecuteList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    changeStartDate(sValue: Date) {
        if (sValue) {
            this.enableVATRegnEndDate = true;
            this.errorStartDate = true;
            this.nextDay = new Date(sValue);
            this.nextDay.setDate(sValue.getDate() + 1);
        }
    }
    changeEndDate(eValue: Date) {
        if (eValue) {
            this.errorEndDate = true;
            this.endDate = new Date(eValue);
            this.endDate.setDate(eValue.getDate() - 1);
        }
    }
    changeStartDateValue() {
        if (this.agentForm.controls['VATRegnStrtDate'].value) {
            const RegistrationExpiry = new Date(this.agentForm.controls['VATRegnStrtDate'].value);
            this.agentForm.controls['VATRegnStrtDate'].setValue(new DatePipe('en-US').transform(RegistrationExpiry, 'dd/MM/yyyy'));
        }
    }
    changeEndDateValue() {
        if (this.agentForm.controls['VATRegnEndDate'].value) {
            const RegistrationExpiry = new Date(this.agentForm.controls['VATRegnEndDate'].value);
            this.agentForm.controls['VATRegnEndDate'].setValue(new DatePipe('en-US').transform(RegistrationExpiry, 'dd/MM/yyyy'));
        }
    }

    createEntityForm(): void {
        this.agentForm = this.fb.group({
            // Code: [1],
            EngName: ['', Validators.required],
            ArabicName: [''],
            E_Licence_No: ['', Validators.required],
            LicenceEpiry: ['', Validators.required],
            VATCode: [''],
            VATRegistartionNo: ['', Validators.required],
            EngEmail: ['', [Validators.required, Validators.email]],
            PhoneNumber: ['', Validators.required],
            MobileNumber: ['', Validators.required],
            Fax: [''],
            Branch: [sessionStorage.getItem('locationcode'), Validators.required],
            VATRate: [''],
            VATRegistrationCountry: [''],
            EngAddress1: ['', Validators.required],
            ArabicAddress1: [''],
            EngAddress2: [''],
            ArabicAddress2: [''],
            EngAddress3: [''],
            ArabicAddress3: [''],
            POBox: [''],
            EngZIP: ['', Validators.required],
            AgentGroup: [''],
            Remarks: [''],
            Category: [''],
            AppDate: [''],
            Status: ['', Validators.required],
            VATRegnStrtDate: [''],
            VATRegnEndDate: [''],
            Int_Acc_Executive: ['', Validators.required],
            PreparedBy: [sessionStorage.getItem('LoggedInUserId')],
            IsValid: [0]
        });
    }

    setErrorInvalid() {
        this.errorEname = this.agentEname.invalid;
        this.errorElicno = this.agentElicno.invalid;
        this.errorLicExpry = this.agentLicExpry.invalid;
        this.errorVatRegNo = this.agentVatRegNo.invalid;
        this.errorEmail = this.agentEmail.invalid;
        this.errorPhone = this.agentPhone.invalid;
        this.errorMobile = this.agentMobile.invalid;
        this.errorBranch = this.agentBranch.invalid;
        this.errorpostalcode = this.agentpostalcode.invalid;
        this.errorEngAddress1 = this.agentEngAddress1.invalid;
        this.errorACExecutive = this.agentAcc_Executive.invalid;
        this.errorStatus = this.agentStatus.invalid;
    }

    submitForm() {
        //this.submitted = true;
        this.setErrorInvalid();
        // stop here if form is invalid
        if (this.agentForm.invalid) {
            return;
        }
        if (this.errorStartDate != this.errorEndDate) {

            if (this.errorStartDate == false) {
                this.errorStart = true;
                return false;
            }
            else {
                this.errorEnd = true;
                return false;
            }
        }

        else {
            console.log("\n second form values" + JSON.stringify(this.agentForm.value) + "\n");
            let clonedAgentForm: any = this.agentForm.value;
            if (this.isCategoryAdded) {
                clonedAgentForm.AgtCategory = { "Code": this.agentForm.controls['Category'].value, "EngDesc": this.isCategoryAdded ? this.categoryList[this.categoryList.length - 1].E_desc : "", "ArabicDesc": this.isCategoryAdded ? this.categoryList[this.categoryList.length - 1].E_desc : "", "IsNewSel": this.agentForm.controls['Category'].value === '0' ? true : false };
            } else {
                clonedAgentForm.AgtCategory = null;
            }
            console.log("cloned values\n" + JSON.stringify(clonedAgentForm));
            this.agentService.createAgent(JSON.stringify(clonedAgentForm)).subscribe(
                dataReturn => {
                    this.returnValue = dataReturn;
                    console.log(this.returnValue, 'this.returnValue');
                    //success modal
                    if (this.returnValue.IsValid == 0) {
                        this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                        this.bsModalRef.content.modelTitle = '';
                        this.bsModalRef.content.modelBodyContent = "Agent Successfully Created";
                        this.bsModalRef.content.smallMessage = "ID: " + this.returnValue.Code;
                        this.bsModalRef.content.bigMessage = " Agent Name: " + this.returnValue.EngName;
                        this.bsModalRef.content.actionBtn = "Close";
                        this.bsModalRef.content.valueChange.subscribe((data) => {
                            console.log(" success datat" + data);
                            if (data == 'Close') {
                                console.log("close btn clicked");
                            } else {
                                console.log(" else close");
                            }
                            this.resetForm();
                        });
                    }
                    else if (this.returnValue.IsValid == 1) {
                        //alert modal
                        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                        this.bsModalRef.content.modelTitle = '';
                        this.bsModalRef.content.modelBodyContent = "Alert! Other than VAT Registration Number remaining fields  already exists";
                        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
                        this.bsModalRef.content.actionBtn = "Proceed";
                        this.bsModalRef.content.valueChange.subscribe((data) => {
                            console.log("datat" + data);
                            if (data = 'Proceed') {
                                console.log("proceed btn clicked");
                                this.agentForm.value.IsValid = 1;
                                this.submitForm();
                            }

                            else {
                                console.log(" else close");
                            }
                        });
                        //end for alert modal
                    }
                    else if (this.returnValue.IsValid == 2) {
                        this.errorEnameExists = true;
                        this.errorElicnoExists = true;
                        this.errorVatRegNoExists = true;
                        this.errorEmailExists = true;
                        this.errorPhoneExists = true;
                        this.errorMobileExists = true;
                    }
                },
                errorRturn => {
                    console.log(errorRturn);
                }
            );
        }
    }

    resetForm() {
        let arrayFormFields = ['EngName', 'E_Licence_No', 'LicenceEpiry', 'VATCode', 'VATRegistartionNo', 'EngEmail', 'PhoneNumber', 'MobileNumber', 'VATRegnStrtDate',
            'Fax', 'VATRate', 'VATRegistrationCountry', 'EngAddress1', 'ArabicAddress1', 'EngAddress2', 'ArabicAddress2', 'EngAddress3', 'ArabicAddress3',
            'POBox', 'EngZIP', 'AgentGroup', 'Remarks', 'Category', 'AppDate', 'Status', 'Int_Acc_Executive', 'VATRegnEndDate'];

        this.agentForm.controls['IsValid'].reset(0);
        arrayFormFields.forEach((val) => {
            if (this.agentForm.controls[val] != null && this.agentForm.controls[val] != undefined) {
                this.agentForm.controls[val].reset();
            }
        });
        this.clearerrors();
    }



    addNewCategory(catValue: any) {
        if (catValue === 'newCategoryType') {
            console.log(catValue + " new category " + this.agentForm.controls['Category'].value);
            this.selectedTypeVal = catValue;
            this.agentForm.controls['Category'].setValue("");
        }

    }
    addToCateroryList() {
        this.newCategoryname.nativeElement.value = this.newCategoryname.nativeElement.value.trim();
        if (this.newCategoryname.nativeElement.value) {
            if (this.checkDuplicatesInCategoryList() == true) {
                console.log("gggg");
                this.errorCategoryExists = true;
            } else {
                let newCategory: any = { "Code": 0, "E_desc": this.newCategoryname.nativeElement.value };
                this.isCategoryAdded = true;
                this.categoryList.push(newCategory);
                // this.agentForm.controls['Category'].setValue("");
                this.selectedTypeVal = "";
                this.errorCategoryExists = false;
            }

        }
    }
    hideAddCategory() {
        this.agentForm.controls['Category'].setValue("");
        this.selectedTypeVal = "";
        this.errorCategoryExists = false;
    }
    checkDuplicatesInCategoryList() {
        let duplicateValueExists: boolean = false;
        this.categoryList.forEach((item) => {
            if (this.newCategoryname.nativeElement.value == item.E_desc) {
                duplicateValueExists = true;
            }
        });
        return duplicateValueExists;
    }
    cancelForm() {
        if (this.checkValueEnteredOrNot() === true) {
            this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
            this.bsModalRef.content.modelTitle = '';
            this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
            this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
            this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
            this.bsModalRef.content.valueChange.subscribe((data) => {
                if (data === 'PROCEED') {
                    this.router.navigate(['/finance']);
                }
            });
        } else {
            this.router.navigate(['/finance']);
        }
    }
    displayModifyButton(functionid) {
        return this.allowAccess.isAllowed(functionid);
    }
    checkValueEnteredOrNot() {
        let arrayFormFields = ['EngName', 'ArabicName', 'E_Licence_No', 'LicenceEpiry', 'VATCode', 'VATRegistartionNo', 'EngEmail', 'PhoneNumber', 'MobileNumber',
            'Fax', 'VATRate', 'VATRegistrationCountry', 'EngAddress1', 'ArabicAddress1', 'EngAddress2', 'ArabicAddress2', 'EngAddress3', 'ArabicAddress3',
            'POBox', 'EngZIP', 'AgentGroup', 'Remarks', 'Category', 'AppDate', 'Status', 'Int_Acc_Executive', 'VATRegnStrtDate', 'VATRegnEndDate'];
        let valueEntered: boolean = false;
        arrayFormFields.forEach((val) => {
            if (this.agentForm.controls[val].value !== "") {
                valueEntered = true;
            }
        });
        return valueEntered;
    }

}

