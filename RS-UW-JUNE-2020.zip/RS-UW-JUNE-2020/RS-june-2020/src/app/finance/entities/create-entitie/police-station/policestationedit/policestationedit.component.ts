import { Component, OnInit,Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { slideInOut } from '../../../../../shared/animation/slidein';
import { PolicestationService } from '../service/policestation.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { SuccessDialogComponent } from 'src/app/shared/custom-success-model/custom-success-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { catchError, map, shareReplay } from 'rxjs/operators';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
  selector: 'rsa-policestationedit',
  templateUrl: './policestationedit.component.html',
  styleUrls: ['./policestationedit.component.scss'],
  animations: [slideInOut]
})
export class PolicestationeditComponent implements OnInit {

  policeStationForm: FormGroup;  
    isArabicField = false;
    address = false;
    address1 = false;
    address2 = false;
    submitted = false;
    errorDesc: boolean;
    errorEngAddress1: boolean;
    errorEngAddress2: boolean;
    errorEngAddress3: boolean;
    returnValue: any;
    errorDescExists:boolean;
    @Input() entityCode:number;
    editFormOption:boolean;
    functionIDModify:number=405;
    constructor(private fb: FormBuilder, protected policeStationService: PolicestationService,public bsModalRef: BsModalRef,
        private modalService: BsModalService,private allowAccess: UserAutherizationService) { }
    ngOnInit() {
        this.createEntiteForm();
        this.fieldStatusChanges();
        this.getPoliceStationDetails();
        this.policeStationForm.disable();
    }  
    createEntiteForm(): void {
        this.policeStationForm = this.fb.group({
            Code:[this.entityCode],
            DescriptionEnglish: ['', Validators.required],
            DescriptionArabic:[''],
            EngAddress1: ['', Validators.required],
            EngAddress2: ['', Validators.required],
            EngAddress3: ['', Validators.required],
            ArabicAddress1: [''],
            ArabicAddress2: [''],
            ArabicAddress3: [''],
            Type: [''],
            ModifiedByStr: [sessionStorage.getItem('userId')],
            IsValid:[0]
        });
    } 
    clearerrors() {
        this.errorDesc = false;
        this.errorEngAddress1 = false;
        this.errorEngAddress2 = false;
        this.errorEngAddress3 = false;
        this.errorDescExists=false;
    }
    get policDesc() {
        return this.policeStationForm.get('DescriptionEnglish');
    }
    get policEngAddress1() {
        return this.policeStationForm.get('EngAddress1');
    }
    get policEngAddress2() {
        return this.policeStationForm.get('EngAddress2');
    }
    get policEngAddress3() {
        return this.policeStationForm.get('EngAddress3');
    }
    fieldStatusChanges() {

        this.clearerrors();

        this.policDesc.statusChanges.subscribe(
            status => {
                this.errorDesc = (status == 'INVALID');
            }
        );
        this.policEngAddress1.statusChanges.subscribe(
            status => {
                this.errorEngAddress1 = (status == 'INVALID');
            }
        );
        this.policEngAddress2.statusChanges.subscribe(
            status => {
                this.errorEngAddress2 = (status == 'INVALID');
            }
        );
        this.policEngAddress3.statusChanges.subscribe(
            status => {
                this.errorEngAddress3 = (status == 'INVALID');
            }
        );
    }         
    setPoliceStationFormValues() {
        let clonedFormValues: any = {  
                "DescriptionEnglish":this.policeStationForm.value.DescriptionEnglish,
                "DescriptionArabic":this.policeStationForm.value.DescriptionArabic,         
                "address":{  
                "ArabicAddress1":this.policeStationForm.value.ArabicAddress1,
                "EngAddress1":this.policeStationForm.value.EngAddress1,
                "ArabicAddress2":this.policeStationForm.value.ArabicAddress2,
                "EngAddress2":this.policeStationForm.value.EngAddress2,
                "ArabicAddress3":this.policeStationForm.value.ArabicAddress3,
                "EngAddress3":this.policeStationForm.value.EngAddress3
                },  
                "Type":this.policeStationForm.value.Type,
                "ModifiedBy":this.policeStationForm.value.ModifiedByStr,
             "Code":this.policeStationForm.value.Code
            }
        return clonedFormValues;     
    } 
    submitForm() {
        this.errorDesc = this.policDesc.invalid;
        this.errorEngAddress1 = this.policEngAddress1.invalid;
        this.errorEngAddress2 = this.policEngAddress2.invalid;
        this.errorEngAddress3 = this.policEngAddress3.invalid; 
        if (this.policeStationForm.invalid) {
            return;
        }      
        else {    
            let clonePoliceStationForm: any = this.setPoliceStationFormValues();  
           console.log(JSON.stringify(clonePoliceStationForm), 'second form');
            this.policeStationService.updatePoliceStation(JSON.stringify(clonePoliceStationForm)).subscribe(
                dataReturn => {         
                    this.returnValue = dataReturn; 
                    console.log(this.returnValue, 'this.returnValue'); 
                    if(this.returnValue.IsValid==0){
                        this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                        this.bsModalRef.content.modelTitle = '';
                        this.bsModalRef.content.modelBodyContent ="Police Station successfully updated.";
                     //   this.bsModalRef.content.smallMessage="ID: "+this.returnValue.Code;
                      //  this.bsModalRef.content.bigMessage = this.returnValue.EngName;
                        this.bsModalRef.content.actionBtn ="Close";
                        this.bsModalRef.content.valueChange.subscribe((data) => {
                            console.log(" success datat" + data);
                            if(data=='Close'){
                                console.log("close btn clicked");
                            }else {
                                console.log(" else close");
                            }
                            this.editFormOption=false;
                            this.policeStationForm.disable();
                            this.clearerrors();
                        });
                   }
                   else if(this.returnValue.IsValid==2){
                    this.errorDescExists=true;
                   } 
                });
            errorRturn => {
                console.log(errorRturn);
            } 
      }
    }   
    getPoliceStationDetails(){
        const param = 'Code=' + this.entityCode;   
        this.policeStationService.getPoliceStationDetails(param).subscribe(
            dataReturn => { 
                console.log("police station data" + JSON.stringify(dataReturn));
                let arrayFormFields = ['DescriptionEnglish', 'DescriptionArabic','Type'];
                let addressInfo=[ 'EngAddress1', 'EngAddress2', 'EngAddress3',
                'ArabicAddress1', 'ArabicAddress2', 'ArabicAddress3'];
                arrayFormFields.forEach((val) => {
                    if (dataReturn[val] != null && dataReturn[val] != undefined) {
                      this.policeStationForm.controls[val].setValue(dataReturn[val]);
                    }
                  });   
                  addressInfo.forEach((val) => {
                    if (dataReturn['address'][val] != null && dataReturn['address'][val] != undefined) {
                      this.policeStationForm.controls[val].setValue(dataReturn['address'][val]);
                    }
                  });  
            }, 
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    policeStationEdit(){
        this.editFormOption=true;
        this.policeStationForm.enable();
     }
     displayModifyButton(functionid){
        return this.allowAccess.isAllowed(functionid);
      }
}  
