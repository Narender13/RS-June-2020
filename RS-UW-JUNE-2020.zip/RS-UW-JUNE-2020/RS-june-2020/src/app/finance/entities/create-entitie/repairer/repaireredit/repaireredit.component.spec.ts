import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RepairereditComponent } from './repaireredit.component';

describe('RepairereditComponent', () => {
  let component: RepairereditComponent;
  let fixture: ComponentFixture<RepairereditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RepairereditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RepairereditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
