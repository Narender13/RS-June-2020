import { Injectable } from '@angular/core';
import { HttpHeaders, HttpErrorResponse, HttpClient, HttpParams, } from '@angular/common/http';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { catchError, map, shareReplay } from 'rxjs/operators'; 

@Injectable({
  providedIn: 'root'
})
export class RecoveryService {

    constructor(private http: HttpClient) { }

    getRecoveryDetails(params: any) {
        return this.http.get<any>(RSAENDPOINTConstants.GETRECOVERY + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getRecoveryDetails')));
    }
    updateRecoveryDetails(params: any) {
        return this.http.put<any>(RSAENDPOINTConstants.UPDATERECOVERY, params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updateRecoveryDetails')));
    }
    createRecovery(params: any) {
        return this.http.post<any>(RSAENDPOINTConstants.CREATERECOVERY, params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createRecovery')));
    }
    getVATCode() {
        return this.http.get<any>(RSAENDPOINTConstants.VATCODE).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getVATCode')));
    } 
    getVATRegCountry() {
        return this.http.get<any>(RSAENDPOINTConstants.VATREGISTRATIONCOUNTRY).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getVATRegCountry')));
    } 
    getBranchNames(params: any) {
        return this.http.get<any>(RSAENDPOINTConstants.GETBranch + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getBranchNames')));
    } 
    getType() {
        return this.http.get<any>(RSAENDPOINTConstants.RECOVERYTYPE).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getType')));
    } 
    getStatus() {
        return this.http.get<any>(RSAENDPOINTConstants.STATUS).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getStatus')));
    } 
}
