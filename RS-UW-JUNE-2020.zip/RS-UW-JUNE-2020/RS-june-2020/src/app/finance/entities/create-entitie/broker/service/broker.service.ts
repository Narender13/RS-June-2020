import { Injectable } from '@angular/core';
import { HttpHeaders, HttpErrorResponse, HttpClient, HttpParams, } from '@angular/common/http';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { catchError, map, shareReplay } from 'rxjs/operators'; 

@Injectable({
  providedIn: 'root'
})
export class BrokerService {

    constructor(private http: HttpClient) { }
    createBroker(params: any) {
        return this.http.post<any>(RSAENDPOINTConstants.CREATEBROKER, params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createBroker')));
    }
 
   getPayeeBankNames() {
        return this.http.get<any>(RSAENDPOINTConstants.LOADPAYEEBANKNAMES).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPayeeBankNames')));

  } 
   getBranchNames(params: any) {
       return this.http.get<any>(RSAENDPOINTConstants.GETBranch + params).pipe(
           map(res => res),
           catchError(handleErrorObservable<any>('getBranchNames')));
   } 
  
   getvatcode() {
       return this.http.get<any>(RSAENDPOINTConstants.VATCODE).pipe(
           map(res => res),
           catchError(handleErrorObservable<any>('getvatcode')));

   }
   getnationality() {
       return this.http.get<any>(RSAENDPOINTConstants.NATIONALITY).pipe(
           map(res => res),
           catchError(handleErrorObservable<any>('getnationality')));

   }
   getvatregcountry() {
       return this.http.get<any>(RSAENDPOINTConstants.VATREGISTRATIONCOUNTRY).pipe(
           map(res => res),
           catchError(handleErrorObservable<any>('getvatregcountry')));

   }
   getcorrbankname() {
       return this.http.get<any>(RSAENDPOINTConstants.LOADPAYEEBANKNAMES).pipe(
           map(res => res),
           catchError(handleErrorObservable<any>('getcorrbankname')));

   }
   getcategory(params:any) {
       return this.http.get<any>(RSAENDPOINTConstants.BRCATEGORY+params).pipe(
           map(res => res),
           catchError(handleErrorObservable<any>('getcategory')));

   }
   getstatus() {
       return this.http.get<any>(RSAENDPOINTConstants.STATUS).pipe(
           map(res => res),
           catchError(handleErrorObservable<any>('getstatus')));

   }
   getacexecutive() {
       return this.http.get<any>(RSAENDPOINTConstants.ACCOUNTEXECUTIVE).pipe(
           map(res => res),
           catchError(handleErrorObservable<any>('getacexecutive')));

   }
   getBrokerDetails(params: any) {
       return this.http.get<any>(RSAENDPOINTConstants.GETBROKER + params).pipe(
           map(res => res),
           catchError(handleErrorObservable<any>('getBrokerDetails')));
   }
   updateBrokerDetails(params: any) {
       return this.http.put<any>(RSAENDPOINTConstants.UPDATEBROKER, params).pipe(
           map(res => res),
           catchError(handleErrorObservable<any>('updateBrokerDetails')));
   }
   getqualification() {
    return this.http.get<any>(RSAENDPOINTConstants.QUALIFICATION).pipe(
        map(res => res),
        catchError(handleErrorObservable<any>('getqualification')));

}
  

}
