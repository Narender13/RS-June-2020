import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { slideInOut } from '../../../../../shared/animation/slidein';
import { SurveyorService } from '../service/surveyor.service';
import { catchError, map, shareReplay } from 'rxjs/operators';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { SuccessDialogComponent } from 'src/app/shared/custom-success-model/custom-success-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { DatePipe } from '@angular/common';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
@Component({
    selector: 'rsa-edit-surveyor',
    templateUrl: './edit-surveyor.component.html',
    styleUrls: ['./edit-surveyor.component.scss'],
    animations: [slideInOut]
})
export class EditSurveyorComponent implements OnInit {
    surveyorForm: FormGroup;
    submitted = false;
    isArabicField = false;
    address = false;
    address1 = false;
    address2 = false;
    errorName: boolean;
    errorlicensenumberE: boolean;
    errorlicensenumberA: boolean;
    erroremail: boolean;
    errorphonenumber: boolean;
    errorMobileNo: boolean;
    erroraddress: boolean;
    erroraddress3: boolean;
    erroraddress4: boolean;
    errorBeneficiaryBankName: boolean;
    errorCorrespondentBankName: boolean;
    errornationality: boolean;
    errorlicenseexpirydate: boolean;
    errorEngNameExists: boolean;
    errorE_Licence_NoExists: boolean;
    errorPhoneNumberExists: boolean;
    errorMobileNumberExists: boolean;
    errorEngEmailExists: boolean;
    bankNamesList: any[];
    corrbanknameList: any[];
    nationalityList: any[];
    specializationList: any[];
    statusList: any[];
    ratingList: any[];
    qualificationList: any[];
    returnValue: any;
    isOman: any;
    @Input() entityCode: number;
    editFormOption: boolean;
    today = new Date();
    previous = new Date('01/01/2019');
    selectedTypeVal: any;
    selectedrating: any;
    errorCategoryExists: boolean;
    @ViewChild('newSpecialization') private newSpecialization: ElementRef;
    @ViewChild('newRating') private newRating: ElementRef;
    isCategoryAdded: boolean;
    isRatingAdded: boolean;
    errorRatingExists: boolean;
    functionIDModify: number = 408;
    errorStartDate: boolean = false;
    errorEndDate: boolean = false;
    errorStart: boolean = false;
    errorEnd: boolean = false;
    enableVATRegnEndDate: boolean;
    nextDay: Date;
    endDate: Date;

    isUAE: boolean = false;

    constructor(private fb: FormBuilder, protected surveyorservice: SurveyorService,
        public bsModalRef: BsModalRef, private modalService: BsModalService, private allowAccess: UserAutherizationService) { }
    ngOnInit() {
        this.createEntityForm();
        this.fieldStatusChanges();
        this.getPayeeBankNames();
        this.getcorrbankname();
        this.getNationality();
        this.getstatus();
        this.getspecialization();
        this.getrating();
        this.getqualification();
        this.getSurveyorDetails();
        this.surveyorForm.disable();
        this.isOman = sessionStorage.getItem('regioncode') == '3' ? true : false;
        this.isUAE = (sessionStorage.getItem('regioncode') == '2') ? true : false;
    }

    get Namedesc() {
        return this.surveyorForm.get('EngName');
    };
    get licensenumberEdesc() {
        return this.surveyorForm.get('E_Licence_No');
    };
    get licensenumberAdesc() {
        return this.surveyorForm.get('A_Licence_No');
    }
    get emaildesc() {
        return this.surveyorForm.get('EngEmail');
    }
    get phonenumberdesc() {
        return this.surveyorForm.get('PhoneNumber');
    }
    get MobileNodesc() {
        return this.surveyorForm.get('MobileNumber');
    }
    get addressdesc() {
        return this.surveyorForm.get('EngAddress1');
    }
    get address3desc() {
        return this.surveyorForm.get('BenBankAddress');
    }
    get address4desc() {
        return this.surveyorForm.get('CorrBankAddress');
    }
    get BeneficiaryBankNamedesc() {
        return this.surveyorForm.get('BeneficiaryBankName');
    }
    get CorrespondentBankNamedesc() {
        return this.surveyorForm.get('CorrespondentBankName');
    }
    get nationalitydesc() {
        return this.surveyorForm.get('Nationality');
    }
    get licenseexpirydatedesc() {
        return this.surveyorForm.get('LicenceEpiry');
    }
    fieldStatusChanges() {

        this.clearerrors();
        this.Namedesc.statusChanges.subscribe(
            status => {
                this.errorName = (status == 'INVALID');
            }
        );

        this.licensenumberEdesc.statusChanges.subscribe(
            status => {
                this.errorlicensenumberE = (status == 'INVALID');
            }
        );

        this.licensenumberAdesc.statusChanges.subscribe(
            status => {
                this.errorlicensenumberA = (status == 'INVALID');
            }
        );

        this.emaildesc.statusChanges.subscribe(
            status => {
                this.erroremail = (status == 'INVALID');
            }
        );

        this.phonenumberdesc.statusChanges.subscribe(
            status => {
                this.errorphonenumber = (status == 'INVALID');
            }
        );
        this.MobileNodesc.statusChanges.subscribe(
            status => {
                this.errorMobileNo = (status == 'INVALID');
            }
        );
        this.addressdesc.statusChanges.subscribe(
            status => {
                this.erroraddress = (status == 'INVALID');
            }
        );
        this.address3desc.statusChanges.subscribe(
            status => {
                this.erroraddress3 = (status == 'INVALID');
            }
        );
        this.address4desc.statusChanges.subscribe(
            status => {
                this.erroraddress4 = (status == 'INVALID');
            }
        );
        this.BeneficiaryBankNamedesc.statusChanges.subscribe(
            status => {
                this.errorBeneficiaryBankName = (status == 'INVALID');
            }
        );
        this.CorrespondentBankNamedesc.statusChanges.subscribe(
            status => {
                this.errorCorrespondentBankName = (status == 'INVALID');
            }
        );
        this.nationalitydesc.statusChanges.subscribe(
            status => {
                this.errornationality = (status == 'INVALID');
            }
        );
        this.licenseexpirydatedesc.statusChanges.subscribe(
            status => {
                this.errorlicenseexpirydate = (status == 'INVALID');
            }
        );
    }
    clearerrors() {
        this.errorName = false;
        this.errorlicensenumberE = false;
        this.errorlicensenumberA = false;
        this.erroremail = false;
        this.errorphonenumber = false;
        this.errorMobileNo = false;
        this.erroraddress = false;
        this.erroraddress3 = false;
        this.erroraddress4 = false;
        this.errorBeneficiaryBankName = false;
        this.errorCorrespondentBankName = false;
        this.errornationality = false;
        this.errorlicenseexpirydate = false;
        this.errorEngNameExists = false;
        this.errorE_Licence_NoExists = false;
        this.errorPhoneNumberExists = false;
        this.errorMobileNumberExists = false;
        this.errorEngEmailExists = false;
        this.errorStart = false;
        this.errorEnd = false;
        this.errorStartDate = false;
        this.errorEndDate = false;
    }

    changelicenseexpiryDate() {
        if (this.surveyorForm.controls['LicenceEpiry'].value) {
            const LicenceEpiry = new Date(this.surveyorForm.controls['LicenceEpiry'].value);
            this.surveyorForm.controls['LicenceEpiry'].setValue(new DatePipe('en-US').transform(LicenceEpiry, 'dd/MM/yyyy'));
        }
    }
    ChangeempanelDate() {
        if (this.surveyorForm.controls['Empanel'].value) {
            const Empanel = new Date(this.surveyorForm.controls['Empanel'].value);
            this.surveyorForm.controls['Empanel'].setValue(new DatePipe('en-US').transform(Empanel, 'dd/MM/yyyy'));
        }
    }
    changeStartDate(sValue: Date) {
        if (sValue) {
            this.surveyorForm.controls.VATRegnEndDate.enable();
            this.errorStartDate = true;
            this.nextDay = new Date(sValue);
            this.nextDay.setDate(sValue.getDate() + 1);
        }
    }
    changeEndDate(eValue: Date) {
        if (eValue) {
            this.errorEndDate = true;
            this.endDate = new Date(eValue);
            this.endDate.setDate(eValue.getDate() - 1);
        }
    }
    changeStartDateValue() {
        if (this.surveyorForm.controls['VATRegnStrtDate'].value) {
            const RegistrationExpiry = new Date(this.surveyorForm.controls['VATRegnStrtDate'].value);
            this.surveyorForm.controls['VATRegnStrtDate'].setValue(new DatePipe('en-US').transform(RegistrationExpiry, 'dd/MM/yyyy'));
        }
    }
    changeEndDateValue() {
        if (this.surveyorForm.controls['VATRegnEndDate'].value) {
            const RegistrationExpiry = new Date(this.surveyorForm.controls['VATRegnEndDate'].value);
            this.surveyorForm.controls['VATRegnEndDate'].setValue(new DatePipe('en-US').transform(RegistrationExpiry, 'dd/MM/yyyy'));
        }
    }

    createEntityForm(): void {
        this.surveyorForm = this.fb.group({
            Code: [this.entityCode],
            EngName: ['', Validators.required],
            ArabicName: [''],
            E_Licence_No: ['', Validators.required],
            A_Licence_No: ['', Validators.required],
            LicenceEpiry: ['', Validators.required],
            Empanel: [''],
            EngEmail: ['', [Validators.required, Validators.email]],
            PhoneNumber: ['', Validators.required],
            MobileNumber: ['', Validators.required],
            Fax: [''],
            Nationality: ['', Validators.required],
            EngAddress1: ['', Validators.required],
            ArabicAddress1: [''],
            EngAddress2: [''],
            ArabicAddress2: [''],
            EngAddress3: [''],
            ArabicAddress3: [''],
            EngZIP: [''],
            BeneficiaryBankName: ['', Validators.required],
            BeneficiaryAccNo: [''],
            IBAN: [''],
            BenBankAddress: ['', Validators.required],
            BenSwiftCode: [''],
            BenSortCode: [''],
            CorrespondentBankName: ['', Validators.required],
            CorrAccNo: [''],
            CorrSwiftCode: [''],
            CorrSortCode: [''],
            CorrBankAddress: ['', Validators.required],
            Qualification: [''],
            Specilisation: [''],
            Survey: [''],
            Rating: [''],
            Status: [''],
            VATRegnStrtDate: [''],
            VATRegnEndDate: [''],
            ModifiedBy: [sessionStorage.getItem('LoggedInUserId')],
            IsValid: [0]
        });
    }
    get f() { return this.surveyorForm.controls; }
    setErrorInvalid() {
        this.errorName = this.Namedesc.invalid;
        this.errorlicensenumberE = this.licensenumberEdesc.invalid;
        this.errorlicensenumberA = this.licensenumberAdesc.invalid;
        this.erroremail = this.emaildesc.invalid;
        this.errorphonenumber = this.phonenumberdesc.invalid;
        this.errorMobileNo = this.MobileNodesc.invalid;
        this.erroraddress = this.addressdesc.invalid;
        this.erroraddress3 = this.address3desc.invalid;
        this.erroraddress4 = this.address4desc.invalid;
        this.errorBeneficiaryBankName = this.BeneficiaryBankNamedesc.invalid;
        this.errorCorrespondentBankName = this.CorrespondentBankNamedesc.invalid;
        this.errornationality = this.nationalitydesc.invalid;
        this.errorlicenseexpirydate = this.licenseexpirydatedesc.invalid;
    }
    submitForm() {
        this.setErrorInvalid();
        // stop here if form is invalid
        if (this.surveyorForm.invalid) {
            return;
        }
        if (this.errorStartDate != this.errorEndDate) {

            if (this.errorStartDate == false) {
                this.errorStart = true;
                return false;
            }
            else {
                this.errorEnd = true;
                return false;
            }
        }

        else {

            //  console.log("\n second form values" + JSON.stringify(this.surveyorForm.value) + "\n");
            let clonedSurveyorForm: any = this.surveyorForm.value;
            if (this.isCategoryAdded || this.isRatingAdded) {
                clonedSurveyorForm.SurveyorSpecialisation = { "SpeclEngDesc": this.isCategoryAdded ? this.specializationList[this.specializationList.length - 1].E_desc : "", "SpeclArabicDesc": this.isCategoryAdded ? this.specializationList[this.specializationList.length - 1].E_desc : "", "IsNew": this.surveyorForm.controls['Specilisation'].value === '0' ? true : false };
                clonedSurveyorForm.SurveyorRating = { "RatingEngDesc": this.isRatingAdded ? this.ratingList[this.ratingList.length - 1].E_desc : "", "RatingArabicDesc": this.isRatingAdded ? this.ratingList[this.ratingList.length - 1].E_desc : "", "IsNew": this.surveyorForm.controls['Rating'].value === '0' ? true : false };
            } else {
                clonedSurveyorForm.SurveyorSpecialisation = null;
                clonedSurveyorForm.SurveyorRating = null;
            }
            //   console.log("cloned values\n" + JSON.stringify(clonedSurveyorForm));
            this.surveyorservice.updateSurveyorDetails(JSON.stringify(clonedSurveyorForm)).subscribe(
                dataReturn => {
                    this.returnValue = dataReturn;

                    console.log(this.returnValue, 'this.returnValue');
                    if (this.returnValue.IsValid == 0) {
                        this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                        this.bsModalRef.content.modelTitle = '';
                        this.bsModalRef.content.modelBodyContent = "Surveyor Succesfully updated";
                        // this.bsModalRef.content.smallMessage = "ID: " + this.returnValue.Code;
                        // this.bsModalRef.content.bigMessage = this.returnValue.EngName;
                        // this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
                        this.bsModalRef.content.actionBtn = "Close";
                        this.bsModalRef.content.valueChange.subscribe((data) => {
                            console.log(" success data" + data);
                            if (data == 'Close') {
                                console.log("close btn clicked");
                            } else {
                                console.log(" else close");
                            }
                            this.surveyorForm.disable();
                            this.editFormOption = false;
                            this.clearerrors();

                        });
                    }
                    else if (this.returnValue.IsValid == 2) {
                        this.errorEngNameExists = true;
                        this.errorE_Licence_NoExists = true;
                        this.errorPhoneNumberExists = true;
                        this.errorMobileNumberExists = true;
                        this.errorEngEmailExists = true;
                    }
                },
                errorRturn => {
                    console.log(errorRturn);
                }
            );
        }
    }

    getPayeeBankNames() {
        this.surveyorservice.getPayeeBankNames().subscribe(
            dataReturn => {
                this.bankNamesList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }

    getcorrbankname() {
        this.surveyorservice.getcorrbankname().subscribe(
            dataReturn => {
                this.corrbanknameList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getNationality() {
        this.surveyorservice.getNationality().subscribe(
            dataReturn => {
                this.nationalityList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getspecialization() {
        this.surveyorservice.getspecialization().subscribe(
            dataReturn => {
                this.specializationList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getstatus() {
        this.surveyorservice.getstatus().subscribe(
            dataReturn => {
                this.statusList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getrating() {
        this.surveyorservice.getrating().subscribe(
            dataReturn => {
                this.ratingList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getqualification() {
        this.surveyorservice.getqualification().subscribe(
            dataReturn => {
                this.qualificationList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getSurveyorDetails() {
        const param = 'code=' + this.entityCode +
            '&branch=' + sessionStorage.getItem('locationcode');
        this.surveyorservice.getSurveyorDetails(param).subscribe(
            dataReturn => {
                //  console.log("customer data" + JSON.stringify(dataReturn));
                let arrayFormFields = ['EngName', 'ArabicName', 'E_Licence_No', 'A_Licence_No', 'LicenceEpiry', 'Empanel', 'VATRegnStrtDate', 'VATRegnEndDate',
                    'EngEmail', 'PhoneNumber', 'MobileNumber', 'Fax', 'Nationality', 'EngAddress1', 'ArabicAddress1',
                    'EngAddress2', 'ArabicAddress2', 'EngAddress3', 'ArabicAddress3', 'EngZIP', 'BeneficiaryBankName', 'BeneficiaryAccNo',
                    'IBAN', 'BenBankAddress', 'BenSwiftCode', 'BenSortCode', 'CorrespondentBankName', 'CorrAccNo', 'CorrSwiftCode', 'CorrSortCode', 'CorrBankAddress',
                    'Qualification', 'Specilisation', 'Survey', 'Rating', 'Status'];

                arrayFormFields.forEach((val) => {
                    if (dataReturn[val] != null && dataReturn[val] != undefined) {
                        this.surveyorForm.controls[val].setValue(dataReturn[val]);
                    }
                });
                this.surveyorForm.controls.VATRegnEndDate.disable();

            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    resetForm() {
        let arrayFormFields = ['EngName', 'ArabicName', 'E_Licence_No', 'A_Licence_No', 'LicenceEpiry', 'Empanel', 'VATRegnStrtDate', 'VATRegnEndDate',
            'EngEmail', 'PhoneNumber', 'MobileNumber', 'Fax', 'Nationality', 'EngAddress1', 'ArabicAddress1',
            'EngAddress2', 'ArabicAddress2', 'EngAddress3', 'ArabicAddress3', 'EngZIP', 'BeneficiaryBankName', 'BeneficiaryAccNo',
            'IBAN', 'BenBankAddress', 'BenSwiftCode', 'BenSortCode', 'CorrespondentBankName', 'CorrAccNo', 'CorrSwiftCode', 'CorrSortCode', 'CorrBankAddress',
            'Qualification', 'Specilisation', 'Survey', 'Rating', 'Status'];

        this.surveyorForm.controls['ModifiedByStr'].reset("test@ae.rsagroup.com");
        this.surveyorForm.controls['IsValid'].reset(0);
        arrayFormFields.forEach((val) => {
            if (this.surveyorForm.controls[val] != null && this.surveyorForm.controls[val] != undefined) {
                this.surveyorForm.controls[val].reset();
            }
        });
        this.clearerrors();
    }
    surveyorEdit() {
        this.editFormOption = true;
        this.surveyorForm.enable();
        this.surveyorForm.controls.VATRegnEndDate.disable();
    }
    addNewCategory(catValue: any) {
        if (catValue === 'newCategoryType') {
            console.log(catValue + " new category " + this.surveyorForm.controls['Specilisation'].value);
            this.selectedTypeVal = catValue;
            this.surveyorForm.controls['Specilisation'].setValue("");
        }

    }
    addToCateroryList() {
        this.newSpecialization.nativeElement.value = this.newSpecialization.nativeElement.value.trim();
        if (this.newSpecialization.nativeElement.value) {
            if (this.checkDuplicatesInCategoryList() == true) {
                console.log("gggg");
                this.errorCategoryExists = true;
            } else {
                let newCategory: any = { "Code": 0, "E_desc": this.newSpecialization.nativeElement.value };
                this.isCategoryAdded = true;
                this.specializationList.push(newCategory);
                //this.surveyorForm.controls['Specilisation'].setValue("");
                this.selectedTypeVal = "";
                this.errorCategoryExists = false;
            }

        }
    }
    hideAddCategory() {
        this.surveyorForm.controls['Specilisation'].setValue("");
        this.selectedTypeVal = "";
        this.errorCategoryExists = false;
    }
    checkDuplicatesInCategoryList() {
        let duplicateValueExists: boolean = false;
        this.specializationList.forEach((item) => {
            if (this.newSpecialization.nativeElement.value == item.E_desc) {
                duplicateValueExists = true;
            }
        });
        return duplicateValueExists;
    }

    addNewRating(catValue: any) {
        if (catValue === 'newRatingType') {
            console.log(catValue + " new category " + this.surveyorForm.controls['Rating'].value);
            this.selectedrating = catValue;
            this.surveyorForm.controls['Rating'].setValue("");
        }

    }
    addToRatingList() {
        this.newRating.nativeElement.value = this.newRating.nativeElement.value.trim();
        if (this.newRating.nativeElement.value) {
            if (this.checkDuplicatesInRatingList() == true) {
                console.log("gggg");
                this.errorRatingExists = true;
            } else {
                let newCategory: any = { "Code": 0, "E_desc": this.newRating.nativeElement.value };
                this.isRatingAdded = true;
                this.ratingList.push(newCategory);
                //this.surveyorForm.controls['Rating'].setValue("");
                this.selectedrating = "";
                this.errorRatingExists = false;
            }

        }
    }
    hideAddRating() {
        this.surveyorForm.controls['Rating'].setValue("");
        this.selectedrating = "";
        this.errorRatingExists = false;
    }
    checkDuplicatesInRatingList() {
        let duplicateValueExists: boolean = false;
        this.ratingList.forEach((item) => {
            if (this.newRating.nativeElement.value == item.E_desc) {
                duplicateValueExists = true;
            }
        });
        return duplicateValueExists;
    }
    displayModifyButton(functionid) {
        return this.allowAccess.isAllowed(functionid);
    }

}

