import { TestBed, inject } from '@angular/core/testing';

import { PolicestationService } from './policestation.service';

describe('PolicestationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PolicestationService]
    });
  });

  it('should be created', inject([PolicestationService], (service: PolicestationService) => {
    expect(service).toBeTruthy();
  }));
});
