import { Injectable } from '@angular/core';
import { HttpHeaders, HttpErrorResponse, HttpClient, HttpParams, } from '@angular/common/http';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { catchError, map, shareReplay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AgentService {

    constructor(private http: HttpClient) { }

    getAgentDetails(params: any) {
        return this.http.get<any>(RSAENDPOINTConstants.GETAGENT + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAgentDetails')));
    }
    updateAgentDetails(params: any) {
        return this.http.put<any>(RSAENDPOINTConstants.UPDATEAGENT, params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updateAgentDetails')));
    }
    createAgent(params: any) {
        return this.http.post<any>(RSAENDPOINTConstants.CREATEAGENT, params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createAgent')));
    }
    getVATCode() {
        return this.http.get<any>(RSAENDPOINTConstants.VATCODE).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getVATCode')));
    } 
    getBranchNames(params: any) {
        return this.http.get<any>(RSAENDPOINTConstants.GETBranch + params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getBranchNames')));
    }  
    getVATRegCountry() {
        return this.http.get<any>(RSAENDPOINTConstants.VATREGISTRATIONCOUNTRY).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getVATRegCountry')));
    } 
    getCategory(params:any) {
        return this.http.get<any>(RSAENDPOINTConstants.AGENTCATEGORY+params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getCategory')));
    } 
    getStatus() {
        return this.http.get<any>(RSAENDPOINTConstants.STATUS).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getStatus')));
    } 
    getACExecute() {
        return this.http.get<any>(RSAENDPOINTConstants.ACCOUNTEXECUTIVE).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getACExecute')));
    } 

}
