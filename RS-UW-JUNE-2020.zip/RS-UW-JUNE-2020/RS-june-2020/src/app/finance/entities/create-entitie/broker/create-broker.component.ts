﻿import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators} from '@angular/forms';
import { slideInOut } from '../../../../shared/animation/slidein';
import { BrokerService } from './service/broker.service';
import { catchError, map, shareReplay } from 'rxjs/operators';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { SuccessDialogComponent } from 'src/app/shared/custom-success-model/custom-success-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
@Component({
    selector: 'rsa-create-broker',
    templateUrl: './create-broker.component.html',
    styleUrls: ['./create-broker.component.scss'],
    animations: [slideInOut]
})

export class CreateBrokerComponent implements OnInit {
    brokerForm: FormGroup;
    isArabicField = false;
    Address1 = false;
    Address2 = false;
    Address3 = false;
    submitted = false;
    errorname: boolean;
    errorlicensenumber: boolean;
    errorVATRegNo: boolean;
    erroremail: boolean;
    errorTelephone: boolean;
    errorMobileNo: boolean;
    erroraddress: boolean;
    errorpostalcode: boolean;
    errorBranch: boolean;
    errorNationality: boolean;
    errorOverallCreditAmt: boolean;
    errorLicenceExpiryDate: boolean;
    errorvatcode: boolean;
    errorStatus: boolean;
    erroremailExists : boolean;
    errorMobileNoExists :boolean;
    errornameExists : boolean;
    errorTelephoneExists : boolean;
    errorVATRegNoExists : boolean;
    errorELicenceNoExists: boolean;
    isOman: any;
    bankNamesList: any[];
    branchList: any[];
    vatcodeList: any[];
    nationalityList: any[];
    vatregcountryList: any[];
    corrbanknameList: any[];
    categoryList: any[];
    statusList: any[];
    acexecList: any[];
    returnValue: any;
    today = new Date();
    previous = new Date('01/01/2000');       
    overCreditReadonly: boolean; 
    selectedTypeVal: any;        
    errorCategoryExists: boolean;
    @ViewChild('newCategoryname') private newCategoryname: ElementRef;
    isCategoryAdded: boolean;
    qualificationList: any[];
    zeroValue=false;
    errorStartDate:boolean = false;
    errorEndDate:boolean = false;
    errorStart:boolean = false;
    errorEnd:boolean = false;
    isUAE:boolean=false;
    enableVATRegnEndDate : boolean = false;
    nextDay : Date;
    endDate: Date;  
    sumValue: boolean;  
    functionIDModify: number = 402;
    constructor(private fb: FormBuilder, protected brokerService: BrokerService,
        public bsModalRef: BsModalRef, private modalService: BsModalService, private router: Router, private allowAccess: UserAutherizationService) { }
    ngOnInit() {
       this.createEntityForm();
        this.fieldStatusChanges();
        this.getPayeeBankNames();
        this.getBranchNames();
        this.getvatcode();
        this.getnationality();
        this.getvatregcountry();
        this.getcorrbankname();
        this.getcategory();
        this.getstatus();
        this.getacexecutive();
        this.getqualification();      
        this.isOman = sessionStorage.getItem('regioncode') == '3' ? true : false; 
        this.isUAE= (sessionStorage.getItem('regioncode') == '2') ? true:false;
       
       // this.isUAE=false;
        if(this.isUAE)
        {
           this.formControlAddValidator();
        }
        else{
            this.formControlClearValidator();
        }
        this.errorvatcode=false;
        this.errorVATRegNo=false;
    }
     formControlClearValidator() {
        const VATRegNo = this.brokerForm.get('VATRegNo');
        const VATCode = this.brokerForm.get('VATCode');
        VATRegNo.clearValidators();
        VATRegNo.updateValueAndValidity();
        VATCode.clearValidators();
        VATCode.updateValueAndValidity();
     }
     formControlAddValidator() {
        const VATRegNo = this.brokerForm.get('VATRegNo');
        const VATCode = this.brokerForm.get('VATCode');
         VATRegNo.setValidators([Validators.required]);
        VATRegNo.updateValueAndValidity();
        VATCode.setValidators([Validators.required]);
        VATCode.updateValueAndValidity();
     }
    get namedesc() {
        return this.brokerForm.get('EngName');
    };
    get licensenumberdesc() {
        return this.brokerForm.get('ELicenceNo');
    }
    get VATRegNodesc() {
        return this.brokerForm.get('VATRegNo');
    }
    get emaildesc() {
        return this.brokerForm.get('EEmail');
    }
    get Telephonedesc() {
        return this.brokerForm.get('Telephone');
    }
    get MobileNodesc() {
        return this.brokerForm.get('MobileNo');
    }
    
    get addressdesc() {
        return this.brokerForm.get('EAddress1');
    }
    get postalcodedesc() {
        return this.brokerForm.get('EPostalCode');
    }
    get Branchdesc() {
        return this.brokerForm.get('Branch');
    }
    get Nationalitydesc() {
        return this.brokerForm.get('Nationality');
    }
    get OverallCreditAmtdesc() {
        return this.brokerForm.get('OverallCreditAmt');
    }
    get LicenceExpiryDatedesc() {
        return this.brokerForm.get('LicenceExpiryDate');
    }
    get vatcodedesc() {
        return this.brokerForm.get('VATCode');
    }
    get statusdesc() {
        return this.brokerForm.get('Status');
    }
  
    getqualification() {
        this.brokerService.getqualification().subscribe(
            dataReturn => {
                this.qualificationList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    changelicenseexpiryDate() {
        if (this.brokerForm.controls['LicenceExpiryDate'].value) {
            const LicenceExpiryDate = new Date(this.brokerForm.controls['LicenceExpiryDate'].value);
            this.brokerForm.controls['LicenceExpiryDate'].setValue(new DatePipe('en-US').transform(LicenceExpiryDate, 'dd/MM/yyyy'));
        }
    }
    ChangeappDate() {
        if (this.brokerForm.controls['AppDate'].value) {
            const AppDate = new Date(this.brokerForm.controls['AppDate'].value);
            this.brokerForm.controls['AppDate'].setValue(new DatePipe('en-US').transform(AppDate, 'dd/MM/yyyy'));
        }
    }

   
    fieldStatusChanges() {
        this.clearerrors();
        this.namedesc.statusChanges.subscribe(
            status => {
                this.errorname = (status == 'INVALID');
            }
        );

        this.licensenumberdesc.statusChanges.subscribe(
            status => {
                this.errorlicensenumber = (status == 'INVALID');
            }
        );

        this.VATRegNodesc.statusChanges.subscribe(
            status => {
                this.errorVATRegNo = (status == 'INVALID');
            }
        );

        this.emaildesc.statusChanges.subscribe(
            status => {
                this.erroremail = (status == 'INVALID');
            }
        );
        this.Telephonedesc.statusChanges.subscribe(
            status => {
                this.errorTelephone = (status == 'INVALID');
            }
        );
        this.MobileNodesc.statusChanges.subscribe(
            status => {
                this.errorMobileNo = (status == 'INVALID');
            }
        );
        
        this.addressdesc.statusChanges.subscribe(
            status => {
                this.erroraddress = (status == 'INVALID');
            }
        );
        this.postalcodedesc.statusChanges.subscribe(
            status => {
                this.errorpostalcode = (status == 'INVALID');
            }
        );
        this.Branchdesc.statusChanges.subscribe(
            status => {
                this.errorBranch = (status == 'INVALID');
            }
        );
       
        this.Nationalitydesc.statusChanges.subscribe(
            status => {
                this.errorNationality = (status == 'INVALID');
            }
        );
        this.OverallCreditAmtdesc.statusChanges.subscribe(
            status => {
                this.errorOverallCreditAmt = (status == 'INVALID');
            }
        );
        this.LicenceExpiryDatedesc.statusChanges.subscribe(
            status => {
                this.errorLicenceExpiryDate = (status == 'INVALID');
            }
        );
        this.vatcodedesc.statusChanges.subscribe(
            status => {
                this.errorvatcode = (status == 'INVALID');
            }
        );
        this.statusdesc.statusChanges.subscribe(
            status => {
                this.errorStatus = (status == 'INVALID');
            }
        );
    }
    clearerrors() {
        this.errorname = false;
        this.errorlicensenumber = false;
        this.errorVATRegNo = false;
        this.erroremail = false;
        this.errorTelephone = false;
        this.errorMobileNo = false;
        this.errorBranch = false;
        this.erroraddress = false;
        this.errorpostalcode = false;
        this.errorNationality = false;
        this.errorOverallCreditAmt = false;
        this.errorLicenceExpiryDate = false;
        this.errorvatcode = false;
        this.errorStatus = false;
        this.erroremailExists = false;
        this.errorMobileNoExists = false;
        this.errornameExists = false;
        this.errorTelephoneExists = false;
        this.errorVATRegNoExists = false;
        this.errorELicenceNoExists = false;
        this.errorStart = false;
        this.errorEnd = false;
        this.errorStartDate = false;
        this.errorEndDate = false; 

    };
    createEntityForm(): void {
        this.brokerForm = this.fb.group({
           // Code: [1],
            EngName: ['', Validators.required],
            ArabName:[''],
            ELicenceNo: ['', Validators.required],
            LicenceExpiryDate: ['', Validators.required],
            VATCode: ['', Validators.required],
            VATRegNo: ['', Validators.required],
            EEmail: ['', [Validators.required, Validators.email]],
            Telephone: ['', Validators.required],
            MobileNo: ['', Validators.required],
            FAXNo: [''],
            Branch: [sessionStorage.getItem('locationcode'), Validators.required],
            VATRate: [''],
            VATRegCountry: [''],
            EAddress1: ['', Validators.required],
            AAddress1: [''],
            EAddress2: [''],
            AAddress2: [''],
            EAddress3: [''],
            AAddress3: [''],
            EPostalCode: ['', Validators.required],
            Nationality: ['', Validators.required],
            BenfBank: [''],
            BenfAccNo: [''],
            IBANNo: [''],
            BenfBankAdd: [''],
            BenfSwiftCode: [''],
            BenfSortCode: [''],
            CorrBank: [''],
            CorrAccNo: [''],
            CorrBankSwiftCode: [''],
            CorrSortCode: [''],
            CorrBankAddr: [''],
            PLCreditAmount: [''],
            PLCreditDays: [''],
            CLCreditAmt: [''],
            CLCreditDays: [''],
            SME_SPLCreditAmount: [''],
            SME_SPL_CreditDays: [''],
            OverallCreditAmt: ['', Validators.required],
            OverallCreditDays: [''],
            AddlCreditAmt1: [''],
            AddlCrediDays1: [''],
            AddlCreditAmt2: [''],
            AddlCreditDays2: [''],
            BrokerGrp: [''],
            Remarks: [''],
            Qualification: [''],
            AddInfoCategory: [''],
            AppDate: [''],
            Area: [''],
            FACInd: [''],
            IntimationAlerts: [''],
            Status: ['', Validators.required],
            AccExec: [''],
            VATRegnStrtDate :[''],
            VATRegnEndDate :[''],
            PreparedBy: [sessionStorage.getItem('LoggedInUserId')],
            IsValid: [0]
        })

    }
    setVatRate(vatvalue: number) {
        this.vatcodeList.forEach(element => {
            if (element.Code == vatvalue) {
                this.brokerForm.controls['VATRate'].setValue(element.VATRate);
            }
        });
    } 
    changeStartDate(sValue: Date) {  
        if(sValue){ 
            this.enableVATRegnEndDate = true;
            this.errorStartDate = true; 
            this.nextDay = new Date(sValue);
            this.nextDay.setDate(sValue.getDate()+1); 
          }  
      }  
      changeEndDate(eValue: Date) {    
        if(eValue){ 
          this.errorEndDate = true; 
          this.endDate = new Date(eValue);
          this.endDate.setDate(eValue.getDate()-1);
        }   
      }
      changeStartDateValue() {         
        if (this.brokerForm.controls['VATRegnStrtDate'].value) { 
          const RegistrationExpiry = new Date(this.brokerForm.controls['VATRegnStrtDate'].value);
          this.brokerForm.controls['VATRegnStrtDate'].setValue(new DatePipe('en-US').transform(RegistrationExpiry, 'dd/MM/yyyy'));
        } 
      }       
      changeEndDateValue() {  
        if (this.brokerForm.controls['VATRegnEndDate'].value) {
          const RegistrationExpiry = new Date(this.brokerForm.controls['VATRegnEndDate'].value);
          this.brokerForm.controls['VATRegnEndDate'].setValue(new DatePipe('en-US').transform(RegistrationExpiry, 'dd/MM/yyyy'));
        }
      }
    get f() { return this.brokerForm.controls; }
    setErrorInvalid() {
        this.errorname = this.namedesc.invalid;
        this.errorlicensenumber = this.licensenumberdesc.invalid;
        this.errorVATRegNo = this.VATRegNodesc.invalid;
        this.erroremail = this.emaildesc.invalid;
        this.errorTelephone = this.Telephonedesc.invalid;
        this.errorMobileNo = this.MobileNodesc.invalid;
        this.errorBranch = this.Branchdesc.invalid;
        this.erroraddress = this.addressdesc.invalid;
        this.errorpostalcode = this.postalcodedesc.invalid;
        this.errorNationality = this.Nationalitydesc.invalid;
        this.errorOverallCreditAmt = this.OverallCreditAmtdesc.invalid;
        this.errorLicenceExpiryDate = this.LicenceExpiryDatedesc.invalid;
        this.errorvatcode = this.vatcodedesc.invalid;
        this.errorStatus = this.statusdesc.invalid;

    }
    submitForm() {
        this.setErrorInvalid();      
        // stop here if form is invalid
        if (this.brokerForm.invalid) {
            return;
        }
        if(this.errorStartDate != this.errorEndDate )
        { 
                 
          if(this.errorStartDate == false)
          {
            this.errorStart = true;
            return false;
          } 
          else{
            this.errorEnd = true;
            return false;
          }
        } 
        else if(this.brokerForm.controls.OverallCreditAmt.value===0 || this.brokerForm.controls.OverallCreditAmt.value===""){
          this.zeroValue=true;
        }


        else {
            this.zeroValue=false;
            if (this.brokerForm.value.FACInd == true) {
                this.brokerForm.value.FACInd = "Y";
            }
            if (this.brokerForm.value.FACInd == false) {
                this.brokerForm.value.FACInd = null;
            }
            if (this.brokerForm.value.IntimationAlerts == true) {
                this.brokerForm.value.IntimationAlerts = "Y";
            }
            if (this.brokerForm.value.IntimationAlerts == false) {
                this.brokerForm.value.IntimationAlerts = null;
            }
      
                let val1: any = Number(this.brokerForm.controls['PLCreditAmount'].value) + Number(this.brokerForm.controls['CLCreditAmt'].value) + Number(this.brokerForm.controls['SME_SPLCreditAmount'].value);
                if (this.brokerForm.controls['OverallCreditAmt'].value < val1) {
                    this.sumValue = true;
                }
                else {
                    this.sumValue = false;
                    let clonedBrokerForm: any = this.brokerForm.value;
                    if (this.isCategoryAdded) {
                        clonedBrokerForm.BrkCategory = { "EDesc": this.isCategoryAdded ? this.categoryList[this.categoryList.length - 1].E_desc : "", "ADesc": this.isCategoryAdded ? this.categoryList[this.categoryList.length - 1].E_desc : "", "IsNew": this.brokerForm.controls['AddInfoCategory'].value === '0' ? true : false };
                    } else {
                        clonedBrokerForm.BrkCategory = null;
                    }
                    this.brokerService.createBroker(JSON.stringify(clonedBrokerForm)).subscribe(
                        dataReturn => {
                            this.returnValue = dataReturn;

                    console.log(this.returnValue, 'this.returnValue');
                    if (this.returnValue.IsValid == 0) {
                        this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                        this.bsModalRef.content.modelTitle = '';
                        this.bsModalRef.content.modelBodyContent = "Broker Succesfully created";
                        this.bsModalRef.content.smallMessage = "ID: " + this.returnValue.Code;
                        this.bsModalRef.content.bigMessage = "Broker Name: "+ this.returnValue.EngName;
                        this.bsModalRef.content.actionBtn = "Close";
                        this.bsModalRef.content.valueChange.subscribe((data) => {
                            console.log(" success datat" + data);
                            if (data == 'Close') {
                                console.log("close btn clicked");
                            } else {
                                console.log(" else close");
                            }
                            this.resetForm();
                        });
                    } else if (this.returnValue.IsValid == 1) {
                        //alert modal
                        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                        this.bsModalRef.content.modelTitle = '';
                        this.bsModalRef.content.modelBodyContent = "Alert! Other than VAT Registration Number and License Number remaining fields  already exists.";
                        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
                        this.bsModalRef.content.actionBtn = "Proceed";
                        this.bsModalRef.content.valueChange.subscribe((data) => {
                          //  console.log("datat" + data);
                            if (data = 'Proceed') {
                                console.log("proceed btn clicked");
                                this.brokerForm.value.IsValid = 1;
                                this.submitForm();
                            }
                            
                            else {
                                console.log(" else close");
                            }
                        });
                        //end for alert modal
                    }
                    else if (this.returnValue.IsValid == 2) {
                        this.erroremailExists = true;
                        this.errorMobileNoExists = true;
                        this.errornameExists = true;
                        this.errorTelephoneExists = true;
                        this.errorVATRegNoExists = true;
                        this.errorELicenceNoExists = true;
                    }
                },
                errorRturn => {
                    console.log(errorRturn);
                }
            );
        }
   
}
    }
    
    getPayeeBankNames() {
        this.brokerService.getPayeeBankNames().subscribe(
            dataReturn => {
                this.bankNamesList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getBranchNames() {
        const param = 'ctyCode=' + sessionStorage.getItem('countrycode') +
            '&regCode=' + sessionStorage.getItem('regioncode');
        this.brokerService.getBranchNames(param).subscribe(
            dataReturn => {
                this.branchList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }

    getvatcode() {
        this.brokerService.getvatcode().subscribe(
            dataReturn => {
                this.vatcodeList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getnationality() {
        this.brokerService.getnationality().subscribe(
            dataReturn => {
                this.nationalityList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getvatregcountry() {
        this.brokerService.getvatregcountry().subscribe(
            dataReturn => {
                this.vatregcountryList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getcorrbankname() {
        this.brokerService.getcorrbankname().subscribe(
            dataReturn => {
                this.corrbanknameList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getcategory() {
        const param = 'entityType=' + 3;
           
        this.brokerService.getcategory(param).subscribe(
            dataReturn => {
                this.categoryList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getstatus() {
        this.brokerService.getstatus().subscribe(
            dataReturn => {
                this.statusList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getacexecutive() {
        this.brokerService.getacexecutive().subscribe(
            dataReturn => {
                this.acexecList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    resetForm() {
        let arrayFormFields = ['EngName','ArabName', 'ELicenceNo', 'LicenceExpiryDate', 'VATCode', 'VATRegNo',
            'EEmail', 'Telephone', 'MobileNo', 'FAXNo', 'VATRate', 'VATRegCountry','VATRegnStrtDate','VATRegnEndDate',
            'EAddress1', 'AAddress1', 'EAddress2', 'AAddress2', 'EAddress3', 'AAddress3', 'EPostalCode', 'Nationality',
            'BenfBank', 'BenfAccNo', 'IBANNo', 'BenfBankAdd', 'BenfSwiftCode', 'BenfSortCode', 'CorrBank', 'CorrAccNo', 'CorrBankSwiftCode',
            'CorrBankAddr', 'CorrSortCode', 'PLCreditAmount', 'PLCreditDays', 'CLCreditAmt', 'CLCreditDays', 'SME_SPLCreditAmount', 'SME_SPL_CreditDays',
            'OverallCreditAmt', 'OverallCreditDays', 'AddlCreditAmt1', 'AddlCrediDays1', 'AddlCreditAmt2', 'AddlCreditDays2', 'BrokerGrp', 'Remarks',
            'Qualification', 'AddInfoCategory', 'AppDate', 'Area', 'FACInd', 'IntimationAlerts', 'Status', 'AccExec' ];
        this.brokerForm.controls['IsValid'].reset(0);
        arrayFormFields.forEach((val) => {
            if (this.brokerForm.controls[val] != null && this.brokerForm.controls[val] != undefined) {
                this.brokerForm.controls[val].reset();
            }
        });
        this.clearerrors();
    }
    addNewCategory(catValue: any) {
        if (catValue === 'newCategoryType') {
            console.log(catValue + " new category " + this.brokerForm.controls['AddInfoCategory'].value);
            this.selectedTypeVal = catValue;
            this.brokerForm.controls['AddInfoCategory'].setValue('');
        }

    }
    addToCateroryList() {
        this.newCategoryname.nativeElement.value = this.newCategoryname.nativeElement.value.trim(); 
        if (this.newCategoryname.nativeElement.value) {
            if (this.checkDuplicatesInCategoryList() == true) {
                this.errorCategoryExists = true;
            } else {
                let newCategory: any = { "Code": 0, "E_desc": this.newCategoryname.nativeElement.value };
                this.isCategoryAdded = true;
                this.categoryList.push(newCategory);
                // this.agentForm.controls['Category'].setValue("");
                this.selectedTypeVal = "";
                this.errorCategoryExists = false;
            }

        }
    }
    hideAddCategory() {
        this.brokerForm.controls['AddInfoCategory'].setValue("");
        this.selectedTypeVal = "";
        this.errorCategoryExists = false;
    }
    checkDuplicatesInCategoryList() {
        let duplicateValueExists: boolean = false;
        this.categoryList.forEach((item) => {
            if (this.newCategoryname.nativeElement.value == item.E_desc) {
                duplicateValueExists = true;
            }
        });
        return duplicateValueExists;
    }

    setCreditValues(event: any) {
        if (this.brokerForm.controls['PLCreditAmount'].value && this.brokerForm.controls['CLCreditAmt'].value && this.brokerForm.controls['SME_SPLCreditAmount'].value) {
            if (this.brokerForm.controls['PLCreditAmount'].value==0 || this.brokerForm.controls['CLCreditAmt'].value==0 || this.brokerForm.controls['SME_SPLCreditAmount'].value==0){
                this.overCreditReadonly = false;
                let val: any = Number(0)
                this.brokerForm.controls['OverallCreditAmt'].setValue(parseFloat(val));
            }
            else{
                let sum: any = Number(this.brokerForm.controls['PLCreditAmount'].value) + Number(this.brokerForm.controls['CLCreditAmt'].value) + Number(this.brokerForm.controls['SME_SPLCreditAmount'].value);
                this.brokerForm.controls['OverallCreditAmt'].setValue(parseFloat(sum));
            this.overCreditReadonly = true;
            }
        } else {
            this.overCreditReadonly = false;
            let val1: any = Number(0)
            this.brokerForm.controls['OverallCreditAmt'].setValue(parseFloat(val1));
        }
    }
    cancelForm(){
        if(this.checkValueEnteredOrNot()===true){
         this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
         this.bsModalRef.content.modelTitle = '';
         this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
         this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
         this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
         this.bsModalRef.content.valueChange.subscribe((data) => {
             if (data === 'PROCEED') {
                 this.router.navigate(['/finance']);
             }         
         });
        }else{
            this.router.navigate(['/finance']);
        }
     }
    displayModifyButton(functionid) {
        return this.allowAccess.isAllowed(functionid);
    }
    checkValueEnteredOrNot(){
        let arrayFormFields = ['EngName', 'ArabName', 'ELicenceNo', 'LicenceExpiryDate', 'VATCode', 'VATRegNo',
            'EEmail', 'Telephone', 'MobileNo', 'FAXNo', 'VATRate', 'VATRegCountry', 'VATRegnStrtDate', 'VATRegnEndDate',
            'EAddress1', 'AAddress1', 'EAddress2', 'AAddress2', 'EAddress3', 'AAddress3', 'EPostalCode', 'Nationality',
            'BenfBank', 'BenfAccNo', 'IBANNo', 'BenfBankAdd', 'BenfSwiftCode', 'BenfSortCode', 'CorrBank', 'CorrAccNo', 'CorrBankSwiftCode', 'CorrSortCode',
            'CorrBankAddr', 'PLCreditAmount', 'PLCreditDays', 'CLCreditAmt', 'CLCreditDays', 'SME_SPLCreditAmount', 'SME_SPL_CreditDays',
            'OverallCreditAmt', 'OverallCreditDays', 'AddlCreditAmt1', 'AddlCrediDays1', 'AddlCreditAmt2', 'AddlCreditDays2', 'BrokerGrp', 'Remarks',
            'Qualification', 'AddInfoCategory', 'AppDate', 'Area', 'FACInd', 'IntimationAlerts', 'Status', 'AccExec'];
        let valueEntered:boolean=false;
        arrayFormFields.forEach((val) => {
            if (this.brokerForm.controls[val].value !=="") {
                valueEntered=true;
            }
        });
        return valueEntered;
    }
   

}
   
    







