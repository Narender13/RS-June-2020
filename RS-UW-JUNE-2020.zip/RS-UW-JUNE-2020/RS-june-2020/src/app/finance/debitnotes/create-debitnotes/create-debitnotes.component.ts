import { Component, OnInit, ViewChild } from '@angular/core';
import { SharedService } from '../../services/shared.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { CreateReceipt } from '../../search/model/create-receipt';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreateDebitNotes } from 'src/app/finance/debitnotes/create-debitnotes/model/create-dn';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { CreateDebitnotesService } from 'src/app/finance/debitnotes/create-debitnotes/service/create-debitnotes.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { TaxinvoicepreviewComponent } from 'src/app/finance/preview/uae/taxinvoicepreview/taxinvoicepreview.component';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';

@Component({
  selector: 'rsa-create-debitnotes',
  templateUrl: './create-debitnotes.component.html',
  styleUrls: ['./create-debitnotes.component.scss']
})
export class CreateDebitnotesComponent extends BasevoucherComponent implements OnInit {
  title = RSAConstants.TaxInvoiceTitle;
  currency = sessionStorage.getItem(RSAConstants.currency);
  errorpayee: boolean;
  errordetail: boolean;
  errorglCode: boolean;
  /* form error-feilds */
  errorbankcodeCheque: boolean;
  level: any = 2;
  errorbankcodeBanktransfer: boolean;
  errorpaayeebanknameCheque: boolean;
  errorpaayeebanknameBanktransfer: boolean;
  errorchequedateCheque: boolean;
  errorchequedateBankT: boolean;
  errorchequedateCreditCard: boolean;
  errorchequenoCheque: boolean;
  errorchequenoCreditCard: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  errorvoucherdate: boolean;
  matchedRecords = [];
  isUploadUnmatched;
  dnClaimsDetails: any;
  returnValue: any;
  usersReq;
  symbol;
  glAcountHeader: any = [];
  createDebitNotes: CreateDebitNotes;
  clonedDebitNotes: CreateDebitNotes;
  animatedClass = true;
  selectedRowItem: any = [];
  toggleValueCredit = [];
  customerName: string = "";
  ondemandFlag: boolean = true;
  ondemandFlagClaim = true;
  TotAcccode;
  glnumber;
  formArray: any;
  headerDescription: string = "";
  dnVATFlag = false;
  isFromEntity = false;
  dnClaimsFlag: any;
  @ViewChild('tabset') tabset: TabsetComponent;
  ifnewlyAddedRow = false;
  isStateClosed: boolean = false;
  accountingCode;
  receiptAccountingDate: any;
  currentglDetail: any;
  defaultTotallingAccCode;
  defaultGLCode;
  previousAmountValue: any;
  errorReportHeader: boolean;
  isUAE: boolean = false;
  isReportFlag: boolean = false;


  constructor(
    protected sharedService: SharedService,
    private fb: FormBuilder,
    protected modalService: BsModalService,
    protected bsModalRef: BsModalRef,
    protected masterDataService: MasterDataService,
    protected utilityClass: UtilityClass,
    protected createPaymentService: CreateDebitnotesService,
    private alertService: AlertService,
  ) {
    super(masterDataService, sharedService, modalService, utilityClass, bsModalRef);
    //super.setMinMaxDate();
  }


  ngOnInit() {
    /* super with method is calling from BasevoucherComponent */
    // this.regionCode = sessionStorage.getItem(RSAConstants.regionCode);
    this.createVoucherForm(this.paymentMode);
    this.isClaimFlag = this.dnClaimsFlag;
    this.isVATFlag = this.dnVATFlag;
    this.isOnDemandFlag = !this.isAllLob && !this.isFromEntity && !this.isClaimFlag && this.ondemandFlag && !this.isVATFlag;
    console.log("on Demand flag" + this.isOnDemandFlag);
    this.isReportFlag = (this.isOnDemandFlag || this.isFromEntity) && !this.isAllLob;
    this.isUAE = (sessionStorage.getItem('regioncode') == '2') ? true : false;
    if (this.isUAE && this.isReportFlag) {
      super.getAllReportHeadersDebitNote();
      this.mainVoucherForm.controls['Title'].setValidators([Validators.required]);
      this.mainVoucherForm.controls['Title'].updateValueAndValidity();
    }
    else {
      this.mainVoucherForm.controls['Title'].setValue("DEBIT NOTE");
    }
    this.rowClaimData = this.selectedRowItem;
    super.getEntityDefaultData();
    super.getAllBranchData();
    super.getAllCostCenterData({ ev: null, index: 0, flag: true });
    super.getAllTotallingData(true);
    super.getAllProjData();
    super.getAllDeptData();
    super.getAllMasterData2();
    this.fieldStatusChanges();
    super.closeModel();
    super.getAllTranData();
    this.symbol = (sessionStorage.getItem('symbol'));
    // super.setMinMaxDate();
    super.GetAccountingDates(new Date());
    this.getGlAccountHeader(sessionStorage.getItem(RSAConstants.totallingaccount), false);
    this.getDetailsArrayFormGroup();
    super.getModelPreviousClose();
    super.getAllgetLookupBanksData();
    super.getTotalingHeaderDataCnDn();
    const totcode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    super.getGlAccountHeaderDataCnDn(totcode);
    this.isDebitNote = true;
    console.log(this.isClaimFlag, 'this.isClaimFlag');
    setTimeout(() => {
      if (this.TotAcccode) {
        //  this.getGlAccountHeader(this.TotAcccode, true);
        this.defaultTotallingAccCode = this.TotAcccode;
        this.defaultGLCode = this.glnumber;
      }
      this.setTotAccTransCreCredit();
    }, 0);
    if (this.headerDescription != null && this.headerDescription != undefined && this.headerDescription != '') {
      console.log(this.dnClaimsDetails, 'this.dnClaimsDetails');
      this.setHeaderDescription(this.headerDescription);
    }

    if (this.isClaimFlag) {
      console.log(this.dnClaimsDetails, 'this.dnClaimsDetails');
      this.setHeaderDescription(this.dnClaimsDetails);
    }
    /*mutiple GL Code*/
    this.updateFromSession();
    this.sharedService.getMessage().subscribe(val => {
      if (val == 'ClearState') {
        if (sessionStorage.getItem('DNStateExists') != null) {
          sessionStorage.setItem('DNStateExists', 'false');
          this.isStateClosed = true;
        }
      }
      if (val == 'close') {
        this.isStateClosed = true;
        this.mainVoucherForm.markAsPristine();
        this.mainVoucherForm.markAsUntouched();
      }
    });
    this.updateVoucherNo();
  }
  ngOnDestroy() {
    if (!this.isStateClosed) {
      this.addToSession();
    }
  }
  updateVoucherNo() {
    let isFromDraft = sessionStorage.getItem('isFromDraft');
    if (isFromDraft == 'true') {
      let voucherDetail = JSON.parse(sessionStorage.getItem('VoucherDetail'));
      this.prevPreviewID = voucherDetail.VoucherNo;
    }
  }
  addToSession() {
    if (this.mainVoucherForm.dirty || this.mainVoucherForm.touched) {
      let voucherDate = this.mainVoucherForm['controls'].VoucherDate.value;
      let totallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
      let glCode = this.mainVoucherForm.controls.accountInfo['controls'].GLCode.value;
      let description = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
      let payeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
      var commonData = { VoucherDate: voucherDate, TotallingAccCode: totallingAccCode, GLCode: glCode, Description: description, PayeeName: payeeName, PrevReceipt: this.prevPreviewID, PreviewData: this.previewDataDtl }
      sessionStorage.setItem('CommonDNData', JSON.stringify(commonData));//CommonDNData
      sessionStorage.setItem('DNStateExists', 'true');
    }
    this.updateRows();
  }
  updateRows() {
    let formarray = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    if (formarray.controls.length > 0) {
      let voucherDetail = JSON.parse(sessionStorage.getItem('VoucherDetail'));
      voucherDetail.SelectedRows = [];
      formarray.controls.forEach(ctrl => {
        let rowClone = Object.assign({}, ctrl.value);
        rowClone.Amount = (rowClone.Amount) ? rowClone.Amount : 0;
        rowClone.Amount = +(rowClone.Amount);
        rowClone.DNTotallingAcc = rowClone.TotallingAccCode;
        rowClone.CNTotallingAcc = rowClone.TotallingAccCode;
        rowClone.DNVATAmount = 0;
        rowClone.SerialNumber = rowClone.SerialNo;
        voucherDetail.SelectedRows.push(rowClone)
      });
      //set as previous for credit and debit for typecode 2
      if (voucherDetail.SelectedRows && voucherDetail.SelectedRows.length > 0) {
        voucherDetail.SelectedRows.map((item, index) => {
          if (item.TypeCode == 2) {
            item.Amount = item.Amount * -1;
            item.DNVATAmount = (item.DNVATAmount) * -1;
          } else {
            item.Amount = item.Amount;
            item.DNVATAmount = item.DNVATAmount;
          }
        });
      }

      sessionStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
      this.sharedService.sendMessage('RefreshRows');
    }
  }
  updateFromSession() {
    let entityCDStateExists = sessionStorage.getItem('DNStateExists');
    if (entityCDStateExists == 'true') {
      let itemDetail = sessionStorage.getItem('CommonDNData');
      if (itemDetail) {
        this.mainVoucherForm.markAsDirty();
        let commonData = JSON.parse(itemDetail);
        if (commonData.PrevReceipt) { this.prevPreviewID = commonData.PrevReceipt; }
        // if(commonData.VoucherDate) this.mainVoucherForm['controls'].VoucherDate.setValue(new DatePipe('en-US').transform(new Date(commonData.VoucherDate), 'dd/MM/yyyy'));
        if (commonData.TotallingAccCode) {
          this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(commonData.TotallingAccCode);
          setTimeout(() => {
            super.getGlAccountHeaderDataCnDn(commonData.TotallingAccCode);

          }, 500);
          if (commonData.GLCode) this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(commonData.GLCode);
        }
        if (commonData.Description) this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(commonData.Description);
        if (commonData.PayeeName) this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.setValue(commonData.PayeeName);
      }
    }

  }
  checkIsformDirtyCD() {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = 'Proceed') {
        this.modalService.hide(1);
        this.sharedService.sendMessage('close');
        this.isStateClosed = true;
      }
    });
  }
  /*end*/
  /* create entiti form */
  createVoucherForm(param): void {
    this.mainVoucherForm = null;

    this.mainVoucherForm = this.fb.group({
      VoucherDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ApprovedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      ArabicDescription: [],
      Amount: [''],
      CountryCode: [sessionStorage.getItem(RSAConstants.countrycode)],
      CustomerID: [],
      CustCode: [],
      ModifiedBy: [],
      ModifiedDate: [],
      PreparedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [],
      ReprintNo: [],
      PrintDate: [],
      RefreshDate: [],
      PostedDate: [],
      PreprintNo: [],
      Title: [],
      DefaultGLCodeDesc: [],
      RegionCode: [sessionStorage.getItem('regioncode')],
      Approvers: this.fb.array([]),
      detailInfo: this.fb.group({
        PayeeName: [this.customerName.substr(0, 60), Validators.required],
        EnglishDescription: ['', Validators.required],
      }),
      accountInfo: this.fb.group({
        LocationCode: [sessionStorage.getItem('locationcode')],
        CostCenterCode: [sessionStorage.getItem('costcentre')],
        TotallingAccCode: [sessionStorage.getItem(RSAConstants.totallingaccount)],
        GLCode: [sessionStorage.getItem(RSAConstants.defaultGLCode), Validators.required],
      }),
      VoucherDetails: this.fb.array([]),
      TaxPointDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]
    });
  }
  setHeaderDescription(desc) {
    this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(desc);
  }

  get voucherDate() { return this.mainVoucherForm.get('VoucherDate'); }
  getDetailsArrayFormGroup() {
    console.log(this.selectedRowItem, this.ondemandFlag + 'this.selectedRowItem');
    let control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    if (!this.ondemandFlag) {
      console.log('this.selectedRowItem[0].CustomerID', this.selectedRowItem[0].CustomerID);
      this.mainVoucherForm.controls['CustomerID'].setValue(this.selectedRowItem[0].CustomerID);
      this.mainVoucherForm.controls['CustCode'].setValue(this.selectedRowItem[0].CustCode);

      this.selectedRowItem.map((index, item) => {

        let group = this.createDetailsArrayGroup();
        item['IsDebitEntry'] = (item.Amount < 0) ? false : true;
        group.patchValue(item.item);
        console.log('group.get("Amount").value:', group.get("Amount").value)
        console.log("test:::", ((parseFloat(group.get("Amount").value) < 0) ? false : true));
        // group.get('IsDebitEntry').setValue((parseFloat(group.get("Amount").value) < 0) ? false : true);

        group.get("newAddedRow").setValue(false);
        control.push(group);
      });
    } if (!this.ondemandFlagClaim) {
      this.mainVoucherForm.controls['CustomerID'].setValue(this.selectedRowItem[0].CustomerID);
      this.mainVoucherForm.controls['CustCode'].setValue(this.selectedRowItem[0].CustCode);
      /* defect Id  - 2932 fixes Narender */
      this.mainVoucherForm.controls['accountInfo'].get('TotallingAccCode').setValue(this.selectedRowItem[0].DNTotallingAcc);
      this.mainVoucherForm.controls['accountInfo'].get('GLCode').setValue(this.selectedRowItem[0].DNGLCode);

      this.selectedRowItem.map((item, index) => {
        const group = this.createDetailsArrayGroup();
        if (this.dnClaimsFlag) {
          group.addControl('EntryTypeCode', new FormControl());
          item['PreparedBy'] = sessionStorage.getItem(RSAConstants.LoggedInUserId);
          item['ModifiedBy'] = sessionStorage.getItem(RSAConstants.LoggedInUserId);
          group.addControl('TypeCode', new FormControl());
        }
        item['IsDebitEntry'] = (item.Amount < 0) ? false : true;
        if (!item.isVatRow) {
          this.toggleValueCredit[index] = item.Amount < 0 ? false : true;
          console.log(this.toggleValueCredit, 'this.toggleValueCredit');
        }
        group.patchValue(item);
        group.get('newAddedRow').setValue(false);

        control.push(group);

        const ctrl = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
        ctrl.controls.forEach((val, i) => {
          const amount = val.get('Amount').value;
          this.toggleValueCredit[i] = amount < 0 ? false : true;
        });

        /* please let me know [Ankappa] before enable */
        // (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get('Amount').setValue(item.Amount);
        // if (item.Amount > 0) {
        //   (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get('IsDebitEntry').setValue(true);
        // }
        // else {
        //   (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get('IsDebitEntry').setValue(false);
        // }
        // // if (this.dnClaimsFlag) {
        // //   (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get('IsDebitEntry').setValue(true);
        // // }
      });
    } else {
      if (this.isAllLob) {
        this.mainVoucherForm.controls['CustomerID'].setValue(this.selectedRowItem[0].CustomerID);
        this.mainVoucherForm.controls['CustCode'].setValue(this.selectedRowItem[0].CustCode);
        this.selectedRowItem.map((item, index) => {
          let group = this.createDetailsArrayGroup();
          item['IsDebitEntry'] = (item.Amount < 0) ? false : true;
          group.patchValue(item);
          group.get('Description').setValue(item.ConcDescription);
          group.get('newAddedRow').setValue(false);
          control.push(group);
        });
      } else {
        // this.getGlAccountHeader(this.TotAcccode, true);
        const group = this.createDetailsArrayGroup();
        if (this.TotAcccode && this.glnumber) {
          group.get('TotallingAccCode').setValue(this.TotAcccode);
          group.get('GLCode').setValue(this.glnumber);
          console.log(this.currentglDetail, ' currentglDetail');
        } else {
          group.get('GLCode').setValue('');
          group.get('GLCodeDesc').setValue('');
          group.get('TotallingAccCode').setValue('');
        }

        //  group.get('GLCode').setValue(this.mainVoucherForm.controls['DefaultGLCodeDesc'].value);
        control.push(group);
      }
    }
  }


  getGLdataCnDn(ev) {
    const totcode = ev.ev;
    console.log(totcode, 'totcode');
    super.getGlAccountHeaderDataCnDn(totcode, true);
  }

  /* form array for recept details */
  createDetailsArrayGroup(): FormGroup {
    return this.fb.group({
      Amount: [0, Validators.required],
      AnalysisCode: [],
      CostCenterCode: [sessionStorage.getItem('costcentre')],
      ClaimID: [],
      ClassCode: [],
      CauseOfLossCode: [],
      CounterPartyRef: [],
      CountryCode: [sessionStorage.getItem(RSAConstants.countrycode)],
      Description: [],
      DocumentCode: [],
      EntityID: [],
      GLCode: [sessionStorage.getItem(RSAConstants.defaultGLCode), Validators.required],
      GLCodeDesc: [sessionStorage.getItem(RSAConstants.defaultGLCodeDesc), Validators.required],
      LocationCode: [sessionStorage.getItem('locationcode')],
      LocationDesc: [sessionStorage.getItem(RSAConstants.locationdesc)],
      ModifiedBy: [],
      ModifiedDate: [],
      NatureOfLossCode: [],
      PolicyID: [],
      PolicyYear: [],
      PreparedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [],
      RefTransactionID: [],
      RefTransactionSerialNo: [],
      RefTransactionType: [11],
      RegionCode: [sessionStorage.getItem(RSAConstants.regionCode)],
      TotallingAccCode: [sessionStorage.getItem(RSAConstants.totallingaccount), Validators.required],
      PolicyType: [],
      newAddedRow: true,
      IsDebitEntry: [false],
      VoucherNo: [],
      SerialNo: [],
      Department: [],
      DepartmentCode: [],
      Endt_ID: [],
      SrNO: []
    });
  }

  /* set receipt mode and set default values   */
  setReceiptMode(val, paymentname) {
    this.mainVoucherForm.controls['PaymentMode'].setValue(val);
    this.paymentMode = val;
    this.paymentname = paymentname;
    this.createVoucherForm(this.paymentMode);
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;
    if (this.paymentMode == 1) {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1210');
    } else {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(sessionStorage.getItem(RSAConstants.totallingaccount));
      this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue(sessionStorage.getItem(RSAConstants.defaultBankCode));
    }
    this.setdefaultHeaderData();
    this.fieldStatusChanges();
    super.GetAccountingDates(new Date());
  }


  setTotAccTransCreCredit() {
    // getTotallingDetailData
    if (this.selectedRowItem.length) {
      this.selectedRowItem.map((item, index) => {
        const control = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index];
        if (control) {
          super.getTotallingDetailData({ index: index, flag: true });
        }
      });
    }
  }

  /* using req fields and update status  */
  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );
    this.cshvoucherdate.statusChanges.subscribe(
      status => {
        this.errorvoucherdate = (status === 'INVALID');
      }
    );
    this.cshreportHeaders.statusChanges.subscribe(
      status => {
        this.errorReportHeader = (status === 'INVALID');
      }
    );

    // this.glCodeValue.statusChanges.subscribe(
    //   status => {
    //     this.errorglCode = (status === 'INVALID');
    //   }
    // );

  }

  /* clear all errors after reset   */
  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    this.errorReportHeader = false;
    //this.errorglCode = false;
  }

  /* get the controls of each fields   */
  get cshpayeename() { return this.mainVoucherForm.controls.detailInfo['controls'].PayeeName; }
  get cshdetails() { return this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription; }
  get cshvoucherdate() { return this.mainVoucherForm['controls'].VoucherDate; }
  get cshreportHeaders() { return this.mainVoucherForm['controls'].Title; }
  // get glCodeValue() { return this.mainVoucherForm.controls.detailInfo['controls'].GLCode; }


  /* set Description in receptdetails desc   */
  setDescription() {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[0].get('Description').setValue(this.cshdetails.value);
  }

  // getPreviousValue(index) {
  //   (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).valueChanges.subscribe((data) => {
  //     this.previousAmountValue = this.mainVoucherForm.value['VoucherDetails'][index].Amount;
  //     console.log('Old value: ', this.previousAmountValue);
  //     console.log('New value: ', data);
  //     console.log(data[0].Amount,'data[index].Amount');
  //     if (this.previousAmountValue == data[0].Amount) {
  //       console.log('cmg-here');
  //       (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].setValue(0.00);
  //     }
  //   });
  // }

  getActualAmountSum(processFlag) {
    let total = 0;
    let amt = 0;
    let actualamt = 0;
    let flagtoggle = false;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {
      //  this.getPreviousValue(index);
      if (this.getFromFormArrayControlVal("Amount", index) != undefined
        && this.getFromFormArrayControlVal("Amount", index) != null) {
        flagtoggle = this.getFromFormArrayControlVal("IsDebitEntry", index);
        console.log(flagtoggle, 'flagtoggle');
        const Camt = parseFloat(this.getFromFormArrayControlVal("Amount", index));
        console.log(Camt, 'currentvalue');
        amt = Math.abs(Camt);
        if (processFlag == 'DN') {
          actualamt = (flagtoggle) ? amt : (amt * -1);
        }
        console.log('flagtoggle:' + flagtoggle + ",amt:" + amt + ",actualamt:" + actualamt);
        total = total + actualamt;
      }

    });
    this.totalAmount = total;
  }
  setCreditEntryDn(ev) {

    console.log(ev.event.target.checked, '<<<<key');
    const actualData = Number(ev.data.controls['Amount'].value);
    //const curdata = -(ev.data.controls['Amount'].value);
    // ev.data.controls['Amount'].patchValue(curdata);

    if (actualData === 0 || actualData === undefined) {
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.EMPTYAMOUNTCHECK,
        'btnaction': RSAMSGConstants.OKTEXT
      });
      ev.event.target.checked = false;

    }
    //console.log(ev.event.target.checked, 'ev.event.target.checked');
    // (<FormArray>this.mainVoucherForm.controls['VoucherDetails'])
    //   .controls[ev.index].get(ev.iscredit).setValue(ev.event.target.checked);
    this.setFormArrayCTRLDefaultValue(ev.iscredit, ev.index, ev.event.target.checked);
    this.getActualAmountSum('DN');
    if (this.totalAmount > 0) {
      ev.event.target.checked = false;
      this.setFormArrayCTRLDefaultValue(ev.iscredit, ev.index, false);
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.CREDITEXCEEDMSG,
        'btnaction': RSAMSGConstants.OKTEXT
      });
    }
    this.getActualAmountSum('DN');
  }



  /* add receipt in review screen */
  addReceipt(len) {
    this.ifnewlyAddedRow = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('newAddedRow').value;
    console.log(this.ifnewlyAddedRow, 'ifnewlyAddedRow');
    const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    const CurrentAmount = Math.abs((<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('Amount').value);
    // const toggleFlag = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('IsDebitEntry').value;
    // let totalAmount = (!toggleFlag)?CurrentAmount * -1:CurrentAmount;
    if (CurrentAmount != null && CurrentAmount != 0 && CurrentAmount != undefined) {
      this.isNewRow = true;
      control.push(this.createDetailsArrayGroup());
      this.setFormArrayCTRLDefaultValue('GLCode', len, '');
      this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '');
      this.setFormArrayCTRLDefaultValue('TotallingAccCode', len, '');
      // super.getTotallingDetailData({ index: len, flag: true, isOndemand: true });
      // this.dtltotallingacc[len] = this.cachedDtlTot;
      this.setOndemandTotallingDetail({ index: len });
      this.glaccount[len] = [];
    } else {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      return false;
    }
  }

  reSetForm(params) {
    const param = params.defaultParam;
    /*set default value here and reset */
    if (param == 1) {
      super.validateAllFormFields(this.mainVoucherForm);
      this.mainVoucherForm.controls.VoucherDate.setValue([new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]);
      this.mainVoucherForm.controls.GLCode.setValue(sessionStorage.getItem(RSAConstants.defaultGLCode));
      this.mainVoucherForm.controls.GLCodeDesc.setValue(sessionStorage.getItem(RSAConstants.defaultGLCodeDesc));
      this.clearerrors();
    } else if (param == 2) {
      this.mainVoucherForm.controls['VoucherDetails'].reset();
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('LocationCode').setValue([sessionStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([sessionStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(sessionStorage.getItem(RSAConstants.totallingaccount));
        item.get('GLCode').setValue(sessionStorage.getItem(RSAConstants.defaultGLCode));
        item.get('GLCodeDesc').setValue(sessionStorage.getItem(RSAConstants.defaultGLCodeDesc));
      });
      this.getActualAmountSum('DN');
    }
    super.GetAccountingDates(new Date());
  }
  updateDebitVoucherValues(dataReturn: any) {
    this.mainVoucherForm.addControl('DebitNoteNo', new FormControl(dataReturn.DebitNoteNo));
  }
  /* update  form values to create-receipt objects*/
  createCNFormValues() {
    this.createDebitNotes = new CreateDebitNotes();
    const mainFormFieldArray = ['VoucherDate', 'ApprovedBy', 'ArabicDescription',
      'CountryCode', 'CustomerID', 'CustCode', 'ModifiedDate', 'ModifiedBy', 'PostedDate',
      'PreparedBy', 'PreparedDate', 'PreprintNo', 'PrintDate', 'RefreshDate', 'RegionCode', 'Title',
      'Approvers'];
    mainFormFieldArray.forEach(item => {
      console.log('this.item****', item);
      this.createDebitNotes[item] = this.mainVoucherForm.controls[item].value;
    });
    if (this.mainVoucherForm.controls['DebitNoteNo']) {
      this.prevPreviewID = this.mainVoucherForm.controls['DebitNoteNo'].value;
    }
    this.createDebitNotes.PreparedDate = this.mainVoucherForm.controls['VoucherDate'].value;
    this.createDebitNotes.LocationCode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    this.createDebitNotes.CostCenterCode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    this.createDebitNotes.TotallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    this.createDebitNotes.GLCode = this.mainVoucherForm.controls.accountInfo['controls'].GLCode.value;

    this.createDebitNotes.PayeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
    this.createDebitNotes.EnglishDescription = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
    this.createDebitNotes.DebitNoteDetail = this.mainVoucherForm.controls['VoucherDetails'].value;
    this.createDebitNotes.TaxPointDate = this.mainVoucherForm.controls['TaxPointDate'].value;
    console.log('this.createCreditNotes****', this.createDebitNotes);

  }
  preSubmission(precessFlag) {
    let flagtoggle: boolean = false;
    let amt: number = 0;
    this.clonedDebitNotes = Object.assign({}, this.createDebitNotes);
    this.clonedDebitNotes.DebitNoteDetail.forEach((element, index) => {
      flagtoggle = element.IsDebitEntry;
      if (!flagtoggle && precessFlag == 'DN') {
        element.Amount = (Math.abs(element.Amount)) * -1;
      }
      if (this.dnVATFlag && !this.ifnewlyAddedRow) {
        if ((index % 2) !== 0) {
          console.log(element, 'element');
          element.DNVATAmount = element.Amount;
          element.Amount = element.Amount;
        }
        element['CNVATflag'] = true;
      }
    });
    console.log('this.clonedDebitNotes', this.clonedDebitNotes);
  }
  /* create-receipt form*/
  submitForm() {
    console.log(this.totalAmount, 'toatalamount');
    super.validateDetailInfo();
    this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;
    this.errorvoucherdate = this.cshvoucherdate.invalid;
    if (this.isUAE && this.isReportFlag) {
      this.errorReportHeader = this.cshreportHeaders.invalid;
    }
    // zero amount warning
    if (this.amountZeroCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTZEROCHECK);
      return false;
    }
    if (!(!this.errorpayee && !this.errordetail && !this.errorvoucherdate && !this.errorglCode)) {
      return false;
    }
    if (this.amountLimitCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTEXCEEDMSG);
      return false;
    }
    if (this.glerrorcount > 0) {
      return false;
    }
    if (this.totaccrorcount > 0) {
      return false;
    }
    if (this.submitError > 0) {
      this.alertService.warn(RSAMSGConstants.REQFIELDERROR);
      return false;
    }
    this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
      this.approverusers.length > 0);
    if (this.totalAmount < 0) {
      // UAE Approver is not needed for country=3
      // if (!(sessionStorage.getItem(RSAConstants.regionCode) == '2')) {
      //   // if (this.totalAmount < -99999 && !this.usersReq) {
      //   //   return false;
      //   // }
      // }

      this.createCNFormValues();

      console.log(this.createDebitNotes, ' this.createCreditNotes');
      if (this.prevPreviewID == null || this.prevPreviewID == undefined)
        this.prevPreviewID = 0;
      this.createDebitNotes["DebitNoteNo"] = this.prevPreviewID;
      this.preSubmission('DN');
      //this.clonedDebitNotes["DebitNoteNo"] = this.prevPreviewID;

      if (this.dnVATFlag) {
        this.clonedDebitNotes['dnVATFlag'] = true;
      }

      if (this.isUAE && this.errorReportHeader && this.isReportFlag) {
        return false;
      }

      console.log('this.prevPreviewID', this.prevPreviewID);
      // console.log("cloned debit notes"+JSON.stringify(this.clonedDebitNotes));
      this.createPaymentService.createDebitNote(JSON.stringify(this.clonedDebitNotes)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.updateDebitVoucherValues(dataReturn);
          this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = true;
          this.previewFlag = true;
          // tslint:disable-next-line:max-line-length
          this.bsModalRef = this.modalService.show(TaxinvoicepreviewComponent, { class: 'preview-modal-dailog', keyboard: false, ignoreBackdropClick: true });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
          this.bsModalRef.content.backdrop = true;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
    if (this.totalAmount >= 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTTEXTREQ);
    }
  }


  getGlAccountHeader(totAccCode, detailFlag) {
    const param = 'totAccCode=' + totAccCode +
      '&ccCode=' + sessionStorage.getItem('costcentre');
    this.masterDataService.getDetailGlAccount(param).subscribe(data => {
      this.glAcountHeader = data;
      let code = this.glAcountHeader.filter(itemX => itemX.Code === this.glnumber);
      if (detailFlag) {
        this.currentglDetail = code;
      } else {
        if (this.selectedRowItem && this.selectedRowItem.length > 0) {
          // tslint:disable-next-line:max-line-length
         const  glcode = (this.selectedRowItem && this.selectedRowItem[0].DNGLCode) ? this.selectedRowItem[0].DNGLCode : this.selectedRowItem[0].GLCode;
         code = this.glAcountHeader.filter(itemX => itemX.Code === glcode);
        }
        if (code.length > 0) {
          this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(code[0].Code);
        } else {
          this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(data[0].Code);
        }
      }
    });
  }

  setGLHdrHiddenValue(ev) {
    console.log(ev);
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue(ev.item.Code);
  }
  clearHdrGLCode(ev) {
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue('');
    this.mainVoucherForm.controls.detailInfo['controls'].GLCodeDesc.setValue('');
  }
  changeTaxPointDate() {
    if (this.mainVoucherForm.controls['TaxPointDate'].value) {
      const TaxPointDate = new Date(this.mainVoucherForm.controls['TaxPointDate'].value);
      this.mainVoucherForm.controls['TaxPointDate'].setValue(new DatePipe('en-US').transform(TaxPointDate, 'dd/MM/yyyy'));
    }
  }

}