import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';

@Component({
  selector: 'rsa-drafts-header',
  templateUrl: './drafts-header.component.html',
  styleUrls: ['./drafts-header.component.scss']
})
export class DraftsHeaderComponent implements OnInit {
  @Input() catid: number;
  constructor(private router: Router) { }
  TaxInv;
  ngOnInit() {
    this.TaxInv = (sessionStorage.getItem(RSAConstants.country) === 'OMAN')?'Debit Notes':'Tax Invoices';
  }
  getVoucherType(vochername) {
    const params = {
      'voucherName': vochername,
    };
    //console.log(params);
    this.router.navigate(['finance/search/draft'], {
      queryParams: params
    });
  }
}

