import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DraftsHeaderComponent } from './drafts-header.component';

describe('DraftsHeaderComponent', () => {
  let component: DraftsHeaderComponent;
  let fixture: ComponentFixture<DraftsHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DraftsHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DraftsHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

