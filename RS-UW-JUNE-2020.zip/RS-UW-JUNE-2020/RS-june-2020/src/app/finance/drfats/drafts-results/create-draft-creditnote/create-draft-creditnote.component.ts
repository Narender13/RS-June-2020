import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { SharedService } from 'src/app/finance/services/shared.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { CreateReceipt } from 'src/app/finance/search/model/create-receipt';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreateCreditNotes } from 'src/app/finance/creditnotes/create-creditnotes/model/create-cn';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { CreateCreditnotesService } from 'src/app/finance/creditnotes/create-creditnotes/service/create-creditnotes.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { CnpreviewComponent } from 'src/app/finance/preview/uae/cnpreview/cnpreview.component';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
import { Router } from '@angular/router';
@Component({
  selector: 'rsa-create-draft-creditnote',
  templateUrl: './create-draft-creditnote.component.html',
  styleUrls: ['./create-draft-creditnote.component.scss']
})
export class CreateDraftCreditnoteComponent extends BasevoucherComponent implements OnInit, OnDestroy {
  title = 'Credit Note';
  currency = sessionStorage.getItem(RSAConstants.currency);
  errorpayee: boolean;
  errordetail: boolean;
  errorglCode: boolean;
  /* form error-feilds */
  errorbankcodeCheque: boolean;
  level: any = 2;
  errorbankcodeBanktransfer: boolean;
  errorpaayeebanknameCheque: boolean;
  errorpaayeebanknameBanktransfer: boolean;
  errorchequedateCheque: boolean;
  errorchequedateBankT: boolean;
  errorchequedateCreditCard: boolean;
  errorchequenoCheque: boolean;
  errorchequenoCreditCard: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  matchedRecords = [];
  isUploadUnmatched;
  returnValue: any;
  usersReq;
  symbol;
  glAcountHeader: any = [];
  createCreditNotes: CreateCreditNotes;
  animatedClass = true;
  selectedRowItem: any = [];
  creditnoteEditData: any = [];
  customerName: string = "";
  ondemandFlag: boolean = false;
  ondemandFlagClaim = true;
  formArray: any;
  isCreditNote;
  unApproved;
  customOnDemandFlag: boolean = true;
  selectedRowEntitiDataTable: any;
  isStateClosed: boolean = false;

  @ViewChild('tabset') tabset: TabsetComponent;
  errorReportHeader: boolean;
  isUAE: boolean = false;

  constructor(
    protected sharedService: SharedService,
    private fb: FormBuilder,
    protected modalService: BsModalService,
    protected bsModalRef: BsModalRef,
    protected masterDataService: MasterDataService,
    protected utilityClass: UtilityClass,
    protected createPaymentService: CreateCreditnotesService,
    private alertService: AlertService,
    private router: Router
  ) {
    super(masterDataService, sharedService, modalService, utilityClass, bsModalRef);
    //super.setMinMaxDate();
  }
  ngOnInit() {
    /* super with method is calling from BasevoucherComponent */
    this.regionCode = sessionStorage.getItem(RSAConstants.regionCode);
    this.createVoucherForm(this.paymentMode);
    this.isUAE = (sessionStorage.getItem('regioncode') == '2') ? true : false;
    if (this.isUAE) {
      super.getAllReportHeadersCreditNote();
      this.mainVoucherForm.controls['Title'].setValidators([Validators.required]);
      this.mainVoucherForm.controls['Title'].updateValueAndValidity();
    }
    this.isRowDraftCN = true;
    this.cnEditData = this.creditnoteEditData;
    //console.log(this.cnEditData, 'this.cnEditData');
    this.customOnDemandFlag = this.checkonDemandOrOnAccount(this.cnEditData.CreditNoteDetail);
    super.getAllBranchData();
    super.setBranchData(this.cnEditData.LocationCode);
    super.getAllCostCenterData({ ev: null, index: 0, flag: true });
    super.getAllTotallingData(true);
    super.getAllProjData();
    super.getAllDeptData();
    super.getAllMasterData2();
    this.fieldStatusChanges();
    super.getModelPreviousClose();
    super.closeModel();
    super.getAllTranData();
    this.symbol = (sessionStorage.getItem('symbol'));
    //super.setMinMaxDate();
    this.selectedRowEntitiDataTable = this.cnEditData.CreditNoteDetail;
    this.getPreviousRows();
    super.GetAccountingDates(this.cnEditData.VoucherDate);
    this.getGlAccountHeader();
    this.getDetailsArrayFormGroup();
    super.getModelPreviousClose();
    super.getAllgetLookupBanksData();
    // console.log(this.selectedRowItem, 'selectedRowItem');
    super.getTotalingHeaderDataCnDn();
    const totcode = this.creditnoteEditData.TotallingAccCode;
    super.getGlAccountHeaderDataCnDn(totcode);
    this.getActualAmountSum('CN');
    this.setHeaderData();
    console.log(this.creditnoteEditData, 'creditnoteEditData');
    this.sharedService.getMessage().subscribe(val => {
      if (val == 'close') {
        this.isStateClosed = true;
        this.mainVoucherForm.markAsPristine();
        this.mainVoucherForm.markAsUntouched();
      }
    });
    this.getPreviousRows();
  }

  ngOnDestroy() {
    if (!this.isStateClosed) {
      this.addRowsToSession();
    }
  }
  addRowsToSession() {
    this.selectedRowEntitiDataTable.forEach(row => {
      row.isFromDraft = 'true';
    });
    if (this.selectedRowEntitiDataTable.length > 0) {
      sessionStorage.setItem('SnackbarAdded', 'true');
      sessionStorage.setItem('isFromDraft', 'true');
      let vType = 'CreditNote';
      this.prevPreviewID = this.cnEditData.CreditNoteNo;
      let voucherDetail = { SelectedRows: this.selectedRowEntitiDataTable, voucherType: vType, VoucherNo: this.prevPreviewID };
      sessionStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
      let voucherDate = this.mainVoucherForm['controls'].VoucherDate.value;
      let totallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
      let glCode = this.mainVoucherForm.controls.accountInfo['controls'].GLCode.value;
      let description = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
      let payeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
      var commonData = { VoucherDate: voucherDate, TotallingAccCode: totallingAccCode, GLCode: glCode, Description: description, PayeeName: payeeName }
      sessionStorage.setItem('CommonCNData', JSON.stringify(commonData));//CommonDNData
      sessionStorage.setItem('CNStateExists', 'true');
      this.updateRows();
      this.sharedService.sendMessage('CNSnackbarAdded');
    }
  }

  updateRows() {
    let formarray = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    if (formarray.controls.length > 0) {
      let voucherDetail = JSON.parse(sessionStorage.getItem('VoucherDetail'));
      voucherDetail.SelectedRows = [];
      formarray.controls.forEach(ctrl => {
        let rowClone = Object.assign({}, ctrl.value);
        rowClone.Amount = (rowClone.Amount) ? rowClone.Amount : 0;
        rowClone.Amount = parseInt(rowClone.Amount);
        rowClone.CNTotallingAcc = rowClone.TotallingAccCode;
        rowClone.CNVATAmount = 0;
        rowClone.isFromDraft = 'true';
        voucherDetail.SelectedRows.push(rowClone)
      });
      sessionStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
    }
  }

  getPreviousRows() {
    const SnackbarAdded = sessionStorage.getItem('SnackbarAdded');
    if (SnackbarAdded == 'true') {
      const voucherDetail = JSON.parse(sessionStorage.getItem('VoucherDetail'));
      if (this.cnEditData.CreditNoteNo == voucherDetail.VoucherNo) {
        this.cnEditData.CreditNoteDetail = voucherDetail.SelectedRows;
        this.selectedRowEntitiDataTable = voucherDetail.SelectedRows;

      } else {
        this.selectedRowEntitiDataTable = this.cnEditData.CreditNoteDetail;
      }
    } else {
      this.selectedRowEntitiDataTable = this.cnEditData.CreditNoteDetail;
    }
  }
  /* create entiti form */
  createVoucherForm(param): void {
    this.mainVoucherForm = null;

    this.mainVoucherForm = this.fb.group({
      VoucherDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ApprovedBy: [],
      ArabicDescription: [],
      Amount: [''],
      CountryCode: [sessionStorage.getItem(RSAConstants.countrycode)],
      CustomerID: [],
      CustCode: [],
      ModifiedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      ModifiedDate: [],
      PreparedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [],
      ReprintNo: [],
      PrintDate: [],
      RefreshDate: [],
      PostedDate: [],
      PreprintNo: [],
      Title: [],
      RegionCode: [sessionStorage.getItem('regioncode')],
      Approvers: this.fb.array([]),
      detailInfo: this.fb.group({
        PayeeName: [this.customerName, Validators.required],
        EnglishDescription: ['', Validators.required],
      }),
      accountInfo: this.fb.group({
        LocationCode: [sessionStorage.getItem('locationcode')],
        CostCenterCode: [sessionStorage.getItem('costcentre')],
        TotallingAccCode: [sessionStorage.getItem(RSAConstants.totallingaccount)],
        GLCode: [sessionStorage.getItem(RSAConstants.defaultGLCode), Validators.required],
        GLCodeDesc: [sessionStorage.getItem(RSAConstants.defaultGLCodeDesc), Validators.required]
      }),
      VoucherDetails: this.fb.array([]),
      TaxPointDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]
    });
  }

  getGLdataCnDn(ev) {
    const totcode = ev.ev;
    console.log(totcode, 'totcode');
    super.getGlAccountHeaderDataCnDn(totcode, true);
  }
  setHeaderData() {
    this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(this.creditnoteEditData.TotallingAccCode);
    this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(this.creditnoteEditData.GLCode);
    this.mainVoucherForm.controls.accountInfo['controls'].GLCodeDesc.setValue(this.creditnoteEditData.GLCodeDesc);
    this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.setValue(this.creditnoteEditData.PayeeName);
    this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(this.creditnoteEditData.EnglishDescription);
    this.mainVoucherForm.controls['ModifiedDate'].setValue(this.creditnoteEditData.ModifiedDate);
    this.mainVoucherForm.controls['Title'].setValue(this.creditnoteEditData.Title);
    if (this.creditnoteEditData.TaxPointDate === null || this.creditnoteEditData.TaxPointDate === undefined || this.creditnoteEditData.TaxPointDate === '01/01/0001') {
      this.creditnoteEditData.TaxPointDate = new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy');
    }
    if (this.checkValidDateOrNot(this.creditnoteEditData.TaxPointDate) === true) {
      this.creditnoteEditData.TaxPointDate = null;
    }
    this.mainVoucherForm.controls['TaxPointDate'].setValue(this.creditnoteEditData.TaxPointDate);
  }
  checkValidDateOrNot(date: string) {
    if (date) {
      let datestr = date.split(' ');
      if (datestr.length > 1) {
        return true;
      } else {
        return false;
      }
    }
  }
  getDetailsArrayFormGroup() {
    console.log('creditnoteEditData>>>', this.creditnoteEditData.CreditNoteDetail);
    this.selectedRowItem = this.creditnoteEditData.CreditNoteDetail;

    let control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    if (!this.ondemandFlag) {
      this.mainVoucherForm.controls['CustomerID'].setValue(this.creditnoteEditData.CustomerID);
      this.mainVoucherForm.controls['CustCode'].setValue(this.creditnoteEditData.CustCode);
      this.mainVoucherForm.controls['PreparedDate'].setValue(this.creditnoteEditData.PreparedDate);

      console.log(this.selectedRowItem, 'this.selectedRowItem');
      this.selectedRowItem.map((item, index) => {
        super.getAllCostCenterData({ ev: null, index: index, flag: true });
        let group = this.createDetailsArrayGroup();
        group.patchValue(item);
        group.get("newAddedRow").setValue(false);
        group.get('IsDebitEntry').setValue((parseFloat(group.get("Amount").value) < 0) ? false : true);
        control.push(group);
      });
    } else {
      control.push(this.createDetailsArrayGroup());
    }
  }

  /* form array for recept details */
  createDetailsArrayGroup(): FormGroup {
    return this.fb.group({
      Amount: ['', Validators.required],
      AnalysisCode: [],
      CostCenterCode: [sessionStorage.getItem('costcentre')],
      ClaimID: [],
      ClassCode: [],
      CauseOfLossCode: [],
      CounterPartyRef: [],
      CountryCode: [sessionStorage.getItem(RSAConstants.countrycode)],
      Description: [],
      DocumentCode: [],
      EntityID: [],
      GLCode: [sessionStorage.getItem(RSAConstants.defaultGLCode), Validators.required],
      GLCodeDesc: [sessionStorage.getItem(RSAConstants.defaultGLCodeDesc), Validators.required],
      LocationCode: [sessionStorage.getItem('locationcode')],
      LocationDesc: [sessionStorage.getItem(RSAConstants.locationdesc)],
      ModifiedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      ModifiedDate: [],
      NatureOfLossCode: [],
      PolicyID: [],
      PolicyYear: [],
      PreparedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [],
      RefTransactionID: [],
      RefTransactionSerialNo: [],
      RefTransactionType: [10],
      RegionCode: [sessionStorage.getItem(RSAConstants.regionCode)],
      TotallingAccCode: [sessionStorage.getItem(RSAConstants.totallingaccount), Validators.required],
      PolicyType: [],
      newAddedRow: true,
      VoucherNo: [],
      IsDebitEntry: [true],
      SerialNo: [],
      SrNO: [],
      Department: [],
      DepartmentCode: [],
      CNVATAmount: [],
    });
  }

  /* set receipt mode and set default values   */
  setReceiptMode(val, paymentname) {
    this.mainVoucherForm.controls['PaymentMode'].setValue(val);
    this.paymentMode = val;
    this.paymentname = paymentname;
    this.createVoucherForm(this.paymentMode);
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;
    if (this.paymentMode == 1) {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1210');
    } else {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(sessionStorage.getItem(RSAConstants.totallingaccount));
      // this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue(sessionStorage.getItem(RSAConstants.defaultBankCode));
    }
    this.setdefaultHeaderData();
    this.fieldStatusChanges();
    super.GetAccountingDates(this.cnEditData.VoucherDate);
  }


  /* using req fields and update status  */
  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );
    this.cshreportHeaders.statusChanges.subscribe(
      status => {
        this.errorReportHeader = (status === 'INVALID');
      }
    );

    // this.glCodeValue.statusChanges.subscribe(
    //   status => {
    //     this.errorglCode = (status === 'INVALID');
    //   }
    // );

  }
  getActualAmountSum(processFlag) {
    let total = 0;
    let amt = 0;
    let actualamt = 0;
    let flagtoggle = true;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {

      if (this.getFromFormArrayControlVal('Amount', index) != undefined
        && this.getFromFormArrayControlVal('Amount', index) != null) {
        flagtoggle = this.getFromFormArrayControlVal('IsDebitEntry', index);
        amt = parseFloat(this.getFromFormArrayControlVal('Amount', index));
        amt = Math.abs(amt);
        if (processFlag == 'CN') {
          actualamt = (flagtoggle) ? amt : (amt * -1);
        }
        console.log('flagtoggle:' + flagtoggle + ',amt:' + amt + ',actualamt:' + actualamt);
        total = total + actualamt;
      }
    });
    this.totalAmount = total;
  }
  updateDetailsAmount(processFlag) {
    let amt = 0;
    let actualamt = 0;
    let flagtoggle = true;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {

      if (this.getFromFormArrayControlVal('Amount', index) != undefined
        && this.getFromFormArrayControlVal('Amount', index) != null) {
        flagtoggle = this.getFromFormArrayControlVal('IsDebitEntry', index);
        amt = parseFloat(this.getFromFormArrayControlVal('Amount', index));
        amt = Math.abs(amt);
        if (processFlag == 'CN') {
          actualamt = (flagtoggle) ? amt : (amt * -1);
        }
        this.setFormArrayCTRLDefaultValue('Amount', index, actualamt);
      }
    });
  }
  setDebitEntry(ev) {
    console.log(ev, '<<<<key');
    const actualData = Number(ev.data.controls['Amount'].value);

    if (actualData === 0 || actualData === undefined) {
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.AMOUNTVALIDATIONMSG,
        'btnaction': RSAMSGConstants.OKTEXT
      });
      ev.event.target.checked = !ev.event.target.checked;

    }
    this.setFormArrayCTRLDefaultValue(ev.isDebit, ev.index, ev.event.target.checked);
    this.getActualAmountSum('CN');
    if (this.totalAmount < 0) {
      ev.event.target.checked = true;
      this.setFormArrayCTRLDefaultValue(ev.isDebit, ev.index, true);
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.DEBITEXCEEDMSG,
        'btnaction': RSAMSGConstants.OKTEXT
      });
    }
    this.getActualAmountSum('CN');
  }

  /* clear all errors after reset   */
  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    this.errorReportHeader = false;
    // this.errorglCode = false;
  }

  /* get the controls of each fields   */
  get cshpayeename() { return this.mainVoucherForm.controls.detailInfo['controls'].PayeeName; }
  get cshdetails() { return this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription; }
  get cshreportHeaders() { return this.mainVoucherForm['controls'].Title; }
  //get glCodeValue() { return this.mainVoucherForm.controls.detailInfo['controls'].GLCode; }


  /* set Description in receptdetails desc   */
  setDescription() {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[0].get('Description').setValue(this.cshdetails.value);
  }


  /* add receipt in review screen */
  addReceipt(len, newRow) {
    console.log(newRow);
    const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    const CurrentAmount = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('Amount').value;
    if (newRow) {
      if (CurrentAmount != null && CurrentAmount != 0 && CurrentAmount != undefined) {
        control.push(this.createDetailsArrayGroup());
        this.setFormArrayCTRLDefaultValue('GLCode', len, '');
        this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '');
        this.setFormArrayCTRLDefaultValue('TotallingAccCode', len, '');

        // this.dtltotallingacc[len] = this.cachedDtlTot;
        this.setOndemandTotallingDetail({ index: len });
        this.glaccount[len] = [];
      } else {
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
        return false;
      }
    }

    // if (newRow){
    //   if (CurrentAmount != null && CurrentAmount != 0 && CurrentAmount != undefined){}
    // }
  }



  reSetForm(params) {
    const param = params.defaultParam;
    /*set default value here and reset */
    if (param == 1) {
      super.validateAllFormFields(this.mainVoucherForm);
      this.mainVoucherForm.controls.VoucherDate.setValue([new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]);
      this.mainVoucherForm.controls.GLCode.setValue(sessionStorage.getItem(RSAConstants.defaultGLCode));
      this.mainVoucherForm.controls.GLCodeDesc.setValue(sessionStorage.getItem(RSAConstants.defaultGLCodeDesc));
      this.clearerrors();
    } else if (param == 2) {
      this.mainVoucherForm.controls['VoucherDetails'].reset();
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('LocationCode').setValue([sessionStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([sessionStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(sessionStorage.getItem(RSAConstants.totallingaccount));
        item.get('GLCode').setValue(sessionStorage.getItem(RSAConstants.defaultGLCode));
        item.get('GLCodeDesc').setValue(sessionStorage.getItem(RSAConstants.defaultGLCodeDesc));
      });
      this.getActualAmountSum('CN');
    }
    super.GetAccountingDates(this.cnEditData.VoucherDate);
  }

  updateCreditVoucherValues(dataReturn: any) {
    this.mainVoucherForm.addControl('CreditNoteNo', new FormControl(dataReturn.CreditNoteNo));
  }
  /* update  form values to create-receipt objects*/
  createCNFormValues() {
    this.createCreditNotes = new CreateCreditNotes();
    const mainFormFieldArray = ['VoucherDate', 'ApprovedBy', 'ArabicDescription',
      'CountryCode', 'CustomerID', 'CustCode', 'ModifiedDate', 'ModifiedBy', 'PostedDate',
      'PreparedBy', 'PreparedDate', 'PreprintNo', 'PrintDate', 'RefreshDate', 'RegionCode', 'Title',
      'Approvers'];
    mainFormFieldArray.forEach(item => {
      console.log('this.item****', item);
      this.createCreditNotes[item] = this.mainVoucherForm.controls[item].value;

    });
    if (this.mainVoucherForm.controls['CreditNoteNo']) {
      this.prevPreviewID = this.mainVoucherForm.controls['CreditNoteNo'].value;
    }
    this.createCreditNotes.LocationCode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    this.createCreditNotes.CostCenterCode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    this.createCreditNotes.TotallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    this.createCreditNotes.GLCode = this.mainVoucherForm.controls.accountInfo['controls'].GLCode.value;
    this.createCreditNotes.PayeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
    this.createCreditNotes.EnglishDescription = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
    this.createCreditNotes.CreditNoteDetail = this.mainVoucherForm.controls['VoucherDetails'].value;
    this.createCreditNotes.TaxPointDate = this.mainVoucherForm.controls['TaxPointDate'].value;
    this.createCreditNotes.ModifiedDate = this.mainVoucherForm.controls['ModifiedDate'].value;
    console.log('this.createCreditNotes****', this.createCreditNotes);
  }

  /* create-receipt form*/
  submitForm() {
    super.validateDetailInfo();
    this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;
    //  this.errorglCode = this.glCodeValue.invalid;
    if (!(!this.errorpayee && !this.errordetail && !this.errorglCode)) {
      return false;
    }

    //zero amount warning
    if (this.amountZeroCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTZEROCHECK);
      return false;
    }
    if (this.glerrorcount > 0) {
      return false;
    }
    if (this.submitError > 0) {
      this.alertService.warn(RSAMSGConstants.REQFIELDERROR);
      return false;
    }
    // this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
    //   this.approverusers.length > 0);
    if (this.totalAmount > 0) {
      // if (!(sessionStorage.getItem(RSAConstants.regionCode) == '2')) {
      //   if (this.totalAmount > 99999 && !this.usersReq) {
      //     return false;
      //   }
      // }
      this.updateDetailsAmount('CN');
      this.createCNFormValues();
      console.log(this.createCreditNotes, ' this.createCreditNotes');
      if (this.prevPreviewID == null || this.prevPreviewID == undefined) {
        this.prevPreviewID = 0;
        this.createCreditNotes["CreditNoteNo"] = this.prevPreviewID;
      }
      this.createCreditNotes["CreditNoteNo"] = this.creditnoteEditData.CreditNoteNo;

      if (this.isUAE && this.customOnDemandFlag) {
        if (this.mainVoucherForm.controls['Title'].value === null || this.mainVoucherForm.controls['Title'].value === '' || this.mainVoucherForm.controls['Title'].value === undefined) {
          return false;
        }
      }
      //  console.log("\ncreate Draft credit note"+JSON.stringify(this.createCreditNotes));
      this.createPaymentService.createCreditNote(JSON.stringify(this.createCreditNotes)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.updateCreditVoucherValues(dataReturn);
          //for concurrency supported
          if (this.returnValue.IsRejectandEdit) {
            this.checkConcurrency();
          } else {
            this.returnValue['approverlist'] = this.approverusers;
            this.returnValue['ondemand'] = true;
            this.previewFlag = true;
            this.bsModalRef = this.modalService.show(CnpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
            this.bsModalRef.content.data = this.returnValue;
            this.bsModalRef.content.totalAmount = this.totalAmount;
            this.bsModalRef.content.backdrop = true;
            this.bsModalRef.content.unApproved = this.unApproved;
          }

        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
    if (this.totalAmount <= 0) {
      this.alertService.warn(RSAMSGConstants.DEBITEXCEEDMSG);
    }
  }
  checkConcurrency() {
    this.displayAlertModal({
      'title': '',
      'txt': RSAMSGConstants.MSGFORCONCURRENCY,
      'btnaction': RSAMSGConstants.BTNPROCEED,
      'btncancel': RSAMSGConstants.BTNCANCEL
    });
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data === 'PROCEED') {
        this.modalService.hide(1);
        this.router.navigate(['/finance']);
      }
    });
  }


  getGlAccountHeader() {
    const param = 'totAccCode=' + this.creditnoteEditData.TotallingAccCode +
      '&ccCode=' + this.creditnoteEditData.CostCenterCode;
    this.masterDataService.getDetailGlAccount(param).subscribe(data => {
      this.glAcountHeader = data;
      console.log('gldata', data);
      const isGLCodeAvailable = data.filter(item => item.Code == this.creditnoteEditData.GLCode);
      if (isGLCodeAvailable.length <= 0) {
        this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(data[0].Code);
      }
    });
  }

  setGLHdrHiddenValue(ev) {
    console.log(ev);
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue(ev.item.Code);
  }
  clearHdrGLCode(ev) {
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue('');
    this.mainVoucherForm.controls.detailInfo['controls'].GLCodeDesc.setValue('');
  }
  changeTaxPointDate() {
    if (this.mainVoucherForm.controls['TaxPointDate'].value) {
      const TaxPointDate = new Date(this.mainVoucherForm.controls['TaxPointDate'].value);
      this.mainVoucherForm.controls['TaxPointDate'].setValue(new DatePipe('en-US').transform(TaxPointDate, 'dd/MM/yyyy'));
    }
  }
  checkonDemandOrOnAccount(editData: any) {
    let onDemandorOnAccount: boolean = true;
    if (editData && editData.length > 0) {
      editData.forEach(element => {
        if (element.ClaimID !== null && element.PolicyID !== null) {
          onDemandorOnAccount = false;
        }
      });
    }
    return onDemandorOnAccount;
  }
}

