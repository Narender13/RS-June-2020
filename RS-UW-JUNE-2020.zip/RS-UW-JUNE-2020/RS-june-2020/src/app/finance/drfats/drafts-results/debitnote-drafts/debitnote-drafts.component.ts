import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { SharedService } from 'src/app/finance/services/shared.service';
import { CreateDraftDebitnoteComponent } from '../../../drfats/drafts-results/create-draft-debitnote/create-draft-debitnote.component';
import { TaxinvoicepreviewComponent } from 'src/app/finance/preview/uae/taxinvoicepreview/taxinvoicepreview.component';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';

@Component({
  selector: 'rsa-debitnote-drafts',
  templateUrl: './debitnote-drafts.component.html',
  styleUrls: ['./debitnote-drafts.component.scss']
})
export class DebitnoteDraftsComponent implements OnInit {

  @Input() debitnoteDraftData: any = [];
  @Input() VName:string;
  bsModalRef: BsModalRef;
  buttonName: { id: string; name: string; access: boolean; }[];
  selectedRowEntitiDataTable: any;
  totalVoucherCount: number;
  showSnackbar: boolean;
  totalVoucherAmount: number;
  isClosed=false;
  constructor(private modalService: BsModalService,private sharedService: SharedService) { }

  ngOnInit() {
    console.log(this.debitnoteDraftData, 'debitnoteDraftData-cpomp');
    this.sharedService.getMessage().subscribe(val => {
      if (val === 'DNSnackbarAdded') {
        if(!this.isClosed){
          this.displaySnackBar();
        }
      } 
      if (val == 'close' || val == true || val == undefined) {
        this.isClosed=true;
        this.clearSnackBar();
      }
      if(val=='OpenVoucher'){
        this.isClosed=false;
      }
    });
  }
  displaySnackBar(){
    let SnackbarAdded = sessionStorage.getItem('SnackbarAdded');
    if (SnackbarAdded == 'true') {
      let voucherDetail = JSON.parse(sessionStorage.getItem('VoucherDetail'));
      this.buttonName=[{ id: '2', name: RSAConstants.TaxInvoiceTitle, access: true }];
      this.selectedRowEntitiDataTable = voucherDetail.SelectedRows;
      this.totalVoucherCount = 0;
      this.totalVoucherAmount = 0;
      this.selectedRowEntitiDataTable.forEach(row => {
        this.totalVoucherCount++;
        this.totalVoucherAmount += row.Amount;
      });
    }
    this.showSnackbar=true;
  }
   clearSnackBar() {
    this.totalVoucherCount = 0;
    this.totalVoucherAmount = 0;
    sessionStorage.setItem('SnackbarAdded', 'false');
    sessionStorage.setItem('isFromDraft', 'false');
    this.selectedRowEntitiDataTable = [];
    this.buttonName = [];
    let voucherDetail = { ButtonNames: this.buttonName, SelectedRowEntitiDataTable: this.selectedRowEntitiDataTable };
    sessionStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
    this.showSnackbar = false;
  }
  hideSnackBar(ev) {
    this.clearSnackBar();
  }
  buttonHandler(e){
    let receiptData=JSON.parse(sessionStorage.getItem('DraftData'));
    if(receiptData!=undefined){
      const initialState = {
        backdrop: true,
        ignoreBackdropClick: true,
        debitnoteEditData: receiptData,
        isDebitNote: true
      };
      console.log('initialState:', initialState);
      this.bsModalRef = this.modalService.show(CreateDraftDebitnoteComponent,
        { class: 'create-modal-dailog', initialState, ignoreBackdropClick: false });
    }
  }
}
