import { Component, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DrfatService } from './services/drafts.service';
import { SharedService } from '../../services/shared.service';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';


@Component({
  selector: 'rsa-drafts-results',
  templateUrl: './drafts-results.component.html',
  styleUrls: ['./drafts-results.component.scss']
})
export class DraftsResultsComponent implements OnInit, OnChanges {
  voucherName;
  voucherCount;
  receiptDraftsData: any = [];
  debitnoteDraftsData: any = [];
  creditnoteDraftsData: any = [];
  paymentDraftsData: any = [];
  JournalDraftsData: any = [];
  clmPmtDraftsData: any = [];
  isClaimPayment: boolean;
  isOman:boolean=false;

  constructor(private route: ActivatedRoute, private drfatService: DrfatService, private sharedService: SharedService) { }

  ngOnInit() {
    this.isOman = (sessionStorage.getItem(RSAConstants.regionCode) == '3') ?true: false;
    this.route.queryParams.subscribe(params => {
      console.log(params, "paramsssss");
      this.voucherName = params['voucherName'];
      this.voucherCount = params['voucherCount'];
      this.getDrfatsDetails(this.voucherName);
    });
    this.refreshGridOnFinalize();
    
  }

  ngOnChanges(changes: SimpleChanges) {
    this.refreshGridOnFinalize();
  }

  refreshGridOnFinalize() {
    this.sharedService.getMessage().subscribe((data) => {
      console.log(data, 'dataindrafts');
      const voucherName = data.voucherName;
      const message = data.message;
      console.log(voucherName, message, 'voucherName message');
      if (message === 'save-voucher') {
        this.getDrfatsDetails(voucherName);
      }
    });
  }

  getDrfatsDetails(voucherName) {
    if (voucherName == 'Receipts') {
      this.getDrfatsReceipt();
    }

    if (voucherName == 'Tax Invoice') {
      this.getDrfatsDebitnote();
    }
    if (voucherName == 'Credit Note') {
      this.getDrfatsCreditnote();
    }
    if (voucherName == 'Payments') {
      this.getDrfatsPayment();
    }
    if (voucherName == 'JV') {
      this.getDrfatsJournal();
    }
    if (voucherName == 'Claim Payments') {
      this.getClmPaymentDrafts();
    }
  }

  getDrfatsReceipt() {
    const param = 'loggedInUserId=' + sessionStorage.getItem(RSAConstants.LoggedInUserId);
    this.drfatService.getDraftReceipts(param).subscribe(data => {
      this.receiptDraftsData = data;
      console.log(data, 'Receiptdata');
    });
  }


  getDrfatsDebitnote() {
    const param = 'loggedInUserId=' + sessionStorage.getItem(RSAConstants.LoggedInUserId);
    this.drfatService.getDrfatsDebitnotes(param).subscribe(data => {
      this.debitnoteDraftsData = data;
      console.log(data, 'Dndata');

    });
  }

  getDrfatsCreditnote() {
    const param = 'loggedInUserId=' + sessionStorage.getItem(RSAConstants.LoggedInUserId);
    this.drfatService.getDrfatsCreditnotes(param).subscribe(data => {
      this.creditnoteDraftsData = data;
      console.log(data, 'Cndata...');
    });
  }

  getDrfatsPayment() {
    const param = 'loggedInUserId=' + sessionStorage.getItem(RSAConstants.LoggedInUserId)+'&isApprovalRequired='+this.isOman;
    this.drfatService.getDrfatsPayments(param).subscribe(data => {
      this.paymentDraftsData = data;
      console.log(data, 'payment Data');
    });
  }

  getClmPaymentDrafts() {
    const locCode = sessionStorage.getItem('locationcode');
    const param = 'type=Drafts&loggedInUserId=' + sessionStorage.getItem(RSAConstants.LoggedInUserId);
    this.drfatService.getClmPaymentDrafts(param).subscribe(data => {
      this.clmPmtDraftsData = data;
    });
  }

  getDrfatsJournal() {

    const param = 'loggedInUserId=' + sessionStorage.getItem(RSAConstants.LoggedInUserId);
    this.drfatService.getDrfatsJournals(param).subscribe(data => {
      this.JournalDraftsData = data;
      console.log(data, 'jvdata');
    });
  }

}

