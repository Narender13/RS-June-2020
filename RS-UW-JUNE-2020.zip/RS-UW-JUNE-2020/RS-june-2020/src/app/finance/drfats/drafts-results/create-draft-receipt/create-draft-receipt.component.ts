import { Component, OnInit,OnDestroy, ChangeDetectorRef, ViewChild, Inject, Renderer2 } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { Customvalidators } from 'src/app/shared/validators/customvalidators';
import { SharedService } from 'src/app/finance/services/shared.service';
import { CreateService } from 'src/app/finance/receipts/create-receipt/service/create.service';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';

import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'rsa-create-draft-receipt',
  templateUrl: './create-draft-receipt.component.html',
  styleUrls: ['./create-draft-receipt.component.scss']
})
export class CreateDraftReceiptComponent implements OnInit,OnDestroy {
  title = 'Receipt';
  taxInvNo = RSAConstants.TaxInvoiceTitle+' No';
  level: any = 1;
  amount;
  currency = sessionStorage.getItem(RSAConstants.currency);
  collapsetoheader: boolean;
  receiptForm: FormGroup;
  BankName: any;
  results: any;
  errorMsg;
  terminals;
  slided;
  returnValue;
  count;
  branchdata: any = [];
  users: any = [];
  RcptMode;
  selectedRowEntitiDataTable = [];
  getbankterminaldetails = {};
  payeedataBankName: any = [];
  receiverdataBankName: any = [];
  pjctindicator: any = [];
  department: any = [];
  placeholder: any;
  glaccount: any = [];
  totallingacc: any = [];
  transactiontype: any = [];
  chequeTypeData: any = [];
  private masterdata: any = [];
  private masterdata2: any = [];
  costcentredata = [];
  displayApprover = false;
  approverusers: string;
  totalAmount;
  glerrorcount = 0;
  setcredit = true;
  totalSum = 0;
  dtltotallingacc: any = [];
  symbol: string;
  arrUser: any = [];
  paymentname;
  regionCode: any;
  usersReq = true;
  errorpayee: boolean;
  errordetail: boolean;
  errorbankcode: boolean;
  errorinstrumentdate: boolean;
  errorchequedate: boolean;
  errorchequeno: boolean;
  errorinstrumentrefno: boolean;
  //errorterminalID: boolean;
  errorexpirydate: boolean;
  errorChequeTypeCheque: boolean;
  errorchequetype: boolean;
  minDate;
  total;
  minDateRd;
  maxDateRd;
  currentDate;
  isDisabled = true;
  setPayeeName;
  currentTbIndex = 0;
  previewFlag: boolean = false;
  cachedPayeeBankData: any;
  cachedDtlTot: any;
  cachedGL;
  prevReceipt: any;
  previewDataDtl: any = [];
  receiptEditData: any;
  ReceiptModeDesc;
  cachedCostcentredata: any;
  cachedReceiverBankData: any = [];
  cachedTotAcc: any = [];
  counter: number = 0;
  setDecimalpoint: any;
  isUAE;
  isOMAN;
  unApproved;
  defaultUserId;
  defaultTerminalId;

  amountZeroCheck;
  amountLimitCheck;
  editReceiptFromPrevious = false;
  receiptAccountingDate: any;
  receiptLocationCode:any;
  @ViewChild('tabset') tabset: TabsetComponent;
  submitError: number;
  isNewRow: boolean;
  isStateClosed: boolean = false;
  constructor(
    @Inject(DOCUMENT) private document: Document,
    private ref: ChangeDetectorRef,
    private renderer: Renderer2,
    public bsModalRef: BsModalRef,
    private fb: FormBuilder,
    private createservice: CreateService,
    private masterDataService: MasterDataService,
    private modalService: BsModalService,
    private gridApiService: GridApiService,
    private alertService: AlertService,
    private sharedService: SharedService,
    private router: Router) {
    this.minDateRd = new Date();
    this.maxDateRd = new Date();
    this.minDateRd.setDate(this.minDateRd.getDate() - 0);
    this.maxDateRd.setDate(this.maxDateRd.getDate() - 0);
    this.currentDate = new Date();
  }


  ngOnInit() {
      const precison = +(sessionStorage.getItem('precisionDecimalValue'));
      console.log(precison, 'precison');
      if (precison) {
          this.setDecimalpoint = {
              precision: precison,
          };
      }
    this.regionCode = sessionStorage.getItem(RSAConstants.regionCode);
    this.getReceiptData();
    this.getModalFromPrevious();
    this.isUAE = sessionStorage.getItem(RSAConstants.regionCode) == '2' ? true : false;
    this.isOMAN = sessionStorage.getItem(RSAConstants.regionCode) == '3' ? true : false;
    this.sharedService.getMessage().subscribe(val => {
      if (val == 'close') {
        this.isStateClosed = true;
        this.receiptForm.markAsPristine();
        this.receiptForm.markAsUntouched();
      }
    });
    this.getPreviousRows();
  }
  getPreviousRows(){
    let SnackbarAdded = sessionStorage.getItem('SnackbarAdded');
    if (SnackbarAdded == 'true') {
      let voucherDetail = JSON.parse(sessionStorage.getItem('VoucherDetail'));
      if(this.receiptEditData.ReceiptNo==voucherDetail.VoucherNo){
        this.receiptEditData.ReceiptDetails=voucherDetail.SelectedRows;
        this.selectedRowEntitiDataTable=voucherDetail.SelectedRows;
      }
    }
  }
  get receiptdate() { return this.receiptForm.get('ReceiptDate'); }
  getReceiptData() {
    console.log('^^^^^^^^^^', this.receiptEditData);
    this.RcptMode = this.receiptEditData.ReceiptMode;
    this.prevReceipt = this.receiptEditData.ReceiptNo;
    const currentIndex = {
      '2': 0,
      '1': 2,
      '8': 1,
      '5': 3,
    };

    console.log('this.receiptEditData:', this.receiptEditData);
    this.receiptLocationCode=this.receiptEditData.LocationCode;
    const selectedTab = currentIndex[this.RcptMode];

    console.log(selectedTab, 'setectedtab');
    if (this.RcptMode) {
      this.tabset.tabs[selectedTab].active = true;
      this.createReceiptEntitiRowSForm(this.RcptMode);
      this.getAllMasterData(sessionStorage.getItem(RSAConstants.totallingaccount));
      this.getAllMasterData2();
      this.getAllTranData();
      this.getTotallingData(sessionStorage.getItem('costcentre'));
      this.getBankData(true);
      this.symbol = (sessionStorage.getItem('symbol'));
      console.log(this.receiptEditData, 'this.receiptEditData');
      this.getModalFromPrevious();
      this.fieldStatusChanges();
      this.getPayeeBankData(true);
      this.getAllInstrumentTypes();
      const receiptDesc = this.receiptEditData.ReceiptModeDesc;
      this.totalAmount = this.receiptEditData.TotalAmount;
      this.paymentname = receiptDesc;
      console.log(this.totalAmount, 'totalAmount3244324');
      this.patchValueFromDrft();
      this.GetAccountingDates(this.receiptEditData.ReceiptDate);
      console.log(this.receiptEditData.ReceiptMode, 'receiptEditData');
    }
    this.tabset.tabs[selectedTab].active = true;
    this.selectedRowEntitiDataTable=this.receiptEditData.ReceiptDetails;
  }
  ngOnDestroy() {
    if (!this.isStateClosed) {
      this.addRowsToSession();
    }
  }
  addRowsToSession() {
    if (this.selectedRowEntitiDataTable.length > 0) {
      this.selectedRowEntitiDataTable.forEach(row=>{
        row.isFromDraft='true';
      });
      sessionStorage.setItem('SnackbarAdded', 'true');
      sessionStorage.setItem('isFromDraft', 'true');
     
      let voucherDetail = { SelectedRows: this.selectedRowEntitiDataTable,voucherType: 'Receipt',VoucherNo:this.prevReceipt };
      sessionStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
      //Add receipt data
      let receiptDate = this.getDateClrlValue('ReceiptDate');
      let totallingAccCode = this.getFormCtrlValue('TotallingAccCode');
      let recevierBankCode = this.getFormCtrlValue('RecevierBankCode');
      let description = this.getFormCtrlValue('EnglishDescription');//PayeeName
      let payeeName = this.getFormCtrlValue('PayeeName')
      var commonData={ReceiptDate:receiptDate,CurrentTabIndex:this.currentTbIndex ,TotallingAccCode:totallingAccCode,RecevierBankCode:recevierBankCode,
      Description:description,PayeeName:payeeName,VoucherNo: this.prevReceipt, PreviewData:this.previewDataDtl}
      sessionStorage.setItem('ReceiptCommonData',JSON.stringify(commonData));
      let contentData=this.getContentData();
      sessionStorage.setItem('ReceiptContentData',JSON.stringify(contentData));
      sessionStorage.setItem('ReceiptStateExists','true');
      this.updateRows();
      this.sharedService.sendMessage('ReceiptSnackbarAdded');
    }
  }
  updateRows(){
    let formarray = <FormArray>this.receiptForm.controls['ReceiptDetails'];
    if(formarray.controls.length>0){
      let voucherDetail = JSON.parse(sessionStorage.getItem('VoucherDetail'));
      voucherDetail.SelectedRows=[];
      let i=0;
      formarray.controls.forEach(ctrl=>{
        let rowClone=Object.assign({}, ctrl.value);
        let newRow=ctrl.get('newAddedRow');
        if(newRow.value == true){
          let bData=this.branchdata.filter(x=>x.Code==rowClone.BranchCode)[0];
          let cc=this.costcentredata[i].filter(x=>x.CCCode==rowClone.CostCenterCode)[0];
          let ttAcc=this.dtltotallingacc[i].filter(x=>x.TotAccCode==rowClone.TotallingAccCode)[0];
          rowClone.BranchName= bData.Code + ' - ' + bData.E_desc;
          rowClone.CostCenterName=cc.CCCode + ' - ' + cc.E_Desc;
          rowClone.TotallingAccName=(ttAcc)?ttAcc.TACEngDescription:'';
        }
        rowClone.Amount=(rowClone.Amount)?rowClone.Amount:0;
        rowClone.Amount=parseInt(rowClone.Amount);
        rowClone.DepartmentCode=rowClone.Department;
        rowClone.ConcDescription=rowClone.Description;
        rowClone.isFromDraft='true';
         voucherDetail.SelectedRows.push(rowClone);
         i++;
      });
      sessionStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
    }
 }
  getContentData() {
    var contentData: any;
    if (this.currentTbIndex == 0) {
      let payeeBankCode = this.getFormCtrlValue('PayeeBankCode');
      let instrumentDate = this.getDateClrlValue('InstrumentDate');
      let chequeNo = this.getFormCtrlValue('ChequeNo');
      contentData = { PayeeBankCode: payeeBankCode, InstrumentDate: instrumentDate, ChequeNo: chequeNo }
    }
    if (this.currentTbIndex == 1) {
      let instrumentRefNo = this.getFormCtrlValue('InstrumentRefNo');
      let chequeDate = this.getDateClrlValue('ChequeDate');
      let chequeNo = this.getFormCtrlValue('ChequeNo');
      let chequeType = this.getFormCtrlValue('ChequeType');
      let transactionNo = this.getFormCtrlValue('TransactionNo');
      let terminalUserID = this.getFormCtrlValue('TerminalUserID');
      contentData = { InstrumentRefNo: instrumentRefNo, ChequeDate: chequeDate, ChequeNo: chequeNo, ChequeType: chequeType, TransactionNo:transactionNo, TerminalUserID: terminalUserID }
    }
    if (this.currentTbIndex == 3) {
      let payeeBankCode = this.getFormCtrlValue('PayeeBankCode');
      let chequeDate = this.getDateClrlValue('ChequeDate');
      let instrumentRefNo = this.getFormCtrlValue('InstrumentRefNo');
      contentData = { InstrumentRefNo: instrumentRefNo, ChequeDate: chequeDate, PayeeBankCode: payeeBankCode }
    }
    return contentData;
  }
  getDateClrlValue(contrlName: string) {
    if (this.receiptForm.controls[contrlName].dirty || this.receiptForm.controls[contrlName].touched) {
      return this.receiptForm.controls[contrlName].value;
    }
    else {
      return null;
    }
  }
  doPatchRefFields() {
    const formarray = (<FormArray>this.receiptForm.controls['ReceiptDetails']);
    formarray.controls.map((item, index) => {
      item.get('RefTransactionID').setValue(this.previewDataDtl[index].RefTransactionID);
      item.get('RefTransactionSerialNo').setValue(this.previewDataDtl[index].RefTransactionSerialNo);
    });
  }
  getModalFromPrevious() {
    this.sharedService.getMessage().subscribe(val => {
      if (val === 'previous') {
        this.previewFlag = false;
        this.editReceiptFromPrevious = true;
      } else if (val === 'close') {
        this.modalService.hide(1);
      }
      if(val!='OpenVoucher'){
        this.prevReceipt = val.id;
        console.log(this.prevReceipt, 'this.prevReceipt');
        this.previewDataDtl = val.data;
        if (this.previewDataDtl != null || this.previewDataDtl != undefined) {
          this.doPatchRefFields();
        }
      }
     
    });
  } 
  patchValueFromDrft() {
    if (this.receiptEditData) {
      if (this.receiptEditData.ReceiptMode == 2) {
        this.receiptForm.patchValue({
         ChequeNo:String(this.receiptEditData.ChequeNo).padStart(4,'0'),
          InstrumentDate: this.receiptEditData.ChequeDate,
          PayeeBankCode: this.receiptEditData.PayeeBankCode,
        });
      }
      if (this.receiptEditData.ReceiptMode == 5) {
        this.receiptForm.patchValue({
          ChequeDate: this.receiptEditData.ChequeDate,
          PayeeBankCode: this.receiptEditData.PayeeBankCode,
          InstrumentRefNo: this.receiptEditData.InstrumentRefNo,
        });
      }
      if (this.receiptEditData.ReceiptMode == 1) {
        this.receiptForm.patchValue({
          PayeeName: this.receiptEditData.PayeeName,
          EnglishDescription: this.receiptEditData.EnglishDescription,
        });
      }
      if (this.receiptEditData.ReceiptMode == 8) {
        this.receiptForm.patchValue({
          ChequeNo: String(this.receiptEditData.ChequeNo).padStart(4,'0'),
          ChequeDate: this.receiptEditData.ChequeDate,
          InstrumentRefNo: this.receiptEditData.InstrumentRefNo,
          //TerminalID: this.receiptEditData.TerminalID,
          ChequeType: this.receiptEditData.ChequeType,
          TransactionNo: this.receiptEditData.TransactionNo,
        });
        // this.receiptForm.controls['TerminalID'].setValue(this.receiptEditData.TerminalID);
      }

      this.receiptForm.patchValue({
        ReceiptDate: this.receiptEditData.ReceiptDate,
        PayeeName: this.receiptEditData.PayeeName,
        EnglishDescription: this.receiptEditData.EnglishDescription,
        TotallingAccCode: this.receiptEditData.TotallingAccCode,
        RecevierBankCode: this.receiptEditData.RecevierBankCode,
        ReceiptMode: this.receiptEditData.ReceiptMode,
        PrintDate: this.receiptEditData.PrintDate,
        ReceiptType: this.receiptEditData.ReceiptType,
        PreparedBy: sessionStorage.getItem(RSAConstants.LoggedInUserId),
        ModifiedBy: this.receiptEditData.ModifiedBy,
        CustomerID: this.receiptEditData.CustomerID,
        // TerminalUserID: this.receiptEditData.TerminalUserID,
        // TerminalID: this.receiptEditData.TerminalID,
        TerminalUserName: this.receiptEditData.TerminalUserName,
        CountryCode: this.receiptEditData.CountryCode,
        LocationCode: this.receiptEditData.LocationCode,
        RegionCode: this.receiptEditData.RegionCode,
        ReprintNo: this.receiptEditData.ReprintNo,
        CostCenterCode: this.receiptEditData.CostCenterCode,
        ArabicDescription: this.receiptEditData.ArabicDescription,
      });
      this.setBankForDropdown(
        this.receiptEditData.CostCenterCode,
        this.receiptEditData.TotallingAccCode);
      this.getDefaultBankData();
    }
  }
  setExpiryDate(date: string) {
    const month = date && date.split('/')[1] ? date.split('/')[1] : new DatePipe('en-US').transform(new Date(), 'MM');
    const year = date && date.split('/')[2] ? date.split('/')[2] : new DatePipe('en-US').transform(new Date(), 'yyyy');
    console.log('Month', month);
    console.log('year', year);
    return month + '/' + year;
  }
  setBankForDropdown(ccentre, totcode) {
    const param = 'totallingAccCode=' + totcode +
      '&costCenter=' + ccentre;
    this.masterDataService.getBankData(param).subscribe(
      dataReturn => {
        this.receiverdataBankName = dataReturn;
        this.receiptForm.controls['RecevierBankCode'].setValue(this.receiptEditData.RecevierBankCode);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    this.errorbankcode = false;
    this.errorchequedate = false;
    this.errorchequeno = false;
    this.errorinstrumentrefno = false;
    //this.errorterminalID = false;
    this.errorexpirydate = false;
    this.errorinstrumentdate = false;
    this.errorchequetype = false;
  }

  getPayeeBankData(initFlag) {
    this.masterDataService.getPayeeBankData().subscribe(
      dataReturn => {
        this.payeedataBankName = dataReturn;
        // dthis.receiptForm.controls['PayeeBankCode'].setValue(this.payeedataBankName[0].BankCode);
        if (!initFlag) {
          if (this.RcptMode == 2 || this.RcptMode == 5) {
            this.receiptForm.controls['PayeeBankCode'].setValue('');
          }
        }
        if (initFlag) {
          this.cachedPayeeBankData = dataReturn;
        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  setFormArrayCTRLDefaultValue(contrlname, index, val) {
    (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[index].get(contrlname).setValue(val);
  }
  getFromFormArrayControlVal(contrlname, index) {
    return (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[index].get(contrlname).value;
  }
  getFormCtrlValue(contrlName) {
    console.log(this.receiptForm.controls, 'this.receiptForm.controls');
    return this.receiptForm.controls[contrlName].value;
  }

  onDateValueChange(ev) {
    this.receiptForm.controls['ChequeDateFld'].setValue(new DatePipe('en-US').transform(new Date(ev), 'dd/MM/yyyy'));

  }
  /* changePayeeBank() {
     console.log(this.payeebankcode, ' changePayeeBank');
     if (this.receiptForm.controls['PayeeBankCode'].value  == '') {
       alert('no value');
     this.receiptForm.controls['PayeeBankCode'].valid = true;
     }
   } */
  getTotallingDetailData(index, initFlag, newrow?) {
      const ccentre = (initFlag == true) ? sessionStorage.getItem(RSAConstants.costcentre) : this.getFromFormArrayControlVal('CostCenterCode', index);

    const param = 'paymentMode=' + this.paymentname +
      '&costCenter=' + ccentre;
    console.log(param, 'getTotallingDetailData');

    this.masterDataService.getTotallingDetailData(param).subscribe(
      dataReturn => {
        this.dtltotallingacc[index] = dataReturn;

        const totcode = (initFlag == true) ? sessionStorage.getItem(RSAConstants.totallingaccount) : this.dtltotallingacc[index][0].TotAccCode;
        if (!initFlag) {
          this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, totcode);
        }
        if (initFlag) {
          this.cachedDtlTot = dataReturn;

        }
        if(this.isNewRow){
          this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, '');
        }
        this.getGLData(index, initFlag, totcode, newrow);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  setReqValFormArrayControl(contrlname, index, isRequired) {
    //isRequired = true;
    let selCtrl = (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[index].get(contrlname);
    if (isRequired) {
      if (selCtrl.value === null || selCtrl.value === '') {
        selCtrl.setValidators([Validators.required]);
        selCtrl.markAsTouched();
        selCtrl.markAsDirty();
        selCtrl.setErrors({ 'incorrect': true });
      }
      (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[index].updateValueAndValidity();
    }
    else {
      selCtrl.clearValidators();
    }
  }


  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );
    if (this.RcptMode == 2) {
      if (this.payeebankcode != null && this.payeebankcode != undefined) {
        this.payeebankcode.statusChanges.subscribe(
          status => {
            this.errorbankcode = (status == 'INVALID');
          }
        );
      }
      if (this.instrumentdate != null && this.instrumentdate != undefined) {
        this.instrumentdate.statusChanges.subscribe(
          status => {
            this.errorinstrumentdate = (status == 'INVALID');
          }
        );
      }
    }
    if (this.RcptMode == 5) {
      if (this.payeebankcode != null && this.payeebankcode != undefined && this.payeebankcode.value != '') {
        this.payeebankcode.statusChanges.subscribe(
          status => {
            this.errorbankcode = (status == 'INVALID');
          }
        );
      }
      if (this.instrumentrefno != null && this.instrumentrefno !== undefined) {
        this.instrumentrefno.statusChanges.subscribe(
          status => {
            this.errorinstrumentrefno = (status === 'INVALID');
          }
        );
      }
    }
    if (this.chequedate != null && this.chequedate !== undefined) {
      this.chequedate.statusChanges.subscribe(
        status => {
          this.errorchequedate = (status === 'INVALID');
        }
      );
    }
    if (this.chequeno != null && this.chequeno !== undefined) {
      this.chequeno.statusChanges.subscribe(
        status => {
          this.errorchequeno = (status === 'INVALID');
        }
      );
    }


    if (this.chequeType != null && this.chequeType != undefined) {
      this.chequeType.statusChanges.subscribe(
        status => {
          this.errorchequetype = (status == 'INVALID');
        }
      );
    }
    if (this.expirydate != null && this.expirydate !== undefined) {
      this.expirydate.statusChanges.subscribe(
        status => {
          this.errorexpirydate = (status === 'INVALID');
        }
      );
    }

  }

  goNext() {
    this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;

    if (this.RcptMode == 2) {
      if (this.payeebankcode != null && this.payeebankcode != undefined) {
        this.errorbankcode = this.payeebankcode.invalid;
      }
      if (this.instrumentdate != null && this.instrumentdate !== undefined) {
        this.errorinstrumentdate = this.instrumentdate.invalid;
      }
    }

    if (this.RcptMode != 1 && this.RcptMode != 2) {
      if (this.chequedate != null && this.chequedate !== undefined) {
        this.errorchequedate = this.chequedate.invalid;
      }
    }

    if (this.chequeno != null && this.chequeno !== undefined) {
      this.errorchequeno = this.chequeno.invalid;
    }
    if (this.chequeType != null && this.chequeType !== undefined) {
      this.errorchequetype = this.chequeType.invalid;
    }


    if (this.expirydate != null && this.expirydate !== undefined) {
      this.errorexpirydate = this.expirydate.invalid;
    }
    if (this.RcptMode == 5) {
      if (this.instrumentrefno != null && this.instrumentrefno !== undefined) {
        this.errorinstrumentrefno = this.instrumentrefno.invalid;
      }
    }

    if (!this.errorpayee && !this.errordetail && !this.errorchequedate && !this.errorchequeno && !this.errorinstrumentrefno
      && !this.errorexpirydate && !this.errorbankcode && !this.errorchequetype && !this.errorinstrumentdate) {
      if (this.counter === 0) {
        this.receiptEditData.ReceiptDetails.map((item, index) => this.addReceipt(item, index, false));
      }
      this.level = 2;
    }
  }

  /* get all instrument types */
  getAllInstrumentTypes() {
    this.masterDataService.getInstrumentTypes().subscribe((data) => {
      this.chequeTypeData = data.filter(c => c.Related_Code == 8);
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }


  getVoucherDetailsLength() {
    return this.receiptEditData.ReceiptDetails.length;
  }

  setPayeName() {
    this.receiptForm.controls['PayeeName'].setValue(this.receiptEditData.PayeeName);
  }

  setReceiptMode(val, paymentname, ev) {
    if (this.counter < 1) {
      this.counter = 0;
    }
    if (!ev.tabset) {
      return;
    }

    this.RcptMode = val;
    this.paymentname = paymentname;
    console.log(this.RcptMode, 'set');
    // if (!this.editReceiptFromPrevious) {
    //   this.createReceiptEntitiRowSForm(this.RcptMode, true);
    // }
    // set previous review values- defect 5766
    // if (this.editReceiptFromPrevious) {
      if (this.counter == 0) {
        this.createReceiptEntitiRowSForm(this.RcptMode);
      } else {
        const control = <FormArray>this.receiptForm.controls['ReceiptDetails'];
        this.createReceiptEntitiRowSForm(this.RcptMode);
        this.receiptForm.controls['ReceiptDetails'] = control;
      }

    // }
    this.GetAccountingDates(this.receiptEditData.ReceiptDate);
    this.payeedataBankName = this.cachedPayeeBankData;
    // this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.setcurrentTbIndex(paymentname);

    this.receiptForm.controls['TotallingAccCode'].setValue(this.receiptEditData.TotallingAccCode);
    this.receiptForm.controls['RecevierBankCode'].setValue(this.receiptEditData.RecevierBankCode);
    this.receiptForm.controls['ReceiptMode'].setValue(this.RcptMode);
    //this.receiptForm.controls['ReceiptDate'].setValue(this.minDateRd);
    if (this.terminals != null && this.terminals.length > 0) {
      const terminal = this.terminals.filter(x => x.UserID == sessionStorage.getItem(RSAConstants.LoggedInUserId));
      this.defaultUserId = terminal != null && terminal[0] != null ? terminal[0].UserID : null;
      this.defaultTerminalId = terminal != null && terminal[0] != null ? terminal[0].TerminalID : null;
    }
    if (this.RcptMode == 8 && this.isUAE === true) {
      let terminalUserId = this.defaultUserId ? this.defaultUserId : '';
      let terminalId = this.defaultTerminalId ? this.defaultTerminalId : '';
      this.receiptForm.controls['TerminalUserID'].setValue(terminalUserId);
      this.receiptForm.controls['TerminalID'].setValue(terminalId);
    }
    this.setPayeName();
    this.receiptForm.controls['EnglishDescription'].setValue(this.receiptEditData.EnglishDescription);
    this.clearPayeeBankCode();
    this.fieldStatusChanges();
  }
  getDefaultBankData() {
    const ccentre = this.getFormCtrlValue('CostCenterCode');
    const totcode = sessionStorage.getItem(RSAConstants.totallingaccount);

    const param = 'totallingAccCode=' + totcode +
      '&costCenter=' + ccentre;

    this.masterDataService.getBankData(param).subscribe(
      dataReturn => {
        this.receiverdataBankName = dataReturn;
        this.cachedReceiverBankData = dataReturn;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  clearPayeeBankCode() {
    if (this.RcptMode == 5 || this.RcptMode == 2) {
      this.receiptForm.controls['PayeeBankCode'].setValue('');
      this.receiptForm.controls['PayeeBankCode'].updateValueAndValidity();
    }
    this.clearerrors();
  }
  getSum() {
    let total = 0;
    let amt = 0;
    let actualamt = 0;
    let flagtoggle = false;
    (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls.forEach((element, index) => {
      if (this.getFromFormArrayControlVal('Amount', index) != undefined
        && this.getFromFormArrayControlVal('Amount', index) != null) {
        flagtoggle = this.getFromFormArrayControlVal('IsCreditEntry', index);
        amt = parseFloat(this.getFromFormArrayControlVal('Amount', index));
        amt = Math.abs(amt) || 0;
        actualamt = (!flagtoggle) ? amt : (amt * -1);
        total = total + actualamt;
      }

    });

    this.totalAmount = (total == null || total == undefined || isNaN(total)) ? 0.00 : total;
  }
  getGLData(index, initFlag, val, newrow?) {
      const ccentre = (initFlag) ? sessionStorage.getItem(RSAConstants.costcentre) : this.getFromFormArrayControlVal('CostCenterCode', index);
    const totcode = val;
    if (totcode === undefined || totcode === null || totcode === '') {
      this.clearGLCode(index, '');
      this.glaccount[index] = [];
      return false;
    }
    const param = 'totallingAccCode=' + totcode +
      '&CostCenterCode=' + ccentre;
    console.log('param-GL', param);

    this.masterDataService.getGLData(param).subscribe(
      dataReturn => {
        this.glaccount[index] = newrow  ? [] : dataReturn;
        console.log(this.glaccount, 'glacount');
        if (!initFlag) {
          // this.setFormArrayCTRLDefaultValue('GLCode', index, this.glaccount[index][0].GLCode);
          // this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, this.glaccount[index][0].GLEngDescription);
        }
        if (initFlag) {
          this.cachedGL = dataReturn;
        }
        if (this.isNewRow) {
          this.clearGLCode(index, '');
        }
        console.log(this.cachedGL, 'cachedGL');
      },
      errorRturn => this.errorMsg = errorRturn
    );
    if (this.level == 2) {
      (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls.map(item => {
        // item.get('Amount').clearValidators();
        // item.get('GLCode').clearValidators();
        item.get('Amount').updateValueAndValidity();
        item.get('GLCode').updateValueAndValidity();
      });
    }
  }
  changeCostcenter(index, flagInit, newrow) {
    const loccode = this.getFromFormArrayControlVal('LocationCode', index);
    this.masterDataService.getCostCenters().subscribe(
      dataReturn => {
        this.costcentredata[index] = dataReturn;
        if (flagInit) {
          this.cachedCostcentredata = dataReturn;
        }
        if (loccode == '20') {
          this.setFormArrayCTRLDefaultValue('CostCenterCode', index, sessionStorage.getItem(RSAConstants.costcentre));
        }
        this.getTotallingDetailData(index, flagInit,newrow);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }


  setBankData(val) {

    this.getBankData(false);
  }
  getBankData(flagInit) {
    const ccentre = this.getFormCtrlValue('CostCenterCode');
    const totcode = this.getFormCtrlValue('TotallingAccCode');

    const param = 'totallingAccCode=' + totcode +
      '&costCenter=' + ccentre;

    console.log(param, 'getBankData');
    this.masterDataService.getBankData(param).subscribe(
      dataReturn => {
        this.receiverdataBankName = dataReturn;
        if (!flagInit) {
          this.receiptForm.controls['RecevierBankCode'].setValue(this.receiverdataBankName[0].BankCode);

        }
        // if (flagInit)
        //   this.cachedReceiverBankData = dataReturn;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getTotallingData(initflag) {
    const ccentre = this.getFormCtrlValue('CostCenterCode');
    const param = 'paymentMode=' + this.paymentname +
      '&costCenter=' + ccentre+'&loccode='+this.receiptLocationCode;
    console.log(param, 'getTotallingData');
    console.log(initflag, 'initflag1111');
    this.masterDataService.getTotallingData(param).subscribe(
      dataReturn => {
        this.totallingacc = dataReturn;
        if (initflag) {
          this.cachedTotAcc = dataReturn;

        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  getAllMasterData(totalacc): void {
    this.masterDataService.getAllMasterData(totalacc).subscribe(
  
      dataReturn => {
        this.masterdata = dataReturn;
        console.log(dataReturn, ' : master data');
        this.payeedataBankName = this.masterdata.LoadPayeeBanks;
        this.terminals = this.masterdata.Terminals;
        this.pjctindicator = this.masterdata.ProjectIndicators;
        this.department = this.masterdata.Departments;
        console.log(this.department, 'd');
        console.log(this.pjctindicator, 'p');
        console.log(this.terminals, 't');
        // this.transactiontype = this.masterdata.TransactionType;
        if (this.receiptEditData.ReceiptMode === 8 && this.isUAE === true) {
          const terminal = this.terminals.filter(item => item.UserID == this.receiptEditData.TerminalUserID);
          if (terminal.length > 0) {
            this.receiptForm.controls['TerminalUserID'].setValue(this.receiptEditData.TerminalUserID);
          }
          this.receiptForm.controls['TerminalID'].setValue(this.receiptEditData.TerminalID);
        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getAllMasterData2(): void {
    this.masterDataService.getAllMasterData2().subscribe(
      dataReturn => {
        this.masterdata2 = dataReturn;
        console.log(dataReturn, ' : master data');
        this.glaccount = this.masterdata2.GLCodes;
        this.users = this.masterdata2.Users;
        this.branchdata = this.masterdata2.Locations;
        this.cachedCostcentredata = this.masterdata2.CostCenter;
        this.costcentredata[0] = this.masterdata2.CostCenter;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

/* get all transcation data for  details */
getAllTranData() {
  this.masterDataService.getAllTranData().subscribe((data) => {
    this.transactiontype = data;
  },
    errorRturn => this.errorMsg = errorRturn
  );
}


  onUserChange(userid: string, isChecked: boolean, username: string) {
    const userFormArray = <FormArray>this.receiptForm.controls.Approvers;
    if (isChecked) {
      userFormArray.push(new FormControl(userid));
      this.arrUser.push(username);
    } else {
      const index = userFormArray.controls.findIndex(x => x.value === userid);
      userFormArray.removeAt(index);
      this.arrUser = this.arrUser.filter(v => v !== username);
    }
    this.approverusers = this.arrUser.join();
    console.log(this.approverusers);
  }


  createReceiptEntitiRowSForm(param, flag?): void {

    this.receiptForm = null;

    this.receiptForm = this.fb.group({
      ReceiptDate: [],
      ReceiptMode: [],
      PrintDate: [],
      ReceiptType: [],
      PreparedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      ModifiedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      InstrumentRefNo: [],
      Approvers: this.fb.array([]),
      CustomerID: [],
      TerminalID: [],
      TerminalUserID: [],
      TerminalUserName: [],
      CountryCode: [sessionStorage.getItem(RSAConstants.countrycode)],
      LocationCode: [sessionStorage.getItem('locationcode')],
      RegionCode: [sessionStorage.getItem(RSAConstants.regionCode)],
      ReprintNo: [],
      CostCenterCode: [sessionStorage.getItem('costcentre')],
      ArabicDescription: [],
      TotallingAccCode: [this.receiptEditData.TotallingAccCode],
      RecevierBankCode: [this.receiptEditData.RecevierBankCode],
      PayeeName: ['', Validators.required],
      EnglishDescription: ['', Validators.required],
      ChequeDateFld: [''],
      ChequeDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required],
      ReceiptDetails: this.fb.array([])
    });

    switch (param) {
      case 1:
        this.receiptForm.addControl('Amount', new FormControl(''));
        /* if (this.receiptForm.controls.ChequeDate !== null || this.receiptForm.controls.ChequeDate !== undefined) {
           this.receiptForm.removeControl('ChequeDate');
         }*/
        break;
      case 2:
        this.receiptForm.addControl('ChequeNo', new FormControl('', Validators.required));
        this.receiptForm.controls['ChequeNo'].updateValueAndValidity();
        this.receiptForm.addControl('InstrumentDate', new FormControl(new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required));
        this.receiptForm.controls['InstrumentDate'].updateValueAndValidity();
        this.receiptForm.addControl('PayeeBankCode', new FormControl('', Validators.required));
        this.receiptForm.controls['PayeeBankCode'].updateValueAndValidity();
        this.receiptForm.addControl('PayeeBankName', new FormControl('', Validators.required));
        this.receiptForm.controls['PayeeBankName'].updateValueAndValidity();
        break;
      case 8:
        this.receiptForm.addControl('ChequeNo', new FormControl('', [Validators.required, Customvalidators.creditcardValidator]));
        this.receiptForm.controls['ChequeNo'].updateValueAndValidity();
        this.receiptForm.addControl('InstrumentRefNo', new FormControl(''));
        this.receiptForm.addControl('ChequeDate', new FormControl('', Validators.required));
        this.receiptForm.controls['ChequeDate'].updateValueAndValidity();
        this.receiptForm.addControl('TerminalUserID', new FormControl(''));
        //this.receiptForm.controls['TerminalUserID'].updateValueAndValidity();
        this.receiptForm.addControl('TransactionNo', new FormControl(''));
        this.receiptForm.addControl('ChequeType', new FormControl('', Validators.required));
        this.receiptForm.controls['ChequeType'].updateValueAndValidity();

        break;
      case 5:
        this.receiptForm.addControl('PayeeBankCode', new FormControl(''));
        this.receiptForm.controls['PayeeBankCode'].updateValueAndValidity();
        this.receiptForm.addControl('PayeeBankName', new FormControl('', Validators.required));
        this.receiptForm.controls['PayeeBankName'].updateValueAndValidity();
        this.receiptForm.addControl('ChequeDate', new FormControl('', Validators.required));
        this.receiptForm.controls['ChequeDate'].updateValueAndValidity();
        // defect 3080- make required for bank transfer
        this.receiptForm.addControl('InstrumentRefNo', new FormControl('', [Validators.required]));
        this.receiptForm.controls['InstrumentRefNo'].updateValueAndValidity();
        break;
    }
  }

  get voucherDetailsLength() {
    return this.receiptForm.controls.ReceiptDetails['controls'].length > 1;
  }
  entitiRowSelectionFormGroup(): FormGroup {
    return this.fb.group({
      CounterPartyReferenceNo: [],
      LocationCode: [sessionStorage.getItem('locationcode')],
      BranchCode: [sessionStorage.getItem('locationcode')],
      BranchName:[],
      LocationDesc: [],
      RefTranTypeName: [],
      CountryCode: [sessionStorage.getItem(RSAConstants.countrycode)],
      CostCenterCode: [sessionStorage.getItem('costcentre')],
      ClassCode: [],
      CostCenterName: [],
      CounterPartyRef: [],
      TotallingAccName: [],
      Class: [],
      Description: [],
      Amount: ['', Validators.required],
      Amt: [],
      LocationName: [],
      RefTransactionID: [],
      IsCreditEntry: [false],
      RefTransactionType: [3],
      RefTranTypeDesc: [],
      RefTranType: [],
      PolicyID: [],
      PolicyNumber: [],
      ModifiedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      ReceiptDate: [],
      AnalysisCode: [],
      Department: [],
      DepartmentName: [],
      RefTransactionSerialNo: [],
      PlaceHolderCode: [],
      GLCode: [null, Validators.required],
      GLCodeDesc: [null, Validators.required],
      GLAccountName: [],
      GLAccount: [],
      RegionCode: [sessionStorage.getItem('regioncode')],
      TotallingAccCode: [null, Validators.required],
      ClaimID: [],
      VoucherType: [],
      TransactionNumber: [],
      PolicyYear: [],
      PolicyType: [],
      TaxInvoiceNo: [],
      RefPolicyNo: [],
      RefPolicyYear: [],
      ReferenceID1: [],
      ReferenceID2: [],
      SerialNo: [0],
      Endt_ID: [],
      // Aaded new formControlName to make row readonly if coming from selection rows
      newAddedRow: true
    });
  }


  setHiddenValue(ev, iter, key, setKey) {
    (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.item[setKey]);
    let glAccntId = parseInt(ev.item[setKey]);
    let selGLAccnt = this.glaccount[iter].filter(data => data.GLCode === glAccntId)[0];
    this.setReqValFormArrayControl('AnalysisCode', iter, selGLAccnt.ProjectIndicator ? true : false);
    this.setReqValFormArrayControl('Department', iter, selGLAccnt.Department ? true : false);
  }
  setCreditEntry(ev, iter, key, data) {
    const actualData = Number(data.controls['Amount'].value);
    if (actualData === 0 || actualData === undefined) {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.EMPTYAMOUNTCHECK;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      ev.target.checked = !ev.target.checked;

    }
    this.setFormArrayCTRLDefaultValue(key, iter, !ev.target.checked);
    this.getSum();
    if (this.totalAmount < 0) {
      ev.target.checked = true;
      this.setFormArrayCTRLDefaultValue(key, iter, false);
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.CREDITEXCEEDMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
    }
    this.getSum();
  }
  /// update amount before submit
  updateDetailsAmount() {
    let amt = 0;
    let actualamt = 0;
    let flagtoggle = false;
    this.receiptForm.value.ReceiptDetails = this.receiptForm.controls['ReceiptDetails'].value;
    (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls.forEach((element, index) => {
      if (this.getFromFormArrayControlVal('Amount', index) != undefined
        && this.getFromFormArrayControlVal('Amount', index) != null) {
        flagtoggle = this.getFromFormArrayControlVal('IsCreditEntry', index);
        amt = parseFloat(this.getFromFormArrayControlVal('Amount', index));
        amt = Math.abs(amt) || 0;
        actualamt = (!flagtoggle) ? amt : (amt * -1);
        this.setFormArrayCTRLDefaultValue('Amount', index, actualamt);
      }
    });
  }
  // setting current Tab Index to activiate tab
  setcurrentTbIndex(tab) {
    let tabVal=tab.toLowerCase();
    switch (tabVal) {
      case 'cash':
        this.currentTbIndex = 2;
        break;
      case 'cheque':
        this.currentTbIndex = 0;
        break;
      case 'credit card':
        this.currentTbIndex = 1;
        break;//credit
      case 'credit':
        this.currentTbIndex = 1;
        break;
      case 'bank transfer':
        this.currentTbIndex = 3;
    }
  }
  // Displaying the  confirmation alert on tab click
  confirmTabSwitch(event) {
    console.log(event.target.tagName);
    const parentElement = event.target.parentElement;
    const target = event.target.parentElement.text;
    if (event.target.tagName === 'SPAN' && !parentElement.classList.contains('active') && parentElement.classList.contains('nav-link')) {
      if (this.receiptForm.dirty) {
        // --- showing popup only you have added or changed something
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        // Will move the content to RSAMSGConstants once approved //
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.PAYMENTMODECHANGEMSG;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
        this.bsModalRef.content.valueChange.subscribe((data) => {
          console.log(data);
          // changing the currentTbIndex if user proceed
          if (data = RSAMSGConstants.BTNPROCEED) {
            console.log(this.currentTbIndex);
            setTimeout(() => {
              this.setcurrentTbIndex(target);
            }, 0);
            setTimeout(() => {
              this.tabset.tabs.forEach(item => {
                if (item.heading == target) {
                  item.active = true;
                }
              });
            }, 1);
          }
        });
      } else {
        setTimeout(() => {
          this.setcurrentTbIndex(target);
        }, 0);
        setTimeout(() => {
          this.tabset.tabs.forEach(item => {
            if (item.heading == target) {
              item.active = true;
            }
          });
        }, 1);

      }

    }
  }


  setTerminalCode(ev, key, setKey) {
    console.log(ev, 'ev');
    this.receiptForm.controls[key].setValue(ev.item[setKey]);
  }
  setBankCode(ev, iter, key) {
    this.receiptForm.controls[key].setValue(ev.item.BankCode);
  }

  clearFormArray = (formArray: FormArray) => {
    while (formArray.length !== 0) {
      formArray.removeAt(0)
    }
  }

  addReceipt(item, len?, newAdded?) {
    const control = <FormArray>this.receiptForm.controls['ReceiptDetails'];
    const newRow = this.entitiRowSelectionFormGroup();
    if (!newAdded) {
      this.populateDropdownValues(len);
      newRow.patchValue(item);
      control.push(newRow);
      const regionWiseAmt = this.isOMAN ? (item.Amount).toFixed(3) : (item.Amount).toFixed(2);
      newRow.patchValue({ 'Amount': regionWiseAmt });
      newRow.patchValue({'Department': item.DepartmentCode});
      newRow.patchValue({'newAddedRow': false});
    }
    if (newAdded) {
      control.push(newRow);
      // this.setFormArrayCTRLDefaultValue('GLCode', len, 4);
      // this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '4-HSBC BANK MIDDLE EAST - Deira');
      newRow.patchValue({ 'newAddedRow': true });
      this.isNewRow=true;
      this.costcentredata[len] = this.cachedCostcentredata;
      this.changeCostcenter(len, false, true);
    }
  }
  populateDropdownValues(index) {
    console.log('index', index);
    const branchcode = this.receiptEditData.ReceiptDetails[index].LocationCode;
    const costcentre = this.receiptEditData.ReceiptDetails[index].CostCenterCode;
    const totallingcode = this.receiptEditData.ReceiptDetails[index].TotallingAccCode;
    const glcode = this.receiptEditData.ReceiptDetails[index].GLCode;
    const gldesc = this.receiptEditData.ReceiptDetails[index].GLCodeDesc;
    this.setchangeCostcenter(index, branchcode, costcentre, totallingcode, glcode, gldesc);

  }
  setchangeCostcenter(index, loccode, costcentre, totallingcode, glcode, gldesc) {
    this.masterDataService.getCostCenters().subscribe(
      dataReturn => {
        this.costcentredata[index] = dataReturn;
        this.setFormArrayCTRLDefaultValue('CostCenterCode', index, costcentre);
        this.setTotallingDetailData(index, costcentre, totallingcode, glcode, gldesc);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  setTotallingDetailData(index, costcentre, totallingcode, glcode, gldesc) {

    const param = 'paymentMode=' + this.paymentname +
      '&costCenter=' + costcentre;

    this.masterDataService.getTotallingDetailData(param).subscribe(
      dataReturn => {
        this.dtltotallingacc[index] = dataReturn;
        this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, totallingcode);
        this.setGLData(index, costcentre, totallingcode, glcode, gldesc);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  setGLData(index, costcentre, totallingcode, glcode, gldesc) {

    const param = 'totallingAccCode=' + totallingcode +
      '&CostCenterCode=' + costcentre;
    console.log('param-GL', param);

    this.masterDataService.getGLData(param).subscribe(
      dataReturn => {
        this.glaccount[index] = dataReturn;
        this.setFormArrayCTRLDefaultValue('GLCode', index, glcode);
        this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, gldesc);

      },
      errorRturn => this.errorMsg = errorRturn
    );

  }
  getReceiptDetails(entitiRowSelectionForm) {
    return entitiRowSelectionForm.controls.ReceiptDetails.controls;
  }
  get cshpayeename() { return this.receiptForm.get('PayeeName'); }
  get cshdetails() { return this.receiptForm.get('EnglishDescription'); }
  get payeebankcode() { return this.receiptForm.get('PayeeBankCode'); }
  get chequedate() { return this.receiptForm.get('ChequeDate'); }
  get instrumentrefno() { return this.receiptForm.get('InstrumentRefNo'); }
  get terminalid() { return this.receiptForm.get('TerminalUserID'); }
  get chequeType() { return this.receiptForm.get('ChequeType'); }

  get expirydate() { return this.receiptForm.get('ExpiryDate'); }
  get chequeno() { return this.receiptForm.get('ChequeNo'); }
  get instrumentdate() { return this.receiptForm.get('InstrumentDate'); }

  get receiptRows() { return <FormArray>this.receiptForm.get('ReceiptDetails'); }

  reSetForm(param) {
    /*set default value here and reset */
    if (param == 1) {
      const arrayFields = ['PayeeName', 'EnglishDescription', 'ChequeNo', 'ChequeDate', 'PayeeBankCode',
        'PayeeBankName', 'ExpiryDate', 'InstrumentRefNo', 'TerminalUserID', 'ChequeType', 'TransactionNo'];
      this.receiptForm.controls['LocationCode'].reset(sessionStorage.getItem('locationcode'));
      this.receiptForm.controls['CostCenterCode'].reset(sessionStorage.getItem('costcentre'));
      this.receiptForm.controls['TotallingAccCode'].reset(sessionStorage.getItem(RSAConstants.totallingaccount));
      this.getBankData(true);
      this.receiptForm.controls['RecevierBankCode'].reset(14);
      //  this.receiptForm.controls['EnglishDescription'].reset();

      arrayFields.forEach((val) => {
        if (this.receiptForm.controls[val] != null && this.receiptForm.controls[val] != undefined) {
          this.receiptForm.controls[val].reset();
        }
      });
      if (this.RcptMode == 2) {
        this.receiptForm.controls['InstrumentDate'].setValue('');
      }
      if (this.RcptMode == 5) {
        this.receiptForm.controls['PayeeBankCode'].setValue('');
      }
      if (this.RcptMode == 8 && this.isUAE === true) {
        let terminalUserId = this.defaultUserId ? this.defaultUserId : '';
        let terminalId = this.defaultTerminalId ? this.defaultTerminalId : '';
        this.receiptForm.controls['TerminalUserID'].setValue(terminalUserId);
        this.receiptForm.controls['TerminalID'].setValue(terminalId);
      }
      this.setPayeName();
      this.receiptForm.controls['EnglishDescription'].setValue(this.receiptEditData.EnglishDescription);
      this.clearerrors();
    } else if (param == 2) {
      this.receiptForm.controls['ReceiptDetails'].reset();
      (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls.map(item => {
        item.get('LocationCode').setValue([sessionStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([sessionStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(sessionStorage.getItem(RSAConstants.totallingaccount));
        item.get('GLCode').setValue(sessionStorage.getItem(RSAConstants.defaultGLCode));
        item.get('GLCodeDesc').setValue(sessionStorage.getItem(RSAConstants.defaultGLCodeDesc));
      });

      this.getSum();
    }
    this.GetAccountingDates(this.receiptEditData.ReceiptDate);
  }

  deleteReceipt(index: number, itemrow) {
    console.log(itemrow, 'itemrow');    
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
      this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
      this.bsModalRef.content.valueChange.subscribe((data) => {
        if (data = RSAMSGConstants.BTNPROCEED) {
          const control = <FormArray>this.receiptForm.controls['ReceiptDetails'];
          control.removeAt(index);
          this.getSum();
        }
      });
  }

  checkIsformDirty() {
    if (this.receiptForm.dirty || this.receiptForm.touched) {
      console.log('cmg here');
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
      this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
      this.bsModalRef.content.valueChange.subscribe((data) => {
        if (data = 'Proceed') {
          this.modalService.hide(1);
          this.sharedService.sendMessage('close');
          if (sessionStorage.getItem('ReceiptStateExists') != null) {
            sessionStorage.setItem('ReceiptStateExists', 'false');
          }
        }
      });

    } else {
      this.modalService.hide(1);
      this.sharedService.sendMessage('close');
      if (sessionStorage.getItem('ReceiptStateExists') != null) {
        sessionStorage.setItem('ReceiptStateExists', 'false');
      }
    }
    this.gridApiService.unCheck();

    this.renderer.removeClass(this.document.body, 'modal-open');
  }

  clearGLCode(indx, val) {
    this.setFormArrayCTRLDefaultValue('GLCode', indx, '');
    this.setFormArrayCTRLDefaultValue('GLCodeDesc', indx, '');
  }

  validateDetailInfo() {
    this.glerrorcount = 0;
    this.amountZeroCheck = 0;
    this.amountLimitCheck = 0;
    this.submitError = 0;
    (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls.map((item, index) => {
      item.get('Amount').updateValueAndValidity();
      item.get('Amount').markAsTouched();
      item.get('GLCode').updateValueAndValidity();
      item.get('GLCode').markAsTouched();
      item.get('TotallingAccCode').updateValueAndValidity();
      item.get('TotallingAccCode').markAsTouched();

      if (item.get('GLCode').value == '1133') {

        item.get('Department').setValidators([Validators.required]);
        item.get('AnalysisCode').setValidators([Validators.required]);
        item.get('Department').updateValueAndValidity();
        item.get('Department').markAsTouched();
        item.get('AnalysisCode').updateValueAndValidity();
        item.get('AnalysisCode').markAsTouched();

      }

      if (item.get('GLCode').value == '1133') {
        if (item.get('Department').value == null
          || item.get('Department').value == undefined
          || item.get('Department').value == "") {
          this.glerrorcount = this.glerrorcount + 1;
        }
        if (item.get('AnalysisCode').value == null || item.get('AnalysisCode').value == undefined || item.get('AnalysisCode').value == "") {
          this.glerrorcount = this.glerrorcount + 1;
        }
      }
      if (item.get('GLCode').value == null ||
        item.get('GLCode').value == undefined ||
        item.get('GLCode').value == "") {
        this.glerrorcount = this.glerrorcount + 1;
      }
      if (item.get('TotallingAccCode').value == null ||
        item.get('TotallingAccCode').value == undefined ||
        item.get('TotallingAccCode').value == "") {
        this.glerrorcount = this.glerrorcount + 1;
      }
      if (item.get('Amount').value == null || item.get('Amount').value == 0 ||
        item.get('Amount').value == undefined || item.get('Amount').value == "") {
        this.glerrorcount = this.glerrorcount + 1;
        this.amountZeroCheck = this.amountZeroCheck + 1;
      }

      if ((this.isOMAN && item.get('Amount').value > 999999999.999) || (!this.isOMAN && item.get('Amount').value > 999999999.99)) {
        this.glerrorcount = this.glerrorcount + 1;
        this.amountLimitCheck = this.amountLimitCheck + 1;
        return false;
      }

      if (item.get('GLCode').value !== null &&
        item.get('GLCode').value !== undefined &&
        item.get('GLCode').value !== "") {
        let selGlAccntId = parseInt(item.get('GLCode').value);
        let lstGLAccnt = this.glaccount[index].filter(data => data.GLCode === selGlAccntId);
        if(lstGLAccnt.length > 0){
          let selGLAccnt = lstGLAccnt[0];
          if (item.get('Department').value == null
            || item.get('Department').value == undefined
            || item.get('Department').value == "") {
              if(selGLAccnt.Department){
                this.setReqValFormArrayControl('Department', index, selGLAccnt.Department ? true : false);
                this.submitError++;
              }   
          }
          if (item.get('AnalysisCode').value == null || 
          item.get('AnalysisCode').value == undefined || 
          item.get('AnalysisCode').value == "") {
            if(selGLAccnt.ProjectIndicator){
              this.setReqValFormArrayControl('AnalysisCode', index, selGLAccnt.ProjectIndicator ? true : false);
              this.submitError++;
            }
          }
        }
      }
      if(item.get('AnalysisCode').invalid){
        this.submitError++;
      }
      if(item.get('Department').invalid){
        this.submitError++;
      }


    });
  }


  submitForm(bsModalRef, receiptno) {
    const ReceiptDetails = <FormArray>this.receiptForm.controls['ReceiptDetails'];
    this.receiptForm.value.ReceiptDetails = ReceiptDetails.value;
    this.updateDetailsAmount();
    this.validateDetailInfo();
    console.log(this.glerrorcount, 'glrcount');
    //zero amount warning
    if (this.amountZeroCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTZEROCHECK);
      return false;
    }
    if (this.amountLimitCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTEXCEEDMSG);
      return false;
    }
    if (this.glerrorcount > 0) {
      return false;
    }
    if(this.submitError > 0){
      this.alertService.warn(RSAMSGConstants.REQFIELDERROR);
      return false;
    }
    // this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
    //   this.approverusers.length > 0);
    // Removing newAddedRow key from receiptForm
    this.receiptForm.value.ReceiptDetails.map((item, i) => {
      if (item.newAddedRow) {
        delete item.newAddedRow;
      }
    });
    console.log(this.receiptForm.value, 'value');
    let formval = this.receiptForm.value;
    formval["ChequeDate"] = formval["ChequeDateFld"];
    console.log(this.receiptForm.value, 'formval');
    if (this.totalAmount > 0) {
      // if (this.isUAE === false || this.isOMAN === false) {// UAE,OMAN Approver is not needed
      //   if (this.totalAmount > 99999 && !this.usersReq) {
      //     this.displayApprover=true;
      //   }
      // }
      if (this.prevReceipt == null || this.prevReceipt == undefined) {
        this.prevReceipt = 0;
      }
      //send serialNo in update
      // if (this.prevReceipt > 0 && (this.previewDataDtl != null || this.previewDataDtl != undefined)) {
      //   formval.ReceiptDetails.map((element, index) => {
      //     if (index < this.previewDataDtl.length) {
      //       element.SerialNo = this.previewDataDtl[index].SerialNo;
      //     }
      //   });
      // }
      formval["ReceiptNo"] = this.prevReceipt;

      // if (this.prevReceipt > 0 && (this.previewDataDtl != null || this.previewDataDtl != undefined)) {
      //   formval.ReceiptDetails.map((element, index) => {
      //     if (index < this.previewDataDtl.length) {
      //       element.SerialNo = this.previewDataDtl[index].SerialNo;
      //     }
      //   });
      // }
      this.createservice.createReceipt(JSON.stringify(formval)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = false;
          this.gridApiService.unCheck();
          this.previewFlag = true;
          this.bsModalRef = this.modalService.show(ReceiptpreviewComponent, {
            class: 'preview-modal-dailog',
            ignoreBackdropClick: true,
            backdrop: 'static',
            keyboard: false
          });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
          this.bsModalRef.content.backdrop = true;
          this.bsModalRef.content.isDraft = true;
          this.bsModalRef.content.unApproved = this.unApproved;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }

    if (this.totalAmount <= 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTTEXTREQ);
    }

  }

  goPrevious(val) {
    console.log(this.payeebankcode, ' this.payeebankcode.PayeeBankCode');
    // this.receiptEditData.PayeeBankCode.patchValue('');
    this.level = 1;
    this.counter = this.counter + 1;
  }
  collapseToheader() {
    this.collapsetoheader = !this.collapsetoheader;
    (!this.collapsetoheader) ? this.modalService._showBackdrop() : this.modalService.removeBackdrop();

  }
  setTerminal(val: any) {
    const currentTerminalID = this.terminals.filter(item => item.UserID == val);
    this.receiptForm.get('TerminalID').setValue(currentTerminalID[0].TerminalID);
  }
  GetAccountingDates(voucherDate) {
    if (!voucherDate || voucherDate === '') {
      voucherDate = new Date();
    }
    if (typeof voucherDate === 'string') {
      let dateValueParts = voucherDate.split('/');
      voucherDate = new Date(Number(dateValueParts[2]), Number(dateValueParts[1]) - 1, Number(dateValueParts[0]));
    }
    this.minDateRd = new Date(sessionStorage.getItem('accntStartDate'));
    this.maxDateRd = new Date(sessionStorage.getItem('accntEndDate'));
    const sysDate = new Date();
    if (voucherDate < this.minDateRd) {
      if (sysDate < this.minDateRd) {
        this.receiptAccountingDate = new DatePipe('en-US').transform(this.minDateRd, 'dd/MM/yyyy');
      }
      else {
        this.receiptAccountingDate = new DatePipe('en-US').transform(sysDate, 'dd/MM/yyyy');
      }
    }
    else {
      this.receiptAccountingDate = new DatePipe('en-US').transform(voucherDate, 'dd/MM/yyyy');
    }
    this.receiptdate.setValue(this.receiptAccountingDate);
  }
  changeVoucherDate() {
    if (typeof (this.receiptdate.value) !== 'string') {
      const receiptDate = this.receiptdate.value;
      this.receiptdate.setValue(this.receiptAccountingDate);
      let showConfirm;
      let modelContent;
      let getConfirm;
      if (receiptDate > this.maxDateRd) {
        showConfirm = true;
        getConfirm = true;
        modelContent = RSAMSGConstants.VOUCHERDATEGREATERTHANACCOUNTINGEND;
      }
      else if (receiptDate < this.minDateRd) {
        showConfirm = true;
        getConfirm = false;
        modelContent = RSAMSGConstants.VOUCHERDATELESSERTHANACCOUNTINGEND;
      }
      if (showConfirm) {
        this.receiptdate.setValue(this.receiptAccountingDate);
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = '';
        this.bsModalRef.content.modelBodyContent = modelContent;
        this.bsModalRef.content.cancelBtn = getConfirm ? RSAMSGConstants.NOTEXT : null;
        this.bsModalRef.content.actionBtn = getConfirm ? RSAMSGConstants.YESTEXT : RSAMSGConstants.OKTEXT;
        this.bsModalRef.content.valueChange.subscribe((data) => {
          if (data.toString().trim() === 'YES') {
            this.receiptAccountingDate = new DatePipe('en-US').transform(receiptDate, 'dd/MM/yyyy');
            this.receiptdate.setValue(this.receiptAccountingDate);
          }
          this.bsModalRef.hide();
        });
      }
      else {
        this.receiptAccountingDate = new DatePipe('en-US').transform(receiptDate, 'dd/MM/yyyy');
        this.receiptdate.setValue(this.receiptAccountingDate);
      }
    }
  }
}

