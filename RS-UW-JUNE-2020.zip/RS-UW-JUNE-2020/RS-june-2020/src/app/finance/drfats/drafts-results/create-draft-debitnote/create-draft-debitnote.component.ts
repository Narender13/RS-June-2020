import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { SharedService } from 'src/app/finance/services/shared.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { CreateReceipt } from 'src/app/finance/search/model/create-receipt';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreateDebitNotes } from 'src/app/finance/debitnotes/create-debitnotes/model/create-dn';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { CreateDebitnotesService } from 'src/app/finance/debitnotes/create-debitnotes/service/create-debitnotes.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { TaxinvoicepreviewComponent } from 'src/app/finance/preview/uae/taxinvoicepreview/taxinvoicepreview.component';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';

@Component({
  selector: 'rsa-create-draft-debitnote',
  templateUrl: './create-draft-debitnote.component.html',
  styleUrls: ['./create-draft-debitnote.component.scss']
})
export class CreateDraftDebitnoteComponent extends BasevoucherComponent implements OnInit, OnDestroy {
  title = RSAConstants.TaxInvoiceTitle;
  currency = sessionStorage.getItem(RSAConstants.currency);
  errorpayee: boolean;
  errordetail: boolean;
  errorglCode: boolean;
  /* form error-feilds */
  errorbankcodeCheque: boolean;
  level: any = 2;
  errorbankcodeBanktransfer: boolean;
  errorpaayeebanknameCheque: boolean;
  errorpaayeebanknameBanktransfer: boolean;
  errorchequedateCheque: boolean;
  errorchequedateBankT: boolean;
  errorchequedateCreditCard: boolean;
  errorchequenoCheque: boolean;
  errorchequenoCreditCard: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  matchedRecords = [];
  isUploadUnmatched;
  returnValue: any;
  usersReq;
  symbol;
  glAcountHeader: any = [];
  createDebitNotes: CreateDebitNotes;
  animatedClass = true;
  selectedRowItem: any;
  debitnoteEditData: any;
  customerName: string = "";
  ondemandFlag: boolean = false;
  ondemandFlagClaim = true;
  formArray: any;
  unApproved;
  accountingCode;
  receiptAccountingDate: any;
  toggleValueCredit = [];
  errorReportHeader: boolean;
  isUAE: boolean = false;
  customOnDemandFlag: boolean = true;
  @ViewChild('tabset') tabset: TabsetComponent;
  selectedRowEntitiDataTable: any;
  isStateClosed: boolean = false;
  constructor(
    protected sharedService: SharedService,
    private fb: FormBuilder,
    protected modalService: BsModalService,
    protected bsModalRef: BsModalRef,
    protected masterDataService: MasterDataService,
    protected utilityClass: UtilityClass,
    protected createPaymentService: CreateDebitnotesService,
    private alertService: AlertService,
  ) {
    super(masterDataService, sharedService, modalService, utilityClass, bsModalRef);
    //super.setMinMaxDate();
  }

  ngOnInit() {
    /* super with method is calling from BasevoucherComponent */
    this.createVoucherForm(this.paymentMode);
    this.isUAE = (sessionStorage.getItem('regioncode') == '2') ? true : false;
    if (this.isUAE) {
      super.getAllReportHeadersDebitNote();
      this.mainVoucherForm.controls['Title'].setValidators([Validators.required]);
      this.mainVoucherForm.controls['Title'].updateValueAndValidity();
    }
    this.isRowDraftDN = true;
    this.dnEditData = this.debitnoteEditData;

    //console.log(this.dnEditData, 'this.dnEditData');
    this.customOnDemandFlag = this.checkonDemandOrOnAccount(this.dnEditData.DebitNoteDetail);
    super.getAllBranchData();
    super.setBranchData(this.dnEditData.LocationCode);
    super.getAllCostCenterData({ ev: null, index: 0, flag: true });
    super.getAllTotallingData(true);
    super.getAllProjData();
    super.getAllDeptData();
    super.getAllMasterData2();
    this.fieldStatusChanges();
    super.closeModel();
    super.getAllTranData();
    this.symbol = (sessionStorage.getItem('symbol'));
    //super.setMinMaxDate();
    this.selectedRowEntitiDataTable = this.debitnoteEditData.DebitNoteDetail;
    this.getPreviousRows();
    this.getGlAccountHeader();
    this.getDetailsArrayFormGroup();
    super.getModelPreviousClose();
    super.getAllgetLookupBanksData();
    super.getTotalingHeaderDataCnDn();
    const totcode = this.debitnoteEditData.TotallingAccCode;
    super.getGlAccountHeaderDataCnDn(totcode);
    this.getActualAmountSum('DN');
    this.setHeaderData();
    super.GetAccountingDates(this.dnEditData.VoucherDate);
    this.sharedService.getMessage().subscribe(val => {
      if (val == 'close') {
        this.isStateClosed = true;
        this.mainVoucherForm.markAsPristine();
        this.mainVoucherForm.markAsUntouched();
      }
    });
  }
  ngOnDestroy() {
    if (!this.isStateClosed) {
      this.addRowsToSession();
    }
  }
  addRowsToSession() {
    this.selectedRowEntitiDataTable.forEach(row => {
      row.isFromDraft = 'true';
    });
    if (this.selectedRowEntitiDataTable.length > 0) {
      sessionStorage.setItem('SnackbarAdded', 'true');
      sessionStorage.setItem('isFromDraft', 'true');
      let vType = 'DebitNote';
      this.prevPreviewID = this.debitnoteEditData.DebitNoteNo;
      let voucherDetail = { SelectedRows: this.selectedRowEntitiDataTable, voucherType: vType, VoucherNo: this.prevPreviewID };
      sessionStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
      let voucherDate = this.mainVoucherForm['controls'].VoucherDate.value;
      let totallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
      let glCode = this.mainVoucherForm.controls.accountInfo['controls'].GLCode.value;
      let description = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
      let payeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
      var commonData = { VoucherDate: voucherDate, TotallingAccCode: totallingAccCode, GLCode: glCode, Description: description, PayeeName: payeeName }
      sessionStorage.setItem('CommonDNData', JSON.stringify(commonData));//CommonDNData
      sessionStorage.setItem('DNStateExists', 'true');
      this.updateRows();
      this.sharedService.sendMessage('DNSnackbarAdded');
    }
  }
  updateRows() {
    let formarray = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    if (formarray.controls.length > 0) {
      let voucherDetail = JSON.parse(sessionStorage.getItem('VoucherDetail'));
      voucherDetail.SelectedRows = [];
      formarray.controls.forEach(ctrl => {
        let rowClone = Object.assign({}, ctrl.value);
        rowClone.Amount = (rowClone.Amount) ? rowClone.Amount : 0;
        rowClone.Amount = parseInt(rowClone.Amount);
        rowClone.DNTotallingAcc = rowClone.TotallingAccCode;
        rowClone.DNVATAmount = 0;
        rowClone.isFromDraft = 'true';
        voucherDetail.SelectedRows.push(rowClone)
      });
      sessionStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
    }
  }
  getPreviousRows() {
    let SnackbarAdded = sessionStorage.getItem('SnackbarAdded');
    if (SnackbarAdded == 'true') {
      let voucherDetail = JSON.parse(sessionStorage.getItem('VoucherDetail'));
      if (this.debitnoteEditData.DebitNoteNo == voucherDetail.VoucherNo) {
        this.debitnoteEditData.DebitNoteDetail = voucherDetail.SelectedRows;
        this.selectedRowEntitiDataTable = voucherDetail.SelectedRows;
      }
      else {
        this.selectedRowEntitiDataTable = this.debitnoteEditData.DebitNoteDetail;
      }

    }
    else {
      this.selectedRowEntitiDataTable = this.debitnoteEditData.DebitNoteDetail;
    }
  }
  /* create entiti form */
  createVoucherForm(param): void {
    this.mainVoucherForm = null;
    //let tranDate = sessionStorage.getItem('tranAccntMnthStrtDate') ? new Date(sessionStorage.getItem('tranAccntMnthStrtDate')) : new Date();
    this.mainVoucherForm = this.fb.group({
      VoucherDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ApprovedBy: [],
      ArabicDescription: [],
      Amount: [''],
      CountryCode: [sessionStorage.getItem(RSAConstants.countrycode)],
      CustomerID: [],
      CustCode: [],
      ModifiedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      ModifiedDate: [],
      PreparedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [],
      ReprintNo: [],
      PrintDate: [],
      RefreshDate: [],
      PostedDate: [],
      PreprintNo: [],
      Title: [],
      RegionCode: [sessionStorage.getItem('regioncode')],
      Approvers: this.fb.array([]),
      detailInfo: this.fb.group({
        PayeeName: [this.customerName, Validators.required],
        EnglishDescription: ['', Validators.required],
      }),
      accountInfo: this.fb.group({
        LocationCode: [sessionStorage.getItem('locationcode')],
        CostCenterCode: [sessionStorage.getItem('costcentre')],
        TotallingAccCode: [sessionStorage.getItem(RSAConstants.totallingaccount)],
        GLCode: [sessionStorage.getItem(RSAConstants.defaultGLCode), Validators.required],
        GLCodeDesc: [sessionStorage.getItem(RSAConstants.defaultGLCodeDesc), Validators.required]
      }),
      VoucherDetails: this.fb.array([]),
      TaxPointDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]
    });
  }
  setHeaderData() {
    this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(this.debitnoteEditData.TotallingAccCode);
    this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(this.debitnoteEditData.GLCode);
    this.mainVoucherForm.controls.accountInfo['controls'].GLCodeDesc.setValue(this.debitnoteEditData.GLCodeDesc);
    this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.setValue(this.debitnoteEditData.PayeeName);
    this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(this.debitnoteEditData.EnglishDescription);
    this.mainVoucherForm.controls['Title'].setValue(this.debitnoteEditData.Title);
    if (this.debitnoteEditData.TaxPointDate === null || this.debitnoteEditData.TaxPointDate === undefined || this.debitnoteEditData.TaxPointDate === '01/01/0001') {
      if (this.isUAE) {
        this.debitnoteEditData.TaxPointDate = new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy');
      }
    }
    this.mainVoucherForm.controls['TaxPointDate'].setValue(this.debitnoteEditData.TaxPointDate);

  }
  getDetailsArrayFormGroup() {
    let control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    console.log('this.debitnoteEditData', this.debitnoteEditData);
    this.selectedRowItem = this.debitnoteEditData.DebitNoteDetail;
    console.log(this.selectedRowItem, 'selectedRowItem');
    if (!this.ondemandFlag) {
      this.mainVoucherForm.controls['CustomerID'].setValue(this.debitnoteEditData.CustomerID);
      this.mainVoucherForm.controls['CustCode'].setValue(this.debitnoteEditData.CustCode);

      this.selectedRowItem.map((item, index) => {
        super.getAllCostCenterData({ ev: null, index: index, flag: true });
        let group = this.createDetailsArrayGroup();
        group.patchValue(item);
        group.get('newAddedRow').setValue(false);
        group.get('IsDebitEntry').setValue((parseFloat(group.get('Amount').value) < 0) ? false : true);
        control.push(group);
        const ctrl = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
        ctrl.controls.forEach((val, i) => {
          const amount = val.get('Amount').value;
          this.toggleValueCredit[i] = amount < 0 ? false : true;
        });
        console.log(this.toggleValueCredit, 'this.toggleValueCredit');
      });

    } else {
      control.push(this.createDetailsArrayGroup());
    }
  }


  getGLdataCnDn(ev) {
    const totcode = ev.ev;
    console.log(totcode, 'totcode');
    super.getGlAccountHeaderDataCnDn(totcode, true);
  }

  /* form array for recept details */
  createDetailsArrayGroup(): FormGroup {
    return this.fb.group({
      Amount: ['', Validators.required],
      AnalysisCode: [],
      CostCenterCode: [sessionStorage.getItem('costcentre')],
      ClaimID: [],
      ClassCode: [],
      CauseOfLossCode: [],
      CounterPartyRef: [],
      CountryCode: [sessionStorage.getItem(RSAConstants.countrycode)],
      Description: [],
      DocumentCode: [],
      EntityID: [],
      GLCode: [sessionStorage.getItem(RSAConstants.defaultGLCode), Validators.required],
      GLCodeDesc: [sessionStorage.getItem(RSAConstants.defaultGLCodeDesc), Validators.required],
      LocationCode: [sessionStorage.getItem('locationcode')],
      LocationDesc: [sessionStorage.getItem(RSAConstants.locationdesc)],
      ModifiedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      ModifiedDate: [],
      NatureOfLossCode: [],
      PolicyID: [],
      PolicyYear: [],
      PreparedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
      PreparedDate: [],
      RefTransactionID: [],
      RefTransactionSerialNo: [],
      RefTransactionType: [11],
      RegionCode: [sessionStorage.getItem(RSAConstants.regionCode)],
      TotallingAccCode: [sessionStorage.getItem(RSAConstants.totallingaccount), Validators.required],
      PolicyType: [],
      newAddedRow: true,
      IsDebitEntry: [false],
      VoucherNo: [],
      SerialNo: [],
      SrNO: [],
      Department: [],
      DepartmentCode: []
    });
  }

  /* set receipt mode and set default values   */
  setReceiptMode(val, paymentname) {
    this.mainVoucherForm.controls['PaymentMode'].setValue(val);
    this.paymentMode = val;
    this.paymentname = paymentname;
    this.createVoucherForm(this.paymentMode);
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;
    if (this.paymentMode == 1) {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1210');
    } else {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(sessionStorage.getItem(RSAConstants.totallingaccount));
      this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue(sessionStorage.getItem(RSAConstants.defaultBankCode));
    }
    this.setdefaultHeaderData();
    this.fieldStatusChanges();
    super.GetAccountingDates(this.dnEditData.VoucherDate);
  }


  /* using req fields and update status  */
  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );

    this.cshreportHeaders.statusChanges.subscribe(
      status => {
        this.errorReportHeader = (status === 'INVALID');
      }
    );

    // this.glCodeValue.statusChanges.subscribe(
    //   status => {
    //     this.errorglCode = (status === 'INVALID');
    //   }
    // );

  }

  /* clear all errors after reset   */
  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    this.errorReportHeader = false;
    //this.errorglCode = false;
  }

  /* get the controls of each fields   */
  get cshpayeename() { return this.mainVoucherForm.controls.detailInfo['controls'].PayeeName; }
  get cshdetails() { return this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription; }
  get cshreportHeaders() { return this.mainVoucherForm['controls'].Title; }
  //get glCodeValue() { return this.mainVoucherForm.controls.detailInfo['controls'].GLCode; }


  /* set Description in receptdetails desc   */
  setDescription() {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[0].get('Description').setValue(this.cshdetails.value);
  }
  getActualAmountSum(processFlag) {
    let total: number = 0;
    let amt: number = 0;
    let actualamt: number = 0;
    let flagtoggle: boolean = false;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {

      if (this.getFromFormArrayControlVal("Amount", index) != undefined
        && this.getFromFormArrayControlVal("Amount", index) != null) {
        flagtoggle = this.getFromFormArrayControlVal("IsDebitEntry", index);
        console.log(flagtoggle, 'flagtoggle');
        amt = parseFloat(this.getFromFormArrayControlVal("Amount", index));
        amt = Math.abs(amt || 0);
        if (processFlag == 'DN') {
          actualamt = (!flagtoggle) ? (amt * -1) : amt;
        } else if (processFlag == 'CN') {
          actualamt = (!flagtoggle) ? amt : (amt * -1);
        }
        console.log('flagtoggle:' + flagtoggle + ",amt:" + amt + ",actualamt:" + actualamt);
        total = total + actualamt;
      }

    });
    this.totalAmount = total;
  }

  setCreditEntryDn(ev) {
    console.log(this.totalAmount, 'this.totalAmount');
    const actualData = Number(ev.data.controls['Amount'].value);

    if (actualData === 0 || actualData === undefined) {
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.AMOUNTVALIDATIONMSG,
        'btnaction': RSAMSGConstants.OKTEXT
      });
      ev.event.target.checked = false;
    }
    this.setFormArrayCTRLDefaultValue(ev.iscredit, ev.index, ev.event.target.checked);
    this.getActualAmountSum('DN');
    if (this.totalAmount > 0) {
      console.log(this.totalAmount, 'totalamount');
      ev.event.target.checked = false;
      this.setFormArrayCTRLDefaultValue(ev.iscredit, ev.index, false);
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.CREDITEXCEEDMSG,
        'btnaction': RSAMSGConstants.OKTEXT
      });
    }
    this.getActualAmountSum('DN');
  }

  /// update amount before submit
  updateDetailsAmount(processFlag) {
    let amt = 0;
    let actualamt = 0;
    let flagtoggle = true;
    this.mainVoucherForm.value.VoucherDetails = this.mainVoucherForm.controls['VoucherDetails'].value;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {

      if (this.getFromFormArrayControlVal('Amount', index) != undefined && this.getFromFormArrayControlVal('Amount', index) != null) {
        flagtoggle = this.getFromFormArrayControlVal('IsDebitEntry', index);
        amt = parseFloat(this.getFromFormArrayControlVal('Amount', index));
        amt = Math.abs(amt);
        if (processFlag == 'DN') {
          actualamt = (!flagtoggle) ? (amt * -1) : amt;
        }
        this.setFormArrayCTRLDefaultValue('Amount', index, actualamt);
      }
    });
  }

  /* add receipt in review screen */
  addReceipt(item?, len?, newAdded?) {
    const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    const CurrentAmount = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('Amount').value;
    if (newAdded) {
      if (CurrentAmount != null && CurrentAmount != 0 && CurrentAmount != undefined) {
        const newRow = this.createDetailsArrayGroup();
        newRow.patchValue(item);
        control.push(newRow);
        // this.setFormArrayCTRLDefaultValue('GLCode', len, sessionStorage.getItem(RSAConstants.defaultGLCode));
        // this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, sessionStorage.getItem(RSAConstants.defaultGLCodeDesc));
        newRow.patchValue({ 'newAddedRow': true });
        this.setFormArrayCTRLDefaultValue('CostCenterCode', len, sessionStorage.getItem('costcentre'));
        this.setFormArrayCTRLDefaultValue('GLCode', len, '');
        this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '');
        this.setFormArrayCTRLDefaultValue('TotallingAccCode', len, '');
        // super.getTotallingDetailData({ index: len, flag: true, isOndemand: true });
        // super.getTotallingDetailData({ index: len, flag: false });
        // this.setFormArrayCTRLDefaultValue('TotallingAccCode', len, this.cachedDtlTot[0].Code);
        // this.dtltotallingacc[len] = this.cachedDtlTot;
        this.setOndemandTotallingDetail({ index: len });
        this.glaccount[len] = [];
      } else {
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
        return false;
      }
    }
  }

  reSetForm(params) {
    const param = params.defaultParam;
    /*set default value here and reset */
    if (param == 1) {
      super.validateAllFormFields(this.mainVoucherForm);
      this.mainVoucherForm.controls.VoucherDate.setValue([new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]);
      this.mainVoucherForm.controls.GLCode.setValue(sessionStorage.getItem(RSAConstants.defaultGLCode));
      this.mainVoucherForm.controls.GLCodeDesc.setValue(sessionStorage.getItem(RSAConstants.defaultGLCodeDesc));
      this.clearerrors();
    } else if (param == 2) {
      this.mainVoucherForm.controls['VoucherDetails'].reset();
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('LocationCode').setValue([sessionStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([sessionStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(sessionStorage.getItem(RSAConstants.totallingaccount));
        item.get('GLCode').setValue(sessionStorage.getItem(RSAConstants.defaultGLCode));
        item.get('GLCodeDesc').setValue(sessionStorage.getItem(RSAConstants.defaultGLCodeDesc));
      });
      this.getActualAmountSum('DN');
    }
    super.GetAccountingDates(this.dnEditData.VoucherDate);
  }
  updateDebitVoucherValues(dataReturn: any) {
    this.mainVoucherForm.addControl('DebitNoteNo', new FormControl(dataReturn.DebitNoteNo));
  }
  /* update  form values to create-receipt objects*/
  createCNFormValues() {
    this.createDebitNotes = new CreateDebitNotes();
    const mainFormFieldArray = ['VoucherDate', 'ApprovedBy', 'ArabicDescription',
      'CountryCode', 'CustomerID', 'CustCode', 'ModifiedDate', 'ModifiedBy', 'PostedDate',
      'PreparedBy', 'PreparedDate', 'PreprintNo', 'PrintDate', 'RefreshDate', 'RegionCode', 'Title',
      'Approvers'];
    mainFormFieldArray.forEach(item => {
      console.log('this.item****', item);
      this.createDebitNotes[item] = this.mainVoucherForm.controls[item].value;

    });
    if (this.mainVoucherForm.controls['DebitNoteNo']) {
      this.prevPreviewID = this.mainVoucherForm.controls['DebitNoteNo'].value;
    }

    this.createDebitNotes.LocationCode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    this.createDebitNotes.CostCenterCode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    this.createDebitNotes.TotallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    this.createDebitNotes.GLCode = this.mainVoucherForm.controls.accountInfo['controls'].GLCode.value;

    this.createDebitNotes.PayeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
    this.createDebitNotes.EnglishDescription = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
    this.createDebitNotes.DebitNoteDetail = this.mainVoucherForm.controls['VoucherDetails'].value;
    this.createDebitNotes.TaxPointDate = this.mainVoucherForm.controls['TaxPointDate'].value;
    console.log('this.createCreditNotes****', this.createDebitNotes);
    this.createDebitNotes.DebitNoteDetail.forEach(row => {
      row.ModifiedBy = null;
    });

  }

  /* create-receipt form*/
  submitForm() {
    super.validateDetailInfo();
    this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;
    this.errorReportHeader = this.cshreportHeaders.invalid;

    if (!(!this.errorpayee && !this.errordetail && !this.errorglCode)) {
      return false;
    }
    this.updateDetailsAmount('DN');
    //zero amount warning


    if (this.amountZeroCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTZEROCHECK);
      return false;
    }
    if (this.glerrorcount > 0) {
      return false;
    }
    if (this.submitError > 0) {
      this.alertService.warn(RSAMSGConstants.REQFIELDERROR);
      return false;
    }
    // this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
    //   this.approverusers.length > 0);
    if (this.totalAmount < 0) {
      // if (!(sessionStorage.getItem('country') == '3')) {
      //   if (this.totalAmount > 99999 && !this.usersReq) {
      //     return false;
      //   }
      // }
      this.createCNFormValues();
      console.log(this.createDebitNotes, ' this.createCreditNotes');
      if (this.prevPreviewID == null || this.prevPreviewID == undefined) {
        this.prevPreviewID = 0;
        this.createDebitNotes['DebitNoteNo'] = this.prevPreviewID;
      }
      this.createDebitNotes['DebitNoteNo'] = this.debitnoteEditData.DebitNoteNo;
      if (this.isUAE && this.customOnDemandFlag) {
        if (this.mainVoucherForm.controls['Title'].value === null || this.mainVoucherForm.controls['Title'].value === '' || this.mainVoucherForm.controls['Title'].value === undefined) {
          return false;
        }
      }
      this.createPaymentService.createDebitNote(JSON.stringify(this.createDebitNotes)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.updateDebitVoucherValues(dataReturn);
          this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = true;
          this.previewFlag = true;
          // tslint:disable-next-line:max-line-length
          this.bsModalRef = this.modalService.show(TaxinvoicepreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
          this.bsModalRef.content.backdrop = true;
          this.bsModalRef.content.unApproved = this.unApproved;
          this.bsModalRef.content.dndraftflag = true;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
    if (this.totalAmount >= 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTTEXTREQ);
    }
  }


  getGlAccountHeader() {
    const param = 'totAccCode=' + this.debitnoteEditData.TotallingAccCode +
      '&ccCode=' + this.debitnoteEditData.CostCenterCode;
    this.masterDataService.getDetailGlAccount(param).subscribe(data => {
      this.glAcountHeader = data;
      console.log('gldata', data);
      // tslint:disable-next-line:max-line-length
      const isGLCodeAvailable = data.filter(item => item.Code == this.debitnoteEditData.GLCode);
      if (isGLCodeAvailable.length <= 0) {
        this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(data[0].Code);
      }
    });
  }

  setGLHdrHiddenValue(ev) {
    console.log(ev);
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue(ev.item.Code);
  }
  clearHdrGLCode(ev) {
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue('');
    this.mainVoucherForm.controls.detailInfo['controls'].GLCodeDesc.setValue('');
  }
  changeTaxPointDate() {
    if (this.mainVoucherForm.controls['TaxPointDate'].value) {
      const TaxPointDate = new Date(this.mainVoucherForm.controls['TaxPointDate'].value);
      this.mainVoucherForm.controls['TaxPointDate'].setValue(new DatePipe('en-US').transform(TaxPointDate, 'dd/MM/yyyy'));
    }
  }
  checkonDemandOrOnAccount(editData: any) {
    let onDemandorOnAccount: boolean = true;
    if (editData && editData.length > 0) {
      editData.forEach(element => {
        if (element.ClaimID !== null && element.PolicyID !== null) {
          onDemandorOnAccount = false;
        }
      });
    }
    return onDemandorOnAccount;
  }
}

