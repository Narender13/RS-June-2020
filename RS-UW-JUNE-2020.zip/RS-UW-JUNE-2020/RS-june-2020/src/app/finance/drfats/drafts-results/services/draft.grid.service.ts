import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common';
import { DraftEditViewButtonComponent } from 'src/app/finance/drfats/drafts-results/draft-edit-view-button/draft-edit-view-button.component';
import { filterByDateSlash, dateComparator } from 'src/app/shared/utilites/helper';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';


@Injectable({
    providedIn: 'root'
})
export class DrfatAgridService {
    constructor(public datepipe: DatePipe, private valueFormater: UtilityClass) { }
    get sortOrderForTransactionDate(): any[] {
        return ['asc', 'desc'];
    }
    getEntityColumnHeaderPropertyNames(vvname) {
        if (vvname == 'Receipts') {
            return [
                {
                    headerName: 'Receipt No',
                    field: 'ReceiptNo',
                    type: 'numberColumn',
                    filter: 'agTextColumnFilter',
                    filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                    headerTooltip: 'Receipt No',
                },
                {
                    headerName: 'Description',
                    field: 'EnglishDescription',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Description',
                },
                {
                    headerName: 'Transaction Date (dd/mm/yyyy)',
                    field: 'TransactionDate',
                    filter: 'agDateColumnFilter',
                    //valueFormatter: this.valueFormater.dateValueFormator(),
                    sortingOrder: this.sortOrderForTransactionDate,
                    comparator: dateComparator,
                    filterParams: {
                        comparator: filterByDateSlash()
                    },
                    headerTooltip: 'Transaction Date',

                },
                {
                    headerName: 'Status',
                    field: 'Status',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Status',
                },
                {
                    headerName: 'Prepared By',
                    field: 'PreparedByName',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Prepared By',
                },
                {
                    headerName: 'Amount',
                    type: 'numericColumn',
                    field: 'Amount',
                    filter: 'agTextColumnFilter',
                    cellStyle: { 'text-align': 'right' },
                    headerTooltip: 'Amount',
                    valueFormatter: this.valueFormater.amountFormator(),
                },
                {
                    headerName: 'Action',
                    field: 'value',
                    cellRendererFramework: DraftEditViewButtonComponent,
                    cellRendererParams: {
                        inActoionLink: 'Receipts'
                    },
                    colId: 'params',
                    filter: 'none',
                    headerClass: 'hidefilter'
                }
            ];

        }

        if (vvname == 'Tax Invoice') {
            return [
                {
                    headerName: RSAConstants.TaxInvoiceTitle+' No',
                    field: 'DebitNoteNo',
                    type: 'numberColumn',
                    filter: 'agTextColumnFilter',
                    filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                    headerTooltip: 'Debit No',
                },
                {
                    headerName: 'Description',
                    field: 'EnglishDescription',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Description',
                },
                {
                    headerName: 'Transaction Date (dd/mm/yyyy)',
                    field: 'DebitNoteDate',
                    filter: 'agDateColumnFilter',
                    //valueFormatter: this.valueFormater.dateValueFormator(),
                    sortingOrder: this.sortOrderForTransactionDate,
                    comparator: dateComparator,
                    filterParams: {
                        comparator: filterByDateSlash()
                    },
                    headerTooltip: 'Transaction Date',

                },
                {
                    headerName: 'Status',
                    field: 'Status',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Status',
                },
                {
                    headerName: 'Prepared By',
                    field: 'PreparedByStr',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Prepared By',
                },
                {
                    headerName: 'Amount',
                    type: 'numericColumn',
                    field: 'Amount',
                    filter: 'agTextColumnFilter',
                    cellStyle: { 'text-align': 'right' },
                    headerTooltip: 'Amount',
                    valueFormatter: this.valueFormater.amountFormator(),
                },
                {
                    headerName: 'Action',
                    field: 'value',
                    cellRendererFramework: DraftEditViewButtonComponent,
                    cellRendererParams: {
                        inActoionLink: 'Tax Invoice'
                    },
                    colId: 'params',
                    filter: 'none',
                    headerClass: 'hidefilter'
                }
            ];

        }

        if (vvname == 'Credit Note') {
            return [
                {
                    headerName: 'Credit Note No',
                    field: 'CreditNoteNo',
                    type: 'numberColumn',
                    filter: 'agTextColumnFilter',
                    filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                    headerTooltip: 'Credit Note No',
                },
                {
                    headerName: 'Description',
                    field: 'EnglishDescription',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Description',
                },
                {
                    headerName: 'Transaction Date (dd/mm/yyyy)',
                    field: 'CreditNoteDate',
                    filter: 'agDateColumnFilter',
                    //valueFormatter: this.valueFormater.dateValueFormator(),
                    sortingOrder: this.sortOrderForTransactionDate,
                    comparator: dateComparator,
                    filterParams: {
                        comparator: filterByDateSlash()
                    },
                    headerTooltip: 'Transaction Date',

                },
                {
                    headerName: 'Status',
                    field: 'Status',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Status',
                },
                {
                    headerName: 'Prepared By',
                    field: 'PreparedByname',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Prepared By',
                },
                {
                    headerName: 'Amount',
                    type: 'numericColumn',
                    field: 'Amount',
                    filter: 'agTextColumnFilter',
                    cellStyle: { 'text-align': 'right' },
                    headerTooltip: 'Amount',
                    valueFormatter: this.valueFormater.amountFormator(),
                },
                {
                    headerName: 'Action',
                    field: 'value',
                    cellRendererFramework: DraftEditViewButtonComponent,
                    cellRendererParams: {
                        inActoionLink: 'Credit Note'
                    },
                    colId: 'params',
                    filter: 'none',
                    headerClass: 'hidefilter'
                }
            ];

        }

        if (vvname == 'Payments' || vvname == 'Claim Payments') {
            return [
                {
                    headerName: 'Payment No',
                    field: 'PaymentNo',
                    type: 'numberColumn',
                    filter: 'agTextColumnFilter',
                    filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                    headerTooltip: 'Payment No',
                },
                {
                    headerName: 'Description',
                    field: 'EnglishDescription',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Description',
                },
                {
                    headerName: 'Transaction Date (dd/mm/yyyy)',
                    field: 'TransactionDate',
                    filter: 'agDateColumnFilter',
                    //valueFormatter: this.valueFormater.dateValueFormator(),
                    sortingOrder: this.sortOrderForTransactionDate,
                    comparator: dateComparator,
                    filterParams: {
                        comparator: filterByDateSlash()
                    },
                    headerTooltip: 'Transaction Date',

                },
                {
                    headerName: 'Status',
                    field: 'Status',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Status',
                },
                {
                    headerName: 'Prepared By',
                    field: 'PreparedByName',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Prepared By',
                },
                {
                    headerName: 'Amount',
                    type: 'numericColumn',
                    field: 'Amount',
                    filter: 'agTextColumnFilter',
                    cellStyle: { 'text-align': 'right' },
                    headerTooltip: 'Amount',
                    valueFormatter: this.valueFormater.amountFormator(),
                },
                {
                    headerName: 'Action',
                    field: 'value',
                    cellRendererFramework: DraftEditViewButtonComponent,
                    cellRendererParams: {
                        // inActoionLink: 'Claim Payments'
                        inActoionLink: vvname === 'Claim Payments' ? 'Claim Payments' : 'Payments'
                    },
                    colId: 'params',
                    filter: 'none',
                    headerClass: 'hidefilter'
                }
            ];

        }

        if (vvname == 'JV') {
            return [
                {
                    headerName: 'JV No',
                    field: 'VoucherNo',
                    type: 'numberColumn',
                    filter: 'agTextColumnFilter',
                    filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                    headerTooltip: 'JV No',
                },
                {
                    headerName: 'Description',
                    field: 'Description',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Description',
                },
                {
                    headerName: 'Transaction Date (dd/mm/yyyy)',
                    field: 'TransactionDate',
                    filter: 'agDateColumnFilter',
                    //valueFormatter: this.valueFormater.dateValueFormator(),
                    sortingOrder: this.sortOrderForTransactionDate,
                    comparator: dateComparator,
                    filterParams: {
                        comparator: filterByDateSlash()
                    },
                    headerTooltip: 'Transaction Date',

                },
                {
                    headerName: 'Status',
                    field: 'Status',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Status',
                },
                {
                    headerName: 'Prepared By',
                    field: 'PreparedByName',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Prepared By',
                },
                {
                    headerName: 'Debit',
                    type: 'numericColumn',
                    field: 'AmountDebit',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Debit',
                    valueFormatter: this.valueFormater.amountFormator(),
                },
                {
                    headerName: 'Credit',
                    type: 'numericColumn',
                    field: 'AmountCredit',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Credit',
                    valueFormatter: this.valueFormater.amountFormator(),
                },
                {
                    headerName: 'Action',
                    field: 'value',
                    cellRendererFramework: DraftEditViewButtonComponent,
                    cellRendererParams: {
                        inActoionLink: 'JV'
                    },
                    colId: 'params',
                    filter: 'none',
                    headerClass: 'hidefilter'
                }
            ];

        }

    }//fun name


}
