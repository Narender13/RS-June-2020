import { Component, OnInit, OnDestroy, Input, ViewChild } from '@angular/core';
import { SharedService } from 'src/app/finance/services/shared.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators, ControlContainer } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreatePayment } from 'src/app/finance/search/model/create-payment';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { CreatePaymentService } from 'src/app/finance/payments/create-payment/service/create-payment.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { PaymentpreviewComponent } from 'src/app/finance/preview/uae/paymentpreview/paymentpreview.component';
import { BatchUploadService } from 'src/app/finance/search/service/batch-upload.service';
import { ExcelService } from 'src/app/finance/search/service/excel.service';
import { AddNewTransactionComponent } from 'src/app/shared/add-new-transaction/add-new-transaction.component';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';

@Component({
    selector: 'rsa-create-draft-payment',
    templateUrl: './create-draft-payment.component.html',
    styleUrls: ['./create-draft-payment.component.scss']
})
export class CreateDraftPaymentComponent extends BasevoucherComponent implements OnInit, OnDestroy {
    @Input() claimPayment: boolean;
    title: string;
    currency = sessionStorage.getItem(RSAConstants.currency);
    errorpayee: boolean;
    errordetail: boolean;
    /* form error-feilds */
    errorbankcodeCheque: boolean;
    errorChequeTypeCheque: boolean;
    errorChequeTypeBankT: boolean;
    errorbankcodeBanktransfer: boolean;
    errorpaayeebanknameCheque: boolean;
    errorpaayeebanknameBanktransfer: boolean;
    errorchequedateCheque: boolean;
    errorchequedateBankT: boolean;
    errorchequedateCreditCard: boolean;
    errorchequenoCheque: boolean;
    errorchequenoCreditCard: boolean;
    errorterminalID: boolean;
    errorexpirydate: boolean;
    errorBeneficiaryBankBankT: boolean;
    errorBeneficiaryBankCurrencyBankBankT: boolean;
    errorBeneficiaryAccNoBankBankT: boolean;
    errorBeneficiarySwiftCodeBankBankT: boolean;
    errorBeneficiarySortCodeBankBankT: boolean;
    errorIBANBankBankT: boolean;
    errorCorrespondentBankBankBankT: boolean;
    errorBothfieldsDataBankT: boolean;
    errorCorrespondentAccNoBankBankT: boolean;
    errorCorrespondentBankSwiftCodeBankBankT: boolean;
    errorCorrespondentBankSortCodeBankBankT: boolean;
    matchedRecords = [];
    isUploadUnmatched;
    returnValue: any;
    usersReq;
    symbol;
    createPayment: CreatePayment;
    animatedClass = true;
    isBatch = false;
    selectedRowEntitiDataTable: any = [];
    ondemandFlag = false;
    prevPayment: any;
    paymentEditData: any;
    isPaymentEdit: true;
    prevPreviewID: any;
    paymentBulkForm: FormGroup;
    fileUploadForm: FormGroup;
    ifUploadSuccess = true;
    matchedDetails: any = [];
    bulkuploadData: any;
    totalMatchedAmount: any;
    editPaymentFromPrevious = false;
    totalIntialAmount = new FormControl('');
    headerDescription: string = "";
    @ViewChild('tabset') tabset: TabsetComponent;
    toggleValueCredit = [];
    isStateClosed: boolean = false;
    unApproved: any;
    constructor(protected sharedService: SharedService,
        private fb: FormBuilder,
        protected modalService: BsModalService,
        protected bsModalRef: BsModalRef,
        protected masterDataService: MasterDataService,
        protected utilityClass: UtilityClass,
        protected createPaymentService: CreatePaymentService,
        private alertService: AlertService,
        private batchUploadService: BatchUploadService,
        private excelService: ExcelService) {
        super(masterDataService, sharedService, modalService, utilityClass, bsModalRef);
        //super.setMinMaxDate();
    }

    ngOnInit() {
        /* super with method is calling from BasevoucherComponent */
        console.log('paymentEditData', this.paymentEditData);
        console.log('unApproved->', this.unApproved);
        this.title = this.claimPayment ? 'Claim Payment' : 'Payment';
        // this.setHeaderData();
        this.getPaymentData();

        super.getAllBranchData();
        super.getAllCostCenterData({ ev: null, index: 0, flag: true });
        super.getAllTotallingData(true);
        super.getAllgetLookupBanksData();
        super.getAllPayeeBankData(true);
        super.getAllDeptData();
        super.getAllProjData();
        // super.getEntityDefaultData();
        super.getAllMasterData2();
        super.getAllBankCurrency();
        this.fieldStatusChanges();
        super.getBankData(true);
        super.getModelPreviousClose();
        super.closeModel();
        super.getAllTranData();
        super.getAllInstrumentTypes();
        this.symbol = (sessionStorage.getItem('symbol'));
        //super.setMinMaxDate();

        this.getDetailsArrayFormGroup();
        super.getSettlementTypeData();
        this.patchValueFromDrft();
        this.getModelFromPrevious();
        super.GetAccountingDates(this.paymentEditData.VoucherDate);
        this.fileUploadForm = this.fb.group({
            fileContent: [],
        });
        this.headerDescription = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
        if (this.headerDescription != null && this.headerDescription != undefined && this.headerDescription != '') {
            this.setHeaderDescription(this.headerDescription);
        }
        this.sharedService.getMessage().subscribe(val => {
            if (val == 'close') {
                this.isStateClosed = true;
                this.mainVoucherForm.markAsPristine();
                this.mainVoucherForm.markAsUntouched();
            }
        });

    }
    ngOnDestroy() {
        if (!this.isStateClosed) {
            this.addRowsToSession();
        }
    }
    getPreviousRows() {
        let SnackbarAdded = sessionStorage.getItem('SnackbarAdded');
        if (SnackbarAdded == 'true') {
            let voucherDetail = JSON.parse(sessionStorage.getItem('VoucherDetail'));
            if (this.paymentEditData.VoucherNo == voucherDetail.VoucherNo) {
                this.paymentEditData.PmtDetails = voucherDetail.SelectedRows;
                this.selectedRowEntitiDataTable = voucherDetail.SelectedRows;
            }
            else {
                this.selectedRowEntitiDataTable = this.paymentEditData.PmtDetails;
            }
        }
        else {
            this.selectedRowEntitiDataTable = this.paymentEditData.PmtDetails;
        }
    }
    addRowsToSession() {
        this.selectedRowEntitiDataTable.forEach(row => {
            row.isFromDraft = 'true';
        });
        if (this.selectedRowEntitiDataTable.length > 0) {
            sessionStorage.setItem('SnackbarAdded', 'true');
            sessionStorage.setItem('isFromDraft', 'true');
            let vType = '';
            if (this.claimPayment == true) {
                vType = 'ClaimPayment'
            } else {
                vType = 'Payment'
            }
            let voucherDetail = { SelectedRows: this.selectedRowEntitiDataTable, voucherType: vType, VoucherNo: this.paymentEditData.VoucherNo };
            sessionStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
            let totallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
            let recevierBankCode = this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.value;
            let description = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
            let payeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
            var commonData = {
                CurrentTabIndex: this.currentTbIndex, TotallingAccCode: totallingAccCode, RecevierBankCode: recevierBankCode,
                Description: description, PayeeName: payeeName, PrevReceipt: this.paymentEditData.VoucherNo, PreviewData: this.previewDataDtl
            }
            sessionStorage.setItem('CommonPaymentData', JSON.stringify(commonData));
            let contentData = this.getContentData();
            sessionStorage.setItem('PaymentContentData', JSON.stringify(contentData));
            sessionStorage.setItem('PaymentStateExists', 'true');
            this.updateRows();
            this.sharedService.sendMessage('PaymentSnackbarAdded');
        }
    }
    updateRows() {
        let formarray = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
        if (formarray.controls.length > 0) {
            let voucherDetail = JSON.parse(sessionStorage.getItem('VoucherDetail'));
            voucherDetail.SelectedRows = [];
            formarray.controls.forEach(ctrl => {
                let rowClone = Object.assign({}, ctrl.value);
                rowClone.Amount = (rowClone.Amount) ? rowClone.Amount : 0;
                rowClone.Amount = parseInt(rowClone.Amount);
                // rowClone.Amount=-(rowClone.Amount);
                rowClone.Department = rowClone.DepartmentCode;
                //rowClone.DepartmentCode=rowClone.Department;
                rowClone.ConcDescription = rowClone.Description;
                rowClone.isFromDraft = 'true';
                // rowClone.BranchName=rowClone.BranchCode+' - '+rowClone.LocationDesc;
                voucherDetail.SelectedRows.push(rowClone)
            });
            sessionStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
        }
    }
    getFormCtrlValue(contrlName) {
        return this.mainVoucherForm.controls[contrlName].value;
    }
    getContentData() {
        var contentData: any;
        if (this.currentTbIndex == 0) {
            let chequeDate = this.mainVoucherForm.controls.chequeInfo['controls'].ChequeDate.value;
            let chequeNo = this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.value;
            let chequeType = this.mainVoucherForm.controls.chequeInfo['controls'].ChequeType.value;
            contentData = { ChequeDate: chequeDate, ChequeNo: chequeNo, ChequeType: chequeType }
        }
        if (this.currentTbIndex == 2) {
            let beneficiaryBank = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBank.value;
            //let payeeBankCode = this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankCode.value;
            let beneficiaryBankCurrency = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBankCurrency.value;
            let beneficiaryAccNo = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryAccNo.value;
            let beneficiarySwiftCode = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySwiftCode.value;
            let beneficiarySortCode = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySortCode.value;
            let correspondentBank = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBank.value;
            let iban = this.mainVoucherForm.controls.bankTransfer['controls'].IBAN.value;
            let CorrespondentAccNo = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentAccNo.value;
            let correspondentBankSwiftCode = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSwiftCode.value;
            let correspondentBankSortCode = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSortCode.value;
            let payeeBankName = this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankName.value;
            let chequeType = this.mainVoucherForm.controls.bankTransfer['controls'].ChequeType.value;
            let chequeDate = this.mainVoucherForm.controls.bankTransfer['controls'].ChequeDate.value;
            let instrumentRefNo = this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo.value;

            contentData = {
                BeneficiaryBank: beneficiaryBank, BeneficiaryBankCurrency: beneficiaryBankCurrency, BeneficiaryAccNo: beneficiaryAccNo,
                BeneficiarySwiftCode: beneficiarySwiftCode, BeneficiarySortCode: beneficiarySortCode, CorrespondentBank: correspondentBank, IBAN: iban,
                CorrespondentAccNo: CorrespondentAccNo, CorrespondentBankSwiftCode: correspondentBankSwiftCode, CorrespondentBankSortCode: correspondentBankSortCode,
                PayeeBankName: payeeBankName, ChequeType: chequeType, ChequeDate: chequeDate, InstrumentRefNo: instrumentRefNo
            }
        }
        return contentData;
    }
    getDateClrlValue(contrlName: string) {
        if (this.mainVoucherForm.controls[contrlName].dirty || this.mainVoucherForm.controls[contrlName].touched) {
            return this.mainVoucherForm.controls[contrlName].value;
        }
        else {
            return null;
        }
    }
    getModelFromPrevious() {
        this.sharedService.getMessage().subscribe(val => {
            if (val == 'previous' || val.id) {
                this.editPaymentFromPrevious = true;
            }
        });
    }

    patchValueFromDrft() {
        console.log('paymentEditData', this.paymentEditData);
        const paymentMode = this.paymentEditData.PaymentMode;
        console.log(paymentMode, 'paymentMode');
        this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.setValue(this.paymentEditData.Name);
        if (paymentMode == 2) {
            this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(this.paymentEditData.E_Desc);
            this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.setValue(this.paymentEditData.ChequeNo);
            this.mainVoucherForm.controls.chequeInfo['controls'].ChequeDate.setValue(this.paymentEditData.ChequeDate);
            this.mainVoucherForm.controls.chequeInfo['controls'].ChequeType.setValue(this.paymentEditData.ChequeType);
            this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankCode.setValue(this.paymentEditData.PayeeBankCode);
            //this.mainVoucherForm.controls.chequeInfo['controls'].ChequeDate.setValue(this.paymentEditData.ChequeDate);
        }
        if (paymentMode == 1) {
            this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(this.paymentEditData.E_Desc);

        }
        if (paymentMode == 5) {
            this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(this.paymentEditData.E_Desc);
            // this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo.setValue(this.paymentEditData.E_Desc);
            // this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankName.setValue(this.paymentEditData.E_Desc);
            this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBank.setValue(this.paymentEditData.BeneficiaryBank);
            this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBankCurrency.setValue(this.paymentEditData.BeneficiaryBankCurrency);
            this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryAccNo.setValue(this.paymentEditData.BeneficiaryAccNo);
            this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySwiftCode.setValue(this.paymentEditData.BeneficiarySwiftCode);
            this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySortCode.setValue(this.paymentEditData.BeneficiarySortCode);
            this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBank.setValue(this.paymentEditData.CorrespondentBank);
            this.mainVoucherForm.controls.bankTransfer['controls'].ChequeType.setValue(this.paymentEditData.ChequeType);
            this.mainVoucherForm.controls.bankTransfer['controls'].IBAN.setValue(this.paymentEditData.IBAN);
            this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentAccNo.setValue(this.paymentEditData.CorrespondentAccNo);
            this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSwiftCode.setValue(this.paymentEditData.CorrespondentBankSwiftCode);
            this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSortCode.setValue(this.paymentEditData.CorrespondentBankSortCode);
            this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo.setValue(this.paymentEditData.ChequeNo);
            //this.mainVoucherForm.controls.bankTransfer['controls'].ChequeDate.setValue(new DatePipe('en-US').transform(new Date(this.paymentEditData.ChequeDate), 'dd/MM/yyyy'));
        }
    }


    getPaymentData() {
        console.log('paymentEditData', this.paymentEditData);
        console.log('^^^^^^^^^^', this.paymentEditData);
        this.paymentMode = this.paymentEditData.PaymentMode;
        this.prevPreviewID = this.paymentEditData.VoucherNo;
        // this.prevPayment = this.paymentEditData.ReceiptNo;
        const currentIndex = {
            '2': 0,
            '1': 1,
            '5': 2,
        };

        console.log('this.receiptEditData:' + this.paymentEditData);
        const selectedTab = currentIndex[this.paymentMode];

        console.log(selectedTab, 'setectedtab');
        if (this.paymentMode) {
            // this.tabset.tabs[selectedTab].active = true;
            this.createPaymentForm(this.paymentMode);
            // this.getAllMasterData(1110);
            // this.getAllMasterData2();
            //this.getTotallingData(sessionStorage.getItem('costcentre'));
            // this.getBankData(true);
            this.symbol = (sessionStorage.getItem('symbol'));
            //console.log(this.receiptEditData, 'this.receiptEditData');
            // this.getModalFromPrevious();
            // this.fieldStatusChanges();
            // this.getPayeeBankData(true);
            this.getAllInstrumentTypes();
            this.paymentname = this.paymentEditData.PaymentModeDesc;
            this.totalAmount = this.paymentEditData.TotalAmount;
            console.log(this.totalAmount, 'totalAmount3244324');
            // this.patchValueFromDrft();
            console.log(this.paymentEditData.ReceiptMode, 'receiptEditData');

        }
        this.tabset.tabs[selectedTab].active = true;
        this.getPreviousRows();
    }

    // setHeaderData() {
    //       // this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.setValue(this.paymentEditData.PayeeName);
    //   this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(this.paymentEditData.E_Desc);
    // }

    /* create entiti form */
    createPaymentForm(param): void {
        this.mainVoucherForm = null;
        //let tranDate = sessionStorage.getItem('tranAccntMnthStrtDate') ? new Date(sessionStorage.getItem('tranAccntMnthStrtDate')) : new Date();
        this.mainVoucherForm = this.fb.group({
            VoucherDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
            Amount: [''],
            PaymentMode: [this.paymentMode],
            PrintDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
            ReceiptType: [0],
            PreparedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
            ApprovedBy: [],
            ModifiedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
            Approvers: this.fb.array([]),
            CustomerID: [],
            CustCode: [],
            TerminalID: [],
            TerminalUserID: [20],
            TerminalUserName: [],
            CountryCode: [sessionStorage.getItem(RSAConstants.countrycode)],
            RegionCode: [sessionStorage.getItem(RSAConstants.regionCode)],
            ReprintNo: [],
            ArabicDescription: [],
            ChequeDateFld: [],
            VendorCode: [],
            chequeInfo: this.fb.group({
                ChequeNo: [''],
                ChequeDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required],
                ChequeType: ['', Validators.required],
                PayeeBankCode: [''],
                PayeeBankName: [''],
            }),
            bankTransfer: this.fb.group({
                InstrumentRefNo: [''],
                ChequeDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required],
                // PayeeBankCode: [, Validators.required],
                PayeeBankName: [''],
                BeneficiaryBank: ['', Validators.required],
                BeneficiaryBankCurrency: ['', Validators.required],
                BeneficiaryAccNo: [''],
                BeneficiarySwiftCode: ['', Validators.required],
                BeneficiarySortCode: [''],
                CorrespondentBank: [],
                ChequeType: ['', Validators.required],
                IBAN: [''],
                CorrespondentAccNo: [''],
                CorrespondentBankSwiftCode: [''],
                CorrespondentBankSortCode: [''],
            }),
            detailInfo: this.fb.group({
                PayeeName: ['', Validators.required],
                EnglishDescription: [this.paymentEditData.E_Desc],
            }),
            accountInfo: this.fb.group({
                LocationCode: [this.paymentEditData.LocationCode],
                CostCenterCode: [this.paymentEditData.CostCenterCode],
                TotallingAccCode: [this.paymentEditData.TotallingAccCode],
                RecevierBankCode: [this.paymentEditData.RecevierBankCode],
            }),
            VoucherDetails: this.fb.array([])
        });
    }


    /* form array for recept details */
    createPaymentArrayGroup(): FormGroup {
        return this.fb.group({
            CounterPartyRef: [],
            LocationCode: [sessionStorage.getItem('locationcode')],
            BranchCode: [sessionStorage.getItem('locationcode')],
            LocationDesc: [sessionStorage.getItem(RSAConstants.locationdesc)],
            CountryCode: [sessionStorage.getItem(RSAConstants.countrycode)],
            CostCenterCode: [sessionStorage.getItem('costcentre')],
            Description: [],
            Amount: ['', Validators.required],
            SettlementType: ['', Validators.required],
            RefTransactionID: [],
            RefTransactionType: [this.claimPayment ? 4 : 5],
            IsDebitEntry: [true],
            PolicyID: [],
            // PolicyNumber: [],
            ModifiedBy: [sessionStorage.getItem(RSAConstants.LoggedInUserId)],
            SerialNo: [],
            SrNO: [],
            ReceiptDate: [],
            AnalysisCode: [],
            DepartmentCode: [],
            Department: [],
            RefTransactionSerialNo: [],
            GLCode: [sessionStorage.getItem(RSAConstants.defaultGLCode), Validators.required],
            GLCodeDesc: [sessionStorage.getItem(RSAConstants.defaultGLCodeDesc), Validators.required],
            RegionCode: [sessionStorage.getItem(RSAConstants.regionCode)],
            TotallingAccCode: [sessionStorage.getItem(RSAConstants.totallingaccount), Validators.required],
            // PolicyYear: [],
            // PolicyType: [],
            Endt_ID: [],
            PlaceHolderCode: [],
            GLAccountName: [],
            CostCenterName: [],
            TotallingAccName: [],
            BranchName: [],
            GLAccount: [],
            ClassCode: [],
            ClaimID: [],
            VoucherType: [],
            TransactionNo: [],
            RefTranType: [],
            VoucherNo: [],
            ClaimNumber: [],
            ClaimYear: [],
            CauseOfLoss: [],
            NatureOfLoss: [],
            CauseOfLossDesc: [],
            NatureOfLossDesc: [],
            // Aaded new formControlName to make row readonly if coming from selection rows
            newAddedRow: false
        });
    }


    getDetailsArrayFormGroup() {
        const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
        if (!this.ondemandFlag && !this.editPaymentFromPrevious) {
            this.mainVoucherForm.controls['CustomerID'].setValue(this.paymentEditData.CustomerID);
            this.mainVoucherForm.controls['CustCode'].setValue(this.paymentEditData.CustCode ? this.paymentEditData.CustCode : 0);
            this.paymentEditData.PmtDetails.map((item, index) => {
                super.getAllCostCenterData({ ev: null, index: index, flag: true });
                const group = this.createPaymentArrayGroup();
                //item.SerialNo=0;//fixed for draft edit
                // this.populateDropdownValues(index);
                console.log(item);
                item['IsDebitEntry'] = (item.Amount < 0) ? false : true;
                group.patchValue(item);
                group.get('newAddedRow').setValue(false);
                group.get('IsDebitEntry').setValue((parseFloat(group.get("Amount").value) < 0) ? false : true);
                control.push(group);
                const ctrl = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
                ctrl.controls.forEach((val, i) => {
                    const amount = val.get('Amount').value;
                    this.toggleValueCredit[i] = amount < 0 ? false : true;
                });
                console.log(this.toggleValueCredit, 'this.toggleValueCredit');
            });
        } else {
            control.push(this.createPaymentArrayGroup());
        }
    }
    // populateDropdownValues(index) {
    //     console.log('index', index);
    //     const branchcode = this.paymentEditData.PmtDetails[index].LocationCode;
    //     const costcentre = this.paymentEditData.PmtDetails[index].CostCenterCode;
    //     const totallingcode = this.paymentEditData.PmtDetails[index].TotallingAccCode;
    //     const glcode = this.paymentEditData.PmtDetails[index].GLCode;
    //     const gldesc = this.paymentEditData.PmtDetails[index].GLCodeDesc;
    //     this.setchangeCostcenter(index, branchcode, costcentre, totallingcode, glcode, gldesc);
    // }
    getActualAmountSumPayment() {
        let total = 0;
        let amt = 0;
        let actualamt = 0;
        let flagtoggle = false;
        (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {

            if (this.getFromFormArrayControlVal("Amount", index) != undefined
                && this.getFromFormArrayControlVal("Amount", index) != null) {
                flagtoggle = this.getFromFormArrayControlVal('IsDebitEntry', index);
                amt = parseFloat(this.getFromFormArrayControlVal("Amount", index));
                amt = Math.abs(amt || 0);
                actualamt = (!flagtoggle) ? (amt * -1) : amt;
                total = total + actualamt;
            }

        });
        this.totalAmount = total;
        this.totalAmount = (isNaN(this.totalAmount)) ? 0 : this.totalAmount;
    }
    setCreditEntryClaim(ev) {
        console.log(this.claimPayment, 'this.claimPayment');
        const actualData = Number(ev.data.controls['Amount'].value);
        if (actualData === 0 || actualData === undefined) {
            this.displayAlertModal({
                'title': RSAMSGConstants.MODELTITLE,
                'txt': RSAMSGConstants.AMOUNTVALIDATIONMSG,
                'btnaction': RSAMSGConstants.OKTEXT
            });
            ev.event.target.checked = !ev.event.target.checked;
        }
        this.setFormArrayCTRLDefaultValue(ev.iscredit, ev.index, ev.event.target.checked);
        this.getActualAmountSumPayment();
        if (this.totalAmount < 0 && !this.claimPayment) {
            ev.event.target.checked = true;
            this.setFormArrayCTRLDefaultValue(ev.iscredit, ev.index, true);
            this.displayAlertModal({
                'title': RSAMSGConstants.MODELTITLE,
                'txt': RSAMSGConstants.DEBITEXCEEDMSG,
                'btnaction': RSAMSGConstants.OKTEXT
            });
        }
        this.getActualAmountSumPayment();
    }
    /// update amount before submit
    updateDetailsAmount() {
        let amt = 0;
        let actualamt = 0;
        let flagtoggle = true;
        (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {

            if (this.getFromFormArrayControlVal('Amount', index) != undefined && this.getFromFormArrayControlVal('Amount', index) != null) {
                flagtoggle = this.getFromFormArrayControlVal('IsDebitEntry', index);
                amt = parseFloat(this.getFromFormArrayControlVal('Amount', index));
                amt = Math.abs(amt || 0);
                actualamt = (flagtoggle) ? amt : (amt * -1);
                this.setFormArrayCTRLDefaultValue('Amount', index, actualamt);
            }
        });
    }
    /* set receipt mode and set default values   */
    setReceiptMode(val, paymentname, ev) {
        if (!ev.tabset) { return; } // fix for tab resetting all values on double click
        this.paymentMode = val;
        this.paymentname = paymentname;
        super.GetAccountingDates(this.paymentEditData.VoucherDate);
        // this.receiverdataBankName = this.cachedReceiverBankData;
        this.totallingacc = this.cachedTotAcc;
        this.payeedataBankName = this.cachedPayeeBankData;
        this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.setValue('');
        //  this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue('');
        this.setcurrentTbIndex(paymentname);

        this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(this.paymentEditData.TotallingAccCode);
        this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue(this.paymentEditData.RecevierBankCode);
        this.setHeaderDescription(this.headerDescription);
        // if (!this.editPaymentFromPrevious) {
        //     this.getDetailsArrayFormGroup();
        // }
        this.fieldStatusChanges();

    }
    setHeaderDescription(desc) {
        this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(desc);

    }

    /* using req fields and update status  */
    fieldStatusChanges() {
        this.clearerrors();
        this.cshpayeename.statusChanges.subscribe(
            status => {
                this.errorpayee = (status === 'INVALID');
                console.log(this.errorpayee, 'his.errorpayee');
            }
        );
        this.cshdetails.statusChanges.subscribe(
            status => {
                this.errordetail = (status === 'INVALID');
            }
        );

        /* for cheque */
        if (this.payeebankcodeCheque != null && this.payeebankcodeCheque !== undefined) {
            this.payeebankcodeCheque.statusChanges.subscribe(
                status => {
                    this.errorbankcodeCheque = (status === 'INVALID');
                }
            );
        }
        if (this.chequeTypeCheque != null && this.chequeTypeCheque !== undefined) {
            this.chequeTypeCheque.statusChanges.subscribe(
                status => {
                    this.errorChequeTypeCheque = (status === 'INVALID');
                }
            );
        }

        if (this.chequedateCheque != null && this.chequedateCheque !== undefined) {
            this.chequedateCheque.statusChanges.subscribe(
                status => {
                    this.errorchequedateCheque = (status === 'INVALID');
                }
            );
        }


        if (this.chequeno != null && this.chequeno !== undefined) {
            this.chequeno.statusChanges.subscribe(
                status => {
                    this.errorchequenoCheque = (status === 'INVALID');
                }
            );
        }



        /* for banktransfer */

        // if (this.chequedateBankT != null && this.chequedateBankT !== undefined) {
        //   this.chequedateBankT.statusChanges.subscribe(
        //     status => {
        //       this.errorchequedateBankT = (status === 'INVALID');
        //     }
        //   );
        // }
        if (this.chequeTypeBankT != null && this.chequeTypeBankT !== undefined) {
            this.chequeTypeBankT.statusChanges.subscribe(
                status => {
                    this.errorChequeTypeBankT = (status === 'INVALID');
                }
            );
        }


        // if (this.payeebankcodeBankt != null && this.payeebankcodeBankt !== undefined) {
        //   this.payeebankcodeBankt.statusChanges.subscribe(
        //     status => {
        //       this.errorbankcodeBanktransfer = (status === 'INVALID');
        //     }
        //   );
        // }

        if (this.payeebanknameBankt != null && this.payeebanknameBankt !== undefined) {
            this.payeebanknameBankt.statusChanges.subscribe(
                status => {
                    this.errorpaayeebanknameBanktransfer = (status === 'INVALID');
                }
            );
        }

        if (this.expirydate != null && this.expirydate !== undefined) {
            this.expirydate.statusChanges.subscribe(
                status => {
                    this.errorexpirydate = (status === 'INVALID');
                }
            );
        }

        if (this.beneficiaryBankBankt != null && this.beneficiaryBankBankt !== undefined) {
            this.beneficiaryBankBankt.statusChanges.subscribe(
                status => {
                    this.errorBeneficiaryBankBankT = (status === 'INVALID');
                }
            );
        }

        if (this.beneficiaryBankCurrencyBankt != null && this.beneficiaryBankCurrencyBankt !== undefined) {
            this.beneficiaryBankCurrencyBankt.statusChanges.subscribe(
                status => {
                    this.errorBeneficiaryBankCurrencyBankBankT = (status === 'INVALID');
                }
            );
        }

        if (this.beneficiaryAccNoBankt != null && this.beneficiaryAccNoBankt !== undefined) {
            this.beneficiaryAccNoBankt.statusChanges.subscribe(
                status => {
                    this.errorBeneficiaryAccNoBankBankT = (status === 'INVALID');
                }
            );
        }

        if (this.beneficiarySwiftCodeBankt != null && this.beneficiarySwiftCodeBankt !== undefined) {
            this.beneficiarySwiftCodeBankt.statusChanges.subscribe(
                status => {
                    this.errorBeneficiarySwiftCodeBankBankT = (status === 'INVALID');
                }
            );
        }

        if (this.beneficiarySortCodeBankt != null && this.beneficiarySortCodeBankt !== undefined) {
            this.beneficiarySortCodeBankt.statusChanges.subscribe(
                status => {
                    this.errorBeneficiarySortCodeBankBankT = (status === 'INVALID');
                }
            );
        }

        if (this.correspondentBankBankt != null && this.correspondentBankBankt !== undefined) {
            this.correspondentBankBankt.statusChanges.subscribe(
                status => {
                    this.errorCorrespondentBankBankBankT = (status === 'INVALID');
                }
            );
        }

        if (this.IbanBankt != null && this.IbanBankt !== undefined) {
            this.IbanBankt.statusChanges.subscribe(
                status => {
                    this.errorIBANBankBankT = (status === 'INVALID');
                }
            );
        }

        if (this.correspondentAccNoBankt != null && this.correspondentAccNoBankt !== undefined) {
            this.correspondentAccNoBankt.statusChanges.subscribe(
                status => {
                    this.errorCorrespondentAccNoBankBankT = (status === 'INVALID');
                }
            );
        }

        if (this.correspondentBankSwiftCodeBankt != null && this.correspondentBankSwiftCodeBankt !== undefined) {
            this.correspondentBankSwiftCodeBankt.statusChanges.subscribe(
                status => {
                    this.errorCorrespondentBankSwiftCodeBankBankT = (status === 'INVALID');
                }
            );
        }

        if (this.correspondentBankSortCodeBankt != null && this.correspondentBankSortCodeBankt !== undefined) {
            this.correspondentBankSortCodeBankt.statusChanges.subscribe(
                status => {
                    this.errorCorrespondentBankSortCodeBankBankT = (status === 'INVALID');
                }
            );
        }

    }

    /* clear all errors after reset   */
    clearerrors() {
        this.errorpayee = false;
        this.errordetail = false;
        this.errorbankcodeCheque = false;
        this.errorChequeTypeCheque = false;
        this.errorChequeTypeBankT = false;
        this.errorbankcodeBanktransfer = false;
        this.errorpaayeebanknameCheque = false;
        this.errorpaayeebanknameBanktransfer = false;
        this.errorchequedateCheque = false;
        this.errorchequedateBankT = false;
        this.errorchequedateCreditCard = false;
        this.errorchequenoCheque = false;
        this.errorterminalID = false;
        this.errorexpirydate = false;
        this.errorBeneficiaryBankBankT = false;
        this.errorBeneficiaryBankCurrencyBankBankT = false;
        this.errorBeneficiaryAccNoBankBankT = false;
        this.errorBeneficiarySwiftCodeBankBankT = false;
        this.errorBeneficiarySortCodeBankBankT = false;
        this.errorIBANBankBankT = false;
    }

    /* get the controls of each fields   */
    get cshpayeename() { return this.mainVoucherForm.controls.detailInfo['controls'].PayeeName; }
    get cshdetails() { return this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription; }
    get payeebankcodeCheque() {
        return this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankCode;
    }
    get beneficiaryBankBankt() {
        return this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBank;
    }
    get payeebankcodeBankt() {
        return this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankCode;
    }
    get beneficiaryBankCurrencyBankt() {
        return this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBankCurrency;
    }
    get beneficiaryAccNoBankt() {
        return this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryAccNo;
    }
    get beneficiarySwiftCodeBankt() {
        return this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySwiftCode;
    }
    get beneficiarySortCodeBankt() {
        return this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySortCode;
    }
    get correspondentBankBankt() {
        return this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBank;
    }
    get IbanBankt() {
        return this.mainVoucherForm.controls.bankTransfer['controls'].IBAN;
    }
    get correspondentAccNoBankt() {
        return this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentAccNo;
    }
    get correspondentBankSwiftCodeBankt() {
        return this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSwiftCode;
    }
    get correspondentBankSortCodeBankt() {
        return this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSortCode;
    }
    get payeebanknameBankt() {
        return this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankName;
    }
    get chequedateCheque() {
        return (this.mainVoucherForm.controls.chequeInfo['controls'].ChequeDate);
    }
    get chequeTypeCheque() {
        return (this.mainVoucherForm.controls.chequeInfo['controls'].ChequeType);
    }
    get chequedateBankT() {
        return (this.mainVoucherForm.controls.bankTransfer['controls'].ChequeDate);
    }
    get instrumentrefnoBankT() {
        return (this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo);
    }
    get chequeTypeBankT() {
        return (this.mainVoucherForm.controls.bankTransfer['controls'].ChequeType);
    }
    get expirydate() { return this.mainVoucherForm.get('ExpiryDate'); }
    get chequeno() {
        return this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo;
    }


    /* set Description in receptdetails desc   */
    setDescription() {
        //(<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[0].get('Description').setValue(this.cshdetails.value);
    }

    /* set GL DATA in for default values   */
    setGLData() {
        this.paymentEditData.PmtDetails.map((item, index) => {
            this.setFormArrayCTRLDefaultValue('GLCode', index, item.GLCode);
            this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, item.GLCodeDesc);
        });
    }

    /* go next valiadtion depending on receipt mode   */
    goNext() {
        if (this.isBatch && !this.totalIntialAmount.value) {
            return false;
        }
        if (this.paymentMode === 1) {
            this.errorpayee = this.cshpayeename.invalid;
            console.log(this.errorpayee, 'errorpayee');
            this.errordetail = this.cshdetails.invalid;
            console.log(this.errordetail, 'errordetail');
            if (!this.errorpayee && !this.errordetail) {
                if (this.isBatch && this.totalAmount < 0) {
                    return false;
                }
                this.level = 2;
                if (this.ondemandFlag) {
                    this.setDescription();
                }
                //super.getTotallingDetailData({ index: 0, flag: true });
            }
        }

        if (this.paymentMode === 2) {
            this.errorpayee = this.cshpayeename.invalid;
            console.log(this.errorpayee);
            this.errordetail = this.cshdetails.invalid;

            // if (this.payeebankcodeCheque != null && this.payeebankcodeCheque !== undefined) {
            //   this.errorbankcodeCheque = this.payeebankcodeCheque.invalid;
            //   console.log(this.payeebankcodeCheque.invalid, 'this.payeebankcode.invalid');
            // }
            if (this.mainVoucherForm.controls.chequeInfo['controls'].ChequeType.value == '3') {
                this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.setValidators([Validators.required]);
                this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.updateValueAndValidity();
            } else {
                this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.clearValidators();
                this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.updateValueAndValidity();
            }
            if (this.chequedateCheque != null && this.chequedateCheque !== undefined) {
                this.errorchequedateCheque = this.chequedateCheque.invalid;
            }


            if (this.chequeTypeCheque != null && this.chequeTypeCheque !== undefined) {
                this.errorChequeTypeCheque = this.chequeTypeCheque.invalid;
            }

            if (this.chequeno != null && this.chequeno !== undefined) {
                this.errorchequenoCheque = this.chequeno.invalid;
            }
            if (!this.errorpayee && !this.errordetail &&
                !this.errorchequedateCheque && !this.errorchequenoCheque && !this.errorChequeTypeCheque) {
                if (this.isBatch && this.totalAmount < 0) {
                    return false;
                }
                this.level = 2;
                if (this.ondemandFlag) {
                    this.setDescription();
                }
                // super.getTotallingDetailData({ index: 0, flag: true });
            }
        }


        if (this.paymentMode === 5) {
            this.errorpayee = this.cshpayeename.invalid;
            this.errordetail = this.cshdetails.invalid;

            // if (this.chequedateBankT != null && this.chequedateBankT !== undefined) {
            //   this.errorchequedateBankT = this.chequedateBankT.invalid;

            // }

            // if (this.payeebankcodeBankt != null && this.payeebankcodeBankt !== undefined) {
            //   this.errorbankcodeBanktransfer = this.payeebankcodeBankt.invalid;
            // }

            if (this.beneficiaryBankBankt != null && this.beneficiaryBankBankt !== undefined) {
                this.errorBeneficiaryBankBankT = this.beneficiaryBankBankt.invalid;
            }

            if (this.beneficiaryBankCurrencyBankt != null && this.beneficiaryBankCurrencyBankt !== undefined) {
                this.errorBeneficiaryBankCurrencyBankBankT = this.beneficiaryBankCurrencyBankt.invalid;
            }

            // if (this.beneficiaryAccNoBankt != null && this.beneficiaryAccNoBankt !== undefined) {
            //   this.errorBeneficiaryAccNoBankBankT = this.beneficiaryAccNoBankt.invalid;
            // }
            if (this.beneficiaryAccNoBankt != null && this.beneficiaryAccNoBankt !== undefined) {
                if (!this.IbanBankt.value && !this.beneficiaryAccNoBankt.value) {
                    this.errorBeneficiaryAccNoBankBankT = true;
                    this.errorIBANBankBankT = true;
                    this.errorBothfieldsDataBankT = false;
                } else if (this.IbanBankt.value && this.beneficiaryAccNoBankt.value) {
                    this.errorBothfieldsDataBankT = true;
                } else {
                    this.errorBeneficiaryAccNoBankBankT = this.errorIBANBankBankT = this.errorBothfieldsDataBankT = false;
                }
            }


            if (this.beneficiarySwiftCodeBankt != null && this.beneficiarySwiftCodeBankt !== undefined) {
                this.errorBeneficiarySwiftCodeBankBankT = this.beneficiarySwiftCodeBankt.invalid;
            }

            if (this.beneficiarySortCodeBankt != null && this.beneficiarySortCodeBankt !== undefined) {
                this.errorBeneficiarySortCodeBankBankT = this.beneficiarySortCodeBankt.invalid;
            }

            if (this.correspondentBankBankt != null && this.correspondentBankBankt !== undefined) {
                this.errorCorrespondentBankBankBankT = this.correspondentBankBankt.invalid;
            }

            if (this.IbanBankt != null && this.IbanBankt !== undefined) {
                if (!this.IbanBankt.value && !this.beneficiaryAccNoBankt.value) {
                    this.errorIBANBankBankT = true;
                    this.errorBeneficiaryAccNoBankBankT = true;
                    this.errorBothfieldsDataBankT = false;
                } else if (this.IbanBankt.value && this.beneficiaryAccNoBankt.value) {
                    this.errorBothfieldsDataBankT = true;
                } else {
                    this.errorBeneficiaryAccNoBankBankT = this.errorIBANBankBankT = this.errorBothfieldsDataBankT = false;
                }
                // this.errorIBANBankBankT = this.IbanBankt.invalid;
                console.log(this.errorbankcodeBanktransfer, 'errorbankcodeBanktransfer');
            }

            if (this.correspondentAccNoBankt != null && this.correspondentAccNoBankt !== undefined) {
                this.errorCorrespondentAccNoBankBankT = this.correspondentAccNoBankt.invalid;
            }

            if (this.correspondentBankSwiftCodeBankt != null && this.correspondentBankSwiftCodeBankt !== undefined) {
                this.errorCorrespondentBankSwiftCodeBankBankT = this.correspondentBankSwiftCodeBankt.invalid;
            }

            if (this.correspondentBankSortCodeBankt != null && this.correspondentBankSortCodeBankt !== undefined) {
                this.errorCorrespondentBankSortCodeBankBankT = this.correspondentBankSortCodeBankt.invalid;
            }


            if (this.chequeTypeBankT != null && this.chequeTypeBankT !== undefined) {
                this.errorChequeTypeBankT = this.chequeTypeBankT.invalid;
            }

            if (!this.errorpayee &&
                !this.errordetail &&
                !this.errorbankcodeBanktransfer && !this.errorCorrespondentBankSortCodeBankBankT &&
                !this.errorCorrespondentBankSwiftCodeBankBankT && !this.errorCorrespondentAccNoBankBankT
                && !this.errorIBANBankBankT && !this.errorCorrespondentBankBankBankT && !this.errorBeneficiarySortCodeBankBankT
                && !this.errorBeneficiarySwiftCodeBankBankT && !this.errorBothfieldsDataBankT &&
                !this.errorBeneficiaryAccNoBankBankT && !this.errorBeneficiaryBankCurrencyBankBankT
                && !this.errorBeneficiaryBankBankT && !this.errorChequeTypeBankT) {
                if (this.isBatch && this.totalAmount < 0) {
                    return false;
                }
                this.level = 2;
                if (this.ondemandFlag) {
                    this.setDescription();
                }
                // super.getTotallingDetailData({ index: 0, flag: true });

            }
        }
        // this.getTransactionSum();
        // defect 5463- set default GL code
        // if (this.level === 2 && !this.editPaymentFromPrevious) {
        //     this.setGLData();
        // }
    }
    /* add receipt in review screen */
    addReceipt(item?, len?, newAdded?) {
        if (super.validateAmount(len)) {
            const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
            const CurrentAmount = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('Amount').value;
            const newRow = this.createPaymentArrayGroup();
            newRow.patchValue(item);
            control.push(newRow);
            if (newAdded) {
                this.isNewRow = true;
                if (this.isPaymentFromEntity) {
                    this.setFormArrayCTRLDefaultValue('TotallingAccCode', len, '');
                    this.setFormArrayCTRLDefaultValue('GLCode', len, '');
                    this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '');
                }
                this.setFormArrayCTRLDefaultValue('GLCode', len, '');
                this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '');
                this.setFormArrayCTRLDefaultValue('TotallingAccCode', len, '');
                newRow.patchValue({ 'newAddedRow': true });
                this.setFormArrayCTRLDefaultValue('CostCenterCode', len, sessionStorage.getItem('costcentre'));
                this.setOndemandTotallingDetail({ index: len });
                this.glaccount[len] = [];
                // super.getTotallingDetailData({ index: len, flag: false });
                // this.dtltotallingacc[len] = this.cachedDtlTot;
                // this.glaccount[len] = this.cachedGL;

            }
        }

    }

    reSetForm(params) {
        const param = params.defaultParam;
        /*set default value here and reset */
        if (param === 1) {
            super.validateAllFormFields(this.mainVoucherForm);
            this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.reset(sessionStorage.getItem('locationcode'));
            this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.reset(sessionStorage.getItem('costcentre'));
            this.mainVoucherForm.controls.RegionCode.reset(sessionStorage.getItem(RSAConstants.regionCode));
            this.mainVoucherForm.controls.CountryCode.reset(sessionStorage.getItem(RSAConstants.countrycode));
            this.mainVoucherForm.controls.PreparedBy.reset(1);
            this.mainVoucherForm.controls.ApprovedBy.reset(1);
            this.mainVoucherForm.controls.PaymentMode.reset(this.paymentMode);
            this.mainVoucherForm.controls.TerminalUserID.reset(20);
            this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.reset(sessionStorage.getItem(RSAConstants.totallingaccount));
            this.getBankData(true);
            this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.reset(24);
            this.mainVoucherForm.controls.VoucherDate.setValue(new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'));
            this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.setValue(this.paymentEditData.Name);
            this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(this.paymentEditData.E_Desc);
            this.clearerrors();
        } else if (param === 2) {
            (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
                item.get('LocationCode').setValue([sessionStorage.getItem('locationcode')]);
                item.get('CostCenterCode').setValue([sessionStorage.getItem('costcentre')]);
                item.get('RefTransactionType').setValue(3);
                if (!this.claimPayment) { item.get('TotallingAccCode').setValue(sessionStorage.getItem(RSAConstants.totallingaccount)); }
                item.get('GLCode').setValue(sessionStorage.getItem(RSAConstants.defaultGLCode));
                item.get('GLCodeDesc').setValue(sessionStorage.getItem(RSAConstants.defaultGLCodeDesc));
                item.get('Amount').reset('');
                item.get('Description').setValue('');
                item.get('AnalysisCode').setValue('');
                item.get('Department').setValue('');
                if (this.claimPayment) { item.get('SettlementType').setValue(''); }

            });
            this.getSum();

        }
        super.GetAccountingDates(this.paymentEditData.VoucherDate);
    }
    updatePaymentVoucherValues(dataReturn: any) {
        this.mainVoucherForm.addControl('VoucherNo', new FormControl(dataReturn.VoucherNo, Validators.required));
    }

    /* update  form values to create-receipt objects*/
    upDateCreatePaymentValues() {
        console.log(this.mainVoucherForm.controls.ChequeDateFld.value, 'this.mainVoucherForm.controls.ChequeDateFld.value;');
        this.createPayment = new CreatePayment();
        const mainFormFieldArray = ['VoucherDate', 'RegionCode', 'Amount', 'PaymentMode', 'ReceiptType', 'ModifiedBy',
            'VendorCode', 'PreparedBy', 'ApprovedBy', 'CustomerID', 'CustCode', 'TerminalUserID', 'TerminalUserName',
            'CountryCode', 'ArabicDescription', 'Approvers'];
        mainFormFieldArray.forEach(item => {
            this.createPayment[item] = this.mainVoucherForm.controls[item].value;
        });

        if (this.mainVoucherForm.controls['VoucherNo']) {
            this.createPayment['VoucherNo'] = this.mainVoucherForm.controls['VoucherNo'].value;
        }
        console.log('paymentEditData', this.paymentEditData);
        // assign null values
        this.createPayment.PrintDate = null;
        this.prevPreviewID = this.paymentEditData.VoucherNo;
        this.createPayment.VoucherNo = this.paymentEditData.VoucherNo;
        this.createPayment.PreparedBy = sessionStorage.getItem(RSAConstants.LoggedInUserId);
        // assign batch when batch payment
        if (this.isBatch) { this.createPayment['Batch'] = true; }
        //
        // this.createPayment.RegionCode = this.mainVoucherForm.controls.accountInfo['controls'].RegionCode.value;
        this.createPayment.LocationCode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
        this.createPayment.CostCenterCode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
        this.createPayment.TotallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
        this.createPayment.RecevierBankCode = this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.value;
        this.createPayment.Name = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
        this.createPayment.E_Desc = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
        this.createPayment.PmtDetails = this.mainVoucherForm.controls['VoucherDetails'].value;

        if (this.paymentMode === 2) {
            this.createPayment.ChequeNo = this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.value;
            this.createPayment.ChequeType = this.mainVoucherForm.controls.chequeInfo['controls'].ChequeType.value;
            this.createPayment.ChequeDate = this.mainVoucherForm.controls.ChequeDateFld.value;
            this.createPayment.PayeeBankCode = this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankCode.value;
            this.createPayment.PayeeBankName = this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankName.value;
        }

        if (this.paymentMode === 5) {
            this.createPayment.InstrumentRefNo = this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo.value;
            this.createPayment.ChequeNo = this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo.value;
            this.createPayment.ChequeDate = this.mainVoucherForm.controls.ChequeDateFld.value;
            this.createPayment.ChequeType = this.mainVoucherForm.controls.bankTransfer['controls'].ChequeType.value;
            // this.createPayment.PayeeBankCode = this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankCode.value;
            this.createPayment.BeneficiaryBank = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBank.value;
            this.createPayment.BeneficiaryBankCurrency = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryBankCurrency.value;
            this.createPayment.BeneficiaryAccNo = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiaryAccNo.value;
            this.createPayment.BeneficiarySwiftCode = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySwiftCode.value;
            this.createPayment.BeneficiarySortCode = this.mainVoucherForm.controls.bankTransfer['controls'].BeneficiarySortCode.value;
            this.createPayment.CorrespondentBank = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBank.value;
            this.createPayment.IBAN = this.mainVoucherForm.controls.bankTransfer['controls'].IBAN.value;
            this.createPayment.CorrespondentAccNo = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentAccNo.value;
            // tslint:disable-next-line:max-line-length
            this.createPayment.CorrespondentBankSwiftCode = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSwiftCode.value;
            this.createPayment.CorrespondentBankSortCode = this.mainVoucherForm.controls.bankTransfer['controls'].CorrespondentBankSortCode.value;

        }
    }


    submitBulkPayment() {
        this.upDateCreatePaymentValues();
        this.createPayment['PmtDetails'] = this.matchedDetails;
        console.log(this.createPayment);
        this.createPaymentService.createPayment(JSON.stringify(this.createPayment)).subscribe(
            dataReturn => {
                this.returnValue = dataReturn;
                console.log(dataReturn);
                this.updatePaymentVoucherValues(dataReturn);

                this.returnValue['approverlist'] = this.approverusers;
                this.returnValue['ondemand'] = true;
                const initialState = {
                    'isBatch': true,
                    'totalReceiptAmount': this.totalAmount || 0
                };
                console.log(this.returnValue, 'this.returnValue');
                this.previewFlag = true;
                this.bsModalRef = this.modalService.show(PaymentpreviewComponent, {
                    class: 'preview-modal-dailog', initialState,
                    ignoreBackdropClick: true,
                    backdrop: 'static',
                    keyboard: false
                });
                this.bsModalRef.content.data = this.returnValue;
                this.bsModalRef.content.totalAmount = this.totalAmount;
                this.bsModalRef.content.backdrop = true;
            },
            errorRturn => {
                this.errorMsg = errorRturn;
            }
        );
    }

    submitPayment() {
        super.validateDetailInfo();
        //zero amount warning
        if (this.amountZeroCheck > 0) {
            this.alertService.warn(RSAMSGConstants.AMOUNTZEROCHECK);
            return false;
        }
        if (this.glerrorcount > 0) {
            return false;
        }
        if (this.submitError > 0) {
            this.alertService.warn(RSAMSGConstants.REQFIELDERROR);
            return false;
        }
        // this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
        //     this.approverusers.length > 0);
        // if (!(sessionStorage.getItem(RSAConstants.regionCode) == '2')) {
        //     if (this.totalAmount > 99999 && !this.usersReq) {
        //         return false;
        //     }
        // }
        if (this.prevPreviewID == null || this.prevPreviewID === undefined) {
            this.prevPreviewID = 0;
            this.createPayment['VoucherNo'] = this.prevPreviewID;
        }
        this.createPayment['paymentMode'] = this.paymentMode;
        if (this.claimPayment) {
            let isFromDraftOrNot: boolean = true;
            if (this.bsModalRef.content.unApproved) {
                isFromDraftOrNot = false;
                this.createPayment['IsRejectandEdit'] = true;
            }
            this.createPaymentService.createClaimPayment(JSON.stringify(this.createPayment)).subscribe(
                dataReturn => {
                    this.returnValue = dataReturn;
                    console.log(dataReturn, " createClaimPayment");
                    this.updatePaymentVoucherValues(dataReturn);
                    this.returnValue['approverlist'] = this.approverusers;
                    this.returnValue['ondemand'] = true;
                    console.log(this.returnValue, 'this.returnValue createClaimPayment');
                    this.previewFlag = true;
                    this.bsModalRef = this.modalService.show(PaymentpreviewComponent, {
                        class: 'preview-modal-dailog',
                        ignoreBackdropClick: true,
                        backdrop: 'static',
                        keyboard: false

                    });
                    this.bsModalRef.content.data = this.returnValue;
                    this.bsModalRef.content.totalAmount = this.totalAmount;
                    this.bsModalRef.content.claimPayment = true;
                    this.bsModalRef.content.backdrop = true;
                    this.bsModalRef.content.isDraft = isFromDraftOrNot;
                },
                errorRturn => {
                    this.errorMsg = errorRturn;
                }
            );
        } else {
            if (this.unApproved && !this.ondemandFlag) {
                this.createPayment['IsRejectandEdit'] = true;
            }
            this.createPaymentService.createPayment(JSON.stringify(this.createPayment)).subscribe(
                dataReturn => {
                    this.returnValue = dataReturn;
                    console.log(dataReturn);
                    this.updatePaymentVoucherValues(dataReturn);
                    this.returnValue['approverlist'] = this.approverusers;
                    this.returnValue['ondemand'] = true;
                    console.log(this.returnValue, 'this.returnValue ');
                    this.previewFlag = true;
                    this.bsModalRef = this.modalService.show(PaymentpreviewComponent, {
                        class: 'preview-modal-dailog',
                        ignoreBackdropClick: true,
                        backdrop: 'static',
                        keyboard: false
                    });
                    this.bsModalRef.content.data = this.returnValue;
                    this.bsModalRef.content.totalAmount = this.totalAmount;
                    this.bsModalRef.content.backdrop = true;
                },
                errorRturn => {
                    this.errorMsg = errorRturn;
                }
            );
        }
    }

    /* create-receipt form*/
    submitForm() {
        console.log('paymentEditData', this.paymentEditData);
        if (this.isBatch) {
            this.fileUploadForm.get('fileContent').markAsTouched();
            console.log(this.fileUploadForm.valid);
            if (!this.fileUploadForm.valid) {
                return false;
            }
            if (Number(this.totalMatchedAmount) > Number(this.totalAmount)) {
                this.alertService.warn('Transactions Amount exceeds the Payment Amount!!');
                return false;
            }
            this.submitBulkPayment();

        } else {
            console.log(this.ondemandFlag);
            this.updateDetailsAmount();
            super.validateDetailInfo();
            this.upDateCreatePaymentValues();
            console.log(this.createPayment, ' this.createPayment');
            if (this.createPayment.RecevierBankCode === undefined || this.createPayment.RecevierBankCode === null) {
                if (this.receiverdataBankName && this.receiverdataBankName.length > 0) {
                    this.createPayment.RecevierBankCode = this.receiverdataBankName[0].Code;
                }
            }

            if (this.amountZeroCheck > 0) {
                this.alertService.warn(RSAMSGConstants.AMOUNTZEROCHECK);
                return false;
            }

            if (this.amountLimitCheck > 0) {
                this.alertService.warn(RSAMSGConstants.AMOUNTEXCEEDMSG);
                return false;
            }
            if (this.totalAmount === 0 && this.claimPayment) {
                this.alertService.warn(RSAMSGConstants.AMOUNTZERO);
                return false;
            }
            if (this.submitError > 0) {
                this.alertService.warn(RSAMSGConstants.REQFIELDERROR);
                return false;
            }
            if (this.claimPayment) {
                if (this.glerrorcount > 0) {
                    return false;
                }
                this.submitPayment();
                return false;
            }
            if (this.ondemandFlag) {
                if (this.glerrorcount > 0) {
                    return false;
                }
                if (this.totalAmount <= 0) {
                    this.alertService.warn(RSAMSGConstants.DEBITEXCEEDMSG);
                }
                if (this.totalAmount > 0) {
                    this.submitPayment();
                    return false;
                }
            } else {
                if (this.totalAmount <= 0 && !this.claimPayment && this.glerrorcount > 0) {
                    this.alertService.warn(RSAMSGConstants.DEBITEXCEEDMSG);
                    return false;
                }
                if (this.totalAmount <= 0) {
                    this.alertService.warn(RSAMSGConstants.DEBITEXCEEDMSG);
                    return false;
                }
                this.submitPayment();
            }
        }
    }
    /* check single or batch upload */
    checkSingleOrbatch(e) {
        this.isBatch = !this.isBatch;
        console.log(this.isBatch);
    }


    uploadXlsFile(e) {
        if (e.target.files && e.target.files.length) {
            if (e.target.files[0].name.indexOf('.xls') === -1) {
                this.alertService.warn(`Please upload a valid Excel file.`);
                return false;
            }
        }
        if (e.target.files && e.target.files.length) {
            const selectedFiles = e.target.files;
            console.log(selectedFiles.item(0), 'selectedFiles.item(0)');
            this.batchUploadService.uploadBatchFile(selectedFiles.item(0),
                { 'gl': this.defaultGLCode, 'acc': this.defaultTotallingAccCode }).subscribe((data) => {
                    this.bulkuploadData = data;
                    console.log(this.bulkuploadData);
                    if (Array.isArray(this.bulkuploadData) && this.bulkuploadData.length) {
                        console.log(data, 'Data from API-Payment Bulk Upload');
                        if (this.checkRecieptCommision.commisionValid === false) {
                            this.alertService.warn(`Amount and Commission is blank for Voucher No : ${this.checkRecieptCommision.voucherNo}
              and PolicyNo : ${this.checkRecieptCommision.policyNo}!!`);
                            return false;
                        }
                        this.ifUploadSuccess = false;
                        this.matchedRecords = data.filter(item => item.Matched !== false) || [];
                        this.setMatchedUnmatched(this.matchedRecords);
                    } else {
                        this.alertService.error('Invalid data from API');

                    }
                });
        }
    }
    get checkRecieptCommision(): any {
        let bulkdata = {};
        this.bulkuploadData.map((item) => {
            if (item.Message !== null) {
                bulkdata = {
                    commisionValid: false,
                    voucherNo: item.VoucherNo,
                    policyNo: item.PolicyNumber
                };
                return false;
            }
        });
        return bulkdata;
    }
    clearXlsFile(e: any) {
        e.target.value = '';
    }

    setMatchedUnmatched(data: any[]) {
        if (Array.isArray(data) && data.length) {
            let receiptDetails = {};
            for (const item of data) {
                receiptDetails = {
                    CounterPartyRef: null,
                    LocationCode: sessionStorage.getItem('locationcode'),
                    BranchCode: sessionStorage.getItem('locationcode'),
                    LocationDesc: sessionStorage.getItem(RSAConstants.locationdesc),
                    CountryCode: sessionStorage.getItem(RSAConstants.countrycode),
                    CostCenterCode: sessionStorage.getItem('costcentre'),
                    Description: item.Description,
                    Amount: item.GrossAmount || item.Amount || 0,
                    RefTransactionID: item.TransactionTypeId || '',
                    RefTransactionType: item.RefTransactionType,
                    TransactionType: item.TransactionType,
                    IsDebitEntry: true,
                    PolicyID: item.PolicyID || '',
                    PolicyNumber: item.PolicyNumber,
                    ModifiedBy: item.ModifyBy || '',
                    Filename: item.Filename,
                    ReceiptDate: [],
                    CustomerID: item.Customer_Id,
                    AnalysisCode: '',
                    DepartmentCode: '',
                    Department: '',
                    VoucherDate: item.VoucherDateString || item.VoucherDate,
                    Commision: item.Commision || 0,
                    NetAmount: item.NetAmount || Number(item.GrossAmount || item.Amount) + Number(item.Commision),
                    RefTransactionSerialNo: item.SerialNo,
                    GLCode: this.defaultGLCode,
                    GLCodeDesc: this.defaultGLCodeDesc,
                    RegionCode: sessionStorage.getItem(RSAConstants.regionCode),
                    TotallingAccCode: this.defaultTotallingAccCode,
                    PolicyYear: item.PolicyYear || '',
                    PolicyType: item.PolicyType || '',
                    PlaceHolderCode: null,
                    Endt_ID: item.EndtId,
                    GLAccountName: null,
                    CostCenterName: null,
                    TotallingAccName: null,
                    BranchName: null,
                    DepartmentName: '',
                    GLAccount: null,
                    ClassCode: item.ClassCode,
                    ClaimID: item.Claim_Id,
                    VoucherType: null,
                    TransactionNo: null,
                    RefTranType: null,
                    VoucherNo: item.VoucherNo || null,
                    ExcelVoucherNo: item.VoucherNo || null,
                    CityCode: item.CityCode,
                    // Aaded new formControlName to make row readonly if coming from selection rows
                    newAddedRow: false,
                    CauseOfLoss: '',
                    NatureOfLoss: '',
                    settlementType: ''
                };

                this.matchedDetails.push(receiptDetails);

            }
            this.getMatchedUnmatchedAmtsum(this.matchedDetails);
        }
    }
    // get paymentRows() { return <FormArray>this.paymentBulkForm.get('paymentBulkFormArray'); }
    deleteMatchedRecord(index, row) {
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
        this.bsModalRef.content.valueChange.subscribe((data) => {
            if (data = 'Proceed') {
                console.log(index);
                this.matchedDetails.splice(index, 1);
                this.matchedRecords.splice(index, 1);
                this.getMatchedUnmatchedAmtsum(this.matchedDetails);
            }
        });

    }
    getbatchTotalAmt(amt: number) {
        if (this.isBatch) {
            this.totalAmount = amt;
        }

    }
    getMatchedUnmatchedAmtsum(data: any[]) {
        if (toString.call(data) !== '[object Array]') {
            return false;
        }
        let total = 0;
        for (let i = 0; i < data.length; i++) {
            if (isNaN(data[i].Amount)) {
                continue;
            }
            total += Number(data[i].Amount);
        }
        this.totalMatchedAmount = total.toFixed(2);
    }
    addNewTransaction() {
        const initialState = {
            'branchdata': this.branchdata,
            'costcentredata': this.costcentredata,
            'glaccount': this.glaccount,
            'isEntityPaymentFeildReq': !this.ondemandFlag,
            'voucherDetailsLength': this.voucherDetailsLength,
            'transactiontype': this.transactiontype,
            'department': this.department,
            'pjctindicator': this.pjctindicator,
            'TotallingAccCode': this.defaultTotallingAccCode,
            'GLCodeDesc': this.defaultGLCodeDesc,
            'loccode': this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value,
            'ccode': this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value,
            'totAccCode': this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value,
            'isPaymentFromEntity': this.isPaymentFromEntity,
            'defaultGLCode': this.defaultGLCode,
            'cachedGL': this.cachedGL,
            'settlementType': this.settlementTypeData
        };


        this.bsModalRef = this.modalService.show(AddNewTransactionComponent,
            { class: 'gray modal-add-new-receipt', ignoreBackdropClick: true, backdrop: true, initialState });
        this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
        this.bsModalRef.content.dtltotallingacc = this.dtltotallingacc;
        // this.bsModalRef.content.defaultGLCode = this.defaultGLCode;
        this.bsModalRef.content.valueChange.subscribe((data) => {
            console.log(data);
            this.matchedDetails.push(data);
            this.getMatchedUnmatchedAmtsum(this.matchedDetails);

        });

    }
}
