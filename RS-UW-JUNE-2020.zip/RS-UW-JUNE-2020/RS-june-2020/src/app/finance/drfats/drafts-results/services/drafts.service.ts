import { Injectable } from '@angular/core';
import { HttpParams, HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { map, catchError } from 'rxjs/operators';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';

@Injectable({
    providedIn: 'root'
})
export class DrfatService {

    constructor(private http: HttpClient) { }

    getDraftReceipts(param: any): Observable<any> {
        // DRAFTSRECEIPT DRAFTAPI
        return this.http.get(RSAENDPOINTConstants.DRAFTAPI + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDraftReceipt')));


    }

    getDraftReceipt(receiptNo): Observable<any> {
        // DRAFTSRECEIPT DRAFTAPI
        return this.http.get(RSAENDPOINTConstants.DRAFTAPI_RECEIPT_EDIT_VIEW + receiptNo).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDraftReceipt')));
    }

    getDrfatsDebitnotes(param): Observable<any> {

        return this.http.get(RSAENDPOINTConstants.DRAFT_DN_API + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDraftDns')));
    }

    getDrfatsDebitnote(debitNo): Observable<any> {

        return this.http.get(RSAENDPOINTConstants.DRAFTAPI_DN_EDIT_VIEW + debitNo).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDraftDn')));
    }

    getDrfatsCreditnotes(param): Observable<any> {

        return this.http.get(RSAENDPOINTConstants.DRAFT_CN_API + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDraftCns')));
    }

    getDrfatsCreditnote(creditNo): Observable<any> {

        return this.http.get(RSAENDPOINTConstants.DRAFTAPI_CN_EDIT_VIEW + creditNo).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDraftCn')));
    }

    getDrfatsPayments(param): Observable<any> {

        return this.http.get(RSAENDPOINTConstants.DRAFT_PAYMENT_API + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDraftPayments')));
    }

    getDrfatsPayment(paymentNo): Observable<any> {

        return this.http.get(RSAENDPOINTConstants.DRAFTAPI_PAYMENT_EDIT_VIEW + paymentNo).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDraftPayment')));
    }
    
    getClmPaymentDrafts(param): Observable<any> {
        
        return this.http.get(RSAENDPOINTConstants.DRAFT_CLM_PAYMENT + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDraftClmPayments')));
    }
    getClmPayment(param): Observable<any> {
        
        return this.http.get(RSAENDPOINTConstants.GETCLMPAYMENT + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDraftClmPayments')));
    }


    getDrfatsJournals(param): Observable<any> {

        return this.http.get(RSAENDPOINTConstants.DRAFT_JV_API + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDraftCns')));
    }

    getDrfatsJournal(voucherNo): Observable<any> {
        let param = 'voucherNo=' + voucherNo + '&locationCode=20';
        return this.http.get(RSAENDPOINTConstants.DRAFTAPI_JV_EDIT_VIEW + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDraftDn')));
    }

}
