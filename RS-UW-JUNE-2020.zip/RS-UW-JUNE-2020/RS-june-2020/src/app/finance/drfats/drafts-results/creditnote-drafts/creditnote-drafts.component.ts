import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { CreateDraftCreditnoteComponent } from '../../../drfats/drafts-results/create-draft-creditnote/create-draft-creditnote.component';
import { CnpreviewComponent } from 'src/app/finance/preview/uae/cnpreview/cnpreview.component';
import { SharedService } from 'src/app/finance/services/shared.service';


@Component({
  selector: 'rsa-creditnote-drafts',
  templateUrl: './creditnote-drafts.component.html',
  styleUrls: ['./creditnote-drafts.component.scss']
})
export class CreditnoteDraftsComponent implements OnInit {

  @Input() creditnoteDraftData: any = [];
  @Input() VName: string;
  bsModalRef: BsModalRef;
  buttonName: { id: string; name: string; access: boolean; }[];
  selectedRowEntitiDataTable: any;
  totalVoucherCount: number;
  showSnackbar: boolean;
  totalVoucherAmount: number;
  isClosed=false;
  constructor(private modalService: BsModalService, private sharedService: SharedService) { }

  ngOnInit() {
    console.log(this.creditnoteDraftData, 'creditnoteDraftData-cpomp');
    this.sharedService.getMessage().subscribe(val => {
      if (val === 'CNSnackbarAdded') {
        if(!this.isClosed){
          this.displaySnackBar();
        }
      } 
      if (val == 'close' || val == true || val == undefined) {
        this.isClosed=true;
        this.clearSnackBar();
      }
      if(val=='OpenVoucher'){
        this.isClosed=false;
      }
    });
  }

  displaySnackBar(){
    let SnackbarAdded = sessionStorage.getItem('SnackbarAdded');
    if (SnackbarAdded == 'true') {
      let voucherDetail = JSON.parse(sessionStorage.getItem('VoucherDetail'));
      this.buttonName=[{ id: '4', name: 'CreditNote', access: true }];
      this.selectedRowEntitiDataTable = voucherDetail.SelectedRows;
      this.totalVoucherCount = 0;
      this.totalVoucherAmount = 0;
      this.selectedRowEntitiDataTable.forEach(row => {
        this.totalVoucherCount++;
        this.totalVoucherAmount += row.Amount;
      });
    }
    this.showSnackbar=true;
  }
  clearSnackBar() {
    this.totalVoucherCount = 0;
    this.totalVoucherAmount = 0;
    sessionStorage.setItem('SnackbarAdded', 'false');
    sessionStorage.setItem('isFromDraft', 'false');
    this.selectedRowEntitiDataTable = [];
    this.buttonName = [];
    let voucherDetail = { ButtonNames: this.buttonName, SelectedRowEntitiDataTable: this.selectedRowEntitiDataTable };
    sessionStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
    this.showSnackbar = false;
  }
  hideSnackBar(ev) {
    this.clearSnackBar();
  }
  buttonHandler(e){
    let receiptData=JSON.parse(sessionStorage.getItem('DraftData'));
    if(receiptData!=undefined){
      const initialState = {
        backdrop: true,
        ignoreBackdropClick: true,
        creditnoteEditData: receiptData,
        isCreditNote: true
      };
      console.log('initialState:', initialState);
      this.bsModalRef = this.modalService.show(CreateDraftCreditnoteComponent,
        { class: 'create-modal-dailog', initialState, ignoreBackdropClick: false });
    }
  }

}
