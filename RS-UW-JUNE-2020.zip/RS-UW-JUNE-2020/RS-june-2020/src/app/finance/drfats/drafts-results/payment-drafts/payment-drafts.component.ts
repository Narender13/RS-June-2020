import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { SharedService } from 'src/app/finance/services/shared.service';
//import { CreateReceiptEntitiRowSelectionComponent } from 'src/app/finance/search/search-results/entity/create-receipt-entiti-row-selection/create-receipt-entiti-row-selection.component';
import { CreateDraftPaymentComponent } from 'src/app/finance/drfats/drafts-results/create-draft-payment/create-draft-payment.component';
import { PaymentpreviewComponent } from 'src/app/finance/preview/uae/paymentpreview/paymentpreview.component';

@Component({
  selector: 'rsa-payment-drafts',
  templateUrl: './payment-drafts.component.html',
  styleUrls: ['./payment-drafts.component.scss']
})
export class PaymentDraftsComponent implements OnInit {
  @Input() paymentDraftData: any = [];
  @Input() VName: string;
  @Input() isClaimPayment: boolean;
  paymentHeading:string;
  buttonName: { id: string; name: string; access: boolean; }[];
  selectedRowEntitiDataTable: any;
  totalVoucherCount: number;
  totalVoucherAmount: number;
  showSnackbar=false;
  bsModalRef: BsModalRef;
  isClosed=false;
  constructor(private modalService: BsModalService,private sharedService: SharedService) { }

  ngOnInit() {
    if(this.isClaimPayment)
    {
      this.paymentHeading = 'Claim Payments';
    }
    else
    {
      this.paymentHeading ='Payments';
    }
    this.sharedService.getMessage().subscribe(val => {
      if (val === 'PaymentSnackbarAdded') {
        if(!this.isClosed){
          this.displaySnackBar();
        }
      } 
      if (val == 'close' || val == true || val == undefined) {
        this.isClosed=true;
        this.clearSnackBar();
      }
      if(val=='OpenVoucher'){
        this.isClosed=false;
      }
    });
   // console.log(this.paymentDraftData, 'paymentDraftData-cpomp');
  }
  displaySnackBar(){
    let SnackbarAdded = sessionStorage.getItem('SnackbarAdded');
    if (SnackbarAdded == 'true') {
      let voucherDetail = JSON.parse(sessionStorage.getItem('VoucherDetail'));
      if(voucherDetail.voucherType=='Payment'){
        this.buttonName=[{ id: '3', name: 'payment', access: true }];
      }
      else if(voucherDetail.voucherType=='ClaimPayment'){
        this.buttonName=[{ id: '4', name: 'Claim Payment',access: true}];
      }
      
      this.selectedRowEntitiDataTable = voucherDetail.SelectedRows;
      this.totalVoucherCount = 0;
     this.totalVoucherAmount = 0;
      this.selectedRowEntitiDataTable.forEach(row => {
        this.totalVoucherCount++;
        this.totalVoucherAmount += row.Amount;
      });
    }
    this.showSnackbar=true;
  }
  clearSnackBar() {
    this.totalVoucherCount = 0;
    this.totalVoucherAmount = 0;
    sessionStorage.setItem('SnackbarAdded', 'false');
    sessionStorage.setItem('isFromDraft', 'false');
    this.selectedRowEntitiDataTable = [];
    this.buttonName = [];
    let voucherDetail = { ButtonNames: this.buttonName, SelectedRowEntitiDataTable: this.selectedRowEntitiDataTable };
    sessionStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
    this.showSnackbar = false;
  }
  hideSnackBar(ev) {
    this.clearSnackBar();
  }
  buttonHandler(e){
    let isClaimPayment=(e == '4')?true:false;
    let paymentDetailData=JSON.parse(sessionStorage.getItem('DraftData'));
    if(paymentDetailData!=undefined){
      const initialState = {
        backdrop: true,
        ignoreBackdropClick: true,
        paymentEditData: paymentDetailData,
        claimPayment: isClaimPayment,
        isPayment: true
      };
      console.log('initialState:', initialState);
      this.bsModalRef = this.modalService.show(CreateDraftPaymentComponent,
        { class: 'create-modal-dailog', initialState, ignoreBackdropClick: false });
     }
   }
  }


