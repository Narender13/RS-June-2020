import { Component, OnInit, ViewChild } from '@angular/core';
import { SharedService } from 'src/app/finance/services/shared.service';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { DatePipe } from '@angular/common';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
@Component({
  selector: 'rsa-basevoucher',
  templateUrl: './basevoucher.component.html',
  styleUrls: ['./basevoucher.component.scss']
})
export class BasevoucherComponent implements OnInit {
  totallingacc: any = [];
  totallingaccCnDn: any = [];
  users: any = [];
  costcentredata: any = [];
  branchdata: any = [];
  receiverdataBankName: any = [];
  glaccountCnDnHeader: any = [];
  payeedataBankName: any = [];
  flagInit: boolean;
  paymentMode = 2;
  cachedReceiverBankData: any = [];
  cachedPayeeBankData: any = [];
  cachedDtlTot: any = [];
  cachedBranchdata = [];
  cachedCostcentredata = [];
  cachedTotAcc: any = [];
  cachedGL: any = [];
  errorMsg;
  mainVoucherForm: FormGroup;
  paymentname;
  dtltotallingacc: any = [];
  level: any = 1;
  collapsetoheader: boolean;
  masterdata: any = [];
  masterdata2: any = [];
  terminals = [];
  pjctindicator: any = [];
  department: any = [];
  transactiontype: any = [];
  currentTbIndex = 0;
  totalAmount = 0;
  glerrorcount = 0;
  totaccrorcount = 0;
  previewFlag = false;
  isOnDemandFlag = false;
  glaccount: any = [];
  arrUser: any = [];
  approverusers: string;
  minDateRd: any;
  maxDateRd: any;
  prevPreviewID: any;
  previewDataDtl: any = [];
  claimPayment;
  editPaymentFromPrevious = false;
  bankTransverForPayment = true;
  bankCurrencyData: any = [];
  chequeTypeData: any = [];
  defaultGLCode;
  defaultGLCodeDesc;
  defaultTotallingAccCode;
  isPaymentFromEntity = false;
  entitydata: any;
  cnEditData: any;
  dnEditData: any;
  jvBaseVoucherEditData: any;
  jvBaseVoucherRowData: any;
  rowEntityData: any;
  rowClaimData: any;
  isDebitNote: boolean;
  isPayment: boolean;
  isCreditNote: boolean;
  customerName;
  settlementType: any = [];
  settlementTypeData: any = [];
  totalcr = 0;
  totaldr = 0;
  isRowPaymentEntity: any;
  isClaimRowPaymentEntity: any;
  isSetlementTypeForClaim: any;
  isNewRow: boolean = false;
  isRowJV: boolean = false;
  isCN;
  isJV = false;
  amountZeroCheck;
  amountLimitCheck;
  isRowDraftCN = false;
  isRowDraftDN = false;
  isRowDraftJV = false;
  isclaimJV = false;
  isAllLobJV = false;
  isReverseJV = false;
  isClaimFlag = false;
  isVATFlag = false;
  receiptAccountingDate: any;
  regionCode: any;
  @ViewChild('tabset') tabset: TabsetComponent;
  submitError: number;
  reportHeaders: any = [];
  onFlagClaimSearch: boolean = false;
  isAllLob;
  selectedRowItem: any;
  // selectedRowEntitiDataTable: any;

  constructor(protected masterDataService: MasterDataService, protected sharedService: SharedService,
    protected modalService: BsModalService,
    protected utilityClass: UtilityClass,
    protected bsModalRef: BsModalRef) {
    console.log('basvocher');
    this.regionCode = sessionStorage.getItem(RSAConstants.regionCode);
  }
  ngOnInit() {
    console.log(this.isRowPaymentEntity, 'isRowPaymentEntity');
    console.log(this.regionCode, 'regionCode');
    this.regionCode = sessionStorage.getItem(RSAConstants.regionCode);
    // this.rowEntityData = this.bsModalRef.content.selectedRowEntitiDataTable;
  }
  setNewRow() {
    this.isNewRow = true;
  }
  setBranchData(branchCode) {
    this.mainVoucherForm.controls.accountInfo.get('LocationCode').setValue(branchCode);
  }
  getEntityDefaultData() {
    setTimeout(() => {
      this.isPaymentFromEntity = this.bsModalRef.content != null ? this.bsModalRef.content.isPaymentFromEntity : null;
      this.isRowPaymentEntity = this.bsModalRef.content != null ? this.bsModalRef.content.isRowPaymentEntity : null;
      this.onFlagClaimSearch = this.bsModalRef.content != null ? this.bsModalRef.content.onFlagClaimSearch : null;
      this.isAllLob = this.bsModalRef.content != null ? this.bsModalRef.content.isAllLob : null;
      this.isAllLobJV = this.bsModalRef.content != null ? this.bsModalRef.content.isAllLobJV : null;
      if (this.isRowPaymentEntity) {
        this.rowEntityData = this.bsModalRef.content.selectedRowEntitiDataTable;
      }
      if (this.isPaymentFromEntity || this.isRowPaymentEntity) {
        this.customerName = this.bsModalRef.content.CustomerName;
        if (this.bsModalRef.content.entitydata || this.bsModalRef.content.selectedRowEntitiDataTable) {
          this.entitydata = this.bsModalRef.content.entitydata || this.bsModalRef.content.selectedRowEntitiDataTable[0];
        }
        console.log(this.entitydata, 'entitydata-ankappa');
        if (this.entitydata && !this.isAllLob) {
          this.defaultGLCode = this.entitydata.GLCode;
          this.defaultGLCodeDesc = this.entitydata.GLCodeDesc;
          this.defaultTotallingAccCode = this.entitydata.TotallingAccCode;
        }
      }
    });
  }
  /* go Previous screen in modal */
  goPrevious() {
    this.level = 1;
  }
  /* collapse modal header */
  collapseToheader() {
    this.collapsetoheader = !this.collapsetoheader;
    if (this.collapsetoheader) {
      this.sharedService.sendMessage('collapse');
    } else {
      this.sharedService.sendMessage('not-collapse');
    }
  }

  /* get all branch data for header and details */
  getAllBranchData() {
    this.masterDataService.getLookupLocations().subscribe((data) => {
      this.branchdata = data;
      console.log(data, 'branchdat');
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }



  /* get all transcation data for  details */
  getAllTranData() {
    this.masterDataService.getAllTranData().subscribe((data) => {
      this.transactiontype = data;
      console.log(data, 'transactiontype');
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* get all instrument types */
  getAllInstrumentTypes() {
    this.masterDataService.getInstrumentTypes().subscribe((data) => {
      this.chequeTypeData = data;
      console.log(data, 'chequeTypeData');
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  /* get all department data for  details */
  getAllDeptData() {
    this.masterDataService.getAllDeptData().subscribe((data) => {
      this.department = data;
      console.log(data, 'department');
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* get all project indicator data for  details */
  getAllProjData() {
    this.masterDataService.getAllProjectIndData().subscribe((data) => {
      this.pjctindicator = data;
      console.log(data, 'pjctindicator');
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* get all bank currency  data for  details */
  getAllBankCurrency() {
    this.masterDataService.getAllBankCurrencyData().subscribe((data) => {
      this.bankCurrencyData = data;
      console.log(this.bankCurrencyData, 'pjctindicator');
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* get all cost Centre  data for  header and details */
  getAllCostCenterData(ev) {
    this.masterDataService.getLookupCostCenters().subscribe((data) => {
      this.costcentredata = data;
      console.log(data, 'costcentredata');
      this.getTotallingDetailData(ev);
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* get settlementType data */
  getSettlementTypeData() {
    this.masterDataService.getAllSettlementTypeData().subscribe((data) => {
      this.settlementTypeData = data;
      console.log(this.settlementTypeData, 'settlementTypeData');
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /*set date after changeing date format  */
  onDateValueChange(ev) {
    this.mainVoucherForm.controls['ChequeDateFld'].setValue(new DatePipe('en-US').transform(new Date(ev), 'dd/MM/yyyy'));
  }

  /* get all payeedataBankName  data for  header  */
  getAllPayeeBankData(cachedflag) {
    this.masterDataService.getPayeeBanks().subscribe((data) => {
      this.payeedataBankName = data;
      console.log(this.payeedataBankName, 'payeedataBankName');
      // this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankCode.setValue(this.payeedataBankName[0].Code);
      if (cachedflag) {
        this.cachedPayeeBankData = data;
      }
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }


  /*get All users data from masterservice to approvers */
  getAllMasterData2(): void {
    this.masterDataService.getAllMasterData2().subscribe(
      dataReturn => {
        this.users = dataReturn.Users;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }


  /*get Totalling account data for headers */
  getAllTotallingData(initflag) {
    const ccode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    const param = {
      ccode: ccode,
    };
    this.masterDataService.getTotallingAccount(param).subscribe((data) => {
      this.totallingacc = data;
      console.log(data, 'getAllTotallingData');
      if (initflag) {
        this.cachedTotAcc = data;
      }
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }


  /*get AllgetLookupBanksData  data for headers */
  getAllgetLookupBanksData() {
    const ccode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    const totAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    const param = {
      ccode: ccode,
      totAccCode: totAccCode
    };
    this.masterDataService.getLookupBanks(param).subscribe((data) => {
      this.receiverdataBankName = data;
      console.log(data, 'receiverdataBankName');
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* get all Report Header data Debit Note  */
  getAllReportHeadersDebitNote() {
    this.masterDataService.getAllReportHeadersDebitNote().subscribe((data) => {
      this.reportHeaders = data;
      // console.log(data, 'Report Headers');
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* get all Report Header credit  Note  */
  getAllReportHeadersCreditNote() {
    this.masterDataService.getAllReportHeadersCreditNote().subscribe((data) => {
      this.reportHeaders = data;
      // console.log(data, 'Report Headers');
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* after changing the branch in details */
  changeCostcenter(ev) {
    this.getAllCostCenterData(ev);
  }


  /* after changing the payee bank in headers */
  setBankData(ev) {
    console.log(ev, 'ev');
    this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue('');
    this.getBankData(ev.flag);
  }

  /* after changing the payee bank in headers */
  getBankData(flagInit) {
    const ccentre = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    const totcode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    const param = {
      ccode: ccentre,
      totAccCode: totcode
    };
    this.masterDataService.getLookupBanks(param).subscribe(
      dataReturn => {
        this.receiverdataBankName = dataReturn;
        console.log(this.receiverdataBankName, 'bankdat');
        if (!flagInit) {
          this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue(this.receiverdataBankName[0].BankCode);
        }
        if (flagInit) {
          this.regionCode = sessionStorage.getItem(RSAConstants.regionCode);
          if (this.regionCode == '3') {
            // this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue(202);
            this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue(this.receiverdataBankName[0].Code);
          }
          this.cachedReceiverBankData = dataReturn;
        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* check the perious and display the model using for edit screen  */
  getModelPreviousClose() {
    this.sharedService.getMessage().subscribe(val => {
      if (val != null && val != undefined) {
        if (val === 'previous') {
          this.previewFlag = false;
          this.editPaymentFromPrevious = true;
          this.mainVoucherForm.markAsDirty();
          this.mainVoucherForm.markAsTouched();
        } else if (val === 'close') {
          this.modalService.hide(1);
        }
        this.prevPreviewID = val.id;
        this.previewDataDtl = val.data;
        if (this.previewDataDtl != null || this.previewDataDtl != undefined) {
          this.doPatchRefFields();
        }

      }
    });

  }
  doPatchRefFields() {
    const formarray = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']);
    formarray.controls.map((item, index) => {
      item.get('RefTransactionID').setValue(this.previewDataDtl[index].RefTransactionID);
      item.get('RefTransactionSerialNo').setValue(this.previewDataDtl[index].RefTransactionSerialNo);
      //removed serial no mapping because of this mapping if we delete the record wrong transaction is deleting
      //item.get('SerialNo').setValue(this.previewDataDtl[index].SerialNo);
    });
  }
  // closing modal dialog box
  closeModel() {
    this.utilityClass.isModalShow().subscribe((data) => {
      if (data) {
        this.modalService.hide(1);
      }
      this.modalService.hide(1);
    });
  }

  getGLCodeForExistRecord() {
    const formarray = (<FormArray>this.mainVoucherForm.controls['ReceiptDetails']);
    formarray.controls.map((item, index) => {
      if (item.value.newAddedRow === false) {
        let ccentre = this.getFromFormArrayControlVal('CostCenterCode', index)
        let totcode = this.getFromFormArrayControlVal('TotallingAccCode', index)
        let param = 'totallingAccCode=' + totcode + '&CostCenterCode=' + ccentre;
        this.masterDataService.getGLData(param).subscribe(
          dataReturn => {
            this.glaccount[index] = dataReturn;
            let glAccntId = parseInt(this.getFromFormArrayControlVal('Code', index));
            let selGLAccnt = this.glaccount[index].filter(data => data.GLCode === glAccntId)[0];
            this.setReqValFormArrayControl('AnalysisCode', index, selGLAccnt.ProjectIndicator ? true : false);
            this.setReqValFormArrayControl('DepartmentCode', index, selGLAccnt.Department ? true : false);
          },
          errorRturn => this.errorMsg = errorRturn
        );
      }
    });

  }

  /* after changing TotallingDetailData  details */
  getTotallingDetailData(ev) {
    console.log(ev);
    const index = ev.index;
    const initFlag = ev.flag;
    const ccentre = this.getFromFormArrayControlVal('CostCenterCode', index);

    const param = 'ccCode=' + ccentre;

    this.masterDataService.getDetailTotallingAccount(param).subscribe(
      dataReturn => {
        this.dtltotallingacc[index] = dataReturn;
        console.log('this.dtltotallingacc[index]>>', this.dtltotallingacc[index]);
        let totcode = ev.isOndemand ? '' : this.dtltotallingacc[index][0].Code;
        if (this.defaultTotallingAccCode === undefined) {
          this.defaultTotallingAccCode = totcode;
        }
        if (!initFlag) {
          if (this.isPaymentFromEntity) {
            this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, this.defaultTotallingAccCode);
          } else if (this.isRowPaymentEntity) {
            totcode = this.rowEntityData[index] ? this.rowEntityData[index].TotallingAccCode : this.defaultTotallingAccCode;
            if (!this.isAllLobJV) {
              this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, totcode);
            }
          } else if (this.isRowDraftJV) {
            if (this.jvBaseVoucherEditData != undefined) {
              totcode = this.jvBaseVoucherEditData.JournalVoucherDetails[index].TotallingAccCode;
              this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, totcode);
            }
            if (this.selectedRowItem != undefined) {
              totcode = this.selectedRowItem[index].TotallingAccCode;
              this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, totcode);
            }
          } else if (this.isReverseJV) {
            totcode = this.getFromFormArrayControlVal('TotallingAccCode', index);
            this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, totcode);
          } else if (this.isclaimJV) {
            if (index < this.jvBaseVoucherRowData.length) {
              totcode = this.jvBaseVoucherRowData[index].TotallingAccCode;
            }
            this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, totcode);
          }
          else if (this.isNewRow) {
            this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, '');
          } else {
            this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, totcode);
          }
        }

        if (initFlag) {
          this.cachedDtlTot = dataReturn;
          if (this.isPaymentFromEntity) {
            this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, this.defaultTotallingAccCode);
          } else if (this.isNewRow) {
            this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, '');
          } else if (this.isRowPaymentEntity && this.isClaimRowPaymentEntity) {
            totcode = this.rowEntityData[index].TotallingAccCode;
            this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, totcode);
          } else if (this.isRowPaymentEntity) {
            totcode = this.rowEntityData[index].TotallingAccCode;
            this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, totcode);
          } else if (this.isRowDraftJV) {
            if (this.jvBaseVoucherEditData != undefined) {
              totcode = this.jvBaseVoucherEditData.JournalVoucherDetails[index].TotallingAccCode;
              this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, totcode);
            }
            if (this.selectedRowItem != undefined) {
              totcode = this.selectedRowItem[index].TotallingAccCode;
              this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, totcode);
            }
          } else if (this.isClaimFlag && this.isVATFlag) {
            if (index < this.rowClaimData.length) {
              totcode = this.rowClaimData[index].TotallingAccCode;
            }
            this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, totcode);
          }
        }

        if (ev.isOndemand) {
          this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, '');
          totcode = '';
        }
        if (this.isRowPaymentEntity) {
          totcode = this.rowEntityData[index] ? this.rowEntityData[index].TotallingAccCode : this.defaultTotallingAccCode;
          this.getGLData({ ev: totcode, index: index, flag: initFlag });
        }
        if (this.isPaymentFromEntity) {
          this.getGLData({ ev: this.defaultTotallingAccCode, index: index, flag: initFlag });
        }
        if (this.isRowDraftJV || this.isReverseJV || this.isclaimJV) {
          this.getGLData({ ev: totcode, index: index, flag: initFlag });
        }
        // tslint:disable-next-line:max-line-length
        if (!this.editPaymentFromPrevious && !(this.isPaymentFromEntity || this.isRowPaymentEntity || this.isRowDraftJV || this.isReverseJV || this.isclaimJV)) {
          this.getGLData({ ev: totcode, index: index, flag: initFlag, isOndemand: ev.isOndemand });
        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  getTotalingHeaderDataCnDn() {
    const ccentre = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    const param = 'ccCode=' + ccentre;
    this.masterDataService.getDetailTotallingAccount(param).subscribe(
      dataReturn => {
        this.totallingaccCnDn = dataReturn;
        let totcode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
        const isTotAvailable = dataReturn.filter(item => item.Code == totcode);
        if (isTotAvailable.length > 0) {
          this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(isTotAvailable[0].Code);
        } else {
          this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(dataReturn[0].Code);
          this.getGlAccountHeaderDataCnDn(dataReturn[0].Code, true);
        }
      });
  }

  getGlAccountHeaderDataCnDn(totcode, tottchange?) {
    const ccentre = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    const param = 'totAccCode=' + totcode +
      '&ccCode=' + ccentre;
    console.log('param-GL', param);
    this.masterDataService.getDetailGlAccount(param).subscribe(
      dataReturn => {
        this.glaccountCnDnHeader = dataReturn;
        console.log(this.glaccountCnDnHeader, 'this.glaccountCnDnHeader');
        /* set first value as default */
        if (this.glaccountCnDnHeader.length > 0 && tottchange) {
          this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(this.glaccountCnDnHeader[0].Code);
        }
      });
  }


  /*get gldata  */
  getGLData(ev) {
    console.log(ev);
    const index = ev.index;
    const initFlag = ev.flag;
    console.log(initFlag, 'initFlag');
    const val = ev.ev;
    const ccentre = this.getFromFormArrayControlVal('CostCenterCode', index);
    let totcode = '';
    if (!this.isOnDemandFlag && !ev.isOndemand) {
      totcode = (initFlag) ? this.getFromFormArrayControlVal('TotallingAccCode', index) : val;
    } else {
      totcode = val;
    }
    if (totcode === undefined || totcode === '') {
      this.glaccount[index] = [];
      this.clearGLCode(ev);
      this.isNewRow = false;
      return false;
    }
    const param = 'totAccCode=' + totcode +
      '&ccCode=' + ccentre;
    console.log('param-GL', param);
    this.masterDataService.getDetailGlAccount(param).subscribe(
      dataReturn => {
        console.log(dataReturn, 'dataretrun');
        if (this.isOnDemandFlag || this.isNewRow) {
          this.isOnDemandFlag = false;
          this.isNewRow = false;
          this.glaccount[index] = dataReturn;
          this.clearGLCode(ev);
        } else {
          this.glaccount[index] = dataReturn;
        }
        if (this.isRowJV) {
          this.glaccount[index] = [];
          this.isRowJV = false;
        }
        if (ev.totchangeflag) {
          this.clearGLCode(ev);
          return false;
        }
        if (!initFlag) {
          if (ev.totchangeflag) {
            this.clearGLCode(ev);
            return false;
          }
          if (this.glaccount[index].length > 0) {
            if (this.isRowDraftJV || this.isReverseJV) {
              if (this.jvBaseVoucherEditData != undefined) {
                const currentGL = this.jvBaseVoucherEditData.JournalVoucherDetails[index].GLCode;
                const currentglDetail = this.glaccount[index].filter(itemX => itemX.Code === currentGL);
                if (currentglDetail.length > 0) {
                  this.setFormArrayCTRLDefaultValue('GLCode', index, currentglDetail[0].Code);
                  this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, currentglDetail[0].E_Code_Desc);
                }
              } else {
                const currentGL = this.getFromFormArrayControlVal('GLCode', index);
                const currentglDetail = this.glaccount[index].filter(itemX => itemX.Code === currentGL);
                if (currentglDetail.length > 0) {
                  this.setFormArrayCTRLDefaultValue('GLCode', index, currentglDetail[0].Code);
                  this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, currentglDetail[0].E_Code_Desc);
                }
              }
            } else if (this.isclaimJV) {
              if (index < this.jvBaseVoucherRowData.length) {
                const currentGL = this.jvBaseVoucherRowData[index].GLCode;
                const currentglDetail = this.glaccount[index].filter(itemX => itemX.Code === currentGL);
                if (currentglDetail.length > 0) {
                  this.setFormArrayCTRLDefaultValue('GLCode', index, currentglDetail[0].Code);
                  this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, currentglDetail[0].E_Code_Desc);
                }
              } else {
                this.setFormArrayCTRLDefaultValue('GLCode', index, this.glaccount[index][0].Code);
                this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, this.glaccount[index][0].E_Code_Desc);
              }

            } else {
              if (this.isRowPaymentEntity && this.isJV) {
                const currentEntityGL = index <= (this.rowEntityData.length - 1) ? this.rowEntityData[index].GLCode : this.defaultGLCode;
                const currentglDetail = this.glaccount[index].filter(itemX => itemX.Code === currentEntityGL);
                if (currentglDetail.length > 0) {
                  this.setFormArrayCTRLDefaultValue('GLCode', index, currentglDetail[0].Code);
                  this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, currentglDetail[0].E_Code_Desc);
                }
              } else {
                if (this.isNewRow) {
                  this.setFormArrayCTRLDefaultValue('GLCode', index, '');
                  this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, '');
                } else {
                  this.setFormArrayCTRLDefaultValue('GLCode', index, this.glaccount[index][0].Code);
                  this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, this.glaccount[index][0].E_Code_Desc);
                }

              }
            }
          }
        }
        if (initFlag) {
          if (ev.totchangeflag) {
            this.clearGLCode(ev);
            return false;
          }
          this.cachedGL = dataReturn;
          if (this.isRowPaymentEntity && !this.isNewRow) {
            const currentGL = this.rowEntityData[index].GLCode;
            const currentglDetail = this.glaccount[index].filter(itemX => itemX.Code === currentGL);
            if (currentglDetail.length > 0) {
              this.setFormArrayCTRLDefaultValue('GLCode', index, currentglDetail[0].Code);
              this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, currentglDetail[0].E_Code_Desc);
            }
          }
          if (this.isPaymentFromEntity) {
            const currentglDetail = this.cachedGL.filter(itemX => itemX.Code == this.defaultGLCode);
            this.setFormArrayCTRLDefaultValue('GLCode', index, this.defaultGLCode);
            this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, currentglDetail[0].E_Code_Desc);
          } else if (this.isNewRow) {
            this.setFormArrayCTRLDefaultValue('GLCode', index, this.glaccount[index][0].Code);
            this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, this.glaccount[index][0].E_Code_Desc);
            this.isNewRow = false;
          } else if (this.isRowPaymentEntity && this.isClaimRowPaymentEntity) {
            const currentGL = this.rowEntityData[index].GLCode;
            const currentglDetail = this.glaccount[index].filter(itemX => itemX.Code === currentGL);
            if (currentglDetail.length > 0) {
              this.setFormArrayCTRLDefaultValue('GLCode', index, currentglDetail[0].Code);
              this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, currentglDetail[0].E_Code_Desc);
            }
          } else if (this.isRowDraftCN) {
            const currentGL = this.cnEditData.CreditNoteDetail[index].GLCode;
            const currentglDetail = this.glaccount[index].filter(itemX => itemX.Code === currentGL);
            if (currentglDetail.length > 0) {
              this.setFormArrayCTRLDefaultValue('GLCode', index, currentglDetail[0].Code);
              this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, currentglDetail[0].E_Code_Desc);
            }
          } else if (this.isClaimFlag && this.isVATFlag) {
            const currentGL = this.rowClaimData[index].GLCode;
            const currentglDetail = this.glaccount[index].filter(itemX => itemX.Code === currentGL);
            if (currentglDetail.length > 0) {
              this.setFormArrayCTRLDefaultValue('GLCode', index, currentglDetail[0].Code);
              this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, currentglDetail[0].E_Code_Desc);
            }
          } else if (this.isRowDraftDN) {
            const currentGL = this.dnEditData.DebitNoteDetail[index].GLCode;
            const currentglDetail = this.glaccount[index].filter(itemX => itemX.Code === currentGL);
            if (currentglDetail.length > 0) {
              this.setFormArrayCTRLDefaultValue('GLCode', index, currentglDetail[0].Code);
              this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, currentglDetail[0].E_Code_Desc);
            }
          } else if (this.isRowDraftJV || this.isReverseJV) {
            if (this.jvBaseVoucherEditData != undefined) {
              const currentGL = this.jvBaseVoucherEditData.JournalVoucherDetails[index].GLCode;
              const currentglDetail = this.glaccount[index].filter(itemX => itemX.Code === currentGL);

              if (currentglDetail.length > 0) {
                this.setFormArrayCTRLDefaultValue('GLCode', index, currentglDetail[0].Code);
                this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, currentglDetail[0].E_Code_Desc);
              }
            }
          }
        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* clear glcode on reset */
  clearGLCode(ev) {
    console.log(ev);
    this.setFormArrayCTRLDefaultValue('GLCode', ev.index, '');
    this.setFormArrayCTRLDefaultValue('GLCodeDesc', ev.index, '');
    if (ev.event && ev.event.target !== undefined) {
      this.validateTotalingAccount(ev.index);
    }
  }
  validateTotalingAccount(index) {
    const totalAccount = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get('TotallingAccCode');
    if (totalAccount) {
      if (totalAccount.value == null || totalAccount.value == '') {
        totalAccount.updateValueAndValidity();
        totalAccount.markAsTouched();
      }
    }
  }

  /*add  new voucher- TotallingDetailData */
  setOndemandTotallingDetail(ev) {
    const ccentre = this.getFromFormArrayControlVal('CostCenterCode', ev.index);
    const param = 'ccCode=' + ccentre;
    this.masterDataService.getDetailTotallingAccount(param).subscribe(
      dataReturn => {
        this.dtltotallingacc[ev.index] = dataReturn;
        this.clearGLCode({ index: ev.index });
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /*generic function to take controls of recepdetails Totalling Data  */
  setFormArrayCTRLDefaultValue(contrlname, index, val) {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get(contrlname).setValue(val);
  }

  getFromFormArrayControlVal(contrlname, index) {
    return (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get(contrlname).value;
  }

  // setting minimum and maximum date
  setMinMaxDate() {
    this.minDateRd = new Date();
    this.maxDateRd = new Date();
    this.minDateRd.setDate(this.minDateRd.getDate() - 0);
    this.maxDateRd.setDate(this.maxDateRd.getDate() - 0);
  }

  /* for approvals change results */
  onUserChange(parmas) {
    console.log(parmas, 'params');
    const isCheked = parmas.event.target.checked;
    const userid = parmas.item.UserID;
    const username = parmas.item.UserEngName;

    const userFormArray = <FormArray>this.mainVoucherForm.controls.Approvers;
    if (isCheked) {
      userFormArray.push(new FormControl(userid));
      this.arrUser.push(username);
    } else {
      const index = userFormArray.controls.findIndex(x => x.value == userid);
      userFormArray.removeAt(index);
      this.arrUser = this.arrUser.filter(v => v !== username);
    }
    this.approverusers = this.arrUser.join();

    console.log(this.approverusers, 'approvals');
  }

  /* calculating credit and debit when switch changes */
  setCreditEntry(ev) {
    console.log(ev, 'key');
    const actualData = Number(ev.data.controls['Amount'].value);
    const curdata = -(ev.data.controls['Amount'].value);
    ev.data.controls['Amount'].patchValue(curdata);
    this.getSum();
    if (actualData === 0 || actualData === undefined) {
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.EMPTYAMOUNTCHECK,
        'btnaction': RSAMSGConstants.OKTEXT
      });
      ev.event.target.checked = true;

    }
    console.log(ev.event.target.checked, 'ev.event.target.checked');
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails'])
      .controls[ev.index].get(ev.iscredit).setValue(ev.event.target.checked);
    if (this.totalAmount < 0) {
      ev.event.target.checked = true;
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.DEBITEXCEEDMSG,
        'btnaction': RSAMSGConstants.OKTEXT
      });
      ev.data.controls['Amount'].patchValue(-curdata);
      this.getSum();
    }

  }

  /* set value for glcode */
  setHiddenValue(val) {
    console.log(val);
    const ev = val.event.item.Code;
    const iter = val.index;
    const key = val.item;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[iter].get(key).setValue(ev);
    let glAccntId = parseInt(ev);
    let selGLAccnt = this.glaccount[iter].filter(data => data.Code === glAccntId)[0];
    this.setReqValFormArrayControl('AnalysisCode', iter, selGLAccnt.ProjectIndicator ? true : false);
    this.setReqValFormArrayControl('DepartmentCode', iter, selGLAccnt.Department ? true : false);
  }

  setReqValFormArrayControl(contrlname, index, isRequired) {
    //isRequired = true;
    let selCtrl = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get(contrlname);
    if (selCtrl) {
      if (isRequired) {
        if (selCtrl.value === null || selCtrl.value === '') {
          selCtrl.setValidators([Validators.required]);
          selCtrl.markAsTouched();
          selCtrl.markAsDirty();
          selCtrl.setErrors({ 'incorrect': true });
        }
        (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].updateValueAndValidity();
      }
      else {
        selCtrl.clearValidators();
      }
    }

  }
  // diplay confirmation dialog box
  displayAlertModal(obj: any) {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent,
      { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = obj.title;
    this.bsModalRef.content.modelBodyContent = obj.txt;
    this.bsModalRef.content.cancelBtn = obj.btncancel;
    this.bsModalRef.content.actionBtn = obj.btnaction;

  }
  /* check form is validateDetailInfo */
  validateDetailInfo() {
    this.amountZeroCheck = 0;
    this.amountLimitCheck = 0;
    this.totaccrorcount = 0;
    this.glerrorcount = 0;
    this.submitError = 0;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map((item, index) => {
      item.get('Amount').updateValueAndValidity();
      item.get('Amount').markAsTouched();
      item.get('GLCode').updateValueAndValidity();
      item.get('GLCode').markAsTouched();
      // item.get('GLCodeDesc').updateValueAndValidity();
      // item.get('GLCodeDesc').markAsTouched();
      item.get('TotallingAccCode').updateValueAndValidity();
      item.get('TotallingAccCode').markAsTouched();
      // if (this.isSetlementTypeForClaim) {
      //   item.get('SettlementType').updateValueAndValidity();
      //   item.get('SettlementType').markAsTouched();
      // }

      // tslint:disable-next-line:max-line-length
      if (item.get('TotallingAccCode').value == null || item.get('TotallingAccCode').value == undefined || item.get('TotallingAccCode').value == '') {
        this.totaccrorcount = this.totaccrorcount + 1;
      }
      if (item.get('GLCode').value == null || item.get('GLCode').value == undefined || item.get('GLCode').value == '') {
        this.glerrorcount = this.glerrorcount + 1;
      }
      if (item.get('Amount').value == null || item.get('Amount').value == 0 ||
        item.get('Amount').value == undefined || item.get('Amount').value == '') {
        this.glerrorcount = this.glerrorcount + 1;
        this.amountZeroCheck = this.amountZeroCheck + 1;
      }

      // tslint:disable-next-line:max-line-length
      if ((this.regionCode == '3' && item.get('Amount').value > 999999999.999) || (this.regionCode != '3' && item.get('Amount').value > 999999999.99)) {
        this.glerrorcount = this.glerrorcount + 1;
        this.amountLimitCheck = this.amountLimitCheck + 1;
        return false;
      }
      if (item.get('GLCode').value !== null &&
        item.get('GLCode').value !== undefined &&
        item.get('GLCode').value !== "") {
        let selGlAccntId = parseInt(item.get('GLCode').value);
        let lstGLAccnt = this.glaccount[index].filter(data => data.Code === selGlAccntId);
        if (lstGLAccnt.length > 0) {
          let selGLAccnt = lstGLAccnt[0];
          if (item.get('DepartmentCode').value == null
            || item.get('DepartmentCode').value == undefined
            || item.get('DepartmentCode').value == "") {
            if (selGLAccnt.Department) {
              this.setReqValFormArrayControl('DepartmentCode', index, selGLAccnt.Department ? true : false);
              this.submitError++;
            }
          }
          if (item.get('AnalysisCode').value == null ||
            item.get('AnalysisCode').value == undefined ||
            item.get('AnalysisCode').value == "") {
            if (selGLAccnt.ProjectIndicator) {
              this.setReqValFormArrayControl('AnalysisCode', index, selGLAccnt.ProjectIndicator ? true : false);
              this.submitError++;
            }
          }
        }
      }
      if (item.get('AnalysisCode').invalid) {
        this.submitError++;
      }
      if (item.get('DepartmentCode').invalid) {
        this.submitError++;
      }
    });
  }

  getSumDr() { // updating total of Dr amount from Journal V on delete row
    this.totaldr = 0;
    const ctrldr = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    ctrldr.controls.forEach(val => {
      console.log(val, ' val');
      const amtdr = (val.get('AmountDr').value == null || isNaN(val.get('AmountDr').value) ||
        val.get('AmountDr').value == '') ? 0 : val.get('AmountDr').value;
      this.totaldr += Math.abs(parseFloat(amtdr));
    });
    this.totaldr = (isNaN(this.totaldr)) ? 0 : this.totaldr;
  }


  getSumCr() { // updating total of Cr amount from Journal V on delete row
    this.totalcr = 0;
    const ctrlcr = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    ctrlcr.controls.forEach(val => {
      const amtcr = (val.get('AmountCr').value == null || isNaN(val.get('AmountCr').value) ||
        val.get('AmountCr').value == '') ? 0 : val.get('AmountCr').value;
      this.totalcr += Math.abs(parseFloat(amtcr));
    });
    this.totalcr = (isNaN(this.totalcr)) ? 0 : this.totalcr;
  }

  // getting total of amount
  getSum() {
    this.totalAmount = 0;
    const ctrl = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    ctrl.controls.forEach(val => {
      const amt = (val.get('Amount').value == null || isNaN(val.get('Amount').value) ||
        val.get('Amount').value == '') ? 0 : val.get('Amount').value;
      this.totalAmount += parseFloat(amt);
    });
    this.totalAmount = (isNaN(this.totalAmount)) ? 0 : this.totalAmount;
  }
  // checking voucher detail form array length
  get voucherDetailsLength() {
    return this.mainVoucherForm.controls.VoucherDetails['controls'].length > 1;
  }
  /* get VoucherDetails controls*/
  get voucherRows() { return <FormArray>this.mainVoucherForm.get('VoucherDetails'); }

  /* check form is dirty */
  checkIsformDirty() {
    this.sharedService.sendMessage(this.isRowPaymentEntity);
    this.utilityClass.checkIsformDirty(this.mainVoucherForm);
  }


  getActualAmountSumPayment() {
    let total: number = 0;
    let amt: number = 0;
    let actualamt: number = 0;
    let flagtoggle: boolean = false;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {

      if (this.getFromFormArrayControlVal("Amount", index) != undefined
        && this.getFromFormArrayControlVal("Amount", index) != null) {
        flagtoggle = this.getFromFormArrayControlVal("IsDebitEntry", index);
        amt = parseFloat(this.getFromFormArrayControlVal("Amount", index));
        amt = Math.abs(amt);
        actualamt = (flagtoggle) ? amt : (amt * -1);
        console.log('flagtoggle:' + flagtoggle + ",amt:" + amt + ",actualamt:" + actualamt);
        total = total + actualamt;
      }

    });

    this.totalAmount = (total == null || total == undefined || isNaN(total)) ? 0.00 : total;
  }

  getActualAmountSum(processFlag) {
    let total = 0;
    let amt = 0;
    let actualamt = 0;
    let flagtoggle = false;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {

      if (this.getFromFormArrayControlVal("Amount", index) != undefined
        && this.getFromFormArrayControlVal("Amount", index) != null) {
        flagtoggle = this.getFromFormArrayControlVal("IsDebitEntry", index);
        console.log(flagtoggle, 'flagtoggle');
        const Camt = parseFloat(this.getFromFormArrayControlVal("Amount", index));
        amt = Math.abs(Camt);
        if (processFlag == 'DN') {
          actualamt = (flagtoggle) ? amt : (amt * -1);
        }
        if (processFlag == 'CN') {
          actualamt = (flagtoggle) ? amt : (amt * -1);

        }
        console.log('flagtoggle:' + flagtoggle + ",amt:" + amt + ",actualamt:" + actualamt);
        total = total + actualamt;
      }

    });
    this.totalAmount = total;
    console.log(this.totalAmount, 'totalamount');
  }

  /* delete receitdetails row */
  deleteReceipt(ev) {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = RSAMSGConstants.BTNPROCEED) {
        const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
        control.removeAt(ev.index);
        console.log(control.controls[0].get('AmountCr'), 'control.controls[0].get()');
        if (control.controls[0].get('AmountCr') === null) {
          if (this.isDebitNote) {
            this.getActualAmountSum('DN');
          }
          if (this.isCreditNote) {
            this.getActualAmountSum('CN');
          }
          if (this.isPayment) {
            this.getActualAmountSumPayment();
          }// if not Journal V flow
        } else {
          this.getSumDr();
          this.getSumCr();
        }
      }
    });
  }

  // setting current Tab Index to activiate tab
  setcurrentTbIndex(tab) {
    let tabVal = tab.toLowerCase();
    switch (tabVal) {
      case 'cheque':
        this.currentTbIndex = 0;
        break;
      case 'cash':
        this.currentTbIndex = 1;
        break;
      case 'bank transfer':
        this.currentTbIndex = 2;
        break;
      // case 'Credit Card':
      //   this.currentTbIndex = 3;
      //   break;
    }
  }


  // Displaying the  confirmation alert on tab click
  confirmTabSwitch(event) {
    const parentElement = event.target.parentElement;
    const target = event.target.parentElement.text;
    if (event.target.tagName === 'SPAN' && !parentElement.classList.contains('active') && parentElement.classList.contains('nav-link')) {
      if (this.mainVoucherForm.dirty) {
        // --- showing popup only you have added or changed something
        this.displayAlertModal({
          'title': RSAMSGConstants.MODELTITLE,
          'txt': RSAMSGConstants.PAYMENTMODECHANGEMSG,
          'btnaction': RSAMSGConstants.BTNPROCEED,
          'btncancel': RSAMSGConstants.BTNCANCEL,
        });



        this.bsModalRef.content.valueChange.subscribe((data) => {
          console.log(data);
          // changing the currentTbIndex if user proceed
          if (data = RSAMSGConstants.BTNPROCEED) {
            console.log(this.currentTbIndex);
            setTimeout(() => {
              this.setcurrentTbIndex(target);
            }, 0);
            setTimeout(() => {
              this.tabset.tabs.forEach(item => {
                if (item.heading == target) {
                  item.active = true;
                }
              });
            }, 1);
            if (sessionStorage.getItem('PaymentStateExists') != null) {
              sessionStorage.setItem('PaymentStateExists', 'false');
            }
          }
        });
      } else {
        setTimeout(() => {
          this.setcurrentTbIndex(target);
        }, 0);
        setTimeout(() => {
          this.tabset.tabs.forEach(item => {
            if (item.heading == target) {
              item.active = true;
            }
          });
        }, 1);

      }

    }
  }

  /* set default Header Data   */
  setdefaultHeaderData() {
    console.log(this.terminals[0]);
    console.log(this.payeedataBankName[0].Code);

    // if (this.paymentMode == 2) {
    //   this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankCode
    //     .setValue(this.payeedataBankName[0].Code);
    // }

    // if (this.paymentMode == 5) {
    //   this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankCode
    //     .setValue(this.payeedataBankName[0].Code);
    // }

  }

  /* using for reseting the form */
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      console.log(formGroup.controls);
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.reset();
      }
      if (control instanceof FormGroup) {
        control.reset();
      }
    });
  }



  // validateDetailInfoPayment() {
  //   this.glerrorcount = 0;
  //   (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
  //     item.get('Amount').updateValueAndValidity();
  //     item.get('Amount').markAsTouched();
  //     item.get('GLCode').updateValueAndValidity();
  //     item.get('GLCode').markAsTouched();

  //     if (item.get('GLCode').value == null || item.get('GLCode').value == undefined || item.get('GLCode').value == "") {
  //       this.glerrorcount = this.glerrorcount + 1;
  //     }
  //     if (item.get('Amount').value == null || item.get('Amount').value == 0 || item.get('Amount').value == undefined
  //       || item.get('Amount').value == "") {
  //       this.glerrorcount = this.glerrorcount + 1;
  //     }
  //   });
  // }



  validateAmount(len) {
    let countAmounterror = 0;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {
      // if(this.getFromFormArrayControlVal("newAddedRow",index))
      if (index != len) {
        if (this.getFromFormArrayControlVal("Amount", index) == undefined || this.getFromFormArrayControlVal("Amount", index) == 0)
          countAmounterror = countAmounterror + 1;
      }
    });
    if (countAmounterror > 0) {
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.AMOUNTVALIDATIONMSG,
        'btncancel': RSAMSGConstants.OKTEXT,
      });

      return false;
    }
    else
      return true;
  }
  get receiptdate() { return this.mainVoucherForm.get('VoucherDate'); }
  GetAccountingDates(voucherDate) {
    if (!voucherDate || voucherDate === '') {
      voucherDate = new Date();
    }
    if (typeof voucherDate === 'string') {
      let dateValueParts = voucherDate.split('/');
      voucherDate = new Date(Number(dateValueParts[2]), Number(dateValueParts[1]) - 1, Number(dateValueParts[0]));
    }
    this.minDateRd = new Date(sessionStorage.getItem('accntStartDate'));
    this.maxDateRd = new Date(sessionStorage.getItem('accntEndDate'));
    const sysDate = new Date();

    if (voucherDate < this.minDateRd) {
      if (sysDate < this.minDateRd) {
        this.receiptAccountingDate = new DatePipe('en-US').transform(this.minDateRd, 'dd/MM/yyyy');
      }
      else {
        this.receiptAccountingDate = new DatePipe('en-US').transform(sysDate, 'dd/MM/yyyy');
      }
    }
    else {
      this.receiptAccountingDate = new DatePipe('en-US').transform(voucherDate, 'dd/MM/yyyy');
    }
    this.receiptdate.setValue(this.receiptAccountingDate);
  }
  changeVoucherDate() {
    if (typeof (this.receiptdate.value) !== 'string') {
      const receiptDate = this.receiptdate.value;
      this.receiptdate.setValue(this.receiptAccountingDate);
      let showConfirm;
      let modelContent;
      let getConfirm;
      if (receiptDate > this.maxDateRd) {
        showConfirm = true;
        getConfirm = true;
        modelContent = RSAMSGConstants.VOUCHERDATEGREATERTHANACCOUNTINGEND;
      }
      else if (receiptDate < this.minDateRd) {
        showConfirm = true;
        getConfirm = false;
        modelContent = RSAMSGConstants.VOUCHERDATELESSERTHANACCOUNTINGEND;
      }
      if (showConfirm) {
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = '';
        this.bsModalRef.content.modelBodyContent = modelContent;
        this.bsModalRef.content.cancelBtn = getConfirm ? RSAMSGConstants.NOTEXT : null;
        this.bsModalRef.content.actionBtn = getConfirm ? RSAMSGConstants.YESTEXT : RSAMSGConstants.OKTEXT;
        this.bsModalRef.content.valueChange.subscribe((data) => {
          if (data.toString().trim() === 'YES') {
            this.receiptAccountingDate = new DatePipe('en-US').transform(receiptDate, 'dd/MM/yyyy');
            this.receiptdate.setValue(this.receiptAccountingDate);
          }
          this.bsModalRef.hide();
        });
      }
      else {
        this.receiptAccountingDate = new DatePipe('en-US').transform(receiptDate, 'dd/MM/yyyy');
        this.receiptdate.setValue(this.receiptAccountingDate);
      }
    }
  }
}



