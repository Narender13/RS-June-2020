import { NgModule } from '@angular/core';
import { Routes, RouterModule, CanActivate } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { Page404Component } from './core/page404/page404.component';
import { Page401Component } from './core/page401/page401.component';
import { TechnicalErrorComponent } from 'src/app/core/technicalError/technicalerror.component';
import { LoginComponent } from 'src/app/login/login/login.component';
import { AuthService } from 'src/app/core/guard/services/auth.service';
import { AuthenticationGuard } from 'microsoft-adal-angular6';
import { AuthGuard } from 'src/app/core/guard/auth.guard';
import { DummyCompComponent } from './shared/dummy-comp/dummy-comp.component';
import { environment } from 'src/environments/environment.uat';

const routes: Routes = [
    { path: 'accessdenied', component: Page401Component, data: { title: 'page not found' } },
    { path: '', component: DummyCompComponent, canActivate: [AuthenticationGuard] },
    {
        path: 'finance', component: HomeComponent,
        canActivate: [AuthenticationGuard, AuthGuard]

    },
    { path: 'login', component: LoginComponent },
    {
        path: 'finance/search-top', loadChildren: 'src/app/finance/finance.module#FinanceModule',
        canActivate: [AuthenticationGuard, AuthGuard]
    },
    {
        path: 'finance/search', loadChildren: 'src/app/finance/finance.module#FinanceModule', canActivate: [AuthenticationGuard, AuthGuard]

    },
    {
        path: 'finance/draft', loadChildren: 'src/app/finance/finance.module#FinanceModule', canActivate: [AuthenticationGuard, AuthGuard]
        //canActivate:[AuthGuard]
    },
    {
        path: 'admin', loadChildren: 'src/app/administration/administration.module#AdministrationModule',
        canActivate: [AuthenticationGuard, AuthGuard]
    },
    {
        path: 'underwriting', loadChildren: 'src/app/underwriting/underwriting.module#UnderwritingModule',
        canActivate: [AuthenticationGuard]
    },
    // {
    //     path: 'underwriting',
    //     loadChildren: () => import('src/app/underwriting/underwriting.module').then(mod => mod.UnderwritingModule),
    //     canActivate: [AuthenticationGuard]
    // },

    {
        path: '', loadChildren: 'src/app/finance/finance.module#FinanceModule', canActivate: [AuthenticationGuard, AuthGuard]
        //canActivate:[AuthGuard]
    },

    { path: 'technicalError', component: TechnicalErrorComponent, data: { title: 'Technical Error found' } },
    { path: 'pagenotfound', component: Page404Component, data: { title: 'page not found' } },

    {
        path: '**', component: Page404Component, data: { title: 'page not found' }

    },
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { onSameUrlNavigation: 'reload', enableTracing: !environment.production })],
    exports: [RouterModule],
    providers: [
        AuthService
    ]
})
export class AppRoutingModule { }
