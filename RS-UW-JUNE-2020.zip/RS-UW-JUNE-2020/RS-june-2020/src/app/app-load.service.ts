import { Injectable, OnDestroy } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { map, catchError, tap } from 'rxjs/operators';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
import { UserProfile } from 'src/app/shared/model/userprofile';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import { Subject, of, Subscription } from 'rxjs';
import { MessageService } from './core/message/service/message.service';
import { Router } from '@angular/router';
import { JupiterUser } from './underwriting/entity/user';


@Injectable({
  providedIn: 'root'
})
export class AppLoadService {
  headerMenuDropdownChange = false;
  currentModuleHeader: string;
  returndata: any;
  errormsg: string;
  sub: Subscription;
  currentUserPermison = [];
  currentLoginuser: JupiterUser;
  private isUserLogedInChangedSource = new Subject<boolean>();
  isUserLogedInChangedObservable = this.isUserLogedInChangedSource.asObservable();

  /* user login details and update user changed */
  private currentUserChangedSource = new Subject<JupiterUser>();
  currentUserChanged = this.currentUserChangedSource.asObservable();

  constructor(private http: HttpClient, private messageService: MessageService, private router: Router) { }

  getUserAuthorizationData() {
    let params = new HttpParams();
    params = params.append('userName', (this.getUserId()).toString());
    params = params.append('loccode', (this.getLocationCode()).toString());
    const httpHeaders = new HttpHeaders();
    httpHeaders.append('Accept', 'application/json');
    httpHeaders.append('Content-Type', 'application/json');
    httpHeaders.append('Access-Control-Allow-Origin', '*');
    httpHeaders.append('Authorization', RSAConstants.bearer + this.getAuthToken());

    return this.http.get(RSAENDPOINTConstants.LOGIN_INTERNAL, { params: params, headers: httpHeaders })
      .pipe(
        tap((jupiterUser: JupiterUser) => {
          console.log(jupiterUser, 'login-jupiterUser');
          const obj = {
            'IsActive': jupiterUser.IsActive,
            'IsUserExist': jupiterUser.IsUserExist,
            'AllowedModules': jupiterUser.AllowedApplicationModules !== null ? true : false,
            'AllowedLocation': jupiterUser.AllowedLocations !== null ? true : false,
            'LoginData': jupiterUser
          };
          if (jupiterUser.IsActive && jupiterUser.IsUserExist) {
            sessionStorage.setItem('isAuthorized', 'true');
          } else {
            sessionStorage.setItem('isAuthorized', 'false');
          }
          if (jupiterUser.AllowedLocations === null) {
            this.router.navigate(['/accessdenied']);
          }
          jupiterUser.currentModule = jupiterUser.DefaultApplicationModule;
          this.currentUserPermison.push(obj);
          this.setCurrentUser(jupiterUser);
        }),
        catchError(this.handleError)
      );

  }
  private handleError(error: HttpErrorResponse | any) {

    if (error instanceof Error) {
      return Observable.throw(error.message || error);
    }
  }
  getAuthToken(): string {
    return sessionStorage.getItem(RSAConstants.token);

  }
  getUserId() {
    return sessionStorage.getItem('userId');

  }
  getLocationCode() {
    return sessionStorage.getItem('locationcode');
  }

  /* underWrting Purpuse */

  setCurrentUser(user: JupiterUser) {
    this.currentLoginuser = user;
    this.currentUserChangedSource.next(user);
  }

  getUserID() {
    return this.currentLoginuser.LoggedInUserId;
    // return sessionStorage.getItem('LoggedInUserId');
  }


  getCurrentLoginUser() {
    return this.currentLoginuser;
  }

  getCurrentUser() {
    return this.currentUserPermison;
  }

  getCurrentRegionCode() {
    return this.currentLoginuser.regCode;
  }

  getCurrentRegion(): string {
    if (this.currentLoginuser) {
      if (this.currentLoginuser.regCode === 1) {
        return 'KSA';
      } else if (this.currentLoginuser.regCode === 2) {
        return 'UAE';
      } else if (this.currentLoginuser.regCode === 3) {
        return 'OMAN';
      } else if (this.currentLoginuser.regCode === 5) {
        return 'BAH';
      }
    }
  }

  getCurrentLocationCode() {
    if (this.currentLoginuser) {
      return this.currentLoginuser.LocationCode;
    }
  }

  getCurrentModule() {
    if (this.currentLoginuser) {
      return this.currentLoginuser.currentModule;
    }
  }
  getCurrentLoggedInUserId() {
    if (this.currentLoginuser) {
      return this.currentLoginuser.LoggedInUserId;
    }
  }

  userRoleCheck(functionid: string | number): boolean {
    let functionids = [];
    let isMatch = false;
    if (this.currentLoginuser) {
      functionids = this.currentLoginuser.AllowedFunctionalIds;
      if (functionids.length) {
        if (functionid === 0) {
          return isMatch = true;
        } else {
          isMatch = (functionids.includes(functionid));
          return isMatch;
        }
      }
    }
  }

  isCurrentUserHaveAcess(functionid): boolean {
    return this.userRoleCheck(functionid);
  }



  /* underwrting purpuse end */


  getUserData() {
    let URL: string,
      regCode = sessionStorage.getItem(RSAConstants.regionCode);
    const httpHeaders = new HttpHeaders();
    httpHeaders.append('Accept', 'application/json');
    httpHeaders.append('Content-Type', 'application/json');
    httpHeaders.append('Access-Control-Allow-Origin', '*');
    httpHeaders.append('Authorization', RSAConstants.bearer + this.getAuthToken());

    switch (regCode) {
      case '1': {
        URL = RSAConstants.USERPROFILE_KSA;
        break;
      }
      case '2': {
        URL = RSAConstants.USERPROFILE_UAE;
        break;
      }
      case '3': {
        URL = RSAConstants.USERPROFILE_OMAN;
        break;
      }
      case '5': {
        URL = RSAConstants.USERPROFILE_BAHRAIN;
        break;
      }
    }

    return this.http.get<UserProfile>(URL, { headers: httpHeaders }).pipe(
      map(res => res),
      catchError((handleErrorObservable<any>('getUserData'))));

  }
  getUserProfileData() {
    let params = new HttpParams();
    params = params.append('email', (this.getUserId()).toString());
    return this.http.get(RSAENDPOINTConstants.USER_PROFILE, { params: params })
      .pipe(
        map(res => res),
        catchError(this.handleError)
      );

  }

  checkUserExitAndIsActive(): Observable<boolean> {
    return this.getUserAuthorizationData().pipe(map(((data) => {
      const userAsPermsion = this.currentUserPermison.every((item) => {
        console.log(item, 'auth-guard-result-check-function');
        if (item.IsActive && item.IsUserExist) {
          this.messageService.sendMessage({ 'isAuthorized': true, 'checkuser': true });
          return true;
        } else {
          return false;
        }
      });
      if (userAsPermsion) {
        return true;
      } else {
        return false;
      }
    })));
  }



}