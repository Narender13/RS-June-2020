import { Component, ChangeDetectorRef, OnInit, OnDestroy, HostListener, AfterViewInit } from '@angular/core';
import {
  Router, NavigationEnd, ActivatedRoute, RouteConfigLoadStart, RouteConfigLoadEnd,
  ActivatedRouteSnapshot, RouterStateSnapshot, NavigationStart
} from '@angular/router';
import { LoaderService } from './core/loader/loader-service';
import { HomeService } from './home/services/home.service';
import { Subscription } from 'rxjs';
import { AppLoadService } from 'src/app/app-load.service';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { AuthService } from './core/guard/services/auth.service';
import { MessageService } from 'src/app/core/message/service/message.service';
import { KeydownUserTab, mousedownUserTab, disableF12, disableRightClick } from './shared/utilites/helper';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { SharedService } from 'src/app/finance/services/shared.service';
import { exists } from 'fs';
import { MonthEndDate } from './shared/model/monthend';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  isHome = true;
  isLoading: boolean;
  countrycode: any;
  errorMsg: string;
  bannerurl: string = 'assets/images/spacer.gif';
  profileurl: string;
  private userData: any;
  returndata: any;
  errormsg: any;
  private subscription: Subscription;
  isAuthenticated: boolean;
  isAuthorized: boolean;
  isAuthorizedFlag: boolean;
  isUserAceessDenied: boolean;
  allowedFunctions: any = [];
  issessionStorage = window.sessionStorage;
  reDirectUrl = '';
  rsaModuleChanged = false;
  rsaModuleChangedItem: string;
  sub: Subscription;
  constructor(private messageService: MessageService, private router: Router,
    private loaderService: LoaderService,
    private appLoadService: AppLoadService,
    private adalSvc: MsAdalAngular6Service,
    private auth: AuthService, private alertService: AlertService,
    private sharedService: SharedService,
    private activeRoute: ActivatedRoute,
    private homeService: HomeService
  ) {

    this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationStart) {
        this.reDirectUrl = event.url;
      }
      if (event instanceof NavigationEnd) {
        this.isHome = (this.router.url === '/finance' || this.router.url === '/admin' || this.router.url === '/underwriting'
          || this.router.url === '/accessdenied' || this.router.url === '/underwriting/reports') ? true : false;
        this.isUserAceessDenied = this.router.url.includes('accessdenied');
      }
      if (event instanceof RouteConfigLoadStart) {
        this.isLoading = true;
      } else if (event instanceof RouteConfigLoadEnd) {
        this.isLoading = false;
      }

    });
    this.subscription = this.loaderService.isLoading().subscribe(loading => {
      this.isLoading = loading;
    });

  }


  ngOnInit() {
    /* keyboard tab change */
    KeydownUserTab();
    mousedownUserTab();
    this.getAuth();
    if (this.adalSvc.isAuthenticated) {
      this.isAuthenticated = true;
      if (this.getLocationCode() == null || this.getLocationCode() == undefined || this.getLocationCode() == '') {
        sessionStorage.setItem('locationcode', '0');
        sessionStorage.setItem(RSAConstants.regionCode, RSAConstants.defaultCountry);
        this.setCountry();
        console.log('country =>', sessionStorage.getItem('country'));
      }
      this.getCurrentModule();
      this.checkRSASingleSignOn();
    }

    this.messageService.getMessage().subscribe((data) => {
      if (data != null || data != undefined) {
        if (data.reset === true) {
          this.doAuthorizationRSA();
        } else {
          this.isAuthorizedFlag = data.isAuthorized || this.getAuth();
          console.log('messageservice in app', this.isAuthorizedFlag);
          if (data.isAuthorized) {
            //   this.getBannerUrl();
          }
        }
      }
    });
  }


  getCurrentModule() {
    this.sub = this.messageService.getMessage().subscribe((data) => {
      console.log(data, 'data-current-module');
      if (data.rsamoduleChanged) {
        this.rsaModuleChanged = true;
        this.rsaModuleChangedItem = data.currentModule;
        this.doAuthorizationRSA();
      }
    });
  }

  setDefaultModule() {
    if (sessionStorage) {
      if (sessionStorage.getItem('currentModule') === 'Accounts') {
        this.router.navigate(['/finance']);
      } else if (sessionStorage.getItem('currentModule') === 'Administration') {
        this.router.navigate(['/admin']);
      } else if (sessionStorage.getItem('currentModule') === 'Underwriting') {
        this.router.navigate(['/underwriting']);
      }
    }
    console.log("default module" + this.rsaModuleChangedItem);
  }

  goHome() {
    if (this.router.url === '' || this.router.url === '/' && (this.reDirectUrl === '' || this.reDirectUrl === '/')) {
      if (sessionStorage) {
        if (sessionStorage.getItem('currentModule') === 'Accounts') {
          // setTimeout(() => {
          //   this.router.navigate(['/finance']);
          // }, 1000);
          this.router.navigate(['/finance']);
        } else if (sessionStorage.getItem('currentModule') === 'Administration') {
          // setTimeout(() => {
          //   this.router.navigate(['/admin']);
          // }, 1000);
          this.router.navigate(['/admin']);
        } else if (sessionStorage.getItem('currentModule') === 'Underwriting') {
          // setTimeout(() => {
          //   this.router.navigate(['/underwriting']);
          // }, 1000);
          this.router.navigate(['/underwriting']);
        }
      }
    } else {
      let isQueryParams: boolean;
      isQueryParams = decodeURI(this.reDirectUrl).includes('?');
      if (isQueryParams) {
        const reDirectUrl: any = decodeURI(this.reDirectUrl).split('?');
        this.setCurrentModule(reDirectUrl[0]);
        const queryParams = reDirectUrl[1];
        const param = queryParams.split('&');
        let pair = null;
        const queryParamsdata = {};
        param.forEach((d: any) => {
          pair = d.split('=');
          queryParamsdata[`${pair[0]}`] = pair[1];
        });
        console.log(queryParamsdata, 'app-route-data');
        this.router.navigate([reDirectUrl[0]], {
          queryParams: queryParamsdata
        });
      } else {
        const reDirectUrl: any = decodeURI(this.reDirectUrl);
        this.setCurrentModule(reDirectUrl);
        this.router.navigate([reDirectUrl]);
      }
    }
  }

  setCurrentModule(currentmodule) {
    sessionStorage.removeItem('currentModule');
    if (currentmodule === '/admin' || currentmodule.includes('/admin')) {
      currentmodule = RSAConstants.AdministrationModule;
    }
    if (currentmodule === '/finance' || currentmodule.includes('/finance')) {
      currentmodule = RSAConstants.AccountsModule;
    }

    if (currentmodule === '/underwriting' || currentmodule.includes('/underwriting')) {
      currentmodule = RSAConstants.UnderwritingModule;
    }

    if (currentmodule !== '/accessdenied') {
      sessionStorage.setItem('currentModule', currentmodule);
    }

  }

  getBannerUrl() {
    this.bannerurl = sessionStorage.getItem("bannerurl");
  }
  getUserId() {
    return sessionStorage.getItem('userId');

  }
  getLocationCode() {
    return sessionStorage.getItem('locationcode');
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  getAuth() {
    return (sessionStorage.getItem('isAuthorized') == 'true');
  }



  doAuthorizationRSA() {
    this.appLoadService.getUserAuthorizationData().subscribe(
      data => {
        this.returndata = data;
        console.log(data, 'userdata-login-data');
        if (this.returndata && this.returndata.regCode) {
          this.getRegioncode(this.returndata.regCode);
          if (this.returndata && window.sessionStorage && this.rsaModuleChanged) {
            sessionStorage.removeItem('currentModule');
            sessionStorage.setItem('currentModule', this.rsaModuleChangedItem);
            this.returndata.currentModule = this.rsaModuleChangedItem;
            this.appLoadService.setCurrentUser(this.returndata);
            this.setDefaultModule();
            if (window.sessionStorage && sessionStorage.getItem('currentModule') === RSAConstants.AccountsModule) {
              console.log(this.rsaModuleChangedItem, 'rsaModuleChangedItem');
              this.getMonthEndDate(this.rsaModuleChangedItem);
            }
          }
          if (window.sessionStorage && !this.rsaModuleChanged) {
            sessionStorage.setItem('currentModule', this.returndata['DefaultApplicationModule']);
            this.returndata.currentModule = this.returndata['DefaultApplicationModule'];
            this.appLoadService.setCurrentUser(this.returndata);
          }
        }

        if (this.returndata.AllowedApplicationModules === null) {
          this.router.navigate(['/accessdenied']);
        }
        this.sharedService.sendMessage({ precisionDecimal: this.getRegioncode(this.returndata.regCode) });
        sessionStorage.setItem('precisionDecimalValue', this.getRegioncode(this.returndata.regCode).toString());
        if (window.sessionStorage) {
          if (!this.rsaModuleChanged) {
            this.goHome();
          }
          this.allowedFunctions = this.returndata.AllowedFunctionalIds;
          sessionStorage.setItem(RSAConstants.functionids, JSON.stringify(this.returndata.AllowedFunctionalIds));
          sessionStorage.setItem(RSAConstants.allowedModules, JSON.stringify(this.returndata.AllowedApplicationModules));
          sessionStorage.setItem(RSAConstants.allowedLocations, JSON.stringify(this.returndata.AllowedLocations));
          sessionStorage.setItem(RSAConstants.allowedMenuitems, JSON.stringify(this.returndata.AllowedMenuItems));
          sessionStorage.setItem(RSAConstants.allowedTasklists, JSON.stringify(this.returndata.AllowedTaskList));
          sessionStorage.setItem(RSAConstants.LoggedInUserId, JSON.stringify(this.returndata.LoggedInUserId));

          let al = [];
          al = this.returndata.AllowedLocations;
          let regionCode = sessionStorage.getItem(RSAConstants.regionCode);
          let locCde;
          let dftCity;
          if (regionCode === '3') {
            console.log("OMAN");
            if (al && al.length > 0) {
              locCde = this.setDefaultLocationCode(al);
              if (locCde) {
                dftCity = this.setDefaultCityDesc(locCde, al);
              } else {
                locCde = al[0].locationCode;
                dftCity = al[0].item;
              }

            }
            console.log("loccode" + locCde + " dftcity" + dftCity);
          }

          if (regionCode === '2') {
            console.log("DUBAI");
            if (al && al.length > 0) {
              locCde = this.setDefaultLocationCode(al);
              if (locCde) {
                dftCity = this.setDefaultCityDesc(locCde, al);
              } else {
                locCde = al[0].locationCode;
                dftCity = al[0].item;
              }

            }
            console.log("loccode" + locCde + " dftcity" + dftCity);
          }

          if (regionCode === '1') {
            console.log("KASA");
            if (al && al.length > 0) {
              locCde = this.setDefaultLocationCode(al);
              if (locCde) {
                dftCity = this.setDefaultCityDesc(locCde, al);
              } else {
                locCde = al[0].locationCode;
                dftCity = al[0].item;
              }

            }
            console.log("loccode" + locCde + " dftcity" + dftCity);
          }

          if (regionCode === '5') {
            console.log("Bharaian");
            if (al && al.length > 0) {
              locCde = this.setDefaultLocationCode(al);
              if (locCde) {
                dftCity = this.setDefaultCityDesc(locCde, al);
              } else {
                locCde = al[0].locationCode;
                dftCity = al[0].item;
              }

            }
            console.log("loccode" + locCde + " dftcity" + dftCity);
          }
          this.setDefaultCityOnPageReload(dftCity, locCde);
          // sessionStorage.setItem(RSAConstants.defaultcity, dftCity);
          // sessionStorage.setItem(RSAConstants.locationdesc, dftCity);
          switch (regionCode) {
            case '1':
              sessionStorage.setItem(RSAConstants.currency, "SAR");
              sessionStorage.setItem(RSAConstants.precisionDecimal, '2');
              sessionStorage.setItem(RSAConstants.defaultCurPlaceholder, '0.00');
              sessionStorage.setItem(RSAConstants.symbol, '.2-2');
              sessionStorage.setItem(RSAConstants.logourl, 'assets/images/logo_alamiya.svg');
              sessionStorage.setItem(RSAConstants.bannerurl, 'assets/images/banner_ksa.svg');
              this.bannerurl = 'assets/images/banner_ksa.svg';
              break;
            case '2':
              sessionStorage.setItem(RSAConstants.currency, "AED");
              sessionStorage.setItem(RSAConstants.precisionDecimal, '2');
              sessionStorage.setItem(RSAConstants.defaultCurPlaceholder, '0.00');
              sessionStorage.setItem(RSAConstants.symbol, '.2-2');
              sessionStorage.setItem(RSAConstants.logourl, 'assets/images/logo_rsa.svg');
              sessionStorage.setItem(RSAConstants.bannerurl, 'assets/images/banner_uae.svg');
              this.bannerurl = 'assets/images/banner_uae.svg';
              break;
            case '3':
              sessionStorage.setItem(RSAConstants.currency, "RO");
              sessionStorage.setItem(RSAConstants.precisionDecimal, '3');
              sessionStorage.setItem(RSAConstants.defaultCurPlaceholder, '0.000');
              sessionStorage.setItem(RSAConstants.symbol, '.3-3');
              sessionStorage.setItem(RSAConstants.logourl, 'assets/images/logo_oman.jpg');
              sessionStorage.setItem(RSAConstants.bannerurl, 'assets/images/banner_oman.svg');
              RSAConstants.TaxInvoiceTitle = 'Debit Note';
              this.bannerurl = 'assets/images/banner_oman.svg';
              break;
            case '5':
              sessionStorage.setItem(RSAConstants.currency, "BHD");
              sessionStorage.setItem(RSAConstants.precisionDecimal, '3');
              sessionStorage.setItem(RSAConstants.defaultCurPlaceholder, '0.000');
              sessionStorage.setItem(RSAConstants.symbol, '.3-3');
              sessionStorage.setItem(RSAConstants.logourl, 'assets/images/logo_rsa.svg');
              sessionStorage.setItem(RSAConstants.bannerurl, 'assets/images/banner_bahrain.svg');
              this.bannerurl = 'assets/images/banner_bahrain.svg';
              break;
          }
          console.log('RSAConstants.currency', sessionStorage.getItem(RSAConstants.currency));
          console.log('RSAConstants.precisionDecimal', sessionStorage.getItem(RSAConstants.precisionDecimal));
          sessionStorage.setItem(RSAConstants.allowedAdminMenuitems, JSON.stringify(this.returndata.AllowedAdminMenuItems));
          console.log(this.reDirectUrl, 'reDirectUrl');
          this.isAuthorized = true;
          sessionStorage.setItem('isAuthorized', 'true');
          this.messageService.sendMessage({ 'isAuthorized': true });

        }
      },
    );
    //return returnVal;
  }
  checkdefaultBranchExists(resultData: any) {
    let matchedOrNot: boolean = false;
    if (resultData && resultData.length > 0) {
      resultData.forEach(element => {
        if (Number(element.locationCode) === RSAConstants.OMANDefaultlocCode) {
          matchedOrNot = true;
        }
      });
      return matchedOrNot;
    } else {
      return false;
    }
  }
  setDefaultLocationCode(resultData: any) {
    let locationcode: number;
    if (resultData && resultData.length > 0) {
      resultData.forEach(element => {
        if (element.defaultLocation === 1) {
          locationcode = element.locationCode;
        }
      });
      return locationcode;
    }
  }
  setDefaultCityDesc(loccode: any, resultData: any) {
    let defaultValue: string;
    if (resultData && resultData.length > 0) {
      resultData.forEach(element => {
        if (Number(loccode) === Number(element.locationCode)) {
          defaultValue = element.item;
        }
      });
      return defaultValue;
    }
  }

  getMonthEndDate(currentmodule): void {
    this.homeService.getMonthEndDate(currentmodule).subscribe((monthEndDate: MonthEndDate) => {
      sessionStorage.setItem('accntStartDate', monthEndDate.StartDate.toString());
      sessionStorage.setItem('accntEndDate', monthEndDate.EndDate.toString());

    });
  }

  getRegioncode(regCode) {
    if (regCode === 0 || regCode === 2 || regCode === 4 || regCode === 1) {
      return 2;
    }
    if (regCode === 3 || regCode === 5) {
      return 3;
    }
  }

  checkRSASingleSignOn() {
    let returnval: boolean = true;


    if (this.adalSvc.isAuthenticated) {
      if (this.adalSvc.userInfo)
        this.auth.setUserInfo(this.adalSvc.userInfo);
      this.adalSvc.acquireToken(RSAConstants.ADFS_APP_URL).subscribe((token: string) => {
        if (token == null) {
          this.getRefreshToken();
        } else {
          this.auth.sendToken(token);
          this.doAuthorizationRSA();
        }
      });

    }
    else {
      this.logoutADFC();
    }

  }
  getRefreshToken() {
    console.log("refreshed token");
    this.adalSvc.RenewToken(RSAConstants.ADFS_APP_URL);
    this.adalSvc.acquireToken(RSAConstants.ADFS_APP_URL).subscribe((token: string) => {
      this.auth.sendToken(token);
      this.doAuthorizationRSA();
    });
  }

  logoutADFC() {
    this.adalSvc.logout();
    sessionStorage.clear();
  }
  setCountry() {
    if (sessionStorage) {
      let country: string;
      if (sessionStorage.getItem(RSAConstants.regionCode)) {
        switch (sessionStorage.getItem(RSAConstants.regionCode)) {
          case "1": {
            country = RSAConstants.countryKSA;
            break;
          }
          case "2": {
            country = RSAConstants.countryUAE;
            break;
          }
          case "3": {
            country = RSAConstants.countryOMAN;
            break;
          }
          case "5": {
            country = RSAConstants.countryBAHRAIN;
            break;
          }
        }
        sessionStorage.setItem(RSAConstants.country, country);
      }
    }
  }

  @HostListener('document:keyup', ['$event'])
  onKeyUp(event: KeyboardEvent) {
    if (disableF12(event.keyCode)) {
      this.alertService.info(RSAMSGConstants.DISABLEKEYMESSAGE);
      event.preventDefault();
    }
  }
  @HostListener('document:keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    if (disableF12(event.keyCode)) {
      this.alertService.info(RSAMSGConstants.DISABLEKEYMESSAGE);
      event.preventDefault();
    }
  }

  setDefaultCityOnPageReload(dftCity, locCde) {
    const ifCityinSession = 'defaultcity' in sessionStorage && 'locationdesc' in sessionStorage;
    if (!ifCityinSession) {
      sessionStorage.setItem('locationcode', JSON.stringify(locCde));
      sessionStorage.setItem(RSAConstants.defaultcity, dftCity);
      sessionStorage.setItem(RSAConstants.locationdesc, dftCity);
    }
  }
  @HostListener('document:contextmenu', ['$event'])
  onRightClick(event) {
    if (disableRightClick()) {
      this.alertService.info(RSAMSGConstants.DISABLEKEYMESSAGE);
      event.preventDefault();
    }
  }
}

