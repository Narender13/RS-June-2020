npm install 
npm update caniuse-lite browserslist
ng build --prod